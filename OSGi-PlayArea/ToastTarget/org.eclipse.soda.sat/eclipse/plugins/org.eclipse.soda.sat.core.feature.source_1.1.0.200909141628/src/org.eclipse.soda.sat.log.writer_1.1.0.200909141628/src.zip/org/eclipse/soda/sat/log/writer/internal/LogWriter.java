/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.log.writer.internal;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.ServiceReferenceUtility;
import org.osgi.framework.Bundle;
import org.osgi.framework.ServiceReference;
import org.osgi.service.log.LogEntry;
import org.osgi.service.log.LogListener;
import org.osgi.service.log.LogReaderService;
import org.osgi.service.log.LogService;

/**
 * LogWriter.java
 */
public class LogWriter extends Object {
	private static final String THRESHOLD_PROPERTY = "org.eclipse.soda.sat.log.writer.internal.threshold"; //$NON-NLS-1$

	private static final String DEBUG_THRESHOLD_STRING = "debug"; //$NON-NLS-1$
	private static final String INFO_THRESHOLD_STRING = "info"; //$NON-NLS-1$
	private static final String WARNING_THRESHOLD_STRING = "warning"; //$NON-NLS-1$
	private static final String ERROR_THRESHOLD_STRING = "error"; //$NON-NLS-1$

	private static final int DEBUG_THRESHOLD = 0;
	private static final int INFO_THRESHOLD = 1;
	private static final int WARNING_THRESHOLD = 2;
	private static final int ERROR_THRESHOLD = 3;

	public static final String LINE_SEPARATOR = System.getProperty("line.separator");  //$NON-NLS-1$

	private int threshold;
	private LogReaderService reader;
	private LogListener listener;
	private ICharBuffer buffer;

	/**
	 * Constructor
	 */
	public LogWriter() {
		super();
		initialize();
		setBuffer(createBuffer());
	}

	/**
	 * Bind the LogReaderService to the receiver.
	 *
	 * @param reader  A LogReaderService.
	 */
	public void bind(LogReaderService reader) {
		setReader(reader);
		startup();
	}

	private ICharBuffer createBuffer() {
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(250);
		return buffer;
	}

	/**
	 * Create a LogListener.
	 */
	private LogListener createListener() {
		return new LogListener() {
			public void logged(LogEntry entry) {
				LogWriter.this.logged(entry);
			}
		};
	}

	/**
	 * Drain the log to date.
	 */
	private void drainLog() {
		LogReaderService reader = getReader();
		Enumeration/*<LogEntry>*/ enumeration = reader.getLog();
		List/*<LogEntry>*/ list = new ArrayList(100);
		LogEntry entry;

		while (enumeration.hasMoreElements() == true) {
			entry = (LogEntry) enumeration.nextElement();
			list.add(entry);
		}

		int size = list.size();

		for (int i = size - 1; i >= 0; i--) {
			entry = (LogEntry) list.get(i);
			logged(entry);
		}
	}

	/**
	 * Format a message for logging.
	 *
	 * @see LogService.LOG_DEBUG
	 * @see LogService.LOG_ERROR
	 * @see LogService.LOG_INFO
	 * @see LogService.LOG_WARNING
	 */
	private String formatLogMessage(ServiceReference reference, int level, String message) {
		String logMessage;
		String levelText = getLevelText(level);
		ICharBuffer buffer = getBuffer();

		synchronized (buffer) {
			// Since the buffer is reused, it must be emptied before each use.
			buffer.setLength(0);

			buffer.append('[');
			buffer.append(levelText);
			buffer.append(']');
			buffer.append(' ');
			buffer.append(message);

			if (reference != null) {
				Bundle bundle = reference.getBundle();
				if (bundle != null) {
					String symbolicName = bundle.getSymbolicName();
					long id = bundle.getBundleId();
					buffer.append(',');
					buffer.append("bundle"); //$NON-NLS-1$
					buffer.append('=');
					buffer.append(symbolicName);
					buffer.append(' ');
					buffer.append('[');
					buffer.append(id);
					buffer.append(']');
				}

				List/*<String>*/ names = getServiceNames(reference);
				boolean empty = names.isEmpty();
				if (empty == false) {
					buffer.append(',');
					buffer.append(' ');
					buffer.append("services"); //$NON-NLS-1$
					buffer.append('=');
					buffer.append('[');

					Iterator/*<String>*/ iterator = names.iterator();
					while (iterator.hasNext() == true) {
						Object name = iterator.next();
						buffer.append(name);

						if (iterator.hasNext() == true) {
							buffer.append(',');
							buffer.append(' ');
						}
					}
					buffer.append(']');
				}
			}

			buffer.append(LogWriter.LINE_SEPARATOR);
			logMessage = buffer.toString();
		}

		return logMessage;
	}

	private ICharBuffer getBuffer() {
		return buffer;
	}

	/**
	 * Answer a textual description of the level.
	 *
	 * @see LogService.LOG_DEBUG
	 * @see LogService.LOG_ERROR
	 * @see LogService.LOG_INFO
	 * @see LogService.LOG_WARNING
	 */
	private String getLevelText(int level) {
		String text;

		switch (level) {
			case LogService.LOG_ERROR:
				text = "ERROR"; //$NON-NLS-1$
				break;

			case LogService.LOG_WARNING:
				text = "WARNING"; //$NON-NLS-1$
				break;

			case LogService.LOG_INFO:
				text = "INFO"; //$NON-NLS-1$
				break;

			case LogService.LOG_DEBUG:
				text = "DEBUG"; //$NON-NLS-1$
				break;

			default:
				text = "<UNKNOWN>"; //$NON-NLS-1$
				break;
		}

		return text;
	}

	/**
	 * Private listener getter.
	 */
	private LogListener getListener() {
		return listener;
	}

	/**
	 * Answers the OutputStream used by the receiver.
	 *
	 * @see LogService.LOG_DEBUG
	 * @see LogService.LOG_ERROR
	 * @see LogService.LOG_INFO
	 * @see LogService.LOG_WARNING
	 */
	private OutputStream getOutputStream(int level) {
		OutputStream stream;

		if (level == LogService.LOG_INFO || level == LogService.LOG_DEBUG) {
			stream = System.out;
		} else {
			stream = System.err;
		}

		return stream;
	}

	/**
	 * Private reader getter.
	 */
	private LogReaderService getReader() {
		return reader;
	}

	/**
	 * Query the service names available from a ServiceReference.
	 */
	private List/*<String>*/ getServiceNames(ServiceReference reference) {
		ServiceReferenceUtility utility = ServiceReferenceUtility.getInstance();
		List/*<String>*/ names = utility.getServiceNames(reference);
		return names;
	}

	private int getThreshold() {
		return threshold;
	}

	private void initialize() {
		String value = System.getProperty(LogWriter.THRESHOLD_PROPERTY, LogWriter.DEBUG_THRESHOLD_STRING);
		int threshold;

		if (LogWriter.DEBUG_THRESHOLD_STRING.equalsIgnoreCase(value)) {
			threshold = LogWriter.DEBUG_THRESHOLD;
		} else if (LogWriter.INFO_THRESHOLD_STRING.equalsIgnoreCase(value)) {
			threshold = LogWriter.INFO_THRESHOLD;
		} else if (LogWriter.WARNING_THRESHOLD_STRING.equalsIgnoreCase(value)) {
			threshold = LogWriter.WARNING_THRESHOLD;
		} else if (LogWriter.ERROR_THRESHOLD_STRING.equalsIgnoreCase(value)) {
			threshold = LogWriter.ERROR_THRESHOLD;
		} else {
			throw new RuntimeException("Illegal threshold property value: " + LogWriter.THRESHOLD_PROPERTY + '=' + value); //$NON-NLS-1$
		}

		setThreshold(threshold);
		LogUtility.setLoggingLevel(LogService.LOG_DEBUG);
	}

	/**
	 * Listener method called for each LogEntry object created.
	 */
	private void logged(LogEntry entry) {
		int level = entry.getLevel();
		int threshold = getThreshold();
		OutputStream stream = getOutputStream(level);

		switch (level) {
			case LogService.LOG_ERROR :
				if (threshold <= LogWriter.ERROR_THRESHOLD) {
					logToStream(entry, stream);
				}
				break;
			case LogService.LOG_WARNING :
				if (threshold <= LogWriter.WARNING_THRESHOLD) {
					logToStream(entry, stream);
				}
				break;
			case LogService.LOG_INFO :
				if (threshold <= LogWriter.INFO_THRESHOLD) {
					logToStream(entry, stream);
				}
				break;
			case LogService.LOG_DEBUG :
				if (threshold <= LogWriter.DEBUG_THRESHOLD) {
					logToStream(entry, stream);
				}
				break;
			default:
				break;
		}
	}

	/**
	 * Log the specified entry to the specified stream.
	 */
	private void logToStream(LogEntry entry, OutputStream stream) {
		ServiceReference reference = entry.getServiceReference();
		int level = entry.getLevel();
		String message = entry.getMessage();
		String logMessage = formatLogMessage(reference, level, message);
		byte[] bytes = logMessage.getBytes();

		try {
			stream.write(bytes);
			stream.flush();

			Throwable throwable = entry.getException();

			if (throwable != null) {
				throwable.printStackTrace();
			}
		} catch (IOException exception) {
			exception.printStackTrace();
		}
	}

	private void setBuffer(ICharBuffer buffer) {
		this.buffer = buffer;
	}

	/**
	 * Private listener setter.
	 */
	private void setListener(LogListener listener) {
		LogReaderService reader = getReader();

		if (this.listener != null) {
			reader.removeLogListener(this.listener);
		}

		this.listener = listener;

		if (this.listener != null) {
			reader.addLogListener(this.listener);
		}
	}

	/**
	 * Private reader setter.
	 */
	private void setReader(LogReaderService reader) {
		this.reader = reader;
	}

	private void setThreshold(int threshold) {
		this.threshold = threshold;
	}

	/**
	 * Shutdown the receiver.
	 */
	private void shutdown() {
		LogListener listener = getListener();

		synchronized (this) {
			if (listener == null)
				return;  // Early return.
			setListener(null);
		}
	}

	/**
	 * Start up the receiver.
	 */
	private void startup() {
		synchronized (this) {
			if (listener != null)
				return;  // Early return.
			LogListener listener = createListener();
			setListener(listener);
		}

		drainLog();
	}

	/**
	 * Unbind the receiver.
	 */
	public void unbind() {
		shutdown();
		setReader(null);
	}
}
