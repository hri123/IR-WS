/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.log.writer.internal.bundle;

import org.eclipse.soda.sat.core.framework.BaseBundleActivator;
import org.eclipse.soda.sat.log.writer.internal.LogWriter;
import org.osgi.service.log.LogReaderService;

/**
 * LogWriterActivator.java
 */
public class LogWriterActivator extends BaseBundleActivator {
	private static final String LOG_READER_SERVICE_NAME = LogReaderService.class.getName();
	private LogWriter writer;

	/**
	 * Constructor.
	 */
	public LogWriterActivator() {
		super();
		setWriter(new LogWriter());
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#activate()
	 */
	protected void activate() {
		LogReaderService reader = getLogReaderService();
		LogWriter writer = getWriter();
		writer.bind(reader);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#deactivate()
	 */
	protected void deactivate() {
		LogWriter writer = getWriter();
		writer.unbind();
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#getImportedServiceNames()
	 */
	protected String[] getImportedServiceNames() {
		return new String[] {
			LogReaderService.class.getName()
		};
	}

	/**
	 * Get the imported LogReaderService.
	 */
	private LogReaderService getLogReaderService() {
		return (LogReaderService) getImportedService(LogWriterActivator.LOG_READER_SERVICE_NAME);
	}

	/**
	 * Private writer getter.
	 */
	private LogWriter getWriter() {
		return writer;
	}

	/**
	 * Private writer setter.
	 */
	private void setWriter(LogWriter writer) {
		this.writer = writer;
	}
}