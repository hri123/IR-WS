/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.equinox.console.cmdprov;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.eclipse.osgi.framework.console.CommandInterpreter;
import org.eclipse.soda.sat.core.service.BundleDependencyService;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.eclipse.soda.sat.internal.equinox.console.cmdprov.nls.Messages;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;

public class MissingImportedServicesCommandProvider extends AbstractCommandProvider {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String ALL_MISSING_IMPORTED_SERVICES_DESCRIPTION_KEY = "MissingImportedServicesCommandProvider.AllMissingImportedServicesDescription";  //$NON-NLS-1$
	private static final String IDENTIFIERS_DESCRIPTION_KEY = "MissingImportedServicesCommandProvider.IdentifiersDescription";  //$NON-NLS-1$
	private static final String MISSING_OPTIONAL_IMPORTED_SERVICES_KEY = "MissingImportedServicesCommandProvider.MissingOptionalImportedServices";  //$NON-NLS-1$
	private static final String MISSING_OPTIONAL_IMPORTED_SERVICES_DESCRIPTION_KEY = "MissingImportedServicesCommandProvider.MissingOptionalImportedServicesDescription";  //$NON-NLS-1$
	private static final String MISSING_REQUIRED_IMPORTED_SERVICES_KEY = "MissingImportedServicesCommandProvider.MissingRequiredImportedServices";  //$NON-NLS-1$
	private static final String MISSING_REQUIRED_IMPORTED_SERVICES_DESCRIPTION_KEY = "MissingImportedServicesCommandProvider.MissingRequiredImportedServicesDescription";  //$NON-NLS-1$
	private static final String TITLE_KEY = "MissingImportedServicesCommandProvider.Title";  //$NON-NLS-1$

	// Externalized String Values
	private static final String ALL_MISSING_IMPORTED_SERVICES_DESCRIPTION = Messages.getString(MissingImportedServicesCommandProvider.ALL_MISSING_IMPORTED_SERVICES_DESCRIPTION_KEY);
	private static final String IDENTIFIERS_DESCRIPTION = Messages.getString(MissingImportedServicesCommandProvider.IDENTIFIERS_DESCRIPTION_KEY);
	private static final String MISSING_OPTIONAL_IMPORTED_SERVICES = Messages.getString(MissingImportedServicesCommandProvider.MISSING_OPTIONAL_IMPORTED_SERVICES_KEY);
	private static final String MISSING_OPTIONAL_IMPORTED_SERVICES_DESCRIPTION = Messages.getString(MissingImportedServicesCommandProvider.MISSING_OPTIONAL_IMPORTED_SERVICES_DESCRIPTION_KEY);
	private static final String MISSING_REQUIRED_IMPORTED_SERVICES = Messages.getString(MissingImportedServicesCommandProvider.MISSING_REQUIRED_IMPORTED_SERVICES_KEY);
	private static final String MISSING_REQUIRED_IMPORTED_SERVICES_DESCRIPTION = Messages.getString(MissingImportedServicesCommandProvider.MISSING_REQUIRED_IMPORTED_SERVICES_DESCRIPTION_KEY);
	private static final String TITLE = Messages.getString(MissingImportedServicesCommandProvider.TITLE_KEY);

	// Non-Externalized String Patterns
	private static final String IDENTIFIERS_COMMAND_HELP = "ids - {0}";  //$NON-NLS-1$
	private static final String MISSING_OPTIONAL_IMPORTED_SERVICES_COMMAND_HELP = "mos [id] - {0}";  //$NON-NLS-1$
	private static final String MISSING_REQUIRED_IMPORTED_SERVICES_COMMAND_HELP = "mrs [id] - {0}";  //$NON-NLS-1$
	private static final String ALL_MISSING_IMPORTED_SERVICES_COMMAND_HELP = "ams [id] - {0}";  //$NON-NLS-1$

	//
	// Instance Fields
	//

	private BundleDependencyService model;

	//
	// Constructors
	//

	public MissingImportedServicesCommandProvider(BundleContext bundleContext, BundleDependencyService bundleDependencyService) {
		super(bundleContext);
		setModel(bundleDependencyService);
	}

	//
	// Instance Methods
	//

	public void _ams(CommandInterpreter interpreter) throws Exception {
		setInterpreter(interpreter);
		List/*<String>*/ ids = getIds();
		try {
			appendMissingRequiredImportedServices(ids);
			appendMissingOptionalImportedServices(ids);
		} finally {
			flushBuffer();
		}
	}

	public void _ids(CommandInterpreter interpreter) throws Exception {
		setInterpreter(interpreter);
		List/*<String>*/ ids = getAllIds();
		try {
			append(ids);
		} finally {
			flushBuffer();
		}
	}

	public void _missing(CommandInterpreter interpreter) throws Exception {
		setInterpreter(interpreter);
		try {
			appendAllMissingImportedServices();
		} finally {
			flushBuffer();
		}
	}

	public void _mos(CommandInterpreter interpreter) throws Exception {
		setInterpreter(interpreter);
		List/*<String>*/ ids = getIds();
		try {
			appendMissingOptionalImportedServices(ids);
		} finally {
			flushBuffer();
		}
	}

	public void _mrs(CommandInterpreter interpreter) throws Exception {
		setInterpreter(interpreter);
		List/*<String>*/ ids = getIds();
		try {
			appendMissingRequiredImportedServices(ids);
		} finally {
			flushBuffer();
		}
	}

	private void appendAllMissingImportedServices() {
		List/*<String>*/ ids = getAllIds();
		int size = ids.size();
		List/*<String>*/ list = new ArrayList/*<String>*/(size);
		Iterator/*<String>*/ iterator = ids.iterator();

		while (iterator.hasNext() == true) {
			String id = (String) iterator.next();
			collectMissingRequiredImportedServices(id, list);
			collectMissingOptionalImportedServices(id, list);
		}

		Set/*<String>*/ set = new TreeSet/*<String>*/(list);
		append(set);
	}

	private void appendMissingImportedServices(String id, List/*<String>*/ names, String pattern) {
		boolean empty = names.isEmpty();
		if (empty == true)
			return;  // Early return.

		String message = MessageFormatter.format(pattern, id);
		appendLine(message);
		Collections.sort(names);
		Iterator/*<String>*/ iterator = names.iterator();

		while (iterator.hasNext() == true) {
			String name = (String) iterator.next();
			appendIndent();
			appendLine(name);
		}
	}

	private void appendMissingOptionalImportedServices(List/*<String>*/ ids) throws Exception {
		Iterator/*<String>*/ iterator = ids.iterator();

		while (iterator.hasNext() == true) {
			String id = (String) iterator.next();
			appendMissingOptionalImportedServices(id);
		}
	}

	private void appendMissingOptionalImportedServices(String id) {
		List/*<String>*/ names = getMissingOptionalImportedServices(id);
		appendMissingImportedServices(id, names, MissingImportedServicesCommandProvider.MISSING_OPTIONAL_IMPORTED_SERVICES);
	}

	private void appendMissingRequiredImportedServices(List/*<String>*/ ids) throws Exception {
		Iterator/*<String>*/ iterator = ids.iterator();

		while (iterator.hasNext() == true) {
			String id = (String) iterator.next();
			appendMissingRequiredImportedServices(id);
		}
	}

	private void appendMissingRequiredImportedServices(String id) {
		List/*<String>*/ names = getMissingRequiredImportedServices(id);
		appendMissingImportedServices(id, names, MissingImportedServicesCommandProvider.MISSING_REQUIRED_IMPORTED_SERVICES);
	}

	private void collectMissingOptionalImportedServices(String id, List/*<String>*/ list) {
		List/*<String>*/ missing = getMissingOptionalImportedServices(id);
		list.addAll(missing);
	}

	private void collectMissingRequiredImportedServices(String id, List/*<String>*/ list) {
		List/*<String>*/ missing = getMissingRequiredImportedServices(id);
		list.addAll(missing);
	}

	private List/*<String>*/ getAllIdArguments() {
		List/*<String>*/ arguments = getAllArguments();
		boolean empty = arguments.isEmpty();
		if (empty == true)
			return arguments;  // Early return.

		int size = arguments.size();
		List/*<String>*/ ids = new ArrayList/*<String>*/(size);
		Iterator/*<String>*/ iterator = arguments.iterator();

		while (iterator.hasNext() == true) {
			String argument = (String) iterator.next();
			Bundle bundle = getBundle(argument);
			String id;

			if (bundle != null) {
				id = bundle.getSymbolicName();
			} else {
				id = argument;
			}

			ids.add(id);
		}

		return ids;
	}

	private List/*<String>*/ getAllIds() {
		BundleDependencyService model = getModel();
		List/*<String>*/ list = model.getBundleActivationManagerIds();
		return list;
	}

	private String getAllMissingImportedServicesCommandHelpLine() {
		return MessageFormatter.format(MissingImportedServicesCommandProvider.ALL_MISSING_IMPORTED_SERVICES_COMMAND_HELP, MissingImportedServicesCommandProvider.ALL_MISSING_IMPORTED_SERVICES_DESCRIPTION);
	}

	/**
	 * @see org.eclipse.soda.sat.internal.equinox.console.cmdprov.AbstractCommandProvider#getCommandHelpLines()
	 */
	protected String[] getCommandHelpLines() {
		return new String[] {
			getAllMissingImportedServicesCommandHelpLine(),
			getIdentifiersCommandHelpLine(),
			getMissingOptionalImportedServicesCommandHelpLine(),
			getMissingRequiredImportedServicesCommandHelpLine()
		};
	}

	private String getIdentifiersCommandHelpLine() {
		return MessageFormatter.format(MissingImportedServicesCommandProvider.IDENTIFIERS_COMMAND_HELP, MissingImportedServicesCommandProvider.IDENTIFIERS_DESCRIPTION);
	}

	private List/*<String>*/ getIds() {
		List/*<String>*/ ids = getAllIdArguments();
		boolean empty = ids.isEmpty();
		if (empty == true) {
			ids = getAllIds();
		}
		return ids;
	}

	private List/*<String>*/ getMissingOptionalImportedServices(String id) {
		BundleDependencyService model = getModel();
		List/*<String>*/ names = model.getUnacquiredOptionalImportedServiceNames(id);
		if (names == null)
			return AbstractCommandProvider.EMPTY_LIST;  // TODO IS THIS RIGHT?
		return names;
	}

	private String getMissingOptionalImportedServicesCommandHelpLine() {
		return MessageFormatter.format(MissingImportedServicesCommandProvider.MISSING_OPTIONAL_IMPORTED_SERVICES_COMMAND_HELP, MissingImportedServicesCommandProvider.MISSING_OPTIONAL_IMPORTED_SERVICES_DESCRIPTION);
	}

	private List/*<String>*/ getMissingRequiredImportedServices(String id) {
		BundleDependencyService model = getModel();
		List/*<String>*/ names = model.getUnacquiredImportedServiceNames(id);
		if (names == null)
			return AbstractCommandProvider.EMPTY_LIST;  // TODO IS THIS RIGHT?
		return names;
	}

	private String getMissingRequiredImportedServicesCommandHelpLine() {
		return MessageFormatter.format(MissingImportedServicesCommandProvider.MISSING_REQUIRED_IMPORTED_SERVICES_COMMAND_HELP, MissingImportedServicesCommandProvider.MISSING_REQUIRED_IMPORTED_SERVICES_DESCRIPTION);
	}

	private BundleDependencyService getModel() {
		return model;
	}

	/**
	 * @see org.eclipse.soda.sat.internal.equinox.console.cmdprov.AbstractCommandProvider#getTitle()
	 */
	protected String getTitle() {
		return MissingImportedServicesCommandProvider.TITLE;
	}

	private void setModel(BundleDependencyService model) {
		this.model = model;
	}
}
