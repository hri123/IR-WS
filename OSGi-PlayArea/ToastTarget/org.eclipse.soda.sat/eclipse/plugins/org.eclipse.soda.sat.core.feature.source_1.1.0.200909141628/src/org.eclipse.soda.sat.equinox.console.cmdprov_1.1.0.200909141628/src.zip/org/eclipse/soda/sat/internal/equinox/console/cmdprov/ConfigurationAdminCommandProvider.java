/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.equinox.console.cmdprov;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import org.eclipse.osgi.framework.console.CommandInterpreter;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.eclipse.soda.sat.internal.equinox.console.cmdprov.nls.Messages;
import org.osgi.framework.BundleContext;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;

public class ConfigurationAdminCommandProvider extends AbstractCommandProvider {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String CONFIGURATION_PROPERTIES_DESCRIPTION_KEY = "ConfigurationAdminCommandProvider.ConfigurationPropertiesDescription";  //$NON-NLS-1$
	private static final String FACTORY_PIDS_DESCRIPTION_KEY = "ConfigurationAdminCommandProvider.FactoryPidsDescription";  //$NON-NLS-1$
	private static final String PIDS_DESCRIPTION_KEY = "ConfigurationAdminCommandProvider.PidsDescription";  //$NON-NLS-1$
	private static final String TITLE_KEY = "ConfigurationAdminCommandProvider.Title";  //$NON-NLS-1$

	// Externalized String Values
	private static final String CONFIGURATION_PROPERTIES_DESCRIPTION = Messages.getString(ConfigurationAdminCommandProvider.CONFIGURATION_PROPERTIES_DESCRIPTION_KEY);
	private static final String FACTORY_PIDS_DESCRIPTION = Messages.getString(ConfigurationAdminCommandProvider.FACTORY_PIDS_DESCRIPTION_KEY);
	private static final String PIDS_DESCRIPTION = Messages.getString(ConfigurationAdminCommandProvider.PIDS_DESCRIPTION_KEY);
	private static final String TITLE = Messages.getString(ConfigurationAdminCommandProvider.TITLE_KEY);

	// Non-Externalized String Patterns
	private static final String CONFIGURATION_PROPERTIES_COMMAND_HELP = "cprops [pid] - {0}";  //$NON-NLS-1$
	private static final String FACTORY_PIDS_COMMAND_HELP = "fpids [filter] - {0}";  //$NON-NLS-1$
	private static final String PIDS_COMMAND_HELP = "pids [filter] - {0}";  //$NON-NLS-1$

	// Misc
	private ConfigurationAdmin model;
	private Comparator configurationComparator;

	//
	// Constructors
	//
	public ConfigurationAdminCommandProvider(BundleContext bundleContext, ConfigurationAdmin model) {
		super(bundleContext);
		setModel(model);
		setConfigurationComparator(createConfigurationComparator());
	}

	public void _cprops(CommandInterpreter interpreter) {
		setInterpreter(interpreter);
		try {
			List/*<String>*/ arguments = getAllArguments();
			List/*<Configuration>*/ configurations = getConfigurationsByPids(arguments);
			appendProperties(configurations);
		} finally {
			flushBuffer();
		}
	}

	public void _fpids(CommandInterpreter interpreter) {
		setInterpreter(interpreter);
		String filter = getNextArgument();

		try {
			List/*<Configuration>*/ configurations = getConfigurations(filter);
			List/*<String>*/ fpids = getFactoryPids(configurations);
			append(fpids);
		} finally {
			flushBuffer();
		}
	}

	public void _pids(CommandInterpreter interpreter) {
		setInterpreter(interpreter);
		String filter = getNextArgument();

		try {
			List/*<Configuration>*/ configurations = getConfigurations(filter);
			List/*<String>*/ pids = getPids(configurations);
			append(pids);
		} finally {
			flushBuffer();
		}
	}

	private void appendProperties(Configuration configuration) {
		String pid = configuration.getPid();
		String location = configuration.getBundleLocation();
		append("pid=");  //$NON-NLS-1$
		append(pid);
		append(", ");  //$NON-NLS-1$
		append("location=");  //$NON-NLS-1$
		append(location);
		appendNewLine();
		Dictionary properties = configuration.getProperties();
		appendProperties(properties);
	}

	private void appendProperties(Dictionary properties) {
		Enumeration keys = properties.keys();

		while (keys.hasMoreElements() == true) {
			Object key = keys.nextElement();
			Object value = properties.get(key);
			boolean isString = value instanceof String;

			appendIndent();
			append(key);
			append(" -> ");  //$NON-NLS-1$

			if (isString == true) {
				append('"');
			}

			append(value);

			if (isString == true) {
				append('"');
			}

			appendNewLine();
		}
	}

	private void appendProperties(List/*<Configuration>*/ configurations) {
		Iterator/*<Configuration>*/ iterator = configurations.iterator();

		while (iterator.hasNext() == true) {
			Configuration configuration = (Configuration) iterator.next();
			appendProperties(configuration);
		}
	}

	private int compare(Configuration leftConfiguration, Configuration rightConfiguration) {
		String leftPid = leftConfiguration.getPid();
		String rightPid = rightConfiguration.getPid();
		int result = leftPid.compareTo(rightPid);
		return result;
	}

	private Comparator createConfigurationComparator() {
		return new Comparator() {
			public int compare(Object left, Object right) {
				Configuration leftConfiguration = (Configuration) left;
				Configuration rightConfiguration = (Configuration) right;
				int result = ConfigurationAdminCommandProvider.this.compare(leftConfiguration, rightConfiguration);
				return result;
			}
		};
	}

	protected String[] getCommandHelpLines() {
		return new String[] {
			getConfigurationPropertiesCommandHelpLine(),
			getFactoryPidsCommandHelpLine(),
			getPidsCommandHelpLine(),
		};
	}

	private final Comparator getConfigurationComparator() {
		return configurationComparator;
	}

	private String getConfigurationPropertiesCommandHelpLine() {
		return MessageFormatter.format(ConfigurationAdminCommandProvider.CONFIGURATION_PROPERTIES_COMMAND_HELP, ConfigurationAdminCommandProvider.CONFIGURATION_PROPERTIES_DESCRIPTION);
	}

	private List/*<Configuration>*/ getConfigurations(String filter) {
		ConfigurationAdmin model = getModel();
		List/*<Configuration>*/ list = null;

		try {
			Configuration[] configurations = model.listConfigurations(filter);
			if (configurations == null)
				return AbstractCommandProvider.EMPTY_LIST;
			list = Arrays.asList(configurations);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InvalidSyntaxException e) {
			e.printStackTrace();
		}

		Comparator comparator = getConfigurationComparator();
		Collections.sort(list, comparator);
		return list;
	}

	private List/*<Configuration>*/ getConfigurationsByPids(List/*<String>*/ arguments) {
		List/*<Configuration>*/ configurations = getConfigurations(null);
		boolean empty = arguments.isEmpty();
		if (empty == true)
			return configurations; // Early return.

		int size = configurations.size();
		List/*<Configuration>*/ hits = new ArrayList/*<Configuration>*/(size);
		Iterator/*<Configuration>*/ iterator = configurations.iterator();

		while (iterator.hasNext() == true) {
			Configuration configuration = (Configuration) iterator.next();
			String pid = configuration.getPid();
			boolean match = arguments.contains(pid);
			if (match == false)
				continue;  // Skip to next iteration.
			hits.add(configuration);
		}

		return hits;
	}

	private List getFactoryPids(List/*<Configuration>*/ configurations) {
		int size = configurations.size();
		List/*<String>*/ fpids = new ArrayList/*<String>*/(size);
		Iterator/*<Configuration>*/ iterator = configurations.iterator();

		while (iterator.hasNext() == true) {
			Configuration configuration = (Configuration) iterator.next();
			String fpid = configuration.getFactoryPid();
			if (fpid == null)
				continue;  // Skip to next iteration.
			fpids.add(fpid);
		}

		Collections.sort(fpids);
		return fpids;
	}

	private String getFactoryPidsCommandHelpLine() {
		return MessageFormatter.format(ConfigurationAdminCommandProvider.FACTORY_PIDS_COMMAND_HELP, ConfigurationAdminCommandProvider.FACTORY_PIDS_DESCRIPTION);
	}

	private final ConfigurationAdmin getModel() {
		return model;
	}

	private List getPids(List/*<Configuration>*/ configurations) {
		int size = configurations.size();
		List/*<String>*/ pids = new ArrayList/*<String>*/(size);
		Iterator/*<Configuration>*/ iterator = configurations.iterator();

		while (iterator.hasNext() == true) {
			Configuration configuration = (Configuration) iterator.next();
			try {
				String pid = configuration.getPid();
				pids.add(pid);
			} catch (IllegalStateException exception) {
				// The PID has been deleted.
			}
		}


		Collections.sort(pids);
		return pids;
	}

	private String getPidsCommandHelpLine() {
		return MessageFormatter.format(ConfigurationAdminCommandProvider.PIDS_COMMAND_HELP, ConfigurationAdminCommandProvider.PIDS_DESCRIPTION);
	}

	protected String getTitle() {
		return ConfigurationAdminCommandProvider.TITLE;
	}

	private final void setConfigurationComparator(Comparator configurationComparator) {
		this.configurationComparator = configurationComparator;
	}

	private final void setModel(ConfigurationAdmin model) {
		this.model = model;
	}
}
