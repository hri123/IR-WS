/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.equinox.console.cmdprov;

import org.eclipse.osgi.framework.console.CommandInterpreter;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.eclipse.soda.sat.internal.equinox.console.cmdprov.nls.Messages;
import org.osgi.framework.BundleContext;
import org.osgi.service.log.LogService;

public class LogUtilityCommandProvider extends AbstractCommandProvider {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String DEBUG_LOG_LEVEL_KEY = "LogUtilityCommandProvider.DebugLogLevel";  //$NON-NLS-1$
	private static final String ERROR_LOG_LEVEL_KEY = "LogUtilityCommandProvider.ErrorLogLevel";  //$NON-NLS-1$
	private static final String INFO_LOG_LEVEL_KEY = "LogUtilityCommandProvider.InfoLogLevel";  //$NON-NLS-1$
	private static final String LOG_LEVEL_DESCRIPTION_KEY = "LogUtilityCommandProvider.LogLevelDescription";  //$NON-NLS-1$
	private static final String LOG_LEVEL_IS_KEY = "LogUtilityCommandProvider.LogLevelIs";  //$NON-NLS-1$
	private static final String OFF_KEY = "LogUtilityCommandProvider.Off";  //$NON-NLS-1$
	private static final String ON_KEY = "LogUtilityCommandProvider.On";  //$NON-NLS-1$
	private static final String TITLE_KEY = "LogUtilityCommandProvider.Title";  //$NON-NLS-1$
	private static final String TRACE_DESCRIPTION_KEY = "LogUtilityCommandProvider.TraceDescription";  //$NON-NLS-1$
	private static final String TRACING_IS_KEY = "LogUtilityCommandProvider.TracingIs";  //$NON-NLS-1$
	private static final String UNKNOWN_LOG_LEVEL_KEY = "LogUtilityCommandProvider.UnknownLogLevel";  //$NON-NLS-1$
	private static final String VALID_LOG_LEVEL_PARAMETERS_KEY = "LogUtilityCommandProvider.ValidLogLevelParameters";  //$NON-NLS-1$
	private static final String VALID_TRACE_PARAMETERS_KEY = "LogUtilityCommandProvider.ValidTraceParameters";  //$NON-NLS-1$
	private static final String WARNING_LOG_LEVEL_KEY = "LogUtilityCommandProvider.WarningLogLevel";  //$NON-NLS-1$

	// Externalized String Values
	private static final String DEBUG_LOG_LEVEL = Messages.getString(LogUtilityCommandProvider.DEBUG_LOG_LEVEL_KEY);
	private static final String ERROR_LOG_LEVEL = Messages.getString(LogUtilityCommandProvider.ERROR_LOG_LEVEL_KEY);
	private static final String INFO_LOG_LEVEL = Messages.getString(LogUtilityCommandProvider.INFO_LOG_LEVEL_KEY);
	private static final String LOG_LEVEL_DESCRIPTION = Messages.getString(LogUtilityCommandProvider.LOG_LEVEL_DESCRIPTION_KEY);
	private static final String LOG_LEVEL_IS = Messages.getString(LogUtilityCommandProvider.LOG_LEVEL_IS_KEY);
	private static final String OFF = Messages.getString(LogUtilityCommandProvider.OFF_KEY);
	private static final String ON = Messages.getString(LogUtilityCommandProvider.ON_KEY);
	private static final String TITLE = Messages.getString(LogUtilityCommandProvider.TITLE_KEY);
	private static final String TRACE_DESCRIPTION = Messages.getString(LogUtilityCommandProvider.TRACE_DESCRIPTION_KEY);
	private static final String TRACING_IS = Messages.getString(LogUtilityCommandProvider.TRACING_IS_KEY);
	private static final String UNKNOWN_LOG_LEVEL = Messages.getString(LogUtilityCommandProvider.UNKNOWN_LOG_LEVEL_KEY);
	private static final String VALID_LOG_LEVEL_PARAMETERS = Messages.getString(LogUtilityCommandProvider.VALID_LOG_LEVEL_PARAMETERS_KEY);
	private static final String VALID_TRACE_PARAMETERS = Messages.getString(LogUtilityCommandProvider.VALID_TRACE_PARAMETERS_KEY);
	private static final String WARNING_LOG_LEVEL = Messages.getString(LogUtilityCommandProvider.WARNING_LOG_LEVEL_KEY);

	// Non-Externalized String Patterns
	private static final String LOG_LEVEL_COMMAND_HELP="loglevel [({0}|{1}|{2}|{3})] - {4}";  //$NON-NLS-1$
	private static final String TRACE_COMMAND_HELP = "trace [({0}|{1})] - {2}";  //$NON-NLS-1$

	//
	// Constructors
	//
	public LogUtilityCommandProvider(BundleContext bundleContext) {
		super(bundleContext);
	}

	//
	// Instance Methods
	//

	public void _ll(CommandInterpreter interpreter) {
		_loglevel(interpreter);
	}

	public void _loglevel(CommandInterpreter interpreter) {
		setInterpreter(interpreter);
		try {
			String argument = getNextArgument();

			if (argument == null) {
				appendLogLevel();
			} else {
				int level = toLogLevel(argument);

				if (level != -1) {
					LogUtility.setLoggingLevel(level);
					appendLogLevel();
				} else {
					Object[] values = new Object[] {
						LogUtilityCommandProvider.DEBUG_LOG_LEVEL,
						LogUtilityCommandProvider.INFO_LOG_LEVEL,
						LogUtilityCommandProvider.WARNING_LOG_LEVEL,
						LogUtilityCommandProvider.ERROR_LOG_LEVEL
					};

					String value = MessageFormatter.format(LogUtilityCommandProvider.VALID_LOG_LEVEL_PARAMETERS, values);
					appendLine(value);
				}
			}
		} finally {
			flushBuffer();
		}
	}

	public void _tr(CommandInterpreter interpreter) {
		_trace(interpreter);
	}

	public void _trace(CommandInterpreter interpreter) {
		setInterpreter(interpreter);
		try {
			String argument = getNextArgument();

			if (argument == null) {
				appendTracingState();
			} else {
				if (argument.equalsIgnoreCase(LogUtilityCommandProvider.ON)) {
					setTracing(true);
				} else if (argument.equalsIgnoreCase(LogUtilityCommandProvider.OFF)) {
					setTracing(false);
				} else {
					appendValidTraceParameters();
				}
			}
		} finally {
			flushBuffer();
		}
	}

	private void appendLogLevel() {
		int level = LogUtility.getLoggingLevel();
		String value = toString(level);
		String message = MessageFormatter.format(LogUtilityCommandProvider.LOG_LEVEL_IS, value);
		appendLine(message);
	}

	private void appendTracingState() {
		String state = LogUtility.isTracing() == true ? LogUtilityCommandProvider.ON : LogUtilityCommandProvider.OFF;
		String message = MessageFormatter.format(LogUtilityCommandProvider.TRACING_IS, state);
		appendLine(message);
	}

	private void appendValidTraceParameters() {
		Object[] values = new Object[] {
			LogUtilityCommandProvider.ON,
			LogUtilityCommandProvider.OFF,
		};

		String value = MessageFormatter.format(LogUtilityCommandProvider.VALID_TRACE_PARAMETERS, values);
		appendLine(value);
	}

	/**
	 * @see org.eclipse.soda.sat.internal.equinox.console.cmdprov.AbstractCommandProvider#getCommandHelpLines()
	 */
	protected String[] getCommandHelpLines() {
		return new String[] {
			getLogLevelCommandHelpLine(),
			getTraceCommandHelpLine()
		};
	}

	private String getLogLevelCommandHelpLine() {
		Object[] values = new Object[] {
			LogUtilityCommandProvider.DEBUG_LOG_LEVEL,
			LogUtilityCommandProvider.INFO_LOG_LEVEL,
			LogUtilityCommandProvider.WARNING_LOG_LEVEL,
			LogUtilityCommandProvider.ERROR_LOG_LEVEL,
			LogUtilityCommandProvider.LOG_LEVEL_DESCRIPTION
		};

		return MessageFormatter.format(LogUtilityCommandProvider.LOG_LEVEL_COMMAND_HELP, values);
	}

	/**
	 * @see org.eclipse.soda.sat.internal.equinox.console.cmdprov.AbstractCommandProvider#getTitle()
	 */
	protected String getTitle() {
		return LogUtilityCommandProvider.TITLE;
	}

	private String getTraceCommandHelpLine() {
		Object[] values = new Object[] {
			LogUtilityCommandProvider.ON,
			LogUtilityCommandProvider.OFF,
			LogUtilityCommandProvider.TRACE_DESCRIPTION
		};

		return MessageFormatter.format(LogUtilityCommandProvider.TRACE_COMMAND_HELP, values);
	}

	private void setTracing(boolean tracing) {
		LogUtility.setTracing(tracing);
		appendTracingState();
	}

	private int toLogLevel(String value) {
		if (value.equalsIgnoreCase(LogUtilityCommandProvider.DEBUG_LOG_LEVEL))
			return LogService.LOG_DEBUG;  // Early return.
		if (value.equalsIgnoreCase(LogUtilityCommandProvider.INFO_LOG_LEVEL))
			return LogService.LOG_INFO;  // Early return.
		if (value.equalsIgnoreCase(LogUtilityCommandProvider.WARNING_LOG_LEVEL))
			return LogService.LOG_WARNING;  // Early return.
		if (value.equalsIgnoreCase(LogUtilityCommandProvider.ERROR_LOG_LEVEL))
			return LogService.LOG_ERROR;  // Early return.
		return -1;
	}

	private String toString(int level) {
		if (level == LogService.LOG_DEBUG)
			return LogUtilityCommandProvider.DEBUG_LOG_LEVEL;
		if (level == LogService.LOG_INFO)
			return LogUtilityCommandProvider.INFO_LOG_LEVEL;
		if (level == LogService.LOG_WARNING)
			return LogUtilityCommandProvider.WARNING_LOG_LEVEL;
		if (level == LogService.LOG_ERROR)
			return LogUtilityCommandProvider.ERROR_LOG_LEVEL;
		String message = MessageFormatter.format(LogUtilityCommandProvider.UNKNOWN_LOG_LEVEL, new Integer(level));
		throw new IllegalArgumentException(message);
	}
}
