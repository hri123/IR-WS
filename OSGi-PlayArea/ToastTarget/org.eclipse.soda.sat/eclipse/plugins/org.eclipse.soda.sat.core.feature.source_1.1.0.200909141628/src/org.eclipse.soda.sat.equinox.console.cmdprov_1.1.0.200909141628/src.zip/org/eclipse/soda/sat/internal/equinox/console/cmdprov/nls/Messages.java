/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.equinox.console.cmdprov.nls;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * Messages.java
 */
public final class Messages extends Object {
	//
	// Static Fields
	//

	private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle("org.eclipse.soda.sat.internal.equinox.console.cmdprov.nls.messages");  //$NON-NLS-1$

	//
	// Static Methods
	//

	/**
	 * Look in messages.properties for the message that matches the specified
	 * key.
	 *
	 * @param key  The key of a message in messages.properties.
	 * @return The message string.
	 */
	public static String getString(String key) {
		if (key == null)
			throw new IllegalArgumentException();
		String value;
		try {
			value = Messages.RESOURCE_BUNDLE.getString(key);
			value = value.trim();
		} catch (MissingResourceException exception) {
			System.err.println(exception);
			value = '!' + key + '!'; // $codepro.audit.disable disallowStringConcatenation
		}
		return value;
	}

	//
	// Constructors
	//

	/**
	 * Private constructor.
	 */
	private Messages() {
		super();
	}

//	//
//	// Main
//	//
//
//	public static void main(String[] args) {
//		java.util.Properties properties = new java.util.Properties();
//
//		try {
//			java.io.InputStream stream = Messages.class.getResourceAsStream("messages.properties");  //$NON-NLS-1$
//
//			try {
//				properties.load(stream);
//				java.util.Set set = properties.keySet();
//				java.util.List keys = new java.util.ArrayList(set);
//				java.util.Collections.sort(keys);
//				java.util.Iterator iterator = keys.iterator();
//
//				while (iterator.hasNext() == true) {
//					Object key = iterator.next();
//					Object value = properties.get(key);
//					System.out.println(key + "=" + value);  //$NON-NLS-1$
//				}
//			} finally {
//				if (stream != null) {
//					stream.close();
//				}
//			}
//		} catch (java.io.IOException exception) {
//			exception.printStackTrace();
//		}
//	}
}
