/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.equinox.console.cmdprov;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.eclipse.osgi.framework.console.CommandInterpreter;
import org.eclipse.osgi.framework.console.CommandProvider;
import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.util.BundleManifestUtility;
import org.eclipse.soda.sat.core.util.BundleUtility;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;

public abstract class AbstractCommandProvider extends Object implements CommandProvider {
	// Misc
	protected static final List/*<?>*/ EMPTY_LIST = new ArrayList/*<?>*/(0);
	private static final char INDENT = '\t';
	private static final String LINE_SEPARATOR = System.getProperty("line.separator");  //$NON-NLS-1$
	private static final String NO_VERSION = "0.0.0";  //$NON-NLS-1$
	private static final char SPACE = ' ';

	//
	// Instance Fields
	//

	private ICharBuffer buffer;
	private BundleContext bundleContext;
	private CommandInterpreter interpreter;

	//
	// Constructors
	//

	protected AbstractCommandProvider() {
		super();
		setBuffer(createBuffer());
	}

	protected AbstractCommandProvider(BundleContext bundleContext) {
		this();
		setBundleContext(bundleContext);
	}

	//
	// Instance Methods
	//

	protected final void append(char value) {
		ICharBuffer buffer = getBuffer();
		buffer.append(value);
	}

	protected final void append(Collection/*<Object>*/ list) {
		Iterator/*<Object>*/ iterator = list.iterator();

		while (iterator.hasNext() == true) {
			Object object = iterator.next();
			appendLine(object);
		}
	}

	protected final void append(Object value) {
		ICharBuffer buffer = getBuffer();
		buffer.append(value);
	}

	protected final void appendIndent() {
		append(AbstractCommandProvider.INDENT);
	}

	protected final void appendLine(Object value) {
		append(value);
		appendNewLine();
	}

	protected final void appendNewLine() {
		append(AbstractCommandProvider.LINE_SEPARATOR);
	}

	private ICharBuffer createBuffer() {
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(4096);
		return buffer;
	}

	protected String createBundleStatePadding(Bundle bundle, String state) {
		int stateLength = state.length();
		int length = 12 - stateLength;
		char[] chars = new char [ length ];
		Arrays.fill(chars, AbstractCommandProvider.SPACE);
		String padding = new String(chars);
		return padding;
	}

	protected final void flushBuffer() {
		String value = getBufferContents();
		CommandInterpreter interpreter = getInterpreter();
		interpreter.print(value);
	}

	protected final List/*<String>*/ getAllArguments() {
		String argument = getNextArgument();
		if (argument == null)
			return new ArrayList/*<String>*/(0);
		List/*<String>*/ list = new ArrayList/*<String>*/(5);

		do {
			list.add(argument);
		} while ((argument = getNextArgument()) != null);

		return list;
	}

	private ICharBuffer getBuffer() {
		return buffer;
	}

	private String getBufferContents() {
		ICharBuffer buffer = getBuffer();
		String value = buffer.toString();
		buffer.setLength(0);
		return value;
	}

	private Bundle getBundle(long id) {
		BundleContext context = getBundleContext();
		Bundle bundle = context.getBundle(id);
		return bundle;
	}

	protected final Bundle getBundle(String value) {
		Bundle bundle = null;

		try {
			long id = Long.parseLong(value);
			bundle = getBundle(id);
		} catch (NumberFormatException exception) {
			// OK
		}

		return bundle;
	}

	protected final BundleContext getBundleContext() {
		if (bundleContext == null)
			throw new IllegalStateException("no bundle context");  //$NON-NLS-1$
		return bundleContext;
	}

	protected final String getBundleVersion(Bundle bundle) {
		BundleManifestUtility utility = BundleManifestUtility.getInstance();
		String version = utility.getBundleVersion(bundle);

		if (version == null) {
			version = AbstractCommandProvider.NO_VERSION;
		}

		return version;
	}

	protected abstract String[] getCommandHelpLines();

	/**
	 * @see org.eclipse.osgi.framework.console.CommandProvider#getHelp()
	 */
	public final String getHelp() {
		String decoration = "---";  //$NON-NLS-1$
		String title = getTitle();
		if (title == null) {
			Class clazz = getClass();
			String name = clazz.getName();
			title = name;
		}
		append(decoration);
		append(title);
		appendLine(decoration);
		String[] lines = getCommandHelpLines();

		if (lines != null) {
			int length = lines.length;

			for (int i = 0; i < length; i++) {
				String line = lines [ i ];
				appendIndent();
				appendLine(line);
			}
		}

		String result = getBufferContents();
		return result;
	}

	protected final CommandInterpreter getInterpreter() {
		return interpreter;
	}

	protected final String getNextArgument() {
		CommandInterpreter interpreter = getInterpreter();
		String argument = interpreter.nextArgument();
		return argument;
	}

	protected final Bundle getNextArgumentBundle() {
		String id = getNextArgument();
		if (id == null)
			return null;
		Bundle bundle = getBundle(id);
		return bundle;
	}

	protected abstract String getTitle();

	private void setBuffer(ICharBuffer buffer) {
		this.buffer = buffer;
	}

	private void setBundleContext(BundleContext bundleContext) {
		this.bundleContext = bundleContext;
	}

	protected final void setInterpreter(CommandInterpreter interpreter) {
		this.interpreter = interpreter;
	}

	protected final String toBundleIdString(Bundle bundle) {
		long id = bundle.getBundleId();
		String value = String.valueOf(id);
		return value;
	}

	protected final String toBundleStateString(Bundle bundle) {
		BundleUtility utility = BundleUtility.getInstance();
		String value = utility.toBundleStateString(bundle);
		return value;
	}
}
