// $codepro.audit.disable methodNamingConvention
/*******************************************************************************
 * Copyright (c) 2001, 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.equinox.console.cmdprov;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import org.eclipse.osgi.framework.console.CommandInterpreter;
import org.eclipse.soda.sat.core.service.BundleDependencyService;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.eclipse.soda.sat.internal.equinox.console.cmdprov.nls.Messages;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;

/**
 * BundleDependencyCommandProvider.java
 */
public class BundleDependencyCommandProvider extends AbstractCommandProvider {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String ALL_DEPENDENDS_DESCRIPTION_KEY = "BundleDependencyCommandProvider.AllDependentsDescription";  //$NON-NLS-1$
	private static final String ALL_DEPENDENTS_OF_BUNDLE_KEY = "BundleDependencyCommandProvider.AllDependentsOfBundle";  //$NON-NLS-1$
	private static final String ALL_PREREQUISITES_DESCRIPTION_KEY = "BundleDependencyCommandProvider.AllPrerequisitesDescription";  //$NON-NLS-1$
	private static final String ALL_PREREQUISITES_OF_BUNDLE_KEY = "BundleDependencyCommandProvider.AllPrerequisitesOfBundle";  //$NON-NLS-1$
	private static final String BUNDLE_LIST_HEADER_KEY = "BundleDependencyCommandProvider.BundleListHeader";  //$NON-NLS-1$
	private static final String CIRC_DESCRIPTION_KEY = "BundleDependencyCommandProvider.CircDescription";  //$NON-NLS-1$
	private static final String CIRCULAR_REFERENCES_OF_KEY = "BundleDependencyCommandProvider.CircularReferencesOf";  //$NON-NLS-1$
	private static final String DEPENDENTS_DESCRIPTION_KEY = "BundleDependencyCommandProvider.DependentsDescription";  //$NON-NLS-1$
	private static final String DEPENDENTS_OF_BUNDLE_KEY = "BundleDependencyCommandProvider.DependentsOfBundle";  //$NON-NLS-1$
	private static final String NONE_KEY = "BundleDependencyCommandProvider.None";  //$NON-NLS-1$
	private static final String PREREQUISITES_DESCRIPTION_KEY = "BundleDependencyCommandProvider.PrerequisitesDescription";  //$NON-NLS-1$
	private static final String PREREQUISITES_OF_BUNDLE_KEY = "BundleDependencyCommandProvider.PrerequisitesOfBundle";  //$NON-NLS-1$
	private static final String SORT_BUNDLES_BY_DESCRIPTION_KEY = "BundleDependencyCommandProvider.SortBundlesByDescription";  //$NON-NLS-1$
	private static final String SORTING_BUNDLES_BY_KEY = "BundleDependencyCommandProvider.SortingBundlesBy";  //$NON-NLS-1$
	private static final String TITLE_KEY = "BundleDependencyCommandProvider.Title";  //$NON-NLS-1$

	// Externalized String Values
	private static final String ALL_DEPENDENTS_DESCRIPTION = Messages.getString(BundleDependencyCommandProvider.ALL_DEPENDENDS_DESCRIPTION_KEY);
	private static final String ALL_DEPENDENTS_OF_BUNDLE = Messages.getString(BundleDependencyCommandProvider.ALL_DEPENDENTS_OF_BUNDLE_KEY);
	private static final String ALL_PREREQUISITES_DESCRIPTION = Messages.getString(BundleDependencyCommandProvider.ALL_PREREQUISITES_DESCRIPTION_KEY);
	private static final String ALL_PREREQUISITES_OF_BUNDLE = Messages.getString(BundleDependencyCommandProvider.ALL_PREREQUISITES_OF_BUNDLE_KEY);
	private static final String BUNDLE_LIST_HEADER = Messages.getString(BundleDependencyCommandProvider.BUNDLE_LIST_HEADER_KEY);
	private static final String CIRC_DESCRIPTION = Messages.getString(BundleDependencyCommandProvider.CIRC_DESCRIPTION_KEY);
	private static final String CIRCULAR_REFERENCES_OF = Messages.getString(BundleDependencyCommandProvider.CIRCULAR_REFERENCES_OF_KEY);
	private static final String DEPENDENTS_DESCRIPTION = Messages.getString(BundleDependencyCommandProvider.DEPENDENTS_DESCRIPTION_KEY);
	private static final String DEPENDENTS_OF_BUNDLE = Messages.getString(BundleDependencyCommandProvider.DEPENDENTS_OF_BUNDLE_KEY);
	private static final String NONE = Messages.getString(BundleDependencyCommandProvider.NONE_KEY);
	private static final String PREREQUISITES_DESCRIPTION = Messages.getString(BundleDependencyCommandProvider.PREREQUISITES_DESCRIPTION_KEY);
	private static final String PREREQUISITES_OF_BUNDLE = Messages.getString(BundleDependencyCommandProvider.PREREQUISITES_OF_BUNDLE_KEY);
	private static final String SORT_BUNDLES_BY_DESCRIPTION = Messages.getString(BundleDependencyCommandProvider.SORT_BUNDLES_BY_DESCRIPTION_KEY);
	private static final String SORTING_BUNDLES_BY = Messages.getString(BundleDependencyCommandProvider.SORTING_BUNDLES_BY_KEY);
	private static final String TITLE = Messages.getString(BundleDependencyCommandProvider.TITLE_KEY);

	// Non-Externalized String Patterns
	private static final String ALL_DEPENDENDENTS_COMMAND_HELP = "adep [id] - {0}";  //$NON-NLS-1$
	private static final String ALL_PREREQUISITES_COMMAND_HELP = "apre [id] - {0}";  //$NON-NLS-1$
	private static final String BUNDLE_LIST_ROW = "{0}\t{1}{2}{3}_{4}";  //$NON-NLS-1$
	private static final String CIRC_COMMAND_HELP = "circ [id] - {0}";  //$NON-NLS-1$
	private static final String DEPENDENTS_COMMAND_HELP = "dep [id] - {0}";  //$NON-NLS-1$
	private static final String PREREQUISITES_COMMAND_HELP = "pre [id] - {0}";  //$NON-NLS-1$
	private static final String SORT_BUNDLES_BY_COMMAND_HELP = "sbb [{0} | {1}] - {2}";  //$NON-NLS-1$

	// Sort Bundles By
	private static final String SORT_BUNDLES_BY_BUNDLE_ID = "bid";  //$NON-NLS-1$
	private static final String SORT_BUNDLES_BY_BUNDLE_SYMBOLIC_NAME = "bsn";  //$NON-NLS-1$

	// Misc
	private static final char IS_REGISTERED_AS_UNINSTALLABLE_FLAG = '*';

	//
	// Instance Fields
	//

	private BundleDependencyService model;
	private Comparator bundleComparator;
	private String sortBundlesBy;

	//
	// Constructors
	//

	public BundleDependencyCommandProvider(BundleContext bundleContext, BundleDependencyService bundleDependencyService) {
		super(bundleContext);
		setModel(bundleDependencyService);
		setBundleComparator(createBundleComparator());
		setSortBundlesBy(BundleDependencyCommandProvider.SORT_BUNDLES_BY_BUNDLE_ID);
	}

	//
	// Instance Methods
	//

	public void _adep(CommandInterpreter interpreter) throws Exception {
		setInterpreter(interpreter);
		try {
			List/*<Bundles>*/ bundles = getBundles();
			appendAllDependentsOfBundles(bundles);
		} finally {
			flushBuffer();
		}
	}

	public void _apre(CommandInterpreter interpreter) throws Exception {
		setInterpreter(interpreter);
		try {
			List/*<Bundles>*/ bundles = getBundles();
			appendAllPrerequisitesOfBundles(bundles);
		} finally {
			flushBuffer();
		}
	}

	public void _circ(CommandInterpreter interpreter) throws Exception {
		setInterpreter(interpreter);
		try {
			List/*<Bundles>*/ bundles = getBundles();
			appendCircularReferences(bundles);
		} finally {
			flushBuffer();
		}
	}

	public void _dep(CommandInterpreter interpreter) throws Exception {
		setInterpreter(interpreter);
		try {
			List/*<Bundles>*/ bundles = getBundles();
			appendDependentsOfBundles(bundles);
		} finally {
			flushBuffer();
		}
	}

	public void _pre(CommandInterpreter interpreter) throws Exception {
		setInterpreter(interpreter);
		try {
			List/*<Bundles>*/ bundles = getBundles();
			appendPrerequisitesOfBundles(bundles);
		} finally {
			flushBuffer();
		}
	}

	public void _sbb(CommandInterpreter interpreter) throws Exception {
		setInterpreter(interpreter);
		try {
			String argument = getNextArgument();
			if (argument != null) {
				if (argument.equalsIgnoreCase(BundleDependencyCommandProvider.SORT_BUNDLES_BY_BUNDLE_ID)) {
					setSortBundlesBy(argument);
				} else if (argument.equalsIgnoreCase(BundleDependencyCommandProvider.SORT_BUNDLES_BY_BUNDLE_SYMBOLIC_NAME)) {
					setSortBundlesBy(argument);
				} else {
					String help = getSortBundlesByCommandHelpLine();
					appendLine(help);
					return;  // Early return.
				}
			}

			String sortBundlesBy = getSortBundlesBy();
			String line = MessageFormatter.format(BundleDependencyCommandProvider.SORTING_BUNDLES_BY, sortBundlesBy);
			appendLine(line);
		} finally {
			flushBuffer();
		}
	}

	private void appendAllDependentsOfBundles(List/*<Bundle>*/ bundles) {
		Iterator/*<Bundle>*/ iterator = bundles.iterator();

		while (iterator.hasNext() == true) {
			Bundle bundle = (Bundle) iterator.next();
			String bundleSymbolicName = bundle.getSymbolicName();
			String message = MessageFormatter.format(BundleDependencyCommandProvider.ALL_DEPENDENTS_OF_BUNDLE, bundleSymbolicName);
			appendLine(message);
			List/*<Bundle>*/ list = getAllDependentsOf(bundle);
			appendBundles(list);
		}
	}

	private void appendAllPrerequisitesOfBundles(List/*<Bundle>*/ bundles) {
		Iterator/*<Bundle>*/ iterator = bundles.iterator();

		while (iterator.hasNext() == true) {
			Bundle bundle = (Bundle) iterator.next();
			String bundleSymbolicName = bundle.getSymbolicName();
			String message = MessageFormatter.format(BundleDependencyCommandProvider.ALL_PREREQUISITES_OF_BUNDLE, bundleSymbolicName);
			appendLine(message);
			List/*<Bundle>*/ list = getAllPrerequisitesOf(bundle);
			appendBundles(list);
		}
	}

	private void appendBundles(List/*<Bundle>*/ list) {
		boolean empty = list.isEmpty();

		if (empty == true) {
			appendIndent();
			appendLine(BundleDependencyCommandProvider.NONE);
		} else {
			appendNewLine();
			appendLine(BundleDependencyCommandProvider.BUNDLE_LIST_HEADER);

			sortBundles(list);
			Iterator/*<Bundle>*/ iterator = list.iterator();

			while (iterator.hasNext() == true) {
				Bundle bundle = (Bundle) iterator.next();
				Object id = toBundleIdString(bundle);
				String state = toBundleStateString(bundle);
				Object padding = createBundleStatePadding(bundle, state);
				Object name = bundle.getSymbolicName();
				Object version = getBundleVersion(bundle);

				Object[] values = new Object[] {
					id, state, padding, name, version
				};

				String message = MessageFormatter.format(BundleDependencyCommandProvider.BUNDLE_LIST_ROW, values);
				appendLine(message);
			}
		}

		appendNewLine();
	}

	private void appendCircularReferences(List/*<Bundles>*/ list) {
		sortBundlesByBundleSymbolicName(list);
		Iterator/*<Bundles>*/ iterator = list.iterator();

		while (iterator.hasNext() == true) {
			Bundle bundle = (Bundle) iterator.next();
			boolean state = hasCircularReferences(bundle);
			if (state == false)
				continue;  // Skip to next iteration.
			String bundleSymbolicName = bundle.getSymbolicName();
			String message = MessageFormatter.format(BundleDependencyCommandProvider.CIRCULAR_REFERENCES_OF, bundleSymbolicName);
			appendLine(message);
			List/*<Bundles>*/ prerequisites = getPrerequisitesOf(bundle);
			appendBundles(prerequisites);
		}
	}

	private void appendDependentsOfBundles(List/*<Bundles>*/ bundles) {
		Iterator/*<Bundles>*/ iterator = bundles.iterator();

		while (iterator.hasNext() == true) {
			Bundle bundle = (Bundle) iterator.next();
			String bundleSymbolicName = bundle.getSymbolicName();
			String message = MessageFormatter.format(BundleDependencyCommandProvider.DEPENDENTS_OF_BUNDLE, bundleSymbolicName);
			appendLine(message);
			List/*<Bundle>*/ list = getDependentsOf(bundle);
			appendBundles(list);
		}
	}

	private void appendPrerequisitesOfBundles(List/*<Bundles>*/ bundles) {
		Iterator/*<Bundles>*/ iterator = bundles.iterator();

		while (iterator.hasNext() == true) {
			Bundle bundle = (Bundle) iterator.next();
			String bundleSymbolicName = bundle.getSymbolicName();
			String message = MessageFormatter.format(BundleDependencyCommandProvider.PREREQUISITES_OF_BUNDLE, bundleSymbolicName);
			appendLine(message);
			List/*<Bundle>*/ list = getPrerequisitesOf(bundle);
			appendBundles(list);
		}
	}

	private int compareBundles(Bundle leftBundle, Bundle rightBundle) {
		int result;
		String sortBundlesBy = getSortBundlesBy();

		if (sortBundlesBy.equalsIgnoreCase(BundleDependencyCommandProvider.SORT_BUNDLES_BY_BUNDLE_ID)) {
			result = compareBundlesById(leftBundle, rightBundle);
		} else if (sortBundlesBy.equalsIgnoreCase(BundleDependencyCommandProvider.SORT_BUNDLES_BY_BUNDLE_SYMBOLIC_NAME)) {
			result = compareBundlesByBundleSymbolicName(leftBundle, rightBundle);
		} else {
			String pattern = "unrecognized bundle sort order: {0}";  //$NON-NLS-1$
			String message = MessageFormatter.format(pattern, sortBundlesBy);
			throw new IllegalArgumentException(message);
		}

		return result;
	}


	private int compareBundlesByBundleSymbolicName(Bundle leftBundle, Bundle rightBundle) {
		String leftBundleSymbolicName = leftBundle.getSymbolicName();
		String rightBundleSymbolicName = rightBundle.getSymbolicName();
		int result = leftBundleSymbolicName.compareTo(rightBundleSymbolicName);
		return result;
	}

	private int compareBundlesById(Bundle leftBundle, Bundle rightBundle) {
		long leftBundleId = leftBundle.getBundleId();
		long rightBundleId = rightBundle.getBundleId();
		if (leftBundleId < rightBundleId)
			return -1;
		if (leftBundleId > rightBundleId)
			return 1;
		return 0;
	}

	private Comparator createBundleComparator() {
		return new Comparator(){
			public int compare(Object left, Object right) {
				Bundle leftBundle = (Bundle) left;
				Bundle rightBundle = (Bundle) right;
				int result = BundleDependencyCommandProvider.this.compareBundles(leftBundle, rightBundle);
				return result;
			}
		};
	}

	protected String createBundleStatePadding(Bundle bundle, String state) {
		String padding = super.createBundleStatePadding(bundle, state);
		boolean uninstallable = isRegisteredAsUninstallable(bundle);
		if (uninstallable == false)
			return padding;  // Early return.
		padding += BundleDependencyCommandProvider.IS_REGISTERED_AS_UNINSTALLABLE_FLAG;
		return padding;
	}

	private List/*<Bundle>*/ getAllBundleArguments() {
		List/*<String>*/ arguments = getAllArguments();
		boolean empty = arguments.isEmpty();
		if (empty == true)
			return AbstractCommandProvider.EMPTY_LIST;  // Early return.

		int size = arguments.size();
		List/*<Bundle>*/ bundles = new ArrayList/*<Bundle>*/(size);
		Iterator/*<String>*/ iterator = arguments.iterator();

		while (iterator.hasNext() == true) {
			String argument = (String) iterator.next();
			Bundle bundle = getBundle(argument);
			if (bundle == null)
				continue; // Skip to next iteration.
			bundles.add(bundle);
		}

		return bundles;
	}

	private List/*<Bundle>*/ getAllBundles() {
		BundleContext context = getBundleContext();
		Bundle[] bundles = context.getBundles();
		List/*<Bundle>*/ list = Arrays.asList(bundles);
		Comparator comparator = getBundleComparator();
		Collections.sort(list, comparator);
		return list;
	}

	private String getAllDependentsCommandHelpLine() {
		return MessageFormatter.format(BundleDependencyCommandProvider.ALL_DEPENDENDENTS_COMMAND_HELP, BundleDependencyCommandProvider.ALL_DEPENDENTS_DESCRIPTION);
	}

	private List/*<Bundle>*/ getAllDependentsOf(Bundle bundle) {
		BundleDependencyService bds = getModel();
		List/*<Bundle>*/ list = bds.getAllDependentsOf(bundle);
		return list;
	}

	private String getAllPrerequisitesCommandHelpLine() {
		return MessageFormatter.format(BundleDependencyCommandProvider.ALL_PREREQUISITES_COMMAND_HELP, BundleDependencyCommandProvider.ALL_PREREQUISITES_DESCRIPTION);
	}

	private List/*<Bundle>*/ getAllPrerequisitesOf(Bundle bundle) {
		BundleDependencyService bds = getModel();
		List/*<Bundle>*/ list = bds.getAllPrerequisitesOf(bundle);
		return list;
	}

	private Comparator/*<Bundle>*/ getBundleComparator() {
		return bundleComparator;
	}

	private List/*<String>*/ getBundles() {
		List/*<String>*/ bundles = getAllBundleArguments();
		boolean empty = bundles.isEmpty();
		if (empty == true) {
			bundles = getAllBundles();
		}
		return bundles;
	}

	private String getCircCommandHelpLine() {
		return MessageFormatter.format(BundleDependencyCommandProvider.CIRC_COMMAND_HELP, BundleDependencyCommandProvider.CIRC_DESCRIPTION);
	}

	/**
	 * @see org.eclipse.soda.sat.internal.equinox.console.cmdprov.AbstractCommandProvider#getCommandHelpLines()
	 */
	protected String[] getCommandHelpLines() {
		return new String[] {
			getAllDependentsCommandHelpLine(),
			getAllPrerequisitesCommandHelpLine(),
			getCircCommandHelpLine(),
			getDependentsCommandHelpLine(),
			getPrerequisitesCommandHelpLine(),
		};
	}

	private String getDependentsCommandHelpLine() {
		return MessageFormatter.format(BundleDependencyCommandProvider.DEPENDENTS_COMMAND_HELP, BundleDependencyCommandProvider.DEPENDENTS_DESCRIPTION);
	}

	private List/*<Bundle>*/ getDependentsOf(Bundle bundle) {
		BundleDependencyService bds = getModel();
		List/*<Bundle>*/ list = bds.getDependentsOf(bundle);
		return list;
	}

	private BundleDependencyService getModel() {
		return model;
	}

	private String getPrerequisitesCommandHelpLine() {
		return MessageFormatter.format(BundleDependencyCommandProvider.PREREQUISITES_COMMAND_HELP, BundleDependencyCommandProvider.PREREQUISITES_DESCRIPTION);
	}

	private List/*<Bundle>*/ getPrerequisitesOf(Bundle bundle) {
		BundleDependencyService bds = getModel();
		List/*<Bundle>*/ list = bds.getPrerequisitesOf(bundle);
		return list;
	}

	private String getSortBundlesBy() {
		return sortBundlesBy;
	}

	private String getSortBundlesByCommandHelpLine() {
		Object[] values = new Object[] {
			BundleDependencyCommandProvider.SORT_BUNDLES_BY_BUNDLE_ID,
			BundleDependencyCommandProvider.SORT_BUNDLES_BY_BUNDLE_SYMBOLIC_NAME,
			BundleDependencyCommandProvider.SORT_BUNDLES_BY_DESCRIPTION
		};
		return MessageFormatter.format(BundleDependencyCommandProvider.SORT_BUNDLES_BY_COMMAND_HELP, values);
	}

	/**
	 * @see org.eclipse.soda.sat.internal.equinox.console.cmdprov.AbstractCommandProvider#getTitle()
	 */
	protected String getTitle() {
		return BundleDependencyCommandProvider.TITLE;
	}

	private boolean hasCircularReferences(Bundle bundle) {
		BundleDependencyService bds = getModel();
		boolean result = bds.hasCircularReferences(bundle);
		return result;
	}

	private boolean isRegisteredAsUninstallable(Bundle bundle) {
		BundleDependencyService bds = getModel();
		boolean uninstallable = bds.isRegisteredAsUninstallable(bundle);
		return uninstallable;
	}

	private void setBundleComparator(Comparator bundleComparator) {
		this.bundleComparator = bundleComparator;
	}

	private void setModel(BundleDependencyService model) {
		this.model = model;
	}

	private void setSortBundlesBy(String sortBundlesBy) {
		this.sortBundlesBy = sortBundlesBy;
	}

	private void sortBundles(List/*<Bundle*/ list) {
		Comparator comparator = getBundleComparator();
		Collections.sort(list, comparator);
	}

	private void sortBundlesByBundleSymbolicName(List/*<Bundle*/ list) {
		String sortBundlesBy = getSortBundlesBy();
		try {
			setSortBundlesBy(BundleDependencyCommandProvider.SORT_BUNDLES_BY_BUNDLE_SYMBOLIC_NAME);
			sortBundles(list);
		} finally {
			setSortBundlesBy(sortBundlesBy);
		}
	}
}
