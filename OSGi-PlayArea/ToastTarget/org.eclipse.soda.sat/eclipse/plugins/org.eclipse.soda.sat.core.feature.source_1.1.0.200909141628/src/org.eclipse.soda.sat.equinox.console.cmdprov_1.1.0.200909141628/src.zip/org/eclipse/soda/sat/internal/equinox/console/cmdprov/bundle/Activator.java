/*******************************************************************************
 * Copyright (c) 2001, 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.equinox.console.cmdprov.bundle;

import org.eclipse.osgi.framework.console.CommandProvider;
import org.eclipse.soda.sat.core.framework.BaseBundleActivator;
import org.eclipse.soda.sat.core.service.BundleDependencyService;
import org.eclipse.soda.sat.core.util.MiscUtility;
import org.eclipse.soda.sat.internal.equinox.console.cmdprov.BundleDependencyCommandProvider;
import org.eclipse.soda.sat.internal.equinox.console.cmdprov.ConfigurationAdminCommandProvider;
import org.eclipse.soda.sat.internal.equinox.console.cmdprov.LogUtilityCommandProvider;
import org.eclipse.soda.sat.internal.equinox.console.cmdprov.MissingImportedServicesCommandProvider;
import org.osgi.framework.BundleContext;
import org.osgi.service.cm.ConfigurationAdmin;

/**
 * Activator.java
 */
public class Activator extends BaseBundleActivator {
	//
	// Static Fields
	//

	// Service Names
	private static final String CONFIGURATION_ADMIN_SERVICE_NAME = ConfigurationAdmin.class.getName();
	private static final String COMMAND_PROVIDER_SERVICE_NAME = CommandProvider.class.getName();

	//
	// Instance Fields
	//

	private CommandProvider configurationAdminCommandProvider;

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#activate()
	 */
	protected void activate() {
		addExportedBundleDependencyCommandProvider();
		addExportedLogUtilityCommandProvider();
		addExportedMissingImportedServicesCommandProvider();
	}

	private void addExportedBundleDependencyCommandProvider() {
		boolean enabled = isBundleDependencyServiceEnabled();
		if (enabled == false)
			return;  // Early return.
		BundleContext context = getBundleContext();
		BundleDependencyService bds = getBundleDependencyService();
		Object service = new BundleDependencyCommandProvider(context, bds);
		addExportedService(Activator.COMMAND_PROVIDER_SERVICE_NAME, service, null);
	}

	private void addExportedConfigurationAdminCommandProvider(ConfigurationAdmin admin) {
		BundleContext context = getBundleContext();
		CommandProvider service = new ConfigurationAdminCommandProvider(context, admin);
		setConfigurationAdminCommandProvider(service);
		addExportedService(Activator.COMMAND_PROVIDER_SERVICE_NAME, service, null);
	}

	private void addExportedLogUtilityCommandProvider() {
		BundleContext context = getBundleContext();
		Object service = new LogUtilityCommandProvider(context);
		addExportedService(Activator.COMMAND_PROVIDER_SERVICE_NAME, service, null);
	}

	private void addExportedMissingImportedServicesCommandProvider() {
		boolean enabled = isBundleDependencyServiceEnabled();
		if (enabled == false)
			return;  // Early return.
		BundleContext context = getBundleContext();
		BundleDependencyService bds = getBundleDependencyService();
		MissingImportedServicesCommandProvider service = new MissingImportedServicesCommandProvider(context, bds);
		addExportedService(Activator.COMMAND_PROVIDER_SERVICE_NAME, service, null);
	}

	private BundleDependencyService getBundleDependencyService() {
		return (BundleDependencyService) getImportedService(BundleDependencyService.SERVICE_NAME);
	}

	private final CommandProvider getConfigurationAdminCommandProvider() {
		return configurationAdminCommandProvider;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#getImportedServiceNames()
	 */
	protected String[] getImportedServiceNames() {
		return new String[] {
			BundleDependencyService.SERVICE_NAME
		};
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#getOptionalImportedServiceNames()
	 */
	protected String[] getOptionalImportedServiceNames() {
		return new String[] {
			Activator.CONFIGURATION_ADMIN_SERVICE_NAME
		};
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#handleAcquiredOptionalImportedService(java.lang.String, java.lang.Object)
	 */
	protected void handleAcquiredOptionalImportedService(String serviceName, Object service) {
		if (serviceName.equals(Activator.CONFIGURATION_ADMIN_SERVICE_NAME)) {
			// Register the exported CommandProvider for ConfigurationAdmin .
			ConfigurationAdmin admin = (ConfigurationAdmin) service;
			addExportedConfigurationAdminCommandProvider(admin);
		} else {
			super.handleAcquiredOptionalImportedService(serviceName, service);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#handleReleasedOptionalImportedService(java.lang.String, java.lang.Object)
	 */
	protected void handleReleasedOptionalImportedService(String serviceName, Object service) {
		if (serviceName.equals(Activator.CONFIGURATION_ADMIN_SERVICE_NAME)) {
			// Unregister the exported CommandProvider for ConfigurationAdmin .
			removeExportedConfigurationAdminCommandProvider();
		} else {
			super.handleReleasedOptionalImportedService(serviceName, service);
		}
	}

	private boolean isBundleDependencyServiceEnabled() {
		MiscUtility utility = MiscUtility.getInstance();
		boolean status = utility.getBooleanProperty(BundleDependencyService.BDS_STATUS_PROPERTY, true);
		return status;
	}

	private void removeExportedConfigurationAdminCommandProvider() {
		Object service = getConfigurationAdminCommandProvider();
		removeExportedService(Activator.COMMAND_PROVIDER_SERVICE_NAME, service);
		setConfigurationAdminCommandProvider(null);
	}

	private final void setConfigurationAdminCommandProvider(CommandProvider configurationAdminCommandProvider) {
		this.configurationAdminCommandProvider = configurationAdminCommandProvider;
	}
}