/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/package org.eclipse.soda.sat.internal.core.log;

import org.eclipse.soda.sat.core.service.LogReaderAggregatorService;
import org.osgi.service.log.LogReaderService;

/**
 * ILogReaderAggregator.java
 */
public interface ILogReaderAggregator extends LogReaderAggregatorService {
	/**
	 * Add the specified <code>LogReaderService</code> to the aggregator.
	 *
	 * @param service  A <code>LogReaderService</code>.
	 */
	public void addLogReaderService(LogReaderService service);

	/**
	 * Remove the specified <code>LogReaderService</code> from the aggregator.
	 *
	 * @param service  A <code>LogReaderService</code>.
	 */
	public void removeLogReaderService(LogReaderService service);

	/**
	 * Start aggregating logged messages.
	 */
	public void start();

	/**
	 * Stop aggregating logged messages.
	 */
	public void stop();
}
