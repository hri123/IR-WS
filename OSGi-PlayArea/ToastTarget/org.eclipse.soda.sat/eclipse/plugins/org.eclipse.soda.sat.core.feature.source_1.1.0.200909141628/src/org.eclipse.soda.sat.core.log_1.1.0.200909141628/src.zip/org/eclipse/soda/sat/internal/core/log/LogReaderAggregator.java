/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.core.log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.service.LogReaderAggregatorService;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.osgi.framework.ServiceReference;
import org.osgi.service.log.LogEntry;
import org.osgi.service.log.LogListener;
import org.osgi.service.log.LogReaderService;
import org.osgi.service.log.LogService;

/**
 * LogReaderAggregator.java
 */
public class LogReaderAggregator extends Object implements ILogReaderAggregator {
	//
	// Instance Fields
	//

	private volatile boolean started;
	private volatile LogService consoleLog;
	private LogListener logListener;
	private List/*<LogListener>*/ listeners;
	private List/*<LogReaderService>*/ readers;

	//
	// Constructors
	//

	public LogReaderAggregator() {
		super();
		setStarted(false);
		setListeners(new ArrayList/*<LogListener>*/(5));
		setReaders(new ArrayList/*<LogReaderService>*/(3));
		addConsoleLogListener();
	}

	//
	// Instance Methods
	//

	private void addConsoleLogListener() {
		boolean state = Boolean.getBoolean(LogReaderAggregatorService.LOGGING_TO_CONSOLE_PROPERTY);
		setLogToConsole(state);
		LogListener listener = createConsoleLogListener();
		addLogListener(listener);
	}

	/**
	 * @see org.osgi.service.log.LogReaderService#addLogListener(org.osgi.service.log.LogListener)
	 */
	public void addLogListener(LogListener listener) {
		Assertion.checkArgumentIsNotNull(listener, "listener"); //$NON-NLS-1$
		List/*<LogListener>*/ listeners = getListeners();
		synchronized (listeners) {
			boolean exists = listeners.contains(listener);
			if (exists == true)
				return;  // Early return.
			listeners.add(listener);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.internal.core.log.ILogReaderAggregator#addLogReaderService(org.osgi.service.log.LogReaderService)
	 */
	public void addLogReaderService(LogReaderService reader) {
		Assertion.checkArgumentIsNotNull(reader, "reader");  //$NON-NLS-1$

		synchronized (this) {
			List/*<LogReaderService>*/ readers = getReaders();

			synchronized (readers) {
				boolean exists = readers.contains(reader);
				if (exists == true)
					return;  // Early return.
				readers.add(reader);
			}

			boolean started = isStarted();
			if (started == false)
				return;  // Early return.
			hookLogReaderService(reader);
		}
	}

	private void basicPrintOn(ICharBuffer buffer) {
		Object value = super.toString();
		buffer.append(value);
	}

	private void collectLogEntries(boolean inOrder, List/*<LogEntry>*/ entries, LogReaderService reader) {
		if (inOrder == false) {
			collectLogEntries(entries, reader);
		} else {
			collectLogEntriesInOrder(entries, reader);
		}

	}

	private void collectLogEntries(List/*<LogEntry>*/ entries, LogReaderService reader) {
		Enumeration/*<LogEntry>*/ enumeration = reader.getLog();

		while (enumeration.hasMoreElements() == true) {
			LogEntry entry = (LogEntry) enumeration.nextElement();
			entries.add(entry);
		}
	}

	private void collectLogEntriesInOrder(List/*<LogEntry>*/ entries, LogReaderService reader) {
		Enumeration/*<LogEntry>*/ enumeration = reader.getLog();
		List/*<LogEntry>*/ list = new ArrayList/*<LogEntry>*/(100);

		while (enumeration.hasMoreElements() == true) {
			LogEntry entry = (LogEntry) enumeration.nextElement();
			list.add(entry);
		}

		int size = list.size();

		for (int i = size - 1; i >= 0; i--) {
			LogEntry entry = (LogEntry) list.get(i);
			entries.add(entry);
		}
	}

	private int compare(boolean inOrder, LogEntry leftEntry, LogEntry rightEntry) {
		int comparison;

		if (inOrder == true) {
			comparison = compare(leftEntry, rightEntry);
		} else {
			comparison = compare(rightEntry, leftEntry);
		}

		return comparison;
	}

	private int compare(LogEntry leftEntry, LogEntry rightEntry) {
		long leftEntryTime = leftEntry.getTime();
		long rightEntryTime = rightEntry.getTime();
		long comparison = leftEntryTime - rightEntryTime;
		int result = (int) comparison; // $codepro.audit.disable lossOfPrecisionInCast
		return result;
	}

	private LogListener createConsoleLogListener() {
		return new LogListener() {
			public void logged(LogEntry entry) {
				LogReaderAggregator.this.logToConsole(entry);
			}
		};
	}

	private Comparator/*<LogEntry>*/ createLogEntryComparator(final boolean inOrder) {
		return new Comparator/*<LogEntry>*/() {
			public int compare(Object left, Object right) {
				LogEntry leftEntry = (LogEntry) left;
				LogEntry rightEntry = (LogEntry) right;
				return LogReaderAggregator.this.compare(inOrder, leftEntry, rightEntry);
			}
		};
	}

	private LogListener createLogListener() {
		return new LogListener() {
			public void logged(LogEntry entry) {
				LogReaderAggregator.this.handleLogEntry(entry);
			}
		};
	}

	private void drain(LogReaderService reader) {
		Enumeration/*<LogEntry>*/ enumeration = reader.getLog();
		List/*LogEntry*/ entries = new ArrayList(100);
		LogEntry entry;

		while (enumeration.hasMoreElements() == true) {
			entry = (LogEntry) enumeration.nextElement();
			entries.add(entry);
		}

		int size = entries.size();

		for (int i = size - 1; i >= 0; i--) {
			entry = (LogEntry) entries.get(i);
			handleLogEntry(entry);
		}
	}

	private LogService getConsoleLog() {
		return consoleLog;
	}

	private List/*<LogListener>*/ getListeners() {
		return listeners;
	}

	/**
	 * @see org.osgi.service.log.LogReaderService#getLog()
	 */
	public Enumeration/*<LogEntry>*/ getLog() {
		return getLog(false);
	}

	private Enumeration/*<LogEntry>*/ getLog(boolean inOrder) {
		Vector/*<LogEntry>*/ entries;
		List/*<LogReaderService>*/ readers = getReaders();

		synchronized (readers) {
			int size = readers.size();
			int capacity = size * 100;
			entries = new Vector/*<LogEntry>*/(capacity);
			Iterator/*<LogReaderService>*/ iterator = readers.iterator();

			while (iterator.hasNext() == true) {
				LogReaderService reader = (LogReaderService) iterator.next();
				collectLogEntries(inOrder, entries, reader);
			}
		}

		Enumeration/*<LogEntry>*/ elements = entries.elements();
		Comparator/*<LogEntry>*/ comparator = createLogEntryComparator(inOrder);
		Collections.sort(entries, comparator);
		return elements;
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.LogReaderAggregatorService#getLogInOrder()
	 */
	public Enumeration/*<LogEntry>*/ getLogInOrder() {
		return getLog(true);
	}

	private LogListener getLogListener() {
		synchronized (this) {
			if (logListener == null) {
				LogListener listener = createLogListener();
				setLogListener(listener);
			}

			return logListener;
		}
	}

	private List/*<LogReaderService>*/ getReaders() {
		return readers;
	}

	private void handleLogEntry(LogEntry entry) {
		List/*<LogListener>*/ listeners = getListeners();

		synchronized (listeners) {
			Iterator/*<LogListener>*/ iterator = listeners.iterator();
			while (iterator.hasNext() == true) {
				LogListener listener = (LogListener) iterator.next();
				listener.logged(entry);
			}
		}
	}

	private void hookLogReaderService(LogReaderService reader) {
		LogListener listener = getLogListener();
		reader.addLogListener(listener);
		drain(reader);
	}

	private void hookLogReaderServices() {
		List/*<LogReaderService>*/ readers = getReaders();

		synchronized (readers) {
			Iterator/*<LogReaderService>*/ iterator = readers.iterator();
			while (iterator.hasNext() == true) {
				LogReaderService reader = (LogReaderService) iterator.next();
				hookLogReaderService(reader);
			}
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.LogReaderAggregatorService#isLoggingToConsole()
	 */
	public boolean isLoggingToConsole() {
		Object object = getConsoleLog();
		boolean state = object != null;
		return state;
	}

	private boolean isStarted() {
		return started;
	}

	private void logToConsole(LogEntry entry) {
		LogService log = getConsoleLog();
		if (log == null)
			return;  // Early return.
		ServiceReference reference = entry.getServiceReference();
		int level = entry.getLevel();
		String message = entry.getMessage();
		Throwable throwable = entry.getException();
		log.log(reference, level, message, throwable);
	}

	private void printConsoleLogOn(ICharBuffer buffer) {
		Object object = getConsoleLog();
		buffer.append(", consoleLog=");  //$NON-NLS-1$
		buffer.append(object);
	}

	private void printListenersOn(ICharBuffer buffer) {
		List/*<LogListener>*/ list = getListeners();
		int count = list.size();
		buffer.append(", listeners=");  //$NON-NLS-1$
		buffer.append(count);
	}

	private void printLogListenerOn(ICharBuffer buffer) {
		Object object = getLogListener();
		buffer.append(", logListener=");  //$NON-NLS-1$
		buffer.append(object);
	}

	private void printOn(ICharBuffer buffer) {
		basicPrintOn(buffer);
		printStartedOn(buffer);
		printLogListenerOn(buffer);
		printListenersOn(buffer);
		printReadersOn(buffer);
		printConsoleLogOn(buffer);

	}

	private void printReadersOn(ICharBuffer buffer) {
		List/*<LogReaderService>*/ list = getReaders();
		int count = list.size();
		buffer.append(", readers=");  //$NON-NLS-1$
		buffer.append(count);
	}

	private void printStartedOn(ICharBuffer buffer) {
		boolean started = isStarted();
		buffer.append(", started=");  //$NON-NLS-1$
		buffer.append(started);
	}

	/**
	 * @see org.osgi.service.log.LogReaderService#removeLogListener(org.osgi.service.log.LogListener)
	 */
	public void removeLogListener(LogListener listener) {
		Assertion.checkArgumentIsNotNull(listener, "listener"); //$NON-NLS-1$
		List/*<LogListener>*/ listeners = getListeners();
		synchronized (listeners) {
			listeners.remove(listener);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.internal.core.log.ILogReaderAggregator#removeLogReaderService(org.osgi.service.log.LogReaderService)
	 */
	public void removeLogReaderService(LogReaderService reader) {
		Assertion.checkArgumentIsNotNull(reader, "reader");  //$NON-NLS-1$

		synchronized (this) {
			List/*<LogReaderService>*/ readers = getReaders();

			synchronized (readers) {
				boolean removed = readers.remove(reader);
				if (removed == false)
					return;  // Early return.
			}

			boolean started = isStarted();
			if (started == false)
				return;  // Early return.
			unhookLogReaderService(reader);
		}
	}

	private void setConsoleLog(LogService consoleLog) {
		this.consoleLog = consoleLog;
	}

	private void setListeners(List/*<LogListener>*/ listeners) {
		this.listeners = listeners;
	}

	private void setLogListener(LogListener logListener) {
		this.logListener = logListener;
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.LogReaderAggregatorService#setLogToConsole(boolean)
	 */
	public void setLogToConsole(boolean logToConsole) {
		synchronized (this) {
			LogService log;

			boolean state = isLoggingToConsole();
			if (logToConsole == true) {
				if (state == true)
					return;  // Early return.
				FactoryUtility utility = FactoryUtility.getInstance();
				log = utility.createConsoleLog();
			} else {
				if (state == false)
					return;  // Early return.
				log = null;
			}

			setConsoleLog(log);
		}
	}

	private void setReaders(List/*<LogReaderService>*/ readers) {
		this.readers = readers;
	}

	private void setStarted(boolean started) {
		this.started = started;
	}

	/**
	 * @see org.eclipse.soda.sat.internal.core.log.ILogReaderAggregator#start()
	 */
	public void start() {
		synchronized (this) {
			boolean started = isStarted();
			if (started == true)
				return;
			setStarted(true);
			hookLogReaderServices();
		}
	}

	/**
	 * @see org.eclipse.soda.sat.internal.core.log.ILogReaderAggregator#stop()
	 */
	public void stop() {
		synchronized (this) {
			boolean started = isStarted();
			if (started == false)
				return;  // Early return.
			setStarted(false);
			unhookLogReaderServices();
		}
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(500);
		printOn(buffer);
		String value = buffer.toString();
		return value;
	}

	private void unhookLogReaderService(LogReaderService reader) {
		LogListener listener = getLogListener();
		reader.removeLogListener(listener);
	}

	private void unhookLogReaderServices() {
		List/*<LogReaderService>*/ readers = getReaders();

		synchronized (readers) {
			Iterator/*<LogReaderService>*/ iterator = readers.iterator();
			while (iterator.hasNext() == true) {
				LogReaderService reader = (LogReaderService) iterator.next();
				unhookLogReaderService(reader);
			}
		}
	}
}