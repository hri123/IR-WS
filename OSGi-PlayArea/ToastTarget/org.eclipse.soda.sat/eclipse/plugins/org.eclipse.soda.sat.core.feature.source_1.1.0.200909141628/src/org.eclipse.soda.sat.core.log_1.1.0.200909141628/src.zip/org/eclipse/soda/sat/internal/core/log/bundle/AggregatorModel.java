/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.core.log.bundle;

import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.record.interfaces.IServiceDetecter;
import org.eclipse.soda.sat.core.record.interfaces.ServiceDetecterListener;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.internal.core.log.ILogReaderAggregator;
import org.eclipse.soda.sat.internal.core.log.LogReaderAggregator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.service.log.LogReaderService;

class AggregatorModel extends Object {
	//
	// Static Fields
	//

	private static final String LOG_READER_SERVICE_NAME = LogReaderService.class.getName();

	//
	// Instance Fields
	//

	private BundleContext bundleContext;
	private ILogReaderAggregator aggregator;
	private IServiceDetecter detecter;

	//
	// Constructors
	//

	AggregatorModel(BundleContext bundleContext) {
		super();
		setBundleContext(bundleContext);
	}

	//
	// Instance Methods
	//

	private void addLogReaderService(LogReaderService reader) {
		ILogReaderAggregator aggregator = getAggregator();
		aggregator.addLogReaderService(reader);
	}

	private void basicPrintOn(ICharBuffer buffer) {
		Object value = super.toString();
		buffer.append(value);
	}

	private IServiceDetecter createServiceDetecter() {
		FactoryUtility utility = FactoryUtility.getInstance();
		BundleContext bundleContext = getBundleContext();
		IServiceDetecter detecter = utility.createServiceDetecter(bundleContext, AggregatorModel.LOG_READER_SERVICE_NAME);
		ServiceDetecterListener listener = createServiceDetecterListener();
		detecter.addServiceDetecterListener(listener);
		return detecter;
	}


	private ServiceDetecterListener createServiceDetecterListener() {
		return new ServiceDetecterListener() {
			public void serviceAdded(IServiceDetecter detecter, ServiceReference serviceReference, Object service) {
				LogReaderService reader = (LogReaderService) service;
				AggregatorModel.this.addLogReaderService(reader);
			}

			public void serviceRemoved(IServiceDetecter detecter, ServiceReference serviceReference, Object service) {
				LogReaderService reader = (LogReaderService) service;
				AggregatorModel.this.removeLogReaderService(reader);
			}
		};
	}

	ILogReaderAggregator getAggregator() {
		return aggregator;
	}

	private BundleContext getBundleContext() {
		return bundleContext;
	}

	private IServiceDetecter getDetecter() {
		return detecter;
	}

	private void printAggregatorOn(ICharBuffer buffer) {
		Object object = getAggregator();
		buffer.append(", aggregator=");  //$NON-NLS-1$
		buffer.append(object);
	}

	private void printBundleContextOn(ICharBuffer buffer) {
		Object object = getBundleContext();
		buffer.append(", bundleContext=");  //$NON-NLS-1$
		buffer.append(object);
	}

	private void printDetecterOn(ICharBuffer buffer) {
		Object object = getDetecter();
		buffer.append(", detecter=");  //$NON-NLS-1$
		buffer.append(object);
	}

	private void printOn(ICharBuffer buffer) {
		basicPrintOn(buffer);
		printBundleContextOn(buffer);
		printAggregatorOn(buffer);
		printDetecterOn(buffer);
	}

	private void removeLogReaderService(LogReaderService reader) {
		ILogReaderAggregator aggregator = getAggregator();
		aggregator.removeLogReaderService(reader);
	}

	private void setAggregator(ILogReaderAggregator aggregator) {
		this.aggregator = aggregator;
	}

	private void setBundleContext(BundleContext bundleContext) {
		Assertion.checkArgumentIsNotNull(bundleContext, "bundleContext");  //$NON-NLS-1$
		this.bundleContext = bundleContext;
	}

	private void setDetecter(IServiceDetecter detecter) {
		this.detecter = detecter;
	}


	void start() {
		ILogReaderAggregator aggregator = new LogReaderAggregator();
		setAggregator(aggregator);

		IServiceDetecter detecter = createServiceDetecter();
		setDetecter(detecter);

		aggregator.start();
		detecter.acquire();
	}

	void stop() {
		IServiceDetecter detector = getDetecter();
		detector.release();

		ILogReaderAggregator aggregator = getAggregator();
		aggregator.stop();

		setDetecter(null);
		setAggregator(null);
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(500);
		printOn(buffer);
		String value = buffer.toString();
		return value;
	}
}
