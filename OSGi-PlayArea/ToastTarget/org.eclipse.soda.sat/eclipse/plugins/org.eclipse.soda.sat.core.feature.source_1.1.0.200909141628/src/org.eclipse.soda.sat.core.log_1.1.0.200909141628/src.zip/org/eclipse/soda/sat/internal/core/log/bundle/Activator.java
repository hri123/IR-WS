/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.core.log.bundle;

import org.eclipse.soda.sat.core.framework.BaseBundleActivator;
import org.eclipse.soda.sat.core.service.LogReaderAggregatorService;
import org.osgi.framework.BundleContext;

/**
 * Activator.java
 */
public class Activator extends BaseBundleActivator {
	//
	// Instance Fields
	//

	private AggregatorModel model;

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#activate()
	 */
	protected void activate() {
		AggregatorModel model = startAggregatorModel();
		Object service = model.getAggregator();
		addExportedService(LogReaderAggregatorService.SERVICE_NAME, service, null);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#deactivate()
	 */
	protected void deactivate() {
		stopAggregatorModel();
	}

	private AggregatorModel getAggregatorModel() {
		return model;
	}

	private void setAggregatorModel(AggregatorModel model) {
		this.model = model;
	}

	private AggregatorModel startAggregatorModel() {
		BundleContext context = getBundleContext();
		AggregatorModel aggregatorModel = new AggregatorModel(context);
		setAggregatorModel(aggregatorModel);
		aggregatorModel.start();
		return aggregatorModel;
	}

	private void stopAggregatorModel() {
		AggregatorModel model = getAggregatorModel();
		model.stop();
		setAggregatorModel(null);
	}
}
