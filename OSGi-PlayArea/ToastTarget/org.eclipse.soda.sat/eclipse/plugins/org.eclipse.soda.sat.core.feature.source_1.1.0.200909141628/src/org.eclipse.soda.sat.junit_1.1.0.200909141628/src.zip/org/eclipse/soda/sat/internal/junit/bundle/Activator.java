/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.junit.bundle;

import org.eclipse.soda.sat.internal.junit.TestRunnerServer;
import org.eclipse.soda.sat.junit.service.TestRunnerServerService;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

/**
 * Activator.java
 */
public class Activator extends Object implements BundleActivator {
	private TestRunnerServer server;
	private ServiceRegistration serviceRegistration;

	/**
	 * Constructor.
	 */
	public Activator() {
		super();
		setServer(new TestRunnerServer());
	}

	/**
	 * Private server getter.
	 *
	 * @return  TestRunnerServer
	 */
	private TestRunnerServer getServer() {
		return server;
	}

	/**
	 * Private serviceRegistration getter.
	 *
	 * @return ServiceRegistration
	 */
	private ServiceRegistration getServiceRegistration() {
		return serviceRegistration;
	}

	/**
	 * Private server setter.
	 *
	 * @param server  The TestRunnerServer instance.
	 */
	private void setServer(TestRunnerServer server) {
		this.server = server;
	}

	/**
	 * Private serviceRegistration setter.
	 *
	 * @param serviceRegistration   The ServiceRegistration for the registered
	 *                               TestRunnerServerService.
	 */
	private void setServiceRegistration(ServiceRegistration serviceRegistration) {
		this.serviceRegistration = serviceRegistration;
	}

	/**
	 * Start the bundle.
	 *
	 * @param bundleContext  The BundleContext handle back to the framework.
	 */
	public void start(BundleContext bundleContext) {
		TestRunnerServer server = getServer();
		server.startup();

		ServiceRegistration registration = bundleContext.registerService(TestRunnerServerService.SERVICE_NAME, server, null);
		setServiceRegistration(registration);
	}

	/**
	 * Stop the bundle.
	 *
	 * @param bundleContext  The BundleContext handle back to the framework.
	 */
	public void stop(BundleContext bundleContext) {
		ServiceRegistration registration = getServiceRegistration();
		registration.unregister();
		setServiceRegistration(null);

		TestRunnerServer server = getServer();
		server.shutdown();
	}
}