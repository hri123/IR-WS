/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.junit.util;

/**
 * ValueHolder.java
 */
public class ValueHolder/*<T>*/ extends Object {
	private static final Object ZERO = new Integer(0);

	/**
	 * Answers a new <code>ValueHolder</code> with the <code>boolean</code>
	 * value <code>false</code>.
	 *
	 * @return A <code>ValueHolder</code> containing <code>false</code>.
	 */
	public static ValueHolder/*<Boolean>*/ falseValue() {
		return ValueHolder.valueOf(Boolean.FALSE);
	}

	/**
	 * Answers a new <code>ValueHolder</code> with the value <code>null</code>.
	 *
	 * @return A <code>ValueHolder</code> containing <code>null</code>.
	 */
	public static ValueHolder/*<Object>*/ nullValue() {
		return ValueHolder.valueOf(null);
	}

	/**
	 * Answers a new <code>ValueHolder</code> with the <code>boolean</code>
	 * value <code>true</code>.
	 *
	 * @return A <code>ValueHolder</code> containing <code>true</code>.
	 */
	public static ValueHolder/*<Boolean>*/ trueValue() {
		return ValueHolder.valueOf(Boolean.TRUE);
	}

	/**
	 * Answers a new <code>ValueHolder</code> with the specified
	 * <code>int</code> value.
	 *
	 * @param value  The <code>int</code> to be stored in a
	 *               <code>ValueHolder</code>.
	 * @return A <code>ValueHolder</code> containing an object.
	 */
	public static ValueHolder/*<Integer>*/ valueOf(int value) {
		Object object = new Integer(value);
		ValueHolder holder = new ValueHolder(object);
		return holder;
	}

	/**
	 * Answers a new <code>ValueHolder</code> with the specified value.
	 *
	 * @param value  The object to be stored in a <code>ValueHolder</code>.
	 * @return A <code>ValueHolder</code> containing an object.
	 */
	public static ValueHolder/*<Object>*/ valueOf(Object value) {
		ValueHolder holder = new ValueHolder(value);
		return holder;
	}

	/**
	 * Answers a new <code>ValueHolder</code> with the boolean value
	 * <code>true</code>.
	 *
	 * @return A <code>ValueHolder</code> containing true.
	 */
	public static ValueHolder/*<Integer>*/ zeroValue() {
		return ValueHolder.valueOf(ValueHolder.ZERO);
	}

	private volatile Object value;

	/**
	 * Constructor.
	 */
	private ValueHolder() {
		super();
	}

	/**
	 * Constructor.
	 *
	 * @param value  The object to be stored in the <code>ValueHolder</code>.
	 */
	private ValueHolder(Object value) {
		super();
		setValue(value);
	}

	/**
	 * Decrement the <code>int</code> value of the receiver by one.
	 */
	public void decrement() {
		int value = getIntValue();
		setValue(value - 1);
	}

	/**
	 * Answers the <code>int</code> value of the <code>ValueHolder</code>.
	 *
	 * @return  The <code>int</code> to stored in the receiver.
	 */
	public int getIntValue() {
		Integer wrapper = (Integer) getValue();
		int value = wrapper.intValue();
		return value;
	}

	/**
	 * Answers the value of the <code>ValueHolder</code>.
	 *
	 * @return  The object to stored in the receiver.
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * Increment the <code>int</code> value of the receiver by one.
	 */
	public void increment() {
		int value = getIntValue();
		setValue(value + 1);
	}

	/**
	 * Answers <code>true</code> if the value of the <code>ValueHolder</code> is
	 * <code>false</code>, otherwise <code>false</code>.
	 *
	 * @return True if the object stored in the receiver is false, otherwise
	 *         false.
	 */
	public boolean isFalse() {
		boolean result = isTrue() == false;
		return result;
	}

	/**
	 * Answers <code>true</code> if the value of the <code>ValueHolder</code> is
	 * not <code>null</code>, otherwise <code>false</code>.
	 *
	 * @return True if the object stored in the receiver is not null, otherwise
	 *         false.
	 */
	public boolean isNotNull() {
		boolean result = isNull() == false;
		return result;
	}

	/**
	 * Answers <code>true</code> if the value of the <code>ValueHolder</code> is
	 * not zero, otherwise <code>false</code>.
	 *
	 * @return True if the object stored in the receiver is not zero, otherwise
	 *         false.
	 */
	public boolean isNotZero() {
		boolean result = isZero() == false;
		return result;
	}

	/**
	 * Answers <code>true</code> if the value of the <code>ValueHolder</code> is
	 * <code>null</code>, otherwise <code>false</code>.
	 *
	 * @return True if the object stored in the receiver is null, otherwise
	 *         false.
	 */
	public boolean isNull() {
		Object value = getValue();
		boolean result = value == null;
		return result;
	}

	/**
	 * Answers <code>true</code> if the value of the <code>ValueHolder</code> is
	 * <code>true</code>, otherwise <code>false</code>.
	 *
	 * @return True if the object stored in the receiver is true, otherwise
	 *         false.
	 */
	public boolean isTrue() {
		Object value = getValue();
		boolean result = value == Boolean.TRUE; // $codepro.audit.disable useEquals
		return result;
	}

	/**
	 * Answers <code>true</code> if the value of the <code>ValueHolder</code> is
	 * zero, otherwise <code>false</code>.
	 *
	 * @return True if the object stored in the receiver is zero, otherwise
	 *         false.
	 */
	public boolean isZero() {
		Object value = getValue();
		boolean result = ValueHolder.ZERO.equals(value);
		return result;
	}

	/**
	 * Sets the value of the <code>ValueHolder</code> to <code>false</code>.
	 */
	public void setFalse() {
		setValue(Boolean.FALSE);
	}

	/**
	 * Sets the value of the <code>ValueHolder</code> to <code>null</code>.
	 */
	public void setNull() {
		setValue(null);
	}

	/**
	 * Sets the value of the <code>ValueHolder</code> to <code>true</code>.
	 */
	public void setTrue() {
		setValue(Boolean.TRUE);
	}

	/**
	 * Sets the value of the <code>ValueHolder</code> to the specified
	 * <code>boolean</code> value.
	 *
	 * @param value  The boolean value to be stored in the receiver.
	 */
	public void setValue(boolean value) {
		if (value == true) {
			setTrue();
		} else {
			setFalse();
		}
	}

	/**
	 * Sets the value of the <code>ValueHolder</code> to the specified
	 * <code>int</code> value.
	 *
	 * @param value  The int to be stored in the receiver.
	 */
	public void setValue(int value) {
		if (value == 0) {
			setZero();
		} else {
			Object object = new Integer(value);
			setValue(object);
		}
	}

	/**
	 * Sets the value of the <code>ValueHolder</code> to the specified
	 * <code>Object</code> value.
	 *
	 * @param value  The object to be stored in the receiver.
	 */
	public void setValue(Object value) {
		this.value = value;
	}

	/**
	 * Sets the value of the <code>ValueHolder</code> to zero.
	 */
	public void setZero() {
		setValue(ValueHolder.ZERO);
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		Object value = getValue();
		String result = String.valueOf(value);
		return result;
	}
}