/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.junit.service;

import junit.framework.Test;

/**
 * TestRunnerServerService.java
 */
public interface TestRunnerServerService {
	public static final String SERVICE_NAME = TestRunnerServerService.class.getName();

	/**
	 * Run a test.
	 *
	 * @param test  A JUnit test.
	 */
	public void run(Test test);
}