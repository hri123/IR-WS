/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.junit;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Queue.java
 */
public class Queue extends Object {
	private List items;

	/**
	 * Constructor.
	 */
	public Queue() {
		super();
		setItems(new ArrayList(50));
	}

	/**
	 * Add an object to the the Queue.
	 *
	 * @param item  The object to be added to the Queue.
	 */
	public void add(Object item) {
		Collection items = getItems();

		synchronized (this) {
			items.add(item);
			notifyAll();
		}
	}

	/**
	 * Private items getter.
	 *
	 * @return The List of items in the Queue.
	 */
	private List getItems() {
		return items;
	}

	/**
	 * Answers true if the Queue is empty, otherwise false.
	 *
	 * @return True if the Queue is empty, otherwise false.
	 */
	public boolean isEmpty() {
		List items = getItems();
		boolean empty = items.isEmpty();
		return empty;
	}

	/**
	 * Remove an object from the queue.
	 *
	 * @return The object removed from the Queue, or null if interrupted.
	 * @throws InterruptedException
	 */
	public Object remove() throws InterruptedException {
		Object item = null;

		synchronized (this) {
			waitWhileEmpty();
			List items = getItems();
			item = items.remove(0);
		}

		return item;
	}

	/**
	 * Private items setter.
	 *
	 * @param items  The List of items in the Queue.
	 */
	private void setItems(List items) {
		this.items = items;
	}

	/**
	 * Wait while there are no items in the queue.
	 */
	private void waitWhileEmpty() throws InterruptedException {
		while (isEmpty() == true) {
			wait();
		}
	}
}