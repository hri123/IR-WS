/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.junit;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.runner.Version;
import junit.textui.TestRunner;

import org.eclipse.soda.sat.junit.service.TestRunnerServerService;

/**
 * TestRunnerServer.java
 */
public class TestRunnerServer extends Object implements TestRunnerServerService {
	private boolean running;
	private Queue queue;
	private Thread thread;
	private final Object startupLock = new Object();

	/**
	 * Constructor.
	 */
	public TestRunnerServer() {
		super();
		setQueue(new Queue());
	}

	/**
	 * Answers whether the TestRunnerServer can be shutdown.
	 *
	 * @return True if the TestRunnerServer can be shutdown, otherwise false.
	 */
	private boolean canShutdown() {
		if (hasTests() == true)
			return false;  // Early return.
		if (isRunning() == true)
			return false;  // Early return.
		return true;
	}

	/**
	 * Create and answer the Runnable for the server.
	 *
	 * @return The Runnable for the server.
	 */
	private Runnable createRunnable() {
		Runnable runnable = new Runnable() {
			public void run() {
				TestRunnerServer server = TestRunnerServer.this;

				try {
					while (server.canShutdown() == false) {
						server.process();
					}
				} catch (InterruptedException exception) {
					// OK
				}
			}
		};

		return runnable;
	}

	/**
	 * Private queue getter.
	 *
	 * @return The receiver's Queue.
	 */
	private Queue getQueue() {
		return queue;
	}

	private Object getStartupLock() {
		return startupLock;
	}

	/**
	 * Private thread getter.
	 *
	 * @return The receiver's Thread.
	 */
	private Thread getThread() {
		return thread;
	}

	/**
	 * Answers whether there are still tests to run.
	 *
	 * @return True if there are still Tests to run, otherwise false.
	 */
	private boolean hasTests() {
		Queue queue = getQueue();
		boolean result = queue.isEmpty() == false;
		return result;
	}

	/**
	 * Answers whether the receiver is running.
	 *
	 * @return True if the receiver is running, otherwise false.
	 */
	private boolean isRunning() {
		synchronized (this) {
			return running;
		}
	}

	/**
	 * Prints the name of a Test.
	 *
	 * @param test  A JUnit test.
	 */
	private void printTestName(Test test) {
		if (test instanceof TestSuite == false) // $codepro.audit.disable disallowInstanceof
			return;  // Early return.

		TestSuite suite = (TestSuite) test;
		String name = suite.getName();
		System.out.print("JUnit "); //$NON-NLS-1$
		System.out.print(Version.id());
		System.out.print(" - Running Test Suite: "); //$NON-NLS-1$
		System.out.println(name);
	}

	/**
	 * The body of the server's thread.
	 */
	private void process() throws InterruptedException {
		Queue queue = getQueue();
		Test test = (Test) queue.remove();
		printTestName(test);
		TestRunner.run(test);
	}

	/**
	 * Run a test.
	 *
	 * @param test  A JUnit test.
	 */
	public void run(Test test) {
		Queue queue = getQueue();
		queue.add(test);
	}

	/**
	 * Private queue setter.
	 *
	 * @param queue  The receiver's Queue.
	 */
	private void setQueue(Queue queue) {
		this.queue = queue;
	}

	/**
	 * Private running setter.
	 *
	 * @param running  True if the receiver is running, otherwise false.
	 */
	private void setRunning(boolean running) {
		synchronized (this) {
			this.running = running;
		}
	}

	/**
	 * Private thread setter.
	 *
	 * @param thread  The receiver's Thread.
	 */
	private void setThread(Thread thread) {
		this.thread = thread;
	}

	/**
	 * Shutdown the server.
	 */
	public void shutdown() {
		Object lock = getStartupLock();

		synchronized (lock) {
			boolean running = isRunning();
			if (running == false)
				return;  // Early return.
			setRunning(false);
			shutdownThread();
			setQueue(null);
		}
	}

	/**
	 * Shuts down the TestRunnerServer's thread.
	 */
	private void shutdownThread() {
		Thread thread = getThread();
		thread.interrupt();

		try {
			thread.join();
		}
		catch (InterruptedException exception) {
			// No-op.
		}

		setThread(null);
	}

	/**
	 * Start up the server.
	 */
	public void startup() {
		Object lock = getStartupLock();

		synchronized (lock) {
			boolean running = isRunning();
			if (running == true)
				return;  // Early return.
			setRunning(true);
			startupThread();
		}
	}

	/**
	 * Starts up the TestRunnerServer's thread.
	 */
	private void startupThread() {
		Runnable runnable = createRunnable();
		Thread thread = new Thread(runnable, "TestRunnerServer");  //$NON-NLS-1$
		setThread(thread);
		thread.start();
	}
}