/*******************************************************************************
 * Copyright (c) 2001, 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.dependency.model.interfaces;

import java.util.List;

/**
 * IBundleDependencyModel.java
 */
public interface IBundleDependencyModel {
	public void addBundleDependencyModelListener(BundleDependencyModelListener listener);
	public List/*<String>*/ getAllDependentsOf(String bundleSymbolicName);
	public List/*<String>*/ getAllPrerequisitesOf(String bundleSymbolicName);
	public List/*<String>*/ getBundles();
	public List/*<String>*/ getDependentsOf(String bundleSymbolicName);
	public String getManifest(String bundleSymbolicName);
	public List/*<String>*/ getPrerequisitesOf(String bundleSymbolicName);
	public long[] getServiceIdsExportedBy(String bundleSymbolicName);
	public long[] getServiceIdsImportedBy(String bundleSymbolicName);
	public List getServiceNamesExportedBy(String bundleSymbolicName);
	public List/*<String>*/ getServiceNamesImportedBy(String bundleSymbolicName);
	public int getState(String bundleSymbolicName);
	public List/*<String*/ getUnacquiredImportedServiceNames(String id);
	public List/*<String*/ getUnacquiredOptionalImportedServiceNames(String id);
	public boolean isActive(String bundleSymbolicName);
	public boolean isBundle(String bundleSymbolicName);
	public boolean isExportingServices(String bundleSymbolicName);
	public boolean isImportingServices(String bundleSymbolicName);
	public void removeBundleDependencyModelListener(BundleDependencyModelListener listener);
	public String toXml();
}
