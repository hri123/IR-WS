/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.dependency.servlet.bundle;

import java.util.Set;

import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.internal.dependency.model.BundleDependencyModel;
import org.eclipse.soda.sat.internal.dependency.servlet.BundleDependencyServlet;
import org.osgi.service.http.HttpService;

/**
 * BundleDependencyServletActivator.java
 */
public class BundleDependencyServletActivator extends AbstractDependencyActivator {
	//
	// Static Fields
	//

	private static final String HTTP_SERVICE_NAME = HttpService.class.getName();

	//
	// Instance Fields
	//

	private BundleDependencyServlet servlet;

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#activate()
	 */
	protected void activate() {
		super.activate();

		BundleDependencyServlet servlet = new BundleDependencyServlet();
		setServlet(servlet);

		HttpService http = getHttpService();
		String port = getHttpServicePort();
		BundleDependencyModel model = getModel();
		servlet.bind(http, port, model);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#collectImportedServiceNames(java.util.Set)
	 */
	protected void collectImportedServiceNames(Set serviceNames) {
		super.collectImportedServiceNames(serviceNames);
		serviceNames.add(BundleDependencyServletActivator.HTTP_SERVICE_NAME);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#deactivate()
	 */
	protected void deactivate() {
		BundleDependencyServlet  servlet = getServlet();
		servlet.unbind();
		setServlet(null);

		super.deactivate();
	}

	/**
	 * Gets the HttpService.
	 */
	private HttpService getHttpService() {
		return (HttpService) getImportedService(HttpService.class.getName());
	}

	private String getHttpServicePort() {
		String value;

		try {
			Object wrapper = getImportedServiceProperty(BundleDependencyServletActivator.HTTP_SERVICE_NAME, "http.port");  //$NON-NLS-1$;
			value = wrapper.toString();
		} catch (IllegalArgumentException exception) {
			value = null;
			String message = exception.getMessage();
			LogUtility.logDebug(this, message);
		}

		return value;
	}

	/**
	 * Private servlet getter.
	 */
	private BundleDependencyServlet getServlet() {
		return servlet;
	}

	/**
	 * Private servlet setter.
	 */
	private void setServlet(BundleDependencyServlet servlet) {
		this.servlet = servlet;
	}
}
