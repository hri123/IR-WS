/*******************************************************************************
 * Copyright (c) 2001, 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.dependency.model;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.soda.sat.core.framework.interfaces.BundleDependencyListener;
import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.framework.interfaces.ILineReader;
import org.eclipse.soda.sat.core.service.BundleDependencyService;
import org.eclipse.soda.sat.core.util.BundleUtility;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.ServiceReferenceUtility;
import org.eclipse.soda.sat.internal.dependency.model.interfaces.BundleDependencyModelListener;
import org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel;
import org.eclipse.soda.sat.internal.dependency.nls.Messages;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleEvent;
import org.osgi.framework.BundleListener;
import org.osgi.framework.ServiceReference;

/**
 * BundleDependencyModel.java
 */
public class BundleDependencyModel extends Object implements IBundleDependencyModel {
	//
	// Nested Types
	//

	private class XmlPrinter extends Object {
		public String print() {
			FactoryUtility utility = FactoryUtility.getInstance();
			ICharBuffer buffer = utility.createCharBuffer(1000);
			buffer.append("<?xml version=\"1.0\"?>");  //$NON-NLS-1$
			buffer.append(BundleDependencyModel.LINE_SEPARATOR);
			buffer.append("<bundleDependencyModel>");  //$NON-NLS-1$
			buffer.append(BundleDependencyModel.LINE_SEPARATOR);
			printXmlOn(buffer, 1);
			buffer.append("</bundleDependencyModel>");  //$NON-NLS-1$
			String xml = buffer.toString();
			return xml;
		}

		protected final void printIndentOn(ICharBuffer buffer, int level) {
			String indent = "  ";  //$NON-NLS-1$

			for (int i = 0; i < level; i++) {
				buffer.append(indent);
			}
		}

		protected void printXmlBundleDependenciesOn(ICharBuffer buffer, int indent) {
			BundleDependencyService dependency = getDependency();
			String dependencyXml = dependency.toXml(indent);
			buffer.append(dependencyXml);
		}

		protected void printXmlBundleOn(ICharBuffer buffer, int indent, String bundleSymbolicName) {
			printIndentOn(buffer, indent);
			buffer.append("<bundle>");  //$NON-NLS-1$
			buffer.append(BundleDependencyModel.LINE_SEPARATOR);
			printXmlCDATAOn(buffer, indent + 1, bundleSymbolicName);

//
// Uncomment the following line of code to add "bundles in use" information to
// the XML.  Also uncomment the block of code at the bottom of this class.
//
//			printXmlBundlesInUseOnBuffer(buffer, indent + 1, bundleSymbolicName);

			printIndentOn(buffer, indent);
			buffer.append("</bundle>");  //$NON-NLS-1$
			buffer.append(BundleDependencyModel.LINE_SEPARATOR);
		}

		private void printXmlBundlesOn(ICharBuffer buffer, int indent) {
			printIndentOn(buffer, indent);
			buffer.append("<bundles>");  //$NON-NLS-1$
			buffer.append(BundleDependencyModel.LINE_SEPARATOR);

			List/*<String>*/ bundles = getBundles();
			Iterator/*<String>*/ iterator = bundles.iterator();

			while (iterator.hasNext() == true) {
				String bundleSymbolicName = (String) iterator.next();
				bundleSymbolicName = removeSuffixFrom(bundleSymbolicName);
				printXmlBundleOn(buffer, indent + 1, bundleSymbolicName);
			}

			printIndentOn(buffer, indent);
			buffer.append("</bundles>");  //$NON-NLS-1$
			buffer.append(BundleDependencyModel.LINE_SEPARATOR);
		}

		private void printXmlCDATAOn(ICharBuffer buffer, int indent, Object object) {
			printIndentOn(buffer, indent);
			buffer.append("<![CDATA[");  //$NON-NLS-1$
			buffer.append(object);
			buffer.append("]]>");  //$NON-NLS-1$
			buffer.append(BundleDependencyModel.LINE_SEPARATOR);
		}

		protected void printXmlOn(ICharBuffer buffer, int i) {
			printXmlBundlesOn(buffer, 1);
			printXmlBundleDependenciesOn(buffer, 1);
		}

//
// Uncomment the following code to add "bundles in use" information to the XML.
// Also uncomment the line of code above in the method printXmlBundleOn.
//
//		private int compareBundles(Bundle bundle1, Bundle bundle2) {
//			String name1 = getBundleKey(bundle1);
//			String name2 = getBundleKey(bundle2);
//			int result = name1.compareTo(name2);
//			return result;
//		}
//
//		private Map createBundlesMap() {
//			BundleContext context = getBundleContext();
//			Bundle[] bundles = context.getBundles();
//			int count = bundles.length;
//			Map map = new Hashtable((count * 2) + 1);
//
//			for (int i = 0; i < count; i++) {
//				Bundle bundle = bundles [ i ];
//				Object key = getBundleKey(bundle);
//				ServiceReference[] references = bundle.getServicesInUse();
//				Object value = createServiceReferenceList(references);
//				map.put(key, value);
//			}
//
//			return map;
//		}
//
//		private Comparator createServiceReferenceComparator() {
//			return new Comparator() {
//				public int compare(Object object1, Object object2) {
//					ServiceReference reference1 = (ServiceReference) object1;
//					Bundle bundle1 = reference1.getBundle();
//
//					ServiceReference reference2 = (ServiceReference) object2;
//					Bundle bundle2 = reference2.getBundle();
//
//					int result = XmlPrinter.this.compareBundles(bundle1, bundle2);
//					return result;
//				}
//			};
//		}
//
//		private List createServiceReferenceList(ServiceReference[] references) {
//			if (references == null)
//				return new ArrayList(0);  // Early return.
//
//
//			int referencesCount = references.length;
//			List list = new ArrayList(referencesCount);
//
//			for (int i = 0; i < referencesCount; i++) {
//				ServiceReference reference = references [ i ];
//				list.add(reference);
//			}
//
//			Comparator comparator = createServiceReferenceComparator();
//			Collections.sort(list, comparator);
//			return list;
//		}
//
//		private void printXmlBundlesInUseOnBuffer(StringBuffer buffer, int indent, String bundleSymbolicName) {
//			Map map = createBundlesMap();
//			List serviceReferences = (List) map.get(bundleSymbolicName);
//			boolean empty = serviceReferences.isEmpty();
//			if (empty == true)
//				return;  // Early return.
//
//			printIndentOn(buffer, indent);
//			buffer.append("<bundlesInUse>");  //$NON-NLS-1$
//			buffer.append(LINE_SEPARATOR);
//
//			Iterator iterator = serviceReferences.iterator();
//
//			while (iterator.hasNext() == true) {
//				ServiceReference reference = (ServiceReference) iterator.next();
//				printXmlServiceReferenceOnBuffer(buffer, indent + 1, reference);
//			}
//
//			printIndentOn(buffer, indent);
//			buffer.append("</bundlesInUse>");  //$NON-NLS-1$
//			buffer.append(LINE_SEPARATOR);
//		}
//
//		private void printXmlServiceReferenceOnBuffer(StringBuffer buffer, int indent, ServiceReference reference) {
//			printIndentOn(buffer, indent);
//			buffer.append("<serviceReference>");  //$NON-NLS-1$
//			buffer.append(LINE_SEPARATOR);
//
//			printIndentOn(buffer, indent + 1);
//			buffer.append("<bundle>");  //$NON-NLS-1$
//			buffer.append(LINE_SEPARATOR);
//
//			printIndentOn(buffer, indent + 2);
//			Bundle bundle = reference.getBundle();
//			String bundleSymbolicName = bundle.getSymbolicName();
//			printXmlCDATAOn(buffer, bundleSymbolicName);
//
//			printIndentOn(buffer, indent + 1);
//			buffer.append("</bundle>");  //$NON-NLS-1$
//			buffer.append(LINE_SEPARATOR);
//
//			printXmlServiceReferencePropertiesOnBuffer(buffer, indent + 1, reference);
//
//			printIndentOn(buffer, indent);
//			buffer.append("</serviceReference>");  //$NON-NLS-1$
//			buffer.append(LINE_SEPARATOR);
//		}
//
//		private void printXmlServiceReferencePropertiesOnBuffer(StringBuffer buffer, int indent, ServiceReference reference) {
//			final char quote = '\"';
//			final char gt = '>';
//
//			printIndentOn(buffer, indent);
//			buffer.append("<properties>");  //$NON-NLS-1$
//			buffer.append(LINE_SEPARATOR);
//
//			printIndentOn(buffer, indent + 1);
//			buffer.append("<property");  //$NON-NLS-1$
//			buffer.append(" key=");  //$NON-NLS-1$
//			buffer.append(quote);
//			buffer.append(Constants.SERVICE_ID);
//			buffer.append(quote);
//			buffer.append(gt);
//			buffer.append(LINE_SEPARATOR);
//
//			printIndentOn(buffer, indent + 2);
//			buffer.append("<value>");  //$NON-NLS-1$
//			buffer.append(LINE_SEPARATOR);
//
//			printIndentOn(buffer, indent + 3);
//			Object id = reference.getProperty(Constants.SERVICE_ID);
//			buffer.append(id);
//			buffer.append(LINE_SEPARATOR);
//
//			printIndentOn(buffer, indent + 2);
//			buffer.append("</value>");  //$NON-NLS-1$
//			buffer.append(LINE_SEPARATOR);
//
//			printIndentOn(buffer, indent + 1);
//			buffer.append("</property>");  //$NON-NLS-1$
//			buffer.append(LINE_SEPARATOR);
//
//			printIndentOn(buffer, indent + 1);
//			buffer.append("<property");  //$NON-NLS-1$
//			buffer.append(" key=");  //$NON-NLS-1$
//			buffer.append(quote);
//			buffer.append(Constants.OBJECTCLASS);
//			buffer.append(quote);
//			buffer.append(gt);
//			buffer.append(LINE_SEPARATOR);
//
//			printIndentOn(buffer, indent + 2);
//			buffer.append("<value>");  //$NON-NLS-1$
//			buffer.append(LINE_SEPARATOR);
//
//			printIndentOn(buffer, indent + 3);
//			buffer.append("<objectClass>");  //$NON-NLS-1$
//			buffer.append(LINE_SEPARATOR);
//
//			Object[] objectClasses = (Object[]) reference.getProperty(Constants.OBJECTCLASS);
//
//			for (int i = 0; i < objectClasses.length; i++) {
//				printIndentOn(buffer, indent + 4);
//				Object objectClass = objectClasses [ i ];
//				buffer.append("<class");  //$NON-NLS-1$
//				buffer.append(" name=");  //$NON-NLS-1$
//				buffer.append(quote);
//				buffer.append(objectClass);
//				buffer.append(quote);
//				buffer.append("/>");  //$NON-NLS-1$
//				buffer.append(LINE_SEPARATOR);
//			}
//
//			printIndentOn(buffer, indent + 3);
//			buffer.append("</objectClass>");  //$NON-NLS-1$
//			buffer.append(LINE_SEPARATOR);
//
//			printIndentOn(buffer, indent + 2);
//			buffer.append("</value>");  //$NON-NLS-1$
//			buffer.append(LINE_SEPARATOR);
//
//			printIndentOn(buffer, indent + 1);
//			buffer.append("</property>");  //$NON-NLS-1$
//			buffer.append(LINE_SEPARATOR);
//
//			printIndentOn(buffer, indent);
//			buffer.append("</properties>");  //$NON-NLS-1$
//			buffer.append(LINE_SEPARATOR);
//		}
	}

	//
	// Static Fields
	//

	// Externalized Strings
	private static final String FAILED_TO_READ_MANIFEST_KEY = "BundleDependencyModel.FailedToReadManifest";  //$NON-NLS-1$

	// Misc
	private static final String BUNDLE_MANIFEST_ENTRY = "META-INF/MANIFEST.MF";  //$NON-NLS-1$
	private static final String LINE_SEPARATOR = System.getProperty("line.separator");  //$NON-NLS-1$
	private static final char OPEN_SQUARE_BRACKED = '[';
	private static final char UNINSTALLABLE_DECORATOR = '*';

	//
	// Instance Fields
	//

	private BundleContext bundleContext;
	private Comparator/*<Bundle>*/ bundleIdComparator;
	private BundleListener bundleListener;
	private BundleDependencyService dependency;
	private BundleDependencyListener dependencyListener;
	private Map/*<String, Bundle>*/ installedBundlesTable;
	private List listeners;

	public BundleDependencyModel(BundleContext context) {
		super();
		setBundleContext(context);
		setListeners(new ArrayList/*<BundleDependencyModelListener>*/(5));
		setBundleListener(createBundleListener());
		setInstalledBundlesTable(new HashMap(150));
		setDependencyListener(createDependencyListener());
	}

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel#addBundleDependencyModelListener(org.eclipse.soda.sat.internal.dependency.model.interfaces.BundleDependencyModelListener)
	 */
	public void addBundleDependencyModelListener(BundleDependencyModelListener listener) {
		List/*<BundleDependencyModelListener>*/ listeners = getListeners();
		listeners.add(listener);
	}

	/**
	 * Add a bundle to the installedBundlesTable.
	 */
	private void addToInstalledBundlesTable(Bundle bundle) {
		Map/*<String, Bundle>*/ bundles = getInstalledBundlesTable();
		String key = bundle.getSymbolicName();
		bundles.put(key, bundle);
	}

	public void bind(BundleDependencyService dependency) {
		setDependency(dependency);
		registerAsBundleListener();
		buildBundleTable();
	}

	/**
	 * Build the installedBundlesTable with the installed bundles.
	 */
	private void buildBundleTable() {
		BundleContext context = getBundleContext();
		Bundle[] bundles = context.getBundles();
		Bundle bundle;

		int count = bundles.length;
		int size = count * 2;
		size = Math.max(size, 75);

		Map/*<String, Bundle>*/ table = new HashMap/*<String, Bundle>*/(size);
		setInstalledBundlesTable(table);

		synchronized (this) {
			for (int i = 0; i < count; i++) {
				bundle = bundles [ i ];
				addToInstalledBundlesTable(bundle);
			}
		}
	}

	/**
	 * A Bundle has changed state.
	 *
	 * @param event  A BundleEvent describing the bundle that has changed.
	 */
	private void bundleChanged(BundleEvent event) {
		int type = event.getType();
		Bundle bundle = event.getBundle();

		switch (type) {
			case BundleEvent.INSTALLED:
				handleInstall(bundle);
				break;
			case BundleEvent.STARTED:
				break;
			case BundleEvent.STOPPED:
				break;
			case BundleEvent.UPDATED:
				break;
			case BundleEvent.UNINSTALLED:
				handleUninstall(bundle);
				break;
			default:
				break;
		}
	}

	/**
	 * Create a Comparator for sorting by Bundle ID.
	 */
	private Comparator/*<Bundle>*/ createBundleIdComparator() {
		return new Comparator/*<Bundle>*/() {
			public int compare(Object object1, Object object2) {
				int result = 0;

				Bundle bundle1 = (Bundle) object1;
				Bundle bundle2 = (Bundle) object2;

				long id1 = bundle1.getBundleId();
				long id2 = bundle2.getBundleId();
				long diff = id1 - id2;

				if (diff > 0) {
					result = 1;
				} else if (diff < 0) {
					result = -1;
				}

				return result;
			}
		};
	}

	/**
	 * Create the BundleListener.
	 */
	private BundleListener createBundleListener() {
		return new BundleListener() {
			public void bundleChanged(BundleEvent event) {
				BundleDependencyModel.this.bundleChanged(event);
			}
		};
	}

	/**
	 * Create the BundleDependencyListener.
	 */
	private BundleDependencyListener createDependencyListener() {
		return new BundleDependencyListener() {
			public void registered(Bundle importer, Bundle exporter) {
				handleRegistered(importer, exporter);
			}

			public void unregistered(Bundle importer, Bundle exporter) {
				handleUnregistered(importer, exporter);
			}
		};
	}

	/**
	 * Destroy the installedBundlesTable.
	 */
	private void destroyBundleTable() {
		Map/*<String, Bundle>*/ table = getInstalledBundlesTable();
		table.clear();
	}

	/**
	 * @see org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel#getAllDependentsOf(java.lang.String)
	 */
	public List/*<String>*/ getAllDependentsOf(String bundleSymbolicName) {
		BundleDependencyService dependency = getDependency();
		Bundle bundle = getBundle(bundleSymbolicName);
		List/*<String>*/ names;

		if (bundle == null) {
			names = new ArrayList(0);
		} else {
			Collection/*<Bundle>*/ bundles = dependency.getAllDependentsOf(bundle);
			names = getBundleSymbolicNames(bundles, true, true);
		}

		return names;
	}

	/**
	 * @see org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel#getAllPrerequisitesOf(java.lang.String)
	 */
	public List/*<String>*/ getAllPrerequisitesOf(String bundleSymbolicName) {
		BundleDependencyService dependency = getDependency();
		Bundle bundle = getBundle(bundleSymbolicName);
		List/*<String>*/ names;

		if (bundle == null) {
			names = new ArrayList(0);
		} else {
			Collection bundles = dependency.getAllPrerequisitesOf(bundle);
			names = getBundleSymbolicNames(bundles, true, true);
		}

		return names;
	}

	/**
	 * Get the bundle with the specified symbolic name.
	 */
	private Bundle getBundle(String bundleSymbolicName) {
		Bundle bundle = null;

		if (bundleSymbolicName != null) {
			String key = removeSuffixFrom(bundleSymbolicName);
			Map/*<String, Bundle>*/ bundles = getInstalledBundlesTable();
			bundle = (Bundle) bundles.get(key);
		}

		return bundle;
	}

	/**
	 * Private bundleContext getter.
	 */
	private BundleContext getBundleContext() {
		return bundleContext;
	}

	/**
	 * Returns the bundleIdComparator.
	 * @return Comparator
	 */
	private Comparator/*<Bundle>*/ getBundleIdComparator() {
		synchronized (this) {
			if (bundleIdComparator == null) {
				setBundleIdComparator(createBundleIdComparator());
			}
		}

		return bundleIdComparator;
	}

	/**
	 * Private bundleListener getter.
	 */
	private BundleListener getBundleListener() {
		return bundleListener;
	}

	/**
	 * @see org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel#getBundles()
	 */
	public List/*<String>*/ getBundles() {
		Map/*<String, Bundle>*/ bundlesTable = getInstalledBundlesTable();
		Collection/*<Bundle>*/ values = bundlesTable.values();
		List/*<Bundle>*/ list = new ArrayList/*<Bundle>*/(values);
		sortByBundleId(list);
		List/*<String>*/ names = getBundleSymbolicNames(list, false, false);
		return names;
	}

	/**
	 * Get the bundle symbolic names of the specified bundles.  The names can
	 * optionally be sorted alphabetically.  Bundles that are uninstallable
	 * can optionally be tagged with an asterisk.
	 */
	private List/*<String>*/ getBundleSymbolicNames(Collection/*<Bundle>*/ bundles, boolean sorted, boolean uninstallableFlag) {
		int count = bundles.size();
		List/*<String>*/ result = new ArrayList/*<String>*/(count);

		Iterator/*<Bundle>*/ iterator = bundles.iterator();
		String bundleSymbolicName;
		Bundle bundle;

		while (iterator.hasNext() == true) {
			bundle = (Bundle) iterator.next();
			bundleSymbolicName = toString(bundle, uninstallableFlag);
			result.add(bundleSymbolicName);
		}

		if (sorted == true) {
			Collections.sort(result);
		}

		return result;
	}

	/**
	 * Private dependency getter.
	 */
	private BundleDependencyService getDependency() {
		return dependency;
	}

	/**
	 * Private dependencyListener setter.
	 */
	private BundleDependencyListener getDependencyListener() {
		return dependencyListener;
	}

	/**
	 * @see org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel#getDependentsOf(java.lang.String)
	 */
	public List/*<String>*/ getDependentsOf(String bundleSymbolicName) {
		BundleDependencyService dependency = getDependency();
		Bundle bundle = getBundle(bundleSymbolicName);
		List/*<String>*/ names;

		if (bundle == null) {
			names = new ArrayList(0);
		} else {
			List/*<String>*/ bundles = dependency.getDependentsOf(bundle);
			names = getSymbolicNames(bundles);
		}

		return names;
	}

	/**
	 * Private installedBundlesTable getter.
	 */
	private Map/*<String, Bundle>*/ getInstalledBundlesTable() {
		return installedBundlesTable;
	}

	/**
	 * Private listeners getter.
	 */
	private List/*<String>*//*<BundleDependencyModelListener>*/ getListeners() {
		return listeners;
	}

	public String getManifest(String bundleSymbolicName) {
		URL url = getManifestUrl(bundleSymbolicName);
		String value;

		try {
			InputStream stream = url.openStream();
			value = readContentsFromStream(stream);
		} catch (IOException exception) {
			value = Messages.getString(BundleDependencyModel.FAILED_TO_READ_MANIFEST_KEY);
		}

		return value;
	}

	private URL getManifestUrl(String bundleSymbolicName) {
		Bundle bundle = getBundle(bundleSymbolicName);
		URL url = bundle.getEntry(BundleDependencyModel.BUNDLE_MANIFEST_ENTRY);
		return url;
	}

	/**
	 * @see org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel#getPrerequisitesOf(java.lang.String)
	 */
	public List/*<String>*/ getPrerequisitesOf(String bundleSymbolicName) {
		BundleDependencyService dependency = getDependency();
		Bundle bundle = getBundle(bundleSymbolicName);
		List/*<String>*/ names;

		if (bundle == null) {
			names = new ArrayList(0);
		} else {
			List/*<String>*/ bundles = dependency.getPrerequisitesOf(bundle);
			names = getSymbolicNames(bundles);
		}

		return names;
	}

	private ServiceReference[] getRegisteredServicesOf(String bundleSymbolicName) {
		Bundle bundle = getBundle(bundleSymbolicName);
		ServiceReference[] serviceReferences = bundle.getRegisteredServices();
		return serviceReferences;
	}

	private long[] getServiceIds(ServiceReference[] serviceReferences) {
		if (serviceReferences == null)
			return null;  // Early return.
		ServiceReferenceUtility utility = ServiceReferenceUtility.getInstance();
		long[] ids = utility.getServiceIds(serviceReferences);
		return ids;
	}

	public long[] getServiceIdsExportedBy(String bundleSymbolicName) {
		ServiceReference[] serviceReferences = getRegisteredServicesOf(bundleSymbolicName);
		long[] ids = getServiceIds(serviceReferences);
		return ids;
	}

	public long[] getServiceIdsImportedBy(String bundleSymbolicName) {
		ServiceReference[] serviceReferences = getServicesInUseBy(bundleSymbolicName);
		long[] ids = getServiceIds(serviceReferences);
		return ids;
	}

	private List/*<String>*/ getServiceNames(ServiceReference[] serviceReferences) {
		if (serviceReferences == null)
			return new ArrayList(0);  // Early return.

		ServiceReferenceUtility utility = ServiceReferenceUtility.getInstance();
		ArrayList list = new ArrayList(serviceReferences.length * 4);

		for (int i = 0; i < serviceReferences.length; i++) {
			ServiceReference serviceReference = serviceReferences [ i ];
			List/*<String>*/ names = utility.getServiceNames(serviceReference);
			list.addAll(names);
		}

		list.trimToSize();
		return list;
	}

	public List/*<String>*/ getServiceNamesExportedBy(String bundleSymbolicName) {
		ServiceReference[] serviceReferences = getRegisteredServicesOf(bundleSymbolicName);
		List/*<String>*/ names = getServiceNames(serviceReferences);
		return names;
	}

	public List/*<String>*/ getServiceNamesImportedBy(String bundleSymbolicName) {
		ServiceReference[] serviceReferences = getServicesInUseBy(bundleSymbolicName);
		List/*<String>*/ names = getServiceNames(serviceReferences);
		return names;
	}

	private ServiceReference[] getServicesInUseBy(String bundleSymbolicName) {
		Bundle bundle = getBundle(bundleSymbolicName);
		ServiceReference[] serviceReferences = bundle.getServicesInUse();
		return serviceReferences;
	}

	public int getState(String bundleSymbolicName) {
		Bundle bundle = getBundle(bundleSymbolicName);
		int state = bundle.getState();
		return state;
	}

	/**
	 * Get the symbolic names of the bundles in a List.
	 */
	private List/*<String>*/ getSymbolicNames(List/*<String>*/ bundles) {
		List/*<String>*/ names = getBundleSymbolicNames(bundles, true, true);
		return names;
	}

	/**
	 * @see org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel#getUnacquiredImportedServiceNames(java.lang.String)
	 */
	public List/*<String*/ getUnacquiredImportedServiceNames(String id) {
		BundleDependencyService dependency = getDependency();
		List/*<String*/ names = dependency.getUnacquiredImportedServiceNames(id);
		return names;
	}

	/**
	 * @see org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel#getUnacquiredOptionalImportedServiceNames(java.lang.String)
	 */
	public List/*<String*/ getUnacquiredOptionalImportedServiceNames(String id) {
		BundleDependencyService dependency = getDependency();
		List/*<String*/ names = dependency.getUnacquiredOptionalImportedServiceNames(id);
		return names;
	}

	/**
	 * A bundle has been installed.
	 */
	private void handleInstall(Bundle bundle) {
		addToInstalledBundlesTable(bundle);
		informListenersOfInstalledBundle(bundle);
	}

	/**
	 * A bundle relationship has been registered.
	 */
	private void handleRegistered(Bundle importer, Bundle exporter) {
		informListenersOfRegistration(importer, exporter);
	}

	/**
	 * A bundle has been uninstalled.
	 */
	private void handleUninstall(Bundle bundle) {
		removeFromInstalledBundlesTable(bundle);
		informListenersOfUninstalledBundle(bundle);
	}

	/**
	 * A bundle relationship has been unregistered.
	 */
	private void handleUnregistered(Bundle importer, Bundle exporter) {
		informListenersOfUnregistration(importer, exporter);
	}

	/**
	 * Inform the registered BundleDependencyModelListener objects that a bundle
	 * has been installed.
	 */
	private void informListenersOfInstalledBundle(Bundle bundle) {
		ArrayList/*<BundleDependencyModelListener>*/ listeners = (ArrayList/*<BundleDependencyModelListener>*/) getListeners();
		Collection/*<BundleDependencyModelListener>*/ clone = (Collection/*<BundleDependencyModelListener>*/) listeners.clone();
		Iterator/*<BundleDependencyModelListener>*/ iterator = clone.iterator();

		BundleDependencyModelListener listener;
		String bundleSymbolicName = toString(bundle, false);

		while (iterator.hasNext() == true) {
			listener = (BundleDependencyModelListener) iterator.next();
			listener.addedBundle(bundleSymbolicName);
		}
	}

	/**
	 * Inform the registered BundleDependencyModelListener objects that a bundle
	 * relationship has been registered.
	 */
	private void informListenersOfRegistration(Bundle importer, Bundle exporter) {
		String importerSymbolicName = toString(importer, false);
		String exporterSymbolicName = toString(exporter, false);

		ArrayList/*<BundleDependencyModelListener>*/ listeners = (ArrayList/*<BundleDependencyModelListener>*/) getListeners();
		Collection/*<BundleDependencyModelListener>*/ clone = (Collection/*<BundleDependencyModelListener>*/) listeners.clone();
		Iterator/*<BundleDependencyModelListener>*/ iterator = clone.iterator();

		BundleDependencyModelListener listener;

		while (iterator.hasNext() == true) {
			listener = (BundleDependencyModelListener) iterator.next();
			listener.registered(importerSymbolicName, exporterSymbolicName);
		}
	}

	/**
	 * Inform the registered BundleDependencyModelListener objects that a bundle
	 * has been uninstalled.
	 */
	private void informListenersOfUninstalledBundle(Bundle bundle) {
		ArrayList/*<BundleDependencyModelListener>*/ listeners = (ArrayList/*<BundleDependencyModelListener>*/) getListeners();
		Collection/*<BundleDependencyModelListener>*/ clone = (Collection/*<BundleDependencyModelListener>*/) listeners.clone();
		Iterator/*<BundleDependencyModelListener>*/ iterator = clone.iterator();

		BundleDependencyModelListener listener;
		String bundleSymbolicName = toString(bundle, false);

		while (iterator.hasNext() == true) {
			listener = (BundleDependencyModelListener) iterator.next();
			listener.removedBundle(bundleSymbolicName);
		}
	}

	/**
	 * Inform the registered BundleDependencyModelListener objects that a bundle
	 * relationship has been unregistered.
	 */
	private void informListenersOfUnregistration(Bundle importer, Bundle exporter) {
		String importerSymbolicName = toString(importer, false);
		String exporterSymbolicName = toString(exporter, false);

		ArrayList/*<BundleDependencyModelListener>*/ listeners = (ArrayList/*<BundleDependencyModelListener>*/) getListeners();
		Collection/*<BundleDependencyModelListener>*/ clone = (Collection/*<BundleDependencyModelListener>*/) listeners.clone();
		Iterator/*<BundleDependencyModelListener>*/ iterator = clone.iterator();

		BundleDependencyModelListener listener;

		while (iterator.hasNext() == true) {
			listener = (BundleDependencyModelListener) iterator.next();
			listener.unregistered(importerSymbolicName, exporterSymbolicName);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel#isActive(java.lang.String)
	 */
	public boolean isActive(String bundleSymbolicName) {
		Bundle bundle = getBundle(bundleSymbolicName);
		BundleUtility utility = BundleUtility.getInstance();
		boolean result = utility.isBundleState(bundle, Bundle.ACTIVE);
		return result;
	}

	/**
	 * @see org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel#isBundle(java.lang.String)
	 */
	public boolean isBundle(String bundleSymbolicName) {
		Map/*<String, Bundle>*/ bundleTable = getInstalledBundlesTable();
		String key = removeSuffixFrom(bundleSymbolicName);
		boolean result = bundleTable.containsKey(key);
		return result;
	}

	/**
	 * @see org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel#isExportingServices(java.lang.String)
	 */
	public boolean isExportingServices(String bundleSymbolicName) {
		Object[] services = getRegisteredServicesOf(bundleSymbolicName);
		boolean result = services != null;
		return result;
	}

	/**
	 * @see org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel#isImportingServices(java.lang.String)
	 */
	public boolean isImportingServices(String bundleSymbolicName) {
		Object[] services = getServicesInUseBy(bundleSymbolicName);
		boolean result = services != null;
		return result;
	}

	private String readContentsFromStream(InputStream stream) throws IOException {
		String value = null;
		ILineReader reader = null;

		try {
			FactoryUtility utility = FactoryUtility.getInstance();
			reader = utility.createLineReader(stream);
			Enumeration lines = reader.lines();
			ICharBuffer buffer = utility.createCharBuffer(1500);

			while (lines.hasMoreElements()) {
				String line = (String) lines.nextElement();
				buffer.append(line);
				buffer.append(BundleDependencyModel.LINE_SEPARATOR);
			}

			value = buffer.toString();
		} finally {
			if (reader != null) {
				reader.close();
			}
		}

		return value;
	}

	/**
	 * Register as a BundleListener.
	 */
	private void registerAsBundleListener() {
		BundleContext bundleContext = getBundleContext();
		BundleListener listener = getBundleListener();
		bundleContext.addBundleListener(listener);
	}

	/**
	 * @see org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel#removeBundleDependencyModelListener(org.eclipse.soda.sat.internal.dependency.model.interfaces.BundleDependencyModelListener)
	 */
	public void removeBundleDependencyModelListener(BundleDependencyModelListener listener) {
		List/*<BundleDependencyModelListener>*/ listeners = getListeners();
		listeners.remove(listener);
	}

	/**
	 * Remove a bundle from the installedBundlesTable.
	 */
	private void removeFromInstalledBundlesTable(Bundle bundle) {
		Map/*<String, Bundle>*/ bundles = getInstalledBundlesTable();
		String key = bundle.getSymbolicName();
		bundles.remove(key);
	}

	/**
	 * Remove the suffice from the bundle symbolic name.
	 */
	private String removeSuffixFrom(String bundleSymbolicName) {
		String value = bundleSymbolicName;
		int index = bundleSymbolicName.indexOf(BundleDependencyModel.OPEN_SQUARE_BRACKED);

		if (index != -1) {
			value = bundleSymbolicName.substring(0, index - 1);
		}

		return value;
	}

	/**
	 * Private bundleContext setter.
	 */
	private void setBundleContext(BundleContext bundleContext) {
		this.bundleContext = bundleContext;
	}

	/**
	 * Private bundleIdComparator setter.
	 */
	private void setBundleIdComparator(Comparator/*<Bundle>*/ bundleIdComparator) {
		this.bundleIdComparator = bundleIdComparator;
	}

	/**
	 * Private bundleListener setter.
	 */
	private void setBundleListener(BundleListener bundleListener) {
		this.bundleListener = bundleListener;
	}

	/**
	 * Private dependency setter.
	 */
	private void setDependency(BundleDependencyService dependency) {
		BundleDependencyListener listener = getDependencyListener();

		if (this.dependency != null) {
			this.dependency.removeBundleDependencyListener(listener);
		}

		this.dependency = dependency;

		if (this.dependency != null) {
			this.dependency.addBundleDependencyListener(listener);
		}
	}

	/**
	 * Private dependencyListener setter.
	 */
	private void setDependencyListener(BundleDependencyListener dependencyListener) {
		this.dependencyListener = dependencyListener;
	}

	/**
	 * Private installedBundlesTable setter.
	 */
	private void setInstalledBundlesTable(Map/*<String, Bundle>*/ installedBundlesTable) {
		this.installedBundlesTable = installedBundlesTable;
	}

	/**
	 * Private listeners setter.
	 */
	private void setListeners(List/*<BundleDependencyModelListener>*/ listeners) {
		this.listeners = listeners;
	}

	/**
	 * Sort the specified array of bundles by Bundle ID.
	 */
	private void sortByBundleId(List/*<Bundle>*/ bundles) {
		Comparator/*<Bundle>*/ comparator = getBundleIdComparator();
		Collections.sort(bundles, comparator);
	}

	/**
	 * Create a String containing the bundle symbolic name, plus its ID and
	 * whether the bundle is uninstallable.
	 */
	private String toString(Bundle bundle, boolean uninstallableFlag) {
		String bundleSymbolicName = bundle.getSymbolicName();
		long id = bundle.getBundleId();

		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(50);
		buffer.append(bundleSymbolicName);
		buffer.append(" [");  //$NON-NLS-1$
		buffer.append(id);
		buffer.append(']');

		if (uninstallableFlag == true) {
			BundleDependencyService dependency = getDependency();
			boolean uninstallable = dependency.isRegisteredAsUninstallable(bundle);

			if (uninstallable == true) {
				buffer.append(BundleDependencyModel.UNINSTALLABLE_DECORATOR);
			}
		}

		String result = buffer.toString();
		return result;
	}

	/**
	 * @see org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel#toXml()
	 */
	public String toXml() {
		XmlPrinter printer = new XmlPrinter();
		String xml = printer.print();
		return xml;
	}

	/**
	 * Unbind the BundleDependencyService.
	 */
	public void unbind() {
		unregisterAsBundleListener();
		destroyBundleTable();
		setDependency(null);
	}

	/**
	 * Unregister as a BundleListener.
	 */
	private void unregisterAsBundleListener() {
		BundleContext bundleContext = getBundleContext();
		BundleListener listener = getBundleListener();
		bundleContext.removeBundleListener(listener);
	}
}
