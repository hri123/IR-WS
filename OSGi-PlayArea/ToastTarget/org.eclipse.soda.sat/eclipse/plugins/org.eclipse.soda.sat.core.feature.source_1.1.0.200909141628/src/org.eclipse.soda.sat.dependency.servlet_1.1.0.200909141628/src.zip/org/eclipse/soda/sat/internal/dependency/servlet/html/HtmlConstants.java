/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.dependency.servlet.html;

/**
 * HtmlConstants.java
 */
interface HtmlConstants {
	public static final String COMMENT_BEGIN_TAG = "<!--";  //$NON-NLS-1$
	public static final String COMMENT_END_TAG = "-->";  //$NON-NLS-1$

	public static final String HTML_BEGIN_TAG = "<html>";  //$NON-NLS-1$
	public static final String HTML_END_TAG = "</html>";  //$NON-NLS-1$

	public static final String HEAD_BEGIN_TAG = "<head>";  //$NON-NLS-1$
	public static final String HEAD_END_TAG = "</head>";  //$NON-NLS-1$

	public static final String TITLE_BEGIN_TAG = "<title>";  //$NON-NLS-1$
	public static final String TITLE_END_TAG = "</title>";  //$NON-NLS-1$

	public static final String BODY_BEGIN_TAG = "<body>";  //$NON-NLS-1$
	public static final String BODY_END_TAG = "</body>";  //$NON-NLS-1$

	public static final String H1_FONT_BEGIN_TAG = "<h1>";  //$NON-NLS-1$
	public static final String H1_FONT_END_TAG = "</h1>";  //$NON-NLS-1$

	public static final String H2_FONT_BEGIN_TAG = "<h2>";  //$NON-NLS-1$
	public static final String H2_FONT_END_TAG = "</h2>";  //$NON-NLS-1$

	public static final String H3_FONT_BEGIN_TAG = "<h3>";  //$NON-NLS-1$
	public static final String H3_FONT_END_TAG = "</h3>";  //$NON-NLS-1$

	public static final String H4_FONT_BEGIN_TAG = "<h4>";  //$NON-NLS-1$
	public static final String H4_FONT_END_TAG = "</h4>";  //$NON-NLS-1$

	public static final String TABLE_BEGIN_TAG = "<table>";  //$NON-NLS-1$
	public static final String TABLE_END_TAG = "</table>";  //$NON-NLS-1$

	public static final String TABLE_ROW_BEGIN_TAG = "<tr>";  //$NON-NLS-1$
	public static final String TABLE_ROW_END_TAG = "</tr>";  //$NON-NLS-1$

	public static final String TABLE_DATA_BEGIN_TAG = "<td>";  //$NON-NLS-1$
	public static final String TABLE_DATA_END_TAG = "</td>";  //$NON-NLS-1$

	public static final String ITALIC_BEGIN_TAG = "<i>";  //$NON-NLS-1$
	public static final String ITALIC_END_TAG = "</i>";  //$NON-NLS-1$

	public static final String BOLD_BEGIN_TAG = "<b>";  //$NON-NLS-1$
	public static final String BOLD_END_TAG = "</b>";  //$NON-NLS-1$

	public static final String CENTER_BEGIN_TAG = "<center>";  //$NON-NLS-1$
	public static final String CENTER_END_TAG = "</center>";  //$NON-NLS-1$

	public static final String PREFORMATTED_BEGIN_TAG = "<pre>";  //$NON-NLS-1$
	public static final String PREFORMATTED_END_TAG = "</pre>";  //$NON-NLS-1$

	public static final String TABLE_HEADER_END_TAG = "</th>";  //$NON-NLS-1$
	public static final String FONT_END_TAG = "</font>";  //$NON-NLS-1$
	public static final String LINK_END_TAG = "</a>";  //$NON-NLS-1$
	public static final String FORM_END_TAG = "</form>";  //$NON-NLS-1$
	public static final String BUTTON_END_TAG = "</button>";  //$NON-NLS-1$

	public static final String BREAK_TAG = "<br/>";  //$NON-NLS-1$
	public static final String HORIZONTAL_RULE = "<hr/>";  //$NON-NLS-1$
	public static final String NONBREAKING_SPACE = "&nbsp;";  //$NON-NLS-1$

	public static final String LINK_SEPARATOR = " | ";  //$NON-NLS-1$
	public static final String INDENT = "  ";  //$NON-NLS-1$

	public static final char AMPERSAND_CHAR = '&';
	public static final char CLOSE_CHAR = '>';
	public static final char EQUAL_CHAR = '=';
	public static final char OPEN_CHAR = '<';
	public static final char QUESTION_CHAR = '?';
	public static final char QUOTE_CHAR = '"';
	public static final char SPACE_CHAR = ' ';

	public static final String LINE_SEPARATOR = System.getProperty("line.separator");  //$NON-NLS-1$
}
