/*******************************************************************************
 * Copyright (c) 2001, 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.dependency.servlet.html;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel;
import org.eclipse.soda.sat.internal.dependency.nls.Messages;
import org.eclipse.soda.sat.internal.dependency.servlet.BundleDependencyHttpProcessor;
import org.eclipse.soda.sat.internal.dependency.servlet.BundleDependencyServlet;

/**
 * WebPageGenerator.java
 */
public class WebPageGenerator extends Object {
	//
	// Static Fields
	//

	// Externalized Strings Keys
	private static final String ALL_KEY = "WebPageGenerator.All";  //$NON-NLS-1$
	private static final String AN_EXCEPTION_WAS_THROWN_KEY = "WebPageGenerator.AnExceptionWasThrown";  //$NON-NLS-1$
	private static final String BACK_KEY = "WebPageGenerator.Back";  //$NON-NLS-1$
	private static final String BOTTOM_OF_PAGE_KEY = "WebPageGenerator.BottomOfPage";  //$NON-NLS-1$
	private static final String BUNDLE_DEPENDENCIES_BROWSER_KEY = "WebPageGenerator.BundleDependenciesBrowser";  //$NON-NLS-1$
	private static final String BUNDLE_DEPENDENCY_HOME_PAGE_KEY = "WebPageGenerator.BundleDependencyHomePage";  //$NON-NLS-1$
	private static final String BUNDLE_DEPENDENTS_KEY = "WebPageGenerator.BundleDependents";  //$NON-NLS-1$
	private static final String BUNDLE_PREREQUISITES_KEY = "WebPageGenerator.BundlePrerequisites";  //$NON-NLS-1$
	private static final String COPYRIGHT_NOTICE_KEY = "WebPageGenerator.CopyrightNotice";  //$NON-NLS-1$
	private static final String GENERATED_BY_KEY = "WebPageGenerator.GeneratedBy";  //$NON-NLS-1$
	private static final String INSTALLED_BUNDLES_KEY = "WebPageGenerator.InstalledBundles";  //$NON-NLS-1$
	private static final String RELOAD_PAGE_KEY = "WebPageGenerator.ReloadPage";  //$NON-NLS-1$
	private static final String SHOW_ALL_BUNDLES_KEY = "WebPageGenerator.ShowAllBundles";  //$NON-NLS-1$
	private static final String SHOW_IMMEDIATE_BUNDLES_KEY = "WebPageGenerator.ShowImmediateBundles";  //$NON-NLS-1$
	private static final String TOP_OF_PAGE_KEY = "WebPageGenerator.TopOfPage";  //$NON-NLS-1$

	// Externalized Strings Values
	private static final String ALL_VALUE = Messages.getString(WebPageGenerator.ALL_KEY);
	private static final String BACK_VALUE = Messages.getString(WebPageGenerator.BACK_KEY);
	private static final String BOTTOM_OF_PAGE_VALUE = Messages.getString(WebPageGenerator.BOTTOM_OF_PAGE_KEY);
	private static final String BUNDLE_DEPENDENCIES_BROWSER_VALUE = Messages.getString(WebPageGenerator.BUNDLE_DEPENDENCIES_BROWSER_KEY);
	private static final String BUNDLE_DEPENDENCY_HOME_PAGE_VALUE = Messages.getString(WebPageGenerator.BUNDLE_DEPENDENCY_HOME_PAGE_KEY);
	private static final String BUNDLE_DEPENDENTS_VALUE = Messages.getString(WebPageGenerator.BUNDLE_DEPENDENTS_KEY);
	private static final String BUNDLE_PREREQUISITES_VALUE = Messages.getString(WebPageGenerator.BUNDLE_PREREQUISITES_KEY);
	private static final String COPYRIGHT_NOTICE_VALUE = Messages.getString(WebPageGenerator.COPYRIGHT_NOTICE_KEY);
	private static final String GENERATED_BY_VALUE = Messages.getString(WebPageGenerator.GENERATED_BY_KEY);
	private static final String INSTALLED_BUNDLES_VALUE = Messages.getString(WebPageGenerator.INSTALLED_BUNDLES_KEY);
	private static final String RELOAD_PAGE_VALUE = Messages.getString(WebPageGenerator.RELOAD_PAGE_KEY);
	private static final String SHOW_ALL_BUNDLES_VALUE = Messages.getString(WebPageGenerator.SHOW_ALL_BUNDLES_KEY);
	private static final String SHOW_IMMEDIATE_BUNDLES_VALUE = Messages.getString(WebPageGenerator.SHOW_IMMEDIATE_BUNDLES_KEY);
	private static final String TOP_OF_PAGE_VALUE = Messages.getString(WebPageGenerator.TOP_OF_PAGE_KEY);

	//
	// Instance Fields
	//
	private IBundleDependencyModel model;
	private ICharBuffer buffer;

	public WebPageGenerator(IBundleDependencyModel model) {
		super();
		setModel(model);
		setBuffer(createBuffer());
	}

	private void addBreak(int level) {
		indent(level);

		ICharBuffer buffer = getBuffer();
		buffer.append(HtmlConstants.BREAK_TAG);
	}

	//
	// Instance Methods
	//

	private void addBundleDependencyTable(String bundle, boolean showAllBundles) {
		indent(2);

		ICharBuffer buffer = getBuffer();
		buffer.append(HtmlConstants.OPEN_CHAR);
		buffer.append("table");  //$NON-NLS-1$
		buffer.append(HtmlConstants.SPACE_CHAR);
		buffer.append("border");  //$NON-NLS-1$
		buffer.append(HtmlConstants.EQUAL_CHAR);
		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append('1');
		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append(HtmlConstants.SPACE_CHAR);
		buffer.append("width");  //$NON-NLS-1$
		buffer.append(HtmlConstants.EQUAL_CHAR);
		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append("100%");  //$NON-NLS-1$
		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append(HtmlConstants.CLOSE_CHAR);

		IBundleDependencyModel model = getModel();
		List/*<String>*/ bundles = model.getBundles();

		List dependents = showAllBundles == true ? model.getAllDependentsOf(bundle) : model.getDependentsOf(bundle);
		List prerequisites = showAllBundles == true ? model.getAllPrerequisitesOf(bundle) : model.getPrerequisitesOf(bundle);

		addBundleDependencyTableHeadings(showAllBundles, prerequisites.size(), bundles.size(), dependents.size());
		addBundleDependencyTableRows(bundle, bundles, dependents, prerequisites);

		indent(2);
		buffer.append(HtmlConstants.TABLE_END_TAG);

		addBreak(2);
	}

	private void addBundleDependencyTableHeadings(boolean showAllBundles, int prerequisites, int bundles, int dependents) {
		indent(3);

		ICharBuffer buffer = getBuffer();
		buffer.append(HtmlConstants.OPEN_CHAR);
		buffer.append("tr");  //$NON-NLS-1$
		buffer.append(HtmlConstants.SPACE_CHAR);
		buffer.append("bgcolor");  //$NON-NLS-1$
		buffer.append(HtmlConstants.EQUAL_CHAR);
		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append("silver");  //$NON-NLS-1$
		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append(HtmlConstants.CLOSE_CHAR);

		String th = "<th align=\"left\" width=\"33%\">";  //$NON-NLS-1$

		// Column Heading 1: Bundle Prerequisite (n)
		indent(4);
		buffer.append(th);

		if (showAllBundles == true) {
			buffer.append(WebPageGenerator.ALL_VALUE);
			buffer.append(HtmlConstants.SPACE_CHAR);
		}

		buffer.append(WebPageGenerator.BUNDLE_PREREQUISITES_VALUE);
		buffer.append(HtmlConstants.TABLE_HEADER_END_TAG);

		// Column Heading 2: Installed Bundles (n)
		indent(4);
		buffer.append(th);
		buffer.append(WebPageGenerator.INSTALLED_BUNDLES_VALUE);
		buffer.append(HtmlConstants.TABLE_HEADER_END_TAG);

		// Column Heading 2: Bundles Dependents (n)
		indent(4);
		buffer.append(th);

		if (showAllBundles == true) {
			buffer.append(WebPageGenerator.ALL_VALUE);
			buffer.append(HtmlConstants.SPACE_CHAR);
		}

		buffer.append(WebPageGenerator.BUNDLE_DEPENDENTS_VALUE);
		buffer.append(HtmlConstants.TABLE_HEADER_END_TAG);

		indent(3);
		buffer.append(HtmlConstants.TABLE_ROW_END_TAG);
	}

	private void addBundleDependencyTableRows (String bundle, List bundles, List dependents, List prerequisites) {
		ICharBuffer buffer = getBuffer();
		Iterator iterator = bundles.iterator();
		String symbolicName;

		String td = "<td align=\"left\">";  //$NON-NLS-1$

		int i = 0;

		while (iterator.hasNext() == true) {
			// Row i
			indent(3);
			buffer.append(HtmlConstants.TABLE_ROW_BEGIN_TAG);

			// Row i, Column 1: Bundle Prerequisite (n)
			indent(4);
			buffer.append(td);
			indent(5);

			if (i < prerequisites.size()) {
				symbolicName = (String) prerequisites.get(i);
				addBundleLink(symbolicName);
			} else {
				buffer.append(HtmlConstants.NONBREAKING_SPACE);
			}

			indent(4);
			buffer.append(HtmlConstants.TABLE_DATA_END_TAG);

			// Row i, Column 2: Installed Bundles (n)
			indent(4);
			buffer.append(HtmlConstants.OPEN_CHAR);
			buffer.append("td");  //$NON-NLS-1$
			buffer.append(HtmlConstants.SPACE_CHAR);
			buffer.append("align");  //$NON-NLS-1$
			buffer.append(HtmlConstants.EQUAL_CHAR);
			buffer.append(HtmlConstants.QUOTE_CHAR);
			buffer.append("left");  //$NON-NLS-1$
			buffer.append(HtmlConstants.QUOTE_CHAR);

			symbolicName = (String) iterator.next();

			if (symbolicName.equals(bundle)) {
				buffer.append("bgcolor");  //$NON-NLS-1$
				buffer.append(HtmlConstants.EQUAL_CHAR);
				buffer.append(HtmlConstants.QUOTE_CHAR);
				buffer.append("yellow");  //$NON-NLS-1$
				buffer.append(HtmlConstants.QUOTE_CHAR);
			}

			buffer.append(HtmlConstants.CLOSE_CHAR);

			indent(5);
			addLink(symbolicName, BundleDependencyHttpProcessor.BROWSE_ACTION, BundleDependencyHttpProcessor.BUNDLE_PARAMETER, symbolicName);

			indent(4);
			buffer.append(HtmlConstants.TABLE_DATA_END_TAG);

			// Row i, Column 3: Bundle Dependents (n)
			indent(4);
			buffer.append(td);
			indent(5);

			if (i < dependents.size()) {
				symbolicName = (String) dependents.get(i);
				addBundleLink(symbolicName);
			} else {
				buffer.append(HtmlConstants.NONBREAKING_SPACE);
			}

			indent(4);
			buffer.append(HtmlConstants.TABLE_DATA_END_TAG);

			indent(3);
			buffer.append(HtmlConstants.TABLE_ROW_END_TAG);

			i++;
		}
	}

	private void addBundleLink(String symbolicName) {
		String value = symbolicName;
		int index = symbolicName.indexOf('*');

		if (index != -1) {
			value = symbolicName.substring(0, index);
		}

		addLink(symbolicName, BundleDependencyHttpProcessor.BROWSE_ACTION, BundleDependencyHttpProcessor.BUNDLE_PARAMETER, value);
	}

	private void addCommonLinks(boolean topLink, boolean showAllBundles) {
		indent(2);

		ICharBuffer buffer = getBuffer();
		buffer.append(HtmlConstants.HORIZONTAL_RULE);

		indent(2);
		addLink(WebPageGenerator.RELOAD_PAGE_VALUE, BundleDependencyHttpProcessor.BROWSE_ACTION);
		buffer.append(HtmlConstants.LINK_SEPARATOR);

		indent(2);

		buffer.append(HtmlConstants.OPEN_CHAR);
		buffer.append('a');
		buffer.append(HtmlConstants.SPACE_CHAR);
		buffer.append("href");  //$NON-NLS-1$
		buffer.append(HtmlConstants.EQUAL_CHAR);
		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append(BundleDependencyServlet.getServletContainerPath());
		buffer.append(BundleDependencyServlet.getServletAlias());
		buffer.append(HtmlConstants.QUESTION_CHAR);
		buffer.append(BundleDependencyHttpProcessor.ACTION_PARAMETER);
		buffer.append(HtmlConstants.EQUAL_CHAR);
		buffer.append("browse");  //$NON-NLS-1$

		if (topLink == true) {
			buffer.append("#top");  //$NON-NLS-1$
			buffer.append(HtmlConstants.QUOTE_CHAR);
			buffer.append(HtmlConstants.CLOSE_CHAR);
			buffer.append(WebPageGenerator.TOP_OF_PAGE_VALUE);
		} else {
			buffer.append("#bottom");  //$NON-NLS-1$
			buffer.append(HtmlConstants.QUOTE_CHAR);
			buffer.append(HtmlConstants.CLOSE_CHAR);
			buffer.append(WebPageGenerator.BOTTOM_OF_PAGE_VALUE);
		}

		buffer.append(HtmlConstants.LINK_END_TAG);
		buffer.append(HtmlConstants.LINK_SEPARATOR);

		indent(2);

		String label;
		String action;

		if (showAllBundles == true) {
			label = WebPageGenerator.SHOW_IMMEDIATE_BUNDLES_VALUE;
			action = BundleDependencyHttpProcessor.SHOW_IMMEDIATE_BUNDLES_ACTION;
		} else {
			label = WebPageGenerator.SHOW_ALL_BUNDLES_VALUE;
			action = BundleDependencyHttpProcessor.SHOW_ALL_BUNDLES_ACTION;
		}

		addLink(label, action);

		indent(2);
		buffer.append(HtmlConstants.HORIZONTAL_RULE);

		addBreak(2);
	}

	private void addCopyrightNotice() {
		ICharBuffer buffer = getBuffer();
		buffer.append(HtmlConstants.COMMENT_BEGIN_TAG);
		buffer.append(HtmlConstants.LINE_SEPARATOR);
		buffer.append("Copyright (c) 2001, 2008 IBM Corporation and others.");  //$NON-NLS-1$
		buffer.append(HtmlConstants.LINE_SEPARATOR);
		buffer.append("All rights reserved. This program and the accompanying materials");  //$NON-NLS-1$
		buffer.append(HtmlConstants.LINE_SEPARATOR);
		buffer.append("are made available under the terms of the Eclipse Public License v1.0");  //$NON-NLS-1$
		buffer.append(HtmlConstants.LINE_SEPARATOR);
		buffer.append("which accompanies this distribution, and is available at");  //$NON-NLS-1$
		buffer.append(HtmlConstants.LINE_SEPARATOR);
		buffer.append("http://www.eclipse.org/legal/epl-v10.html");  //$NON-NLS-1$
		buffer.append(HtmlConstants.LINE_SEPARATOR);
		buffer.append(HtmlConstants.LINE_SEPARATOR);
		buffer.append("Contributors:");  //$NON-NLS-1$
		buffer.append(HtmlConstants.LINE_SEPARATOR);
		buffer.append("    IBM Corporation - initial API and implementation");  //$NON-NLS-1$
		buffer.append(HtmlConstants.LINE_SEPARATOR);
		buffer.append(HtmlConstants.COMMENT_END_TAG);
		buffer.append(HtmlConstants.LINE_SEPARATOR);
		buffer.append(HtmlConstants.LINE_SEPARATOR);
	}

	private void addFooter() {
		ICharBuffer buffer = getBuffer();

		indent(2);
		buffer.append(HtmlConstants.OPEN_CHAR);
		buffer.append('a');
		buffer.append(HtmlConstants.SPACE_CHAR);
		buffer.append("name");  //$NON-NLS-1$
		buffer.append(HtmlConstants.EQUAL_CHAR);
		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append("bottom");  //$NON-NLS-1$
		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append(HtmlConstants.CLOSE_CHAR);

		indent(3);
		buffer.append(HtmlConstants.BOLD_BEGIN_TAG);
		buffer.append(WebPageGenerator.GENERATED_BY_VALUE);
		buffer.append(HtmlConstants.BOLD_END_TAG);

		indent(2);
		buffer.append(HtmlConstants.LINK_END_TAG);

		addBreak(2);

		indent(2);
		buffer.append(HtmlConstants.ITALIC_BEGIN_TAG);
		buffer.append(WebPageGenerator.COPYRIGHT_NOTICE_VALUE);
		buffer.append(HtmlConstants.ITALIC_END_TAG);

		indent();
		buffer.append(HtmlConstants.BODY_END_TAG);
		buffer.append(HtmlConstants.LINE_SEPARATOR);
		buffer.append(HtmlConstants.HTML_END_TAG);
	}

	private void addHeader() {
		addCopyrightNotice();

		ICharBuffer buffer = getBuffer();
		buffer.append(HtmlConstants.HTML_BEGIN_TAG);

		indent();
		buffer.append(HtmlConstants.HEAD_BEGIN_TAG);

		indent(2);
		buffer.append(HtmlConstants.TITLE_BEGIN_TAG);
		buffer.append(WebPageGenerator.BUNDLE_DEPENDENCY_HOME_PAGE_VALUE);
		buffer.append(HtmlConstants.TITLE_END_TAG);

		indent();
		buffer.append(HtmlConstants.HEAD_END_TAG);

		indent();
		buffer.append(HtmlConstants.OPEN_CHAR);
		buffer.append("body");  //$NON-NLS-1$
		buffer.append(HtmlConstants.SPACE_CHAR);
		buffer.append("vlink");  //$NON-NLS-1$
		buffer.append(HtmlConstants.EQUAL_CHAR);
		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append("blue");  //$NON-NLS-1$
		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append(HtmlConstants.SPACE_CHAR);
		buffer.append("background");  //$NON-NLS-1$
		buffer.append(HtmlConstants.EQUAL_CHAR);
		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append(BundleDependencyServlet.getResourceAlias());
		buffer.append("/background.gif");  //$NON-NLS-1$
		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append(HtmlConstants.SPACE_CHAR);
		buffer.append("bgproperties");  //$NON-NLS-1$
		buffer.append(HtmlConstants.EQUAL_CHAR);
		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append("fixed");  //$NON-NLS-1$
		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append(HtmlConstants.CLOSE_CHAR);

		indent(2);
		buffer.append(HtmlConstants.OPEN_CHAR);
		buffer.append('a');
		buffer.append(HtmlConstants.SPACE_CHAR);
		buffer.append("name");  //$NON-NLS-1$
		buffer.append(HtmlConstants.EQUAL_CHAR);
		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append("top");  //$NON-NLS-1$
		buffer.append(HtmlConstants.QUOTE_CHAR);

		buffer.append(HtmlConstants.CLOSE_CHAR);

		indent(3);
		buffer.append(HtmlConstants.H2_FONT_BEGIN_TAG);
		buffer.append(WebPageGenerator.BUNDLE_DEPENDENCIES_BROWSER_VALUE);
		buffer.append(HtmlConstants.H2_FONT_END_TAG);

		indent(2);
		buffer.append(HtmlConstants.LINK_END_TAG);
	}

	private void addLink(String label, String action) {
		addLink(label, action, (String[]) null, (String[]) null);
	}

	private void addLink(String label, String action, String parameter, String value) {
		String[] parameters = {
			parameter
		};

		String[] values = {
			value
		};

		addLink(label, action, parameters, values);
	}

	private void addLink(String label, String action, String[] parameters, String[] values) {
		ICharBuffer buffer = getBuffer();
		buffer.append(HtmlConstants.OPEN_CHAR);
		buffer.append('a');
		buffer.append(HtmlConstants.SPACE_CHAR);
		buffer.append("href");  //$NON-NLS-1$
		buffer.append(HtmlConstants.EQUAL_CHAR);
		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append(BundleDependencyServlet.getServletContainerPath());
		buffer.append(BundleDependencyServlet.getServletAlias());

		if (action != null) {
			buffer.append(HtmlConstants.QUESTION_CHAR);
			buffer.append(BundleDependencyHttpProcessor.ACTION_PARAMETER);
			buffer.append(HtmlConstants.EQUAL_CHAR);
			buffer.append(action);
		}

		if (parameters != null) {
			int length = parameters.length;
			String parameter;
			String value;

			for (int i = 0; i < length; i++) {
				parameter = parameters [ i ];
				value = values [ i ];

				buffer.append(HtmlConstants.AMPERSAND_CHAR);
				buffer.append(parameter);
				buffer.append(HtmlConstants.EQUAL_CHAR);
				buffer.append(value);
			}
		}

		buffer.append(HtmlConstants.QUOTE_CHAR);
		buffer.append(HtmlConstants.CLOSE_CHAR);
		buffer.append(label);
		buffer.append(HtmlConstants.LINK_END_TAG);
	}

	private ICharBuffer createBuffer() {
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(15000);
		return buffer;
	}

	public void generate(HttpServletResponse response, Throwable exception) throws IOException {
		PrintWriter out = response.getWriter();
		String text;
		String exceptionWasThrown = Messages.getString(WebPageGenerator.AN_EXCEPTION_WAS_THROWN_KEY);

		synchronized (this) {
			addHeader();

			indent(2);

			ICharBuffer buffer = getBuffer();
			buffer.append(HtmlConstants.HORIZONTAL_RULE);

			indent(2);
			addLink(WebPageGenerator.BACK_VALUE, BundleDependencyHttpProcessor.BROWSE_ACTION);

			indent(2);
			buffer.append(HtmlConstants.HORIZONTAL_RULE);

			indent(2);
			buffer.append(HtmlConstants.H3_FONT_BEGIN_TAG);
			buffer.append(exceptionWasThrown);
			buffer.append(HtmlConstants.H3_FONT_END_TAG);

			indent(2);
			buffer.append(HtmlConstants.OPEN_CHAR);
			buffer.append("font");  //$NON-NLS-1$
			buffer.append(HtmlConstants.SPACE_CHAR);
			buffer.append("color");  //$NON-NLS-1$
			buffer.append(HtmlConstants.EQUAL_CHAR);
			buffer.append(HtmlConstants.QUOTE_CHAR);
			buffer.append("red");  //$NON-NLS-1$
			buffer.append(HtmlConstants.QUOTE_CHAR);
			buffer.append(HtmlConstants.CLOSE_CHAR);

			indent(2);
			buffer.append(HtmlConstants.PREFORMATTED_BEGIN_TAG);

			text = getBufferValue();
			out.print(text);

			exception.printStackTrace(out);

			indent(2);
			buffer.append(HtmlConstants.PREFORMATTED_END_TAG);

			indent(2);
			buffer.append(HtmlConstants.FONT_END_TAG);

			indent(2);
			buffer.append(HtmlConstants.HORIZONTAL_RULE);

			indent(2);
			addLink(WebPageGenerator.BACK_VALUE, BundleDependencyHttpProcessor.BROWSE_ACTION);

			indent(2);
			buffer.append(HtmlConstants.HORIZONTAL_RULE);

			addFooter();

			text = getBufferValue();
		}

		out.print(text);
	}

	public void generate(String bundle, boolean showAllBundles, HttpServletResponse response) throws IOException {
		String text;

		synchronized (this) {
			addHeader();
			addCommonLinks(false, showAllBundles);
			addBundleDependencyTable(bundle, showAllBundles);
			addCommonLinks(true, showAllBundles);
			addFooter();
			text = getBufferValue();
		}

		PrintWriter out = response.getWriter();
		out.print(text);
	}

	private ICharBuffer getBuffer() {
		return buffer;
	}

	private String getBufferValue() {
		ICharBuffer buffer = getBuffer();
		String value = buffer.toString();
		buffer.setLength(0);
		return value;
	}

	private IBundleDependencyModel getModel() {
		return model;
	}

	private void indent() {
		indent(1);
	}

	private void indent(int level) {
		ICharBuffer buffer = getBuffer();
		buffer.append(HtmlConstants.LINE_SEPARATOR);

		for (int i = 0; i < level; i++) {
			buffer.append(HtmlConstants.INDENT);
		}
	}

	private void setBuffer(ICharBuffer buffer) {
		this.buffer = buffer;
	}

	private void setModel(IBundleDependencyModel model) {
		this.model = model;
	}
}
