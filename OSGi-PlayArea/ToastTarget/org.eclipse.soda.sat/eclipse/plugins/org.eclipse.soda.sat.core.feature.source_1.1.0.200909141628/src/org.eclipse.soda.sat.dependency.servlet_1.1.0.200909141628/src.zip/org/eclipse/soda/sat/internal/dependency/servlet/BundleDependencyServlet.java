/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.dependency.servlet;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel;
import org.osgi.service.http.HttpService;
import org.osgi.service.http.NamespaceException;

/**
 * BundleDependencyServlet.java
 */
public class BundleDependencyServlet extends HttpServlet {
	//
	// Static Fields
	//

	// Property Keys
	private static final String SERVLET_ALIAS_PROPERTY_KEY = "org.eclipse.soda.sat.dependency.servlet.alias";  //$NON-NLS-1$
	private static final String SERVLET_CONTAINER_PATH_KEY = "org.eclipse.soda.sat.dependency.servlet.container.path";  //$NON-NLS-1$

	// Default Property Values
	private static final String DEFAULT_SERVLET_ALIAS_PROPERTY = "/bds";  //$NON-NLS-1$
	private static final String DEFAULT_SERVLET_CONTAINER_PATH_PROPERTY = new String();

	// Property Values
	private static final String SERVLET_ALIAS;  // Initialized by static initializer.
	private static final String SERVLET_CONTAINER_PATH;  // Initialized by static initializer.

	// Misc
	private static final String RESOURCE_ALIAS = "/dependency/servlet/html/resource";  //$NON-NLS-1$
	private static final String RESOURCE_PATH = "/org/eclipse/soda/sat/internal/dependency/servlet/html/resource";  //$NON-NLS-1$
	private static final long serialVersionUID = 919428339454657596L;

	// Static Initializer and Methods

	static {
		SERVLET_ALIAS = BundleDependencyServlet.initializeServletAlias();
		SERVLET_CONTAINER_PATH = BundleDependencyServlet.initializeServletContainerPath();
	}

	public static String getResourceAlias() {
		return BundleDependencyServlet.RESOURCE_ALIAS;
	}

	public static String getResourcePath() {
		return BundleDependencyServlet.RESOURCE_PATH;
	}

	public static String getServletAlias() {
		return BundleDependencyServlet.SERVLET_ALIAS;
	}

	public static String getServletContainerPath() {
		return BundleDependencyServlet.SERVLET_CONTAINER_PATH;
	}

	private static String initializeServletAlias() {
		String servletAlias = System.getProperty(BundleDependencyServlet.SERVLET_ALIAS_PROPERTY_KEY);

		if (servletAlias == null) {
			servletAlias = BundleDependencyServlet.DEFAULT_SERVLET_ALIAS_PROPERTY;
		} else {
			servletAlias = BundleDependencyServlet.validatePath(servletAlias);
		}

		return servletAlias;
	}

	private static String initializeServletContainerPath() {
		String servletContainerPath = System.getProperty(BundleDependencyServlet.SERVLET_CONTAINER_PATH_KEY);

		if (servletContainerPath == null) {
			servletContainerPath = BundleDependencyServlet.DEFAULT_SERVLET_CONTAINER_PATH_PROPERTY;
		} else {
			servletContainerPath = BundleDependencyServlet.validatePath(servletContainerPath);
		}

		return servletContainerPath;
	}

	private static String validatePath(String servletAlias) {
		char forwardSlash = '/';
		StringBuffer buffer = new StringBuffer(servletAlias);

		if (buffer.charAt(0) != forwardSlash) {
			buffer.insert(0, forwardSlash);
		}

		int last = buffer.length() - 1;

		if (buffer.charAt(last) == forwardSlash) {
			buffer.deleteCharAt(last);
		}

		String value = buffer.toString();
		return value;
	}

	//
	// Instance Fields
	//

	private HttpService server;
	private String port;
	private BundleDependencyHttpProcessor processor;

	//
	// Constructors
	//

	public BundleDependencyServlet() {
		super();
		setProcessor(new BundleDependencyHttpProcessor());
	}

	//
	// Instance Methods
	//

	public void bind(HttpService server, String port, IBundleDependencyModel model) {
		setServer(server);
		setPort(port);

		BundleDependencyHttpProcessor processor = getProcessor();
		processor.bind(model);

		register();
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BundleDependencyHttpProcessor processor = getProcessor();
		processor.process(request, response);
	}

	private String getHost() {
		String host = null;

		try {
			InetAddress address = InetAddress.getLocalHost();
			host = address.getHostAddress();
		} catch (UnknownHostException exception) {
			host = "localhost";  //$NON-NLS-1$
		}

		return host;
	}

	private String getPort() {
		return port;
	}

	private BundleDependencyHttpProcessor getProcessor() {
		return processor;
	}

	private HttpService getServer() {
		return server;
	}

	private void logServletUrl() {
		String host = getHost();
		String port = getPort();
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(200);
		buffer.append("Servlet URL: ");  //$NON-NLS-1$
		buffer.append("http://");  //$NON-NLS-1$
		buffer.append(host);
		buffer.append(':');

		if (port != null) {
			buffer.append(port);
		} else {
			buffer.append('<');
			buffer.append("port");  //$NON-NLS-1$
			buffer.append('>');
		}

		buffer.append(BundleDependencyServlet.getServletContainerPath());
		buffer.append(BundleDependencyServlet.getServletAlias());
		buffer.append('?');
		buffer.append("action");  //$NON-NLS-1$
		buffer.append('=');
		buffer.append("browse");  //$NON-NLS-1$
		String message = buffer.toString();
		LogUtility.logInfo(this, message);
	}

	private void logSystemPropertyDetails() {
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(200);
		buffer.append("Change the servlet alias using the system propertis: ");  //$NON-NLS-1$
		buffer.append('\n');
		buffer.append(' ');
		buffer.append(' ');
		buffer.append("-D");  //$NON-NLS-1$
		buffer.append(BundleDependencyServlet.SERVLET_CONTAINER_PATH_KEY);
		buffer.append('=');
		buffer.append("<servlet container path>");  //$NON-NLS-1$
		buffer.append('\n');
		buffer.append(' ');
		buffer.append(' ');
		buffer.append("-D");  //$NON-NLS-1$
		buffer.append(BundleDependencyServlet.SERVLET_ALIAS_PROPERTY_KEY);
		buffer.append('=');
		buffer.append("<servlet alias>");  //$NON-NLS-1$
		String message = buffer.toString();
		LogUtility.logInfo(this, message);
	}

	private void register() {
		HttpService server = getServer();

		try {
			server.registerServlet(BundleDependencyServlet.getServletAlias(), this, null, null);
			server.registerResources(BundleDependencyServlet.getResourceAlias(), BundleDependencyServlet.getResourcePath(), null);
		} catch (ServletException exception) {
			exception.printStackTrace();
		} catch (NamespaceException exception) {
			exception.printStackTrace();
		}

		logServletUrl();
		logSystemPropertyDetails();
	}

	private void setPort(String port) {
		this.port = port;
	}

	private void setProcessor(BundleDependencyHttpProcessor processor) {
		this.processor = processor;
	}

	private void setServer(HttpService server) {
		this.server = server;
	}

	public void unbind() {
		unregister();
		setServer(null);
	}

	private void unregister() {
		HttpService server = getServer();
		server.unregister(BundleDependencyServlet.getServletAlias());
		server.unregister(BundleDependencyServlet.getResourceAlias());
	}
}
