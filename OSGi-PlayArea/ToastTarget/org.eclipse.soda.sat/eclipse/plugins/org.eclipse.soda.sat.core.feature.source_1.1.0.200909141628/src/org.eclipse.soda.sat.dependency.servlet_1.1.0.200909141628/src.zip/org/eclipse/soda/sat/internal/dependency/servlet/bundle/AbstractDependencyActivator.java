/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.dependency.servlet.bundle;

import java.util.List;
import java.util.Set;

import org.eclipse.soda.sat.core.framework.BaseBundleActivator;
import org.eclipse.soda.sat.core.service.BundleDependencyService;
import org.eclipse.soda.sat.internal.dependency.model.BundleDependencyModel;
import org.osgi.framework.BundleContext;

/**
 * AbstractDependencyActivator.java
 */
public abstract class AbstractDependencyActivator extends BaseBundleActivator {
	//
	// Instance Fields
	//
	private BundleDependencyModel model;

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#activate()
	 */
	protected void activate() {
		BundleContext bundleContext = getBundleContext();
		BundleDependencyModel model = new BundleDependencyModel(bundleContext);
		setModel(model);
		BundleDependencyService bds = getBundleDependencyService();
		model.bind(bds);
	}

	protected void addImportedServiceNames(List names) {
		names.add(BundleDependencyService.class.getName());
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#collectImportedServiceNames(java.util.Set)
	 */
	protected void collectImportedServiceNames(Set serviceNames) {
		serviceNames.add(BundleDependencyService.SERVICE_NAME);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#deactivate()
	 */
	protected void deactivate() {
		BundleDependencyModel model = getModel();
		model.unbind();
		setModel(null);
	}

	/**
	 * Gets the BundleDependencyService.
	 */
	private BundleDependencyService getBundleDependencyService() {
		return (BundleDependencyService) getImportedService(BundleDependencyService.SERVICE_NAME);
	}

	/**
	 * Protected model getter.
	 */
	protected BundleDependencyModel getModel() {
		return model;
	}

	/**
	 * Private model setter.
	 */
	private void setModel(BundleDependencyModel model) {
		this.model = model;
	}
}