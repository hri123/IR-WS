/*******************************************************************************
 * Copyright (c) 2001, 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.dependency.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.eclipse.soda.sat.internal.dependency.model.interfaces.IBundleDependencyModel;
import org.eclipse.soda.sat.internal.dependency.nls.Messages;
import org.eclipse.soda.sat.internal.dependency.servlet.html.WebPageGenerator;

/**
 * BundleDependencyHttpProcessor.java
 */
public class BundleDependencyHttpProcessor extends Object {
	//
	// Static Fields
	//

	// Externalized Strings Keys
	private static final String UNKNOWN_ACTION_ERROR_KEY = "BundleDependencyHttpProcessor.UnknownActionError";  //$NON-NLS-1$

	// Servlet Parameters Keys
	public static final String ACTION_PARAMETER = "action";  //$NON-NLS-1$
	public static final String BUNDLE_PARAMETER = "bundle";  //$NON-NLS-1$
	public static final String ID_PARAMETER = "id";  //$NON-NLS-1$

	// Servlet Parameter Values
	public static final String BROWSE_ACTION = "browse";  //$NON-NLS-1$
	public static final String PING_ACTION = "ping";  //$NON-NLS-1$
	public static final String SHOW_ALL_BUNDLES_ACTION = "showAllBundles";  //$NON-NLS-1$
	public static final String SHOW_IMMEDIATE_BUNDLES_ACTION = "showImmediateBundles";  //$NON-NLS-1$
	public static final String GET_ALL_DEPENDENTS_OF_ACTION = "getAllDependentsOf";  //$NON-NLS-1$
	public static final String GET_ALL_PREREQUISITES_OF_ACTION = "getAllPrerequisitesOf";  //$NON-NLS-1$
	public static final String GET_BUNDLES_ACTION = "getBundles";  //$NON-NLS-1$
	public static final String GET_STATE_ACTION = "getState";  //$NON-NLS-1$
	public static final String GET_DEPENDENTS_OF_ACTION = "getDependentsOf";  //$NON-NLS-1$
	public static final String GET_MANIFEST_ACTION = "getManifest";  //$NON-NLS-1$
	public static final String GET_PREREQUISITES_OF_ACTION = "getPrerequisitesOf";  //$NON-NLS-1$
	public static final String GET_SERVICES_NAMES_EXPORTED_BY_ACTION = "getServiceNamesExportedBy";  //$NON-NLS-1$
	public static final String GET_SERVICES_NAMES_IMPORTED_BY_ACTION = "getServiceNamesImportedBy";  //$NON-NLS-1$
	public static final String GET_UNACQUIRED_IMPORTED_SERVICE_NAMES_ACTION = "getUnacquiredImportedServiceNames";  //$NON-NLS-1$
	public static final String GET_UNACQUIRED_OPTIONAL_IMPORTED_SERVICE_NAMES_ACTION = "getUnacquiredOptionalImportedServiceNames";  //$NON-NLS-1$
	public static final String IS_BUNDLE_ACTION = "isBundle";  //$NON-NLS-1$
	public static final String IS_EXPORTING_SERVICES_ACTION = "isExportingServices";  //$NON-NLS-1$
	public static final String IS_IMPORTING_SERVICES_ACTION = "isImportingServices";  //$NON-NLS-1$
	public static final String TO_XML_ACTION = "toXml";  //$NON-NLS-1$

	//
	// Misc
	//
	private static final String CONTENT_TYPE = "text/html";  //$NON-NLS-1$

	//
	// Instance Fields
	//
	private String bundle;
	private WebPageGenerator generator;
	private IBundleDependencyModel model;
	private HttpServletRequest request;
	private HttpServletResponse response;
	private boolean showAllBundles;

	//
	// Instance Methods
	//

	public void bind(IBundleDependencyModel model) {
		setModel(model);
	}

	private String getBundle() {
		return bundle;
	}

	private WebPageGenerator getGenerator() {
		synchronized (this) {
			if (generator == null) {
				IBundleDependencyModel model = getModel();
				WebPageGenerator generator = new WebPageGenerator(model);
				setGenerator(generator);
			}
		}

		return generator;
	}

	private IBundleDependencyModel getModel() {
		return model;
	}

	private String getParameter(String name) {
		HttpServletRequest request = getRequest();
		String value = request.getParameter(name);
		if (value != null) {
			value = URLDecoder.decode(value);
		}
		return value;
	}

	private HttpServletRequest getRequest() {
		return request;
	}

	private HttpServletResponse getResponse() {
		return response;
	}

	private boolean getShowAllBundles() {
		return showAllBundles;
	}

	private void handleBrowseRequest() throws IOException {
		String bundle = getParameter(BundleDependencyHttpProcessor.BUNDLE_PARAMETER);
		if (bundle == null) {
			bundle = getBundle();
		} else {
			setBundle(bundle);
		}

		boolean showAllBundles = getShowAllBundles();

		WebPageGenerator generator = getGenerator();
		HttpServletResponse response = getResponse();
		generator.generate(bundle, showAllBundles, response);
	}

	private void handleDefaultRequest() throws IOException {
		HttpServletResponse response = getResponse();
		PrintWriter writer = response.getWriter();
		long time = System.currentTimeMillis();
		writer.print(time);

	}

	private void handleException(Throwable exception) throws IOException {
		if (exception == null)
			return;  // Early return.
		exception.printStackTrace();

		WebPageGenerator generator = getGenerator();
		HttpServletResponse response = getResponse();
		generator.generate(response, exception);
	}

	private void handleGetAllDependentsOfRequest() throws IOException {
		String bundle = getParameter(BundleDependencyHttpProcessor.BUNDLE_PARAMETER);
		IBundleDependencyModel model = getModel();
		List/*<String>*/ list = model.getAllDependentsOf(bundle);
		send(list);
	}

	private void handleGetAllPrerequisitesOfRequest() throws IOException {
		String bundle = getParameter(BundleDependencyHttpProcessor.BUNDLE_PARAMETER);
		IBundleDependencyModel model = getModel();
		List/*<String>*/ list = model.getAllPrerequisitesOf(bundle);
		send(list);
	}

	private void handleGetBundlesRequest() throws IOException {
		IBundleDependencyModel model = getModel();
		List/*<String>*/ list = model.getBundles();
		send(list);
	}

	private void handleGetDependentsOfRequest() throws IOException {
		String bundle = getParameter(BundleDependencyHttpProcessor.BUNDLE_PARAMETER);
		IBundleDependencyModel model = getModel();
		List/*<String>*/ list = model.getDependentsOf(bundle);
		send(list);
	}

	private void handleGetManifestRequest() throws IOException {
		String bundle = getParameter(BundleDependencyHttpProcessor.BUNDLE_PARAMETER);
		IBundleDependencyModel model = getModel();
		String value = model.getManifest(bundle);
		send(value);
	}

	private void handleGetPrerequisitesOfRequest() throws IOException {
		String bundle = getParameter(BundleDependencyHttpProcessor.BUNDLE_PARAMETER);
		IBundleDependencyModel model = getModel();
		List/*<String>*/ list = model.getPrerequisitesOf(bundle);
		send(list);
	}

	private void handleGetServiceNamesExportedByRequest() throws IOException {
		String bundle = getParameter(BundleDependencyHttpProcessor.BUNDLE_PARAMETER);
		IBundleDependencyModel model = getModel();
		List list = model.getServiceNamesExportedBy(bundle);
		send(list);
	}

	private void handleGetServiceNamesImportedByRequest() throws IOException {
		String bundle = getParameter(BundleDependencyHttpProcessor.BUNDLE_PARAMETER);
		IBundleDependencyModel model = getModel();
		List list = model.getServiceNamesImportedBy(bundle);
		send(list);
	}

	private void handleGetStateRequest() throws IOException {
		String bundle = getParameter(BundleDependencyHttpProcessor.BUNDLE_PARAMETER);
		IBundleDependencyModel model = getModel();
		int state = model.getState(bundle);
		send(state);
	}

	private void handleGetUnacquiredImportedServiceNames() throws IOException {
		String id = getParameter(BundleDependencyHttpProcessor.ID_PARAMETER);
		IBundleDependencyModel model = getModel();
		List/*<String>*/ list = model.getUnacquiredImportedServiceNames(id);
		send(list);
	}

	private void handleGetUnacquiredOptionalImportedServiceNames() throws IOException {
		String id = getParameter(BundleDependencyHttpProcessor.ID_PARAMETER);
		IBundleDependencyModel model = getModel();
		List/*<String>*/ list = model.getUnacquiredOptionalImportedServiceNames(id);
		send(list);
	}

	private void handleIsBundleRequest() throws IOException {
		String bundle = getParameter(BundleDependencyHttpProcessor.BUNDLE_PARAMETER);
		IBundleDependencyModel model = getModel();
		boolean isBundle = model.isBundle(bundle);
		send(isBundle);
	}

	private void handleIsExportingServicesRequest() throws IOException {
		String bundle = getParameter(BundleDependencyHttpProcessor.BUNDLE_PARAMETER);
		IBundleDependencyModel model = getModel();
		boolean exportedServices = model.isExportingServices(bundle);
		send(exportedServices);
	}

	private void handleIsImportingServicesRequest() throws IOException {
		String bundle = request.getParameter(BundleDependencyHttpProcessor.BUNDLE_PARAMETER);
		IBundleDependencyModel model = getModel();
		boolean importedServices = model.isImportingServices(bundle);
		send(importedServices);
	}

	private void handlePingRequest() throws IOException {
		send(true);
	}

	private void handleShowAllBundlesRequest() throws IOException {
		setShowAllBundles(true);
		handleBrowseRequest();
	}

	private void handleShowImmediateBundlesRequest() throws IOException {
		setShowAllBundles(false);
		handleBrowseRequest();
	}

	private void handleToXmlRequest() throws IOException {
		IBundleDependencyModel model = getModel();
		String xml = model.toXml();
		send(xml);
	}

	private void handleUnknownAction(String action) throws IOException {
		HttpServletRequest request = getRequest();
		String remoteAddress = request.getRemoteAddr();
		HttpServletResponse response = getResponse();
		int error = HttpServletResponse.SC_BAD_REQUEST;

		Object[] values = {
			new Integer(error),
			action,
			remoteAddress
		};

		String pattern = Messages.getString(BundleDependencyHttpProcessor.UNKNOWN_ACTION_ERROR_KEY);
		String message = MessageFormatter.format(pattern, values);
		LogUtility.logError(this, message);
		response.sendError(error, message);
	}

	public void process(HttpServletRequest request, HttpServletResponse response) throws IOException {
		setRequest(request);
		setResponse(response);
		processAction();
	}

	private void processAction() throws IOException {
		String action = getParameter(BundleDependencyHttpProcessor.ACTION_PARAMETER);

		try {
			if (BundleDependencyHttpProcessor.BROWSE_ACTION.equalsIgnoreCase(action)) {
				handleBrowseRequest();
			} else if (BundleDependencyHttpProcessor.PING_ACTION.equalsIgnoreCase(action)) {
				handlePingRequest();
			} else if (BundleDependencyHttpProcessor.SHOW_ALL_BUNDLES_ACTION.equalsIgnoreCase(action)) {
				handleShowAllBundlesRequest();
			} else if (BundleDependencyHttpProcessor.SHOW_IMMEDIATE_BUNDLES_ACTION.equalsIgnoreCase(action)) {
				handleShowImmediateBundlesRequest();
			} else if (BundleDependencyHttpProcessor.GET_ALL_DEPENDENTS_OF_ACTION.equalsIgnoreCase(action)) {
				handleGetAllDependentsOfRequest();
			} else if (BundleDependencyHttpProcessor.GET_ALL_PREREQUISITES_OF_ACTION.equalsIgnoreCase(action)) {
				handleGetAllPrerequisitesOfRequest();
			} else if (BundleDependencyHttpProcessor.GET_BUNDLES_ACTION.equalsIgnoreCase(action)) {
				handleGetBundlesRequest();
			} else if (BundleDependencyHttpProcessor.GET_DEPENDENTS_OF_ACTION.equalsIgnoreCase(action)) {
				handleGetDependentsOfRequest();
			} else if (BundleDependencyHttpProcessor.GET_MANIFEST_ACTION.equalsIgnoreCase(action)) {
				handleGetManifestRequest();
			} else if (BundleDependencyHttpProcessor.GET_PREREQUISITES_OF_ACTION.equalsIgnoreCase(action)) {
				handleGetPrerequisitesOfRequest();
			} else if (BundleDependencyHttpProcessor.GET_SERVICES_NAMES_EXPORTED_BY_ACTION.equalsIgnoreCase(action)) {
				handleGetServiceNamesExportedByRequest();
			} else if (BundleDependencyHttpProcessor.GET_SERVICES_NAMES_IMPORTED_BY_ACTION.equalsIgnoreCase(action)) {
				handleGetServiceNamesImportedByRequest();
			} else if (BundleDependencyHttpProcessor.GET_STATE_ACTION.equalsIgnoreCase(action)) {
				handleGetStateRequest();
			} else if (BundleDependencyHttpProcessor.GET_UNACQUIRED_IMPORTED_SERVICE_NAMES_ACTION.equalsIgnoreCase(action)) {
				handleGetUnacquiredImportedServiceNames();
			} else if (BundleDependencyHttpProcessor.GET_UNACQUIRED_OPTIONAL_IMPORTED_SERVICE_NAMES_ACTION.equalsIgnoreCase(action)) {
				handleGetUnacquiredOptionalImportedServiceNames();
			} else if (BundleDependencyHttpProcessor.IS_BUNDLE_ACTION.equalsIgnoreCase(action)) {
				handleIsBundleRequest();
			} else if (BundleDependencyHttpProcessor.IS_EXPORTING_SERVICES_ACTION.equalsIgnoreCase(action)) {
				handleIsExportingServicesRequest();
			} else if (BundleDependencyHttpProcessor.IS_IMPORTING_SERVICES_ACTION.equalsIgnoreCase(action)) {
				handleIsImportingServicesRequest();
			} else if (BundleDependencyHttpProcessor.TO_XML_ACTION.equalsIgnoreCase(action)) {
				handleToXmlRequest();
			} else if (action == null) {
				handleDefaultRequest();
			} else {
				handleUnknownAction(action);
			}
		} catch (Exception exception) {
			handleException(exception);
		}
	}

	private void send(boolean value) throws IOException {
		Boolean wrapper = new Boolean(value);
		String text = wrapper.toString();
		HttpServletResponse response = getResponse();
		PrintWriter writer = response.getWriter();
		writer.print(text);
	}

	private void send(int value) throws IOException {
		Integer wrapper = new Integer(value);
		String text = wrapper.toString();
		HttpServletResponse response = getResponse();
		PrintWriter writer = response.getWriter();
		writer.print(text);
	}

	private void send(List/*<String>*/ list) throws IOException {
		if (list == null)
			return;  // Early return.
		HttpServletResponse response = getResponse();
		PrintWriter writer = response.getWriter();

		Iterator/*<String>*/ iterator = list.iterator();
		String bundle;

		while (iterator.hasNext() == true) {
			bundle = (String) iterator.next();
			writer.print(bundle);

			if (iterator.hasNext() == true) {
				writer.print(',');
			}
		}
	}

	private void send(String value) throws IOException {
		HttpServletResponse response = getResponse();
		PrintWriter writer = response.getWriter();
		writer.print(value);
	}

	private void setBundle(String bundle) {
		this.bundle = bundle;
	}

	private void setGenerator(WebPageGenerator generator) {
		this.generator = generator;
	}

	private void setModel(IBundleDependencyModel model) {
		this.model = model;
	}

	private void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	private void setResponse(HttpServletResponse response) {
		response.setContentType(BundleDependencyHttpProcessor.CONTENT_TYPE);
		this.response = response;
	}

	private void setShowAllBundles(boolean showAllBundles) {
		this.showAllBundles = showAllBundles;
	}

	public void unbind() {
		setModel(null);
	}
}
