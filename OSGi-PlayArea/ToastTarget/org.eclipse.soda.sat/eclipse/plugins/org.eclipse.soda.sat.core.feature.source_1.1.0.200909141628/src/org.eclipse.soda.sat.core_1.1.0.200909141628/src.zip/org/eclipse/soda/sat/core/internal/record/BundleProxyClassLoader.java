/*******************************************************************************
 * Copyright (c) 2006-2007 Cognos Incorporated, IBM Corporation and others
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Cognos Incorporated - initial API and implementation
 *     IBM Corporation - bug fixes and enhancements
 *******************************************************************************/

package org.eclipse.soda.sat.core.internal.record;

import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;

import org.osgi.framework.Bundle;

/**
 * A <code>BundleProxyClassLoader</code> wraps a <code>Bundle</code> and uses
 * the various Bundle methods to produce a <code>ClassLoader</code>.  This class
 * is a derivative work that is based on the internal Equinox class
 * <code>org.eclipse.equinox.internal.jsp.jasper.BundleProxyClassLoader</code>,
 * which is made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available
 * <a href="http://www.eclipse.org/legal/epl-v10.html">here</a>.
 */
class BundleProxyClassLoader extends ClassLoader {
	//
	// Instance Fields
	//

	private Bundle bundle;

	//
	// Constructors
	//

	BundleProxyClassLoader(Bundle bundle) {
		super();
		setBundle(bundle);
	}

	//
	// Instance Methods
	//

	/**
	 * @see java.lang.ClassLoader#findClass(java.lang.String)
	 */
	protected Class findClass(String name) throws ClassNotFoundException {
		Bundle bundle = getBundle();
		Class clazz = bundle.loadClass(name);
		return clazz;
	}

	/**
	 * @see java.lang.ClassLoader#findResource(java.lang.String)
	 */
	protected URL findResource(String name) {
		Bundle bundle = getBundle();
		URL url = bundle.getResource(name);
		return url;
	}

	/**
	 * @see java.lang.ClassLoader#findResources(java.lang.String)
	 */
	protected Enumeration findResources(String name) throws IOException {
		Bundle bundle = getBundle();
		Enumeration enumeration = bundle.getResources(name);
		return enumeration;
	}

	/**
	 * Private <code>bundle</code> getter.
	 *
	 * @return  A <code>Bundle</code>.
	 */
	private Bundle getBundle() {
		return bundle;
	}

	/**
	 * @see java.lang.ClassLoader#getResource(java.lang.String)
	 */
	public URL getResource(String name) {
		URL url = findResource(name);
		return url;
	}

	/**
	 * @see java.lang.ClassLoader#loadClass(java.lang.String, boolean)
	 */
	protected Class loadClass(String name, boolean resolve) throws ClassNotFoundException {
		Class clazz = findClass(name);
		if (resolve == true) resolveClass(clazz);
		return clazz;
	}

	/**
	 * Private <code>bundle</code> setter.
	 *
	 * @param bundle  A <code>Bundle</code>.
	 */
	private void setBundle(Bundle bundle) {
		this.bundle = bundle;
	}
}
