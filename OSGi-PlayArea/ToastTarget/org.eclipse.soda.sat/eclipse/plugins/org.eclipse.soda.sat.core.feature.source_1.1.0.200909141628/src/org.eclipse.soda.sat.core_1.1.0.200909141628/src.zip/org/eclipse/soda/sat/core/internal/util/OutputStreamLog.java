/*******************************************************************************
 * Copyright (c) 2001, 2009 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.List;

import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.ServiceReferenceUtility;
import org.osgi.framework.Bundle;
import org.osgi.framework.ServiceReference;
import org.osgi.service.log.LogService;

/**
 * OutputStreamLog.java
 */
public class OutputStreamLog  extends Object implements LogService {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String LOG_LEVEL_DEBUG_KEY = "Common.LogLevelDebug";  //$NON-NLS-1$
	private static final String LOG_LEVEL_ERROR_KEY = "Common.LogLevelError";  //$NON-NLS-1$
	private static final String LOG_LEVEL_INFO_KEY = "Common.LogLevelInfo";  //$NON-NLS-1$
	private static final String LOG_LEVEL_UNKNOWN_KEY = "Common.Unknown";  //$NON-NLS-1$
	private static final String LOG_LEVEL_WARNING_KEY = "Common.LogLevelWarning";  //$NON-NLS-1$

	// Externalized String Values
	private static final String LOG_LEVEL_DEBUG_VALUE = Messages.getString(OutputStreamLog.LOG_LEVEL_DEBUG_KEY);
	private static final String LOG_LEVEL_ERROR_VALUE = Messages.getString(OutputStreamLog.LOG_LEVEL_ERROR_KEY);
	private static final String LOG_LEVEL_INFO_VALUE = Messages.getString(OutputStreamLog.LOG_LEVEL_INFO_KEY);
	private static final String LOG_LEVEL_UNKNOWN_VALUE = Messages.getString(OutputStreamLog.LOG_LEVEL_UNKNOWN_KEY);
	private static final String LOG_LEVEL_WARNING_VALUE = Messages.getString(OutputStreamLog.LOG_LEVEL_WARNING_KEY);

	// Misc
	private static final int DEFAULT_BUFFER_SIZE = 1024;  // 1K
	private static final String LINE_SEPARATOR = System.getProperty("line.separator");  //$NON-NLS-1$

	//
	// Instance Fields
	//

	private OutputStream errorOutputStream;
	private OutputStream warningOutputStream;
	private OutputStream infoOutputStream;
	private OutputStream debugOutputStream;
	private ICharBuffer buffer;

	//
	// Constructors
	//

	/**
	 * Construct a new OutputStreamLog.
	 *
	 * @param errorOutputStream    The error <code>OutputStream</code>.
	 * @param warningOutputStream  The warning <code>OutputStream</code>.
	 * @param infoOutputStream     The info <code>OutputStream</code>.
	 * @param debugOutputStream    The debug <code>OutputStream</code>.
	 */
	public OutputStreamLog(OutputStream errorOutputStream, OutputStream warningOutputStream, OutputStream infoOutputStream, OutputStream debugOutputStream) {
		super();
		initializeOutputStreams(errorOutputStream, warningOutputStream, infoOutputStream, debugOutputStream);
		setBuffer(createBuffer());
	}

	//
	// Instance Methods
	//

	private ICharBuffer createBuffer() {
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(OutputStreamLog.DEFAULT_BUFFER_SIZE);
		return buffer;
	}

	/**
	 * Format the log message for writing to the console.
	 *
	 * @param reference  The service reference.
	 * @param level      The log level.
	 * @param message    The message string to format.
	 *
	 * @return String
	 */
	private String formatLogMessage(ServiceReference reference, int level, String message) {
		ICharBuffer buffer = getBuffer();
		buffer.setLength(0);
		String prefix = getPrefix(level);
		buffer.append(prefix);
		buffer.append(' ');
		buffer.append(message);
		printServiceReferenceOn(buffer, reference);
		buffer.append(OutputStreamLog.LINE_SEPARATOR);
		String logMessage = buffer.toString();
		return logMessage;
	}

	/**
	 * Private buffer getter.
	 *
	 * @return The buffer.
	 */
	private ICharBuffer getBuffer() {
		return buffer;
	}

	private OutputStream getDebugOutputStream() {
		return debugOutputStream;
	}

	private OutputStream getErrorOutputStream() {
		return errorOutputStream;
	}

	private OutputStream getInfoOutputStream() {
		return infoOutputStream;
	}

	/**
	 * Get the log level description.
	 *
	 * @param level  The log level.
	 *
	 * @return A string description of the log level.
	 */
	private String getLevelText(int level) {
		String text;

		switch (level) {
			case LogService.LOG_ERROR:
				text = OutputStreamLog.LOG_LEVEL_ERROR_VALUE;
				break;

			case LogService.LOG_WARNING:
				text = OutputStreamLog.LOG_LEVEL_WARNING_VALUE;
				break;

			case LogService.LOG_INFO:
				text = OutputStreamLog.LOG_LEVEL_INFO_VALUE;
				break;

			case LogService.LOG_DEBUG:
				text = OutputStreamLog.LOG_LEVEL_DEBUG_VALUE;
				break;

			default:
				text = OutputStreamLog.LOG_LEVEL_UNKNOWN_VALUE;
				break;
		}

		return text;
	}

	/**
	 * Get the output stream used when logging to a message.
	 *
	 * @param level  The log level.
	 *
	 * @return <code>System.out</code> for information and debug messages, and
	 * <code>System.err</code> for error and warning messages.
	 */
	private OutputStream getOutputStream(int level) {
		OutputStream stream;

		if (level == LogService.LOG_DEBUG) {
			stream = getDebugOutputStream();
		} else if (level == LogService.LOG_INFO) {
			stream = getInfoOutputStream();
		} else if (level == LogService.LOG_WARNING) {
			stream = getWarningOutputStream();
		} else if (level == LogService.LOG_ERROR) {
			stream = getErrorOutputStream();
		} else {
			stream = System.err;
		}

		return stream;
	}

	/**
	 * Get the message prefix.
	 *
	 * @param level  The log level.
	 *
	 * @return The message prefix string.
	 */
	private String getPrefix(int level) {
		String levelText = getLevelText(level);

		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(10);
		buffer.append('[');
		buffer.append(levelText);
		buffer.append(']');

		String prefix = buffer.toString();
		return prefix;
	}

	/**
	 * Query the service names represented by a service reference.
	 *
	 * @param reference  The service reference to be queried.
	 *
	 * @return The names of the services represented by a service reference.
	 */
	private List/*<String>*/ getServiceNames(ServiceReference reference) {
		ServiceReferenceUtility utility = ServiceReferenceUtility.getInstance();
		List/*<String>*/ names = utility.getServiceNames(reference);
		return names;
	}

	private OutputStream getWarningOutputStream() {
		return warningOutputStream;
	}

	private void initializeOutputStreams(OutputStream errorOutputStream, OutputStream warningOutputStream, OutputStream infoOutputStream, OutputStream debugOutputStream) {
		setErrorOutputStream(errorOutputStream);
		setWarningOutputStream(warningOutputStream);
		setInfoOutputStream(infoOutputStream);
		setDebugOutputStream(debugOutputStream);
	}

	/**
	 * @see org.osgi.service.log.LogService#log(int, String)
	 */
	public void log(int level, String message) {
		log(null, level, message, null);
	}

	/**
	 * @see org.osgi.service.log.LogService#log(int, String, Throwable)
	 */
	public void log(int level, String message, Throwable throwable) {
		log(null, level, message, throwable);
	}

	/**
	 * @see org.osgi.service.log.LogService#log(ServiceReference, int, String)
	 */
	public void log(ServiceReference reference, int level, String message) {
		log(reference, level, message, null);
	}

	/**
	 * @see org.osgi.service.log.LogService#log(ServiceReference, int, String, Throwable)
	 */
	public void log(ServiceReference reference, int level, String message, Throwable throwable) {
		OutputStream stream = getOutputStream(level);
		if (stream == null)
			return;  // Early return.

		synchronized (this) {
			String logMessage = formatLogMessage(reference, level, message);
			byte[] bytes = logMessage.getBytes();

			try {
				stream.write(bytes);
				stream.flush();

				if (throwable != null) {
					PrintStream printStream = new PrintStream(stream);
					throwable.printStackTrace(printStream);
					printStream.flush();
				}
			} catch (IOException exception) {
				exception.printStackTrace();
			}
		}
	}

	private void printServiceReferenceOn(ICharBuffer buffer, ServiceReference reference) {
		if (reference == null)
			return;  // Early return.
		Bundle bundle = reference.getBundle();

		if (bundle != null) {
			String symbolicName = bundle.getSymbolicName();
			long id = bundle.getBundleId();
			buffer.append(',');
			buffer.append(' ');
			buffer.append("bundle"); //$NON-NLS-1$
			buffer.append('=');
			buffer.append(symbolicName);
			buffer.append(' ');
			buffer.append('[');
			buffer.append(id);
			buffer.append(']');
		}

		List/*<String>*/ names = getServiceNames(reference);
		boolean empty = names.isEmpty();
		if (empty == true)
			return;

		buffer.append(',');
		buffer.append(' ');
		buffer.append("services"); //$NON-NLS-1$
		buffer.append('=');
		buffer.append('[');

		Iterator/*<String>*/ iterator = names.iterator();
		while (iterator.hasNext() == true) {
			Object name = iterator.next();
			buffer.append(name);

			if (iterator.hasNext() == true) {
				buffer.append(',');
				buffer.append(' ');
			}
		}

		buffer.append(']');
	}

	private void setBuffer(ICharBuffer buffer) {
		this.buffer = buffer;
	}

	private void setDebugOutputStream(OutputStream debugOutputStream) {
		this.debugOutputStream = debugOutputStream;
	}

	private void setErrorOutputStream(OutputStream errorOutputStream) {
		this.errorOutputStream = errorOutputStream;
	}

	private void setInfoOutputStream(OutputStream infoOutputStream) {
		this.infoOutputStream = infoOutputStream;
	}

	private void setWarningOutputStream(OutputStream warningOutputStream) {
		this.warningOutputStream = warningOutputStream;
	}
}