/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework.interfaces;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Dictionary;
import java.util.Map;
import java.util.Properties;

import org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleException;
import org.osgi.framework.Filter;

/**
 * The <code>IBundleActivationManager</code> interface defines the core API
 * for SAT's bundle activation strategy.
 */
public interface IBundleActivationManager {
	/**
	 * <i>Configuration Method:</i> Acquire the named imported service.
	 *
	 * @param name  The name of an imported service.
	 * @return Object
	 */
	public Object acquireImportedService(String name);

	/**
	 * <i>Configuration Method:</i> Acquire the imported services.
	 */
	public void acquireImportedServices();

	/**
	 * <i>Configuration Method:</i> Acquire the named optional imported
	 * service.
	 *
	 * @param name  The name of an optional imported service.
	 * @return Object
	 */
	public Object acquireOptionalImportedService(String name);
	/**
	 * <i>Configuration Method:</i> Acquire the optional imported services.
	 */
	public void acquireOptionalImportedServices();

	/**
	 * <i>Configuration Method:</i> Add an exported proxy service.
	 *
	 * @param interfaceType  The interface used to create the proxy service and
	 *                       register it with the OSGi framework.
	 * @param handler        The proxy service's handler.
	 * @param properties     The properties to be registered with the service.
	 */
	public void addExportedProxyService(Class interfaceType, IProxyServiceHandler handler, Dictionary properties);

	/**
	 * <i>Configuration Method:</i> Add an exported proxy service.
	 *
	 * @param interfaceTypes  The interfaces used to create the proxy service
	 *                        and register it with the OSGi framework.
	 * @param handler         The proxy service's handler.
	 * @param properties      The properties to be registered with the service.
	 */
	public void addExportedProxyServices(Class[] interfaceTypes, IProxyServiceHandler handler, Dictionary properties);

	/**
	 * <i>Configuration Method:</i> Add an exported service with properties.
	 *
	 * @param name        The name of an exported service.
	 * @param service     The service.
	 * @param properties  The properties to be registered with the service.
	 */
	public void addExportedService(String name, Object service, Dictionary properties);

	/**
	 * <i>Configuration Method:</i> Add multiple exported service with
	 * properties.
	 *
	 * @param names       An array of exported service names.
	 * @param service     The service.
	 * @param properties  The properties to be registered with the services.
	 */
	public void addExportedServices(String[] names, Object service, Dictionary properties);

	/**
	 * <i>Configuration Method:</i> Add the specified export service record.
	 *
	 * @param record  The export service record to add.
	 */
	public void addExportServiceRecord(IExportServiceRecord record);

	/**
	 * <i>Configuration Method:</i> Add the specified export service records.
	 *
	 * @param records  The export service records to add.
	 */
	public void addExportServiceRecords(IExportServiceRecord[] records);

	/**
	 * <i>Configuration Method:</i> Add an LDAP filter to an imported service.
	 *
	 * @param name          The name of the imported service.
	 * @param filterString  The LDAP filter to be used for acquiring the
	 *                      imported service.
	 */
	public void addImportedServiceFilter(String name, String filterString);

	/**
	 * <i>Configuration Method:</i> Add the specified import service record.
	 *
	 * @param record  The import service record to add.
	 */
	public void addImportServiceRecord(IImportServiceRecord record);

	/**
	 * <i>Configuration Method:</i> Add an LDAP filter to an optional imported
	 * service.
	 *
	 * @param name          The name of the optional imported service.
	 * @param filterString  The LDAP filter to be used for acquiring the
	 *                      optional imported service.
	 */
	public void addOptionalImportedServiceFilter(String name, String filterString);

	/**
	 * <i>OSGi Query Method:</i> Get the bundle.
	 *
	 * @return The bundle's <code>Bundle</code> object, or <code>null</code>.
	 */
	public Bundle getBundle();

	/**
	 * <i>OSGi Query Method:</i> Get the <code>BundleContext</code>.
	 *
	 * @return The bundle's <code>BundleContext</code>, or <code>null</code>.
	 */
	public BundleContext getBundleContext();

	/**
	 * <i>OSGi Query Method:</i> Query the bundle's manifest for its
	 * <code>Bundle-SymbolicName</code> header.
	 *
	 * @return The name of the bundle.
	 */
	public String getBundleSymbolicName();

	/**
	 * <i>Persistent Bundle Storage Method:</i> Get the bundle's private data
	 * directory.  The data directory is where it stores persistent
	 * data files.
	 *
	 * @return A File reference to the bundle's private data directory.
	 * @see #getDataFile(String)
	 */
	public File getDataDirectory();

	/**
	 * <i>Persistent Bundle Storage Method:</i> Open a data file contained in
	 * the bundle's private data directory.  If the file does not exist, then it
	 * is created.  The data file resides persistently in the bundle's private
	 * data directory within the bundle store.
	 *
	 * @param filename  The name of the persistent data file.
	 * @return A File object associate with the persistent data file.
	 * @see #getDataDirectory()
	 */
	public File getDataFile(String filename);

	/**
	 * <i>Query Method:</i> Get a named exported service object.
	 *
	 * @param name  The name of the exported service.
	 * @return An exported service object or <code>null</code>.
	 */
	public Object getExportedService(String name);

	/**
	 * <i>Query Method:</i> Answers the names of all the services that are
	 * exported specified in the bundle's manifest.
	 *
	 * @return The exported service names from the bundle manifest.
	 *
	 * @deprecated OSGi R4 has deprecated the Export-Service header.
	 */
	public String[] getExportedServiceNamesFromManifest();

	/**
	 * <i>Query Method:</i> Answers the properties of an exported service.
	 *
	 * @param name  The name of the exported service.
	 *
	 * @return A <code>Dictionary</code> containing the exported service's
	 *         properties.
	 */
	public Dictionary getExportedServiceProperties(String name);

	/**
	 * <i>Query Method:</i> Answers the properties of a specific exported
	 * service.
	 *
	 * @param name     The name of the exported service.
	 * @param service  The exported service.
	 *
	 * @return A <code>Dictionary</code> containing the exported service's
	 *         properties.
	 */
	public Dictionary getExportedServiceProperties(String name, Object service);

	/**
	 * <i>Query Method:</i> Get the exported service objects.  The returned
	 * <code>Map</code> is keyed by service names, and each value is a
	 * <code>List</code> of service objects.  The value is always a
	 * <code>List</code>, even if there is only one exported service for a
	 * particular service name.
	 *
	 * @return A <code>Map</code> where each key is a service names and each
	 * value is a <code>List</code> of service objects.
	 */
	public Map/*<String, List<Object>>*/ getExportedServices();

	/**
	 * <i>Query Method:</i> Query the exported services.
	 *
	 * @param name  The name of the exported service.
	 * @return An array of the named exported services, or an empty array if no
	 * match is found.
	 */
	public Object[] getExportedServices(String name);

	/**
	 * <i>Query Method:</i> Create an input stream on the default properties
	 * file.
	 *
	 * @throws java.io.IOException
	 * @return An input stream on the default properties.
	 */
	public InputStream getFilePropertiesInputStream() throws IOException;

	/**
	 * <i>Query Method:</i> Create an input stream on the specified properties
	 * file.
	 *
	 * @param filename  The name of the properties file.
	 * @throws java.io.IOException
	 * @return An input stream on the specified properties file.
	 */
	public InputStream getFilePropertiesInputStream(String filename) throws IOException;

	/**
	 * <i>Query Method:</i> Get the named imported service.  This method
	 * is guaranteed to return the requested service so long as the following
	 * conditions are true:
	 * <ul>
	 *   <li>
	 *     The method is called from either the owner's <code>activate()</code>
	 *     or <code>deactivate()</code> method.
	 *   <li>
	 *     The owner's method <code>requiresAllImportedServices()</code> has not
	 *     been implemented to return <code>false</code>.
	 *   </li>
	 *   <li>
	 *     The <code>name</code> parameter is the name of a service that is
	 *     imported by the bundle and documented as such using the bundle
	 *     manifest's <code>Import-Service</code> header.
	 *   </li>
	 *   <li>
	 *     This method is only called on the OSGi thread that starts and
	 *     stops the bundle.
	 *   </li>
	 * </ul>
	 * If these conditions are not true, there is the possibility that this
	 * method will return <code>null</code>.
	 *
	 * @param name  The name of the imported service.
	 * @return The imported service or <code>null</code> if no match is found.
	 *
	 * @see IBundleActivationManagerOwner#activate()
	 * @see IBundleActivationManagerOwner#deactivate()
	 */
	public Object getImportedService(String name);

	/**
	 * <i>Query Method:</i> Search for an imported service filter.
	 *
	 * @param name  The name of the imported service.
	 * @return Answers the filter for the named imported service, or
	 *         <code>null</code> if no filter exists.
	 */
	public Filter getImportedServiceFilter(String name);

	/**
	 * <i>Query Method:</i> Answers the names of all the required services that
	 * are imported by the bundle.
	 *
	 * @return The required imported service names.
	 */
	public String[] getImportedServiceNames();

	/**
	 * <i>Query Method:</i> Answers the names of all the services that are
	 * imported specified in the bundle's manifest.
	 *
	 * @return The imported service names from the bundle manifest.
	 *
	 * @deprecated OSGi R4 has deprecated the Import-Service header.
	 */
	public String[] getImportedServiceNamesFromManifest();

	/**
	 * <i>Query Method:</i> Get the value of an imported service's property.
	 *
	 * @param name  The name of the imported service.
	 * @param key   The key of the imported service property.
	 * @return The imported service's property or <code>null</code> if the
	 * property cannot be found.
	 */
	public Object getImportedServiceProperty(String name, String key);

	/**
	 * <i>Query Method:</i> Get the keys of an imported service's properties.
	 *
	 * @param name  The name of the imported service.
	 * @return The imported service's property keys or <code>null</code> if no
	 * properties exist.
	 */
	public String[] getImportedServicePropertyKeys(String name);

	/** <i>Query Method:</i> Get the imported service objects.  The returned
	 * <code>Map</code> is keyed by service names, and each value is a
	 * the service object.
	 *
	 * @return A <code>Map</code> where each key is a service names and each
	 * value is a service object.
	 */
	public Map/*<String, Object>*/ getImportedServices();

	/**
	 * <i>Query Method:</i> Get the named optional imported service.
	 *
	 * @param name  The name of the optional imported service.
	 * @return The imported service or <code>null</code> if no match is found.
	 */
	public Object getOptionalImportedService(String name);

	/**
	 * <i>Query Method:</i> Search for an optional imported service filter.
	 *
	 * @param name  The name of the optional imported service.
	 * @return Answers the filter for the named optional imported service, or
	 *         <code>null</code> if no filter exists.
	 */
	public Filter getOptionalImportedServiceFilter(String name);

	/**
	 * <i>Query Method:</i> Answers the names of all the optional services that
	 * are imported by the bundle.
	 *
	 * @return The optional imported service names.
	 */
	public String[] getOptionalImportedServiceNames();

	/**
	 * <i>Query Method:</i> Get the value of an optional imported service's
	 * property.
	 *
	 * @param name  The name of the optional imported service.
	 * @param key   The key of the optional imported service property.
	 * @return The optional imported service's property or <code>null</code> if
	 * the property cannot be found.
	 */
	public Object getOptionalImportedServiceProperty(String name, String key);

	/**
	 * <i>Query Method:</i> Get the keys of an optional imported service's
	 * properties.
	 *
	 * @param name  The name of the optional imported service.
	 * @return The optional imported service's property keys or
	 * <code>null</code> if no properties exist.
	 */
	public String[] getOptionalImportedServicePropertyKeys(String name);

	/** <i>Query Method:</i> Get the option imported service objects.  The
	 * returned <code>Map</code> is keyed by service names, and each value is a
	 * the service object.
	 *
	 * @return A <code>Map</code> where each key is a service names and each
	 * value is a service object.
	 */
	public Map/*<String, List<Object>>*/ getOptionalImportedServices();

	/**
	 * <i>Query API:</i> Create a <code>Properties</code> object out of the
	 * bundle's properties.  This method does not cache the <code>Properties</code>
	 * object.  The properties are obtained using the query method
	 * <code>getPropertiesInputStream()</code>, which is typically overridden by
	 * subclasses that define properties.
	 *
	 * @return The bundle's properties.
	 */
	public Properties getProperties();

	/**
	 * <i>Query API:</i> Get the value of a property.
	 *
	 * @param key          The property key.
	 * @param defaultValue The default value for the property.
	 * @return The value of the property, or the default value if the key is
	 * not found.
	 */
	public String getProperty(String key, String defaultValue);

	/**
	 * <i>Query API:</i> Get the names of the imported services that have not
	 * been acquired.
	 *
	 * @return The names of the imported services that have not been acquired.
	 */
	public String[] getUnacquiredImportedServiceNames();

	/**
	 * <i>Query API:</i> Get the names of the optional imported services that
	 * have not been acquired.
	 *
	 * @return The names of the optional imported services that have not been
	 * acquired.
	 */
	public String[] getUnacquiredOptionalImportedServiceNames();

	/**
	 * <i>Configuration Method:</i> Release the named imported service.
	 *
	 * @param name  The name of an imported service.
	 */
	public void releaseImportedService(String name);

	/**
	 * <i>Configuration Method:</i> Release the imported services.
	 */
	public void releaseImportedServices();

	/**
	 * <i>Configuration Method:</i> Release the named optional imported service.
	 *
	 * @param name  The name of an optional imported service.
	 */
	public void releaseOptionalImportedService(String name);

	/**
	 * <i>Configuration Method:</i> Release the optional imported services.
	 */
	public void releaseOptionalImportedServices();

	/**
	 * <i>Configuration Method:</i> Remove the exported service record of the
	 * specified type.  Since an <code>IExportServiceRecord</code> can represent
	 * multiple distinct service names, this method will remove all
	 * <code>IExportServiceRecord</code> occurrences, regardless of the
	 * specified service name.  The specified service name is simply used to
	 * identify the <code>IExportServiceRecord</code>.  While this method is
	 * visible to subclasses, it is not typically used.
	 * <p>
	 * <i>Note:</i> All exported services are automatically removed by SAT when
	 * the bundle stops.
	 *
	 * @param name  The service name.
	 */
	public void removeExportedService(String name);

	/**
	 * <i>Configuration Method:</i> Removes the specified exported service.
	 * Since an <code>IExportServiceRecord</code> can represent multiple
	 * distinct service names, this method will remove all
	 * <code>IExportServiceRecord</code> occurrences, regardless of the
	 * specified service name.  The specified service name is simply used to
	 * identify the <code>IExportServiceRecord</code>.  While this method
	 * is visible to subclasses, it is not typically used.
	 * <p>
	 * <i>Note:</i> All exported services are automatically removed by SAT when
	 * the bundle stops.
	 *
	 * @param name     The service name.
	 * @param service  The service.
	 */
	public void removeExportedService(String name, Object service);

	/**
	 * <i>Configuration Method:</i> Remove the named exported service domain
	 * object.
	 * <p>
	 * <i>Note:</i> All exported services are automatically removed by SAT when
	 * the bundle stops.
	 *
	 * @param name  The name of the exported service.
	 */
	public void removeExportedServices(String name);

	/**
	 * <i>Configuration Method:</i> Remove the specified export service record.
	 *
	 * @param record  The export service record to remove.
	 */
	public void removeExportServiceRecord(IExportServiceRecord record);

	/**
	 * <i>Configuration Method:</i> Removes the LDAP filter for an imported
	 * service.
	 *
	 * @param name  The name of the imported service.
	 */
	public void removeImportedServiceFilter(String name);

	/**
	 * <i>Configuration Method:</i> Removes the LDAP filter for an optional
	 * imported service.
	 *
	 * @param name  The name of the optional imported service.
	 */
	public void removeOptionalImportedServiceFilter(String name);

	/**
	 * <i>OSGi Framework Method:</i> Stop and restart the OSGi framework.  If
	 * the bundle has been stopped, this method does nothing.
	 *
	 * @throws org.osgi.framework.BundleException
	 */
	public void restartFramework() throws BundleException;

	/**
	 * <i>Configuration Method:</i> Sets the properties of an exported service.
	 *
	 * @param name        The name of the exported service.
	 * @param properties  The LDAP properties to be registered with the
	 *                    exported service.
	 */
	public void setExportedServiceProperties(String name, Dictionary properties);

	/**
	 * <i>Configuration Method:</i> Sets the properties of an exported service.
	 *
	 * @param name        The name of the exported service.
	 * @param service     The service.
	 * @param properties  The LDAP properties to be registered with the exported
	 *                    service.
	 */
	public void setExportedServiceProperties(String name, Object service, Dictionary properties);

	/**
	 * <i>OSGi Framework Method:</i> Shutdown the OSGi framework.  If the bundle
	 * has been stopped, this method does nothing.
	 *
	 * @throws org.osgi.framework.BundleException
	 */
	public void shutdownFramework() throws BundleException;

	/**
	 * Start the bundle activation manager.
	 *
	 * @param bundleContext  The <code>BundleContext</code> for the bundle.
	 * @param owner          The owner of the bundle activation manager.
	 * @throws Exception when the bundle activation manager fails to start.
	 */
	public void start(BundleContext bundleContext, IBundleActivationManagerOwner owner) throws Exception;

	/**
	 * Stop the bundle activation manager.
	 *
	 * @throws Exception when the bundle activation manager fails to stop.
	 */
	public void stop() throws Exception;
}