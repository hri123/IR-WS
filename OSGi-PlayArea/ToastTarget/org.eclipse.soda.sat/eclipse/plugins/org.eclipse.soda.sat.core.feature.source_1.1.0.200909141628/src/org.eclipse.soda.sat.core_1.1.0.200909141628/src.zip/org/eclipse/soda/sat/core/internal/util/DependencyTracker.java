/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.CollectionUtility;

/**
 * The <code>DependencyTracker</code> class manages the dependency relationship
 * between two objects.  A <code>DependencyTracker</code> can be thought of as
 * a <i>two-way</i> hashed collection since it knows both the <i>dependents</i>
 * of an object and the <i>prerequisites</i> of an object.
 */
public class DependencyTracker/*<D, P>*/ extends Object implements IDependencyTracker/*<D, P>*/ {
	//
	// Static Fields
	//

	// Misc
	private static final int VALUE_CONTAINER_CAPACITY = 20;
	private static final int MAP_SIZE = 251;

	//
	// Instance Fields
	//

	private Map/*<D, Collection<P>>*/ dependentsMap;
	private Map/*<P, Collection<D>>*/ prerequisitesMap;
	private final Object lock = new Object();

	//
	// Constructors
	//

	/**
	 * Constructor.
	 */
	public DependencyTracker/*<D, P>*/() {
		this(DependencyTracker.MAP_SIZE);
	}

	/**
	 * Constructor.
	 *
	 * @param size  The size of the tracker.
	 */
	public DependencyTracker/*<D, P>*/(int size) {
		this(size, size);
	}

	/**
	 * Constructor.
	 *
	 * @param prerequisites  The size of the prerequisites container.
	 * @param dependents     The size of the dependents container.
	 */
	public DependencyTracker/*<D, P>*/(int prerequisites, int dependents) {
		super();
		setPrerequisitesMap(new HashMap/*<P, Collection<D>>*/(estimateHashedCollectionSize(prerequisites)));
		setDependentsMap(new HashMap/*<D, Collection<P>>*/(estimateHashedCollectionSize(dependents)));
	}

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#add(java.lang.Object, java.lang.Object)
	 */
	public boolean add(Object dependent, Object prerequisite) {
		Assertion.checkArgumentIsNotNull(dependent, "dependent");  //$NON-NLS-1$
		Assertion.checkArgumentIsNotNull(prerequisite, "prerequisite");  //$NON-NLS-1$

		boolean added = false;
		Object lock = getLock();

		synchronized (lock) {
			Collection/*<P>*/ prerequisites = prerequisitesOf(dependent);

			if (prerequisites.contains(prerequisite) == false) {
				prerequisites.add(prerequisite);
				added = true;
			}

			Collection/*<D>*/ dependents = dependentsOf(prerequisite);

			if (dependents.contains(dependent) == false) {
				dependents.add(dependent);
				added = true;
			}
		}

		return added;
	}

	private void addAll(Collection/*<Object>*/ source, Set/*<Object>*/ target) {
		Iterator/*<Object>*/ iterator = source.iterator();

		while (iterator.hasNext() == true) {
			Object object = iterator.next();
			target.add(object);
		}
	}

	/**
	 * Recursively collects all the dependents of a prerequisite entry into a
	 * List.
	 *
	 * @param prerequisite  An object that is a prerequisite.
	 * @param results       A container for storing the results of the
	 *                      collection.
	 */
	private void collectDependents(Object prerequisite, Collection/*<D>*/ results) {
		Object lock = getLock();

		synchronized (lock) {
			Map/*<P, Collection<D>>*/ map = getPrerequisitesMap();
			Collection/*<D>*/ dependents = (Collection/*<D>*/) map.get(prerequisite);
			if (dependents == null)
				return;  // Early return.

			Iterator/*<D>*/ iterator = dependents.iterator();

			while (iterator.hasNext() == true) {
				Object dependent = iterator.next();

				if (results.contains(dependent) == false) {
					results.add(dependent);
					collectDependents(dependent, results);
				}
			}
		}
	}

	/**
	 * Recursively collects all the prerequisites of a dependent entry into a
	 * List.
	 *
	 * @param dependent  An object that is a prerequisite.
	 * @param results    A container for storing the results of the collection.
	 */
	private void collectPrerequisites(Object dependent, List/*<P>*/  results) {
		Object lock = getLock();

		synchronized (lock) {
			Map/*<D, Collection<P>>*/ map = getDependentsMap();
			Collection/*<P>*/ prerequisites = (Collection/*<P>*/) map.get(dependent);
			if (prerequisites == null)
				return;  // Early return.

			Iterator/*<P>*/ iterator = prerequisites.iterator();

			while (iterator.hasNext() == true) {
				Object prerequisite = iterator.next();

				if (results.contains(prerequisite) == false) {
					results.add(prerequisite);
					collectPrerequisites(prerequisite, results);
				}
			}
		}
	}

	/**
	 * Answers all dependent entries of a prerequisite entry.
	 *
	 * @param prerequisite  An object that is a prerequisite.
	 * @return A collection of dependent objects.
	 */
	private Collection/*<D>*/ dependentsOf(Object prerequisite) {
		Map/*<P, Collection<D>>*/ map = getPrerequisitesMap();
		Collection/*<D>*/ dependents;
		Object lock = getLock();

		synchronized (lock) {
			dependents = (Collection/*<D>*/) map.get(prerequisite);

			if (dependents == null) {
				dependents = new ArrayList/*<D>*/(DependencyTracker.VALUE_CONTAINER_CAPACITY);
				map.put(prerequisite, dependents);
			}
		}

		return dependents;
	}

	private int estimateHashedCollectionSize(int capacity) {
		CollectionUtility utility = CollectionUtility.getInstance();
		int size = utility.estimateHashedCollectionSize(capacity);
		return size;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#getAllDependents(java.lang.Object)
	 */
	public List/*<D>*/ getAllDependents(Object prerequisite) {
		Assertion.checkArgumentIsNotNull(prerequisite, "prerequisite");  //$NON-NLS-1$
		int size = getMaxMapSize();
		List/*<D>*/ dependents = new ArrayList/*<D>*/(size);
		collectDependents(prerequisite, dependents);
		return dependents;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#getAllPrerequisites(java.lang.Object)
	 */
	public List/*<P>*/ getAllPrerequisites(Object dependent) {
		Assertion.checkArgumentIsNotNull(dependent, "dependent");  //$NON-NLS-1$
		int size = getMaxMapSize();
		List/*<P>*/ prerequisites = new ArrayList/*<P>*/(size);
		collectPrerequisites(dependent, prerequisites);
		return prerequisites;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#getDependents()
	 */
	public List/*<D>*/ getDependents() {
		Map/*<D, Collection<P>>*/ map = getDependentsMap();
		List/*<D>*/ result = getKeys(map);
		return result;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#getDependents(java.lang.Object)
	 */
	public List/*<D>*/ getDependents(Object prerequisite) {
		Assertion.checkArgumentIsNotNull(prerequisite, "prerequisite");  //$NON-NLS-1$
		List/*<D>*/ result;
		Object lock = getLock();

		synchronized (lock) {
			Map/*<P, Collection<D>>*/ map = getPrerequisitesMap();
			Collection/*<D>*/ dependents = (Collection/*<D>*/) map.get(prerequisite);

			if (dependents == null) {
				result = new ArrayList/*<D>*/(0);
			} else {
				int size = dependents.size();
				result = new ArrayList/*<D>*/(size);
				result.addAll(dependents);
			}
		}

		return result;
	}

	/**
	 * Private dependentsMap getter.
	 *
	 * @return The prerequisite -> dependents map.
	 */
	private Map/*<D, Collection<P>>*/ getDependentsMap() {
		return dependentsMap;
	}

	/**
	 * Utility that answers a copy of a Map's keys.
	 *
	 * @param map  The Map to query for its keys.
	 * @return The keys of the Map.
	 */
	private List/*<Object>*/ getKeys(Map/*<Object, Collection<Object>>*/ map) {
		int size = map.size();
		List/*<Object>*/ result = new ArrayList/*<Object>*/(size);

		Collection/*<Object>*/ keys = map.keySet();
		Iterator/*<Object>*/ iterator = keys.iterator();

		while (iterator.hasNext() == true) {
			Object key = iterator.next();
			result.add(key);
		}

		return result;
	}

	private Object getLock() {
		return lock;
	}

	/**
	 * Answers the size of the largest Map.
	 *
	 * @return int
	 */
	private int getMaxMapSize() {
		Map/*<D, Collection<P>>*/ dependentsMap = getDependentsMap();
		int dependentsMapSize = dependentsMap.size();

		Map/*<P, Collection<D>>*/ prerequisitesMap = getPrerequisitesMap();
		int prerequisitesMapSize = prerequisitesMap.size();

		int maxSize = Math.max(dependentsMapSize, prerequisitesMapSize);
		return maxSize;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#getPrerequisites()
	 */
	public List/*<P>*/ getPrerequisites() {
		Map/*<P, Collection<D>>*/ map = getPrerequisitesMap();
		List/*<P>*/ result = getKeys(map);
		return result;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#getPrerequisites(java.lang.Object)
	 */
	public List/*<P>*/ getPrerequisites(Object dependent) {
		Assertion.checkArgumentIsNotNull(dependent, "dependent");  //$NON-NLS-1$
		List/*<P>*/ result;
		Object lock = getLock();

		synchronized (lock) {
			Map/*<D, Collection<P>>*/ map = getDependentsMap();
			Collection/*<P>*/ prerequisites = (Collection/*<P>*/) map.get(dependent);

			if (prerequisites == null) {
				result = new ArrayList/*<P>*/(0);
			} else {
				int size = prerequisites.size();
				result = new ArrayList/*<P>*/(size);
				result.addAll(prerequisites);
			}
		}

		return result;
	}

	/**
	 * Private prerequisitesMap getter.  The dependents -> prerequisite map.
	 *
	 * @return Map
	 */
	private Map/*<P, Collection<D>>*/ getPrerequisitesMap() {
		return prerequisitesMap;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#getValues()
	 */
	public List/*<Object>*/ getValues() {
		Set/*<Object>*/ set;
		Object lock = getLock();

		synchronized (lock) {
			Map/*<P, Collection<D>>*/ prerequisitesMap = getPrerequisitesMap();
			int prerequisitesMapSize = prerequisitesMap.size();

			Map/*<D, Collection<P>>*/ dependentsMap = getDependentsMap();
			int dependentsMapSize = dependentsMap.size();

			int size = prerequisitesMapSize + dependentsMapSize;
			set = new HashSet/*<Object>*/(size * 3);

			Collection/*<Object>*/ keys;

			keys = prerequisitesMap.keySet();
			addAll(keys, set);

			keys = dependentsMap.keySet();
			addAll(keys, set);
		}

		int size = set.size();
		List/*<Object>*/ list = new ArrayList/*<Object>*/(size);
		list.addAll(set);
		return list;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#hasCircularReferences(java.lang.Object)
	 */
	public boolean hasCircularReferences(Object entry) {
		Assertion.checkArgumentIsNotNull(entry, "entry");  //$NON-NLS-1$
		int size = getMaxMapSize();
		Collection/*<D>*/ references = new ArrayList/*<D>*/(size);
		collectDependents(entry, references);
		boolean result = references.contains(entry);
		return result;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#hasDependents()
	 */
	public boolean hasDependents() {
		Map/*<D, Collection<P>>*/ map = getDependentsMap();
		boolean result = map.isEmpty() == false;
		return result;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#hasPrerequisites()
	 */
	public boolean hasPrerequisites() {
		Map/*<P, Collection<D>>*/ map = getPrerequisitesMap();
		boolean result = map.isEmpty() == false;
		return result;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#isEmpty()
	 */
	public boolean isEmpty() {
		Map/*<P, Collection<D>>*/ prerequisitesMap = getPrerequisitesMap();
		Map/*<D, Collection<P>>*/ dependentsMap = getDependentsMap();
		boolean result = prerequisitesMap.isEmpty() == true && dependentsMap.isEmpty() == true;
		return result;
	}

	/**
	 * Utility that answers the prerequisites of a dependent entry.
	 *
	 * @param dependent  An object that is a dependent.
	 * @return A collection of prerequisite objects.
	 */
	private Collection/*<P>*/ prerequisitesOf(Object dependent) {
		List/*<P>*/ prerequisites;
		Map/*<D, Collection<P>>*/ map = getDependentsMap();
		Object lock = getLock();

		synchronized (lock) {
			prerequisites = (List/*<P>*/) map.get(dependent);

			if (prerequisites == null) {
				prerequisites = new ArrayList/*<P>*/(DependencyTracker.VALUE_CONTAINER_CAPACITY);
				map.put(dependent, prerequisites);
			}
		}

		return prerequisites;
	}

	/**
	 * Print the dependency tracker to System.out.
	 */
	public void print() {
		print(System.out);
	}

	/**
	 * Print the dependency tracker to the specified stream.
	 *
	 * @param stream  The stream to which to print the dependency tracker.
	 */
	public void print(java.io.PrintStream stream) {
//		Printer printer = new Printer(stream);
//		printer.print();
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#remove(java.lang.Object)
	 */
	public void remove(Object entry) {
		Object lock = getLock();

		synchronized (lock) {
			removePrerequisite(entry);
			removeDependent(entry);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#remove(java.lang.Object, java.lang.Object)
	 */
	public boolean remove(Object dependent, Object prerequisite) {
		Assertion.checkArgumentIsNotNull(dependent, "dependent");  //$NON-NLS-1$
		Assertion.checkArgumentIsNotNull(prerequisite, "prerequisite");  //$NON-NLS-1$

		Object object = null;
		boolean removed = false;
		Object lock = getLock();

		synchronized (lock) {
			Collection/*<P>*/ prerequisites = prerequisitesOf(dependent);
			removed = prerequisites.remove(prerequisite) == true;

			if (prerequisites.isEmpty() == true) {
				Map/*<D, Collection<P>>*/ map = getDependentsMap();
				object = map.remove(dependent);
				removed = object != null || removed == true;

			}

			Collection/*<D>*/ dependents = dependentsOf(prerequisite);
			removed = dependents.remove(dependent) || removed == true;

			if (dependents.isEmpty() == true) {
				Map/*<P, Collection<D>>*/ map = getPrerequisitesMap();
				object = map.remove(dependent);
				removed = object != null || removed == true;
			}
		}

		return removed;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#removeAll()
	 */
	public void removeAll() {
		Map/*<P, Collection<D>>*/ prerequisitesMap = getPrerequisitesMap();
		Map/*<D, Collection<P>>*/ dependentsMap = getDependentsMap();
		Object lock = getLock();

		synchronized (lock) {
			prerequisitesMap.clear();
			dependentsMap.clear();
		}
	}

	/**
	 * Utility that removes a dependent entry.
	 *
	 * @param entry  A dependent object.
	 */
	public void removeDependent(Object entry) {
		Assertion.checkArgumentIsNotNull(entry, "entry");  //$NON-NLS-1$
		Object lock = getLock();

		synchronized (lock) {
			Map/*<D, Collection<P>>*/ dependentsMap = getDependentsMap();
			Collection/*<P>*/ prerequisites = (Collection/*<P>*/) dependentsMap.get(entry);
			if (prerequisites == null)
				return;  // Early return.

			Iterator/*<P>*/ iterator = prerequisites.iterator();
			Map/*<P, Collection<D>>*/ prerequisitesMap = getPrerequisitesMap();

			while (iterator.hasNext() == true) {
				Object prerequisite = iterator.next();
				Collection/*<D>*/ dependents = (Collection/*<D>*/) prerequisitesMap.get(prerequisite);
				if (dependents == null)
					continue;  // Skip to next iteration.
				dependents.remove(entry);
				boolean empty = dependents.isEmpty();
				if (empty == false)
					continue;  // Skip to next iteration.
				prerequisitesMap.remove(prerequisite);
			}

			dependentsMap.remove(entry);
		}
	}

	/**
	 * Utility that removes a prerequisite entry.
	 *
	 * @param entry  A prerequisite object.
	 */
	public void removePrerequisite(Object entry) {
		Assertion.checkArgumentIsNotNull(entry, "entry");  //$NON-NLS-1$
		Object lock = getLock();

		synchronized (lock) {
			Map/*<P, Collection<D>>*/ prerequisitesMap = getPrerequisitesMap();
			Collection/*<D>*/ dependents = (Collection/*<D>*/) prerequisitesMap.get(entry);
			if (dependents == null)
				return;  // Early return.

			Iterator/*<D>*/ iterator = dependents.iterator();
			Map/*<D, Collection<P>>*/ dependentsMap = getDependentsMap();

			while (iterator.hasNext() == true) {
				Object dependent = iterator.next();
				Collection/*<P>*/ prerequisites = (Collection/*<P>*/) dependentsMap.get(dependent);
				if (prerequisites == null)
					continue;  // Skip to next iteration.
				prerequisites.remove(entry);
				boolean empty = prerequisites.isEmpty();
				if (empty == false)
					continue;  // Skip to next iteration.
				dependentsMap.remove(dependent);
			}

			prerequisitesMap.remove(entry);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#removeWithAllPrerequisites(java.lang.Object)
	 */
	public List/*<P>*/ removeWithAllPrerequisites(Object entry) {
		List/*<P>*/ prerequisites = removeWithPrerequisites(entry, true);
		return prerequisites;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#removeWithPrerequisites(java.lang.Object)
	 */
	public List/*<P>*/ removeWithPrerequisites(Object entry) {
		List/*<P>*/ prerequisites = removeWithPrerequisites(entry, false);
		return prerequisites;
	}

	/**
	 * Removes an entry, along with its prerequisites that are only dependents
	 * of the entry.  Answers the prerequisites that were removed.
	 *
	 * @param entry      A dependent object.
	 * @param removeAll  If all prerequisites should be removed return
	 *                   <code>true</code> and <code>false</code> if only
	 *                   immediate prerequisites should be removed.
	 *
	 * @return <code>List</code>
	 */
	private List/*<P>*/ removeWithPrerequisites(Object entry, boolean removeAll) {
		Assertion.checkArgumentIsNotNull(entry, "entry");  //$NON-NLS-1$
		int size = getMaxMapSize();
		List/*<P>*/ results = new ArrayList/*<P>*/(size);
		Object lock = getLock();

		synchronized (lock) {
			removePrerequisite(entry);
			removeWithPrerequisites(entry, results, removeAll);
		}

		return results;
	}

	/**
	 * Removes the prerequisites of a dependent entry.  The removed
	 * prerequisite entries are collected into the prerequisites List.  This
	 * method is indirectly recursive via the indirectly recursive message
	 * removeWithPrerequisites(Object, Object, List).
	 *
	 * @param dependent      A dependent object.
	 * @param prerequisites  The removed prerequisite objects.
	 * @param removeAll      If all prerequisites should be removed return
	 *                       <code>true</code>, otherwise <code>false</code>.
	 */
	private void removeWithPrerequisites(Object dependent, Collection/*<P>*/ prerequisites, boolean removeAll) {
		Map/*<D, Collection<P>>*/ map = getDependentsMap();
		ArrayList/*<P>*/ prerequisitesOfDependent = (ArrayList/*<P>*/) map.get(dependent); // $codepro.audit.disable pluralizeCollectionNames
		if (prerequisitesOfDependent == null)
			return;  // Early return.

		Collection/*<P>*/ clone = (Collection/*<P>*/) prerequisitesOfDependent.clone();
		Iterator/*<P>*/ iterator = clone.iterator();

		while (iterator.hasNext() == true) {
			Object prerequisite = iterator.next();
			removeWithPrerequisites(prerequisite, dependent, prerequisites, removeAll);
		}

		map.remove(dependent);
	}

	/**
	 * Removes the prerequisites of a dependent entry.
	 *
	 * @param prerequisite  A prerequisite object.
	 * @param dependent     A dependent object.
	 * @param prerequisites The removed prerequisite objects.
	 * @param removeAll     Whether to remove all prerequisites or not.
	 */
	private void removeWithPrerequisites(Object prerequisite, Object dependent, Collection/*<P>*/ prerequisites, boolean removeAll) {
		Map/*<P, Collection<D>>*/ prerequisitesMap = getPrerequisitesMap();
		Collection/*<D>*/ dependentsOfPrerequisite = (Collection/*<D>*/) prerequisitesMap.get(prerequisite); // $codepro.audit.disable pluralizeCollectionNames
		if (dependentsOfPrerequisite == null)
			return;  // Early return.

		dependentsOfPrerequisite.remove(dependent);
		if (dependentsOfPrerequisite.isEmpty() == false)
			return;  // Early return.

		prerequisitesMap.remove(prerequisite);
		if (prerequisites.contains(prerequisite) == true)
			return;  // Early return.

		prerequisites.add(prerequisite);

		if (removeAll == false)
			return;  // Early return.
		removeWithPrerequisites(prerequisite, prerequisites, removeAll);
	}

	/**
	 * Private dependentsMap setter.
	 *
	 * @param dependentsMap  The container of dependents.
	 */
	private void setDependentsMap(Map/*<D, Collection<P>>*/ dependentsMap) {
		this.dependentsMap = dependentsMap;
	}

	/**
	 * Private prerequisitesMap setter.
	 *
	 * @param prerequisitesMap  The container of prerequisites.
	 */
	private void setPrerequisitesMap(Map/*<P, Collection<D>>*/ prerequisitesMap) {
		this.prerequisitesMap = prerequisitesMap;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#size()
	 */
	public int size() {
		Collection/*<Object>*/ values = getValues();
		int size = values.size();
		return size;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#toXml(java.lang.String)
	 */
	public String toXml(String name) {
		String xml = toXml(name, 0);
		return xml;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#toXml(java.lang.String, org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker.IXmlProvider)
	 */
	public String toXml(String name, IDependencyTracker.IXmlProvider xmlProvider) {
		String xml = toXml(name, 0, xmlProvider);
		return xml;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#toXml(java.lang.String, int)
	 */
	public String toXml(String name, int indent) {
		DependencyTrackerXmlConverter xmlConverter = new DependencyTrackerXmlConverter(this, name);
		String xml = xmlConverter.toXml(indent);
		return xml;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker#toXml(java.lang.String, int, org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker.IXmlProvider)
	 */
	public String toXml(String name, int indent, IDependencyTracker.IXmlProvider xmlProvider) {
		DependencyTrackerXmlConverter xmlConverter = new DependencyTrackerXmlConverter(this, name, xmlProvider);
		String xml = xmlConverter.toXml(indent);
		return xml;
	}

//	/**
//	 * The <code>DependencyTracker.Printer</code> class is a utility that prints
//	 * the state of the <code>DependencyTracker</code> whenever it changes.
//	 *
//	 * You can exclude values by defining the following system property with a
//	 * comma separated list of prefixes:
//	 *   -Dorg.eclipse.soda.core.dependencyTracker.printer.exclude=org.eclipse
//	 */
//	private class Printer extends Object {
//		//
//		// Static Fields
//		//
//
//		private static final String EXCLUDE_PROPERTY_KEY = "org.eclipse.soda.core.dependencyTracker.printer.exclude";  //$NON-NLS-1$
//
//		//
//		// Instance Fields
//		//
//
//		private java.util.List exclusionList;
//		private java.io.PrintStream stream;
//
//		//
//		// Constructors
//		//
//
//		Printer(java.io.PrintStream stream) {
//			super();
//			setStream(stream);
//			buildExclusionList();
//		}
//
//		//
//		// Instance Methods
//		//
//
//		private void buildExclusionList() {
//			java.util.ArrayList list = new java.util.ArrayList(15);
//			String property = System.getProperty(Printer.EXCLUDE_PROPERTY_KEY);
//
//			if (property != null) {
//				org.eclipse.soda.sat.core.util.FactoryUtility utility = org.eclipse.soda.sat.core.util.FactoryUtility.getInstance();
//				org.eclipse.soda.sat.core.framework.interfaces.ITokenizer tokenizer = utility.createTokenizer(property);
//
//				while (tokenizer.hasMoreTokens() == true) {
//					String token = tokenizer.nextToken();
//					list.add(token);
//				}
//			}
//
//			list.trimToSize();
//			setExclusionList(list);
//		}
//
//		private int calculateMaximumEntryLength(List list) {
//			int maximumLength = 0;
//			Iterator iterator = list.iterator();
//
//			while (iterator.hasNext() == true) {
//				Object entry = iterator.next();
//				String value = toString(entry);
//				int length = value.length();
//				maximumLength = length > maximumLength ? length : maximumLength;
//			}
//
//			return maximumLength;
//		}
//
//		private List collectIncludedEntries(List entries) {
//			int entriesSize = entries.size();
//			ArrayList includedEntries = new ArrayList(entriesSize);
//			Iterator entriesIterator = entries.iterator();
//
//			while (entriesIterator.hasNext() == true) {
//				Object value = entriesIterator.next();
//				String entryName = toString(value);
//				boolean exclude = isExcluded(entryName);
//				if (exclude == true)
//					continue;  // Early return.
//				includedEntries.add(entryName);
//			}
//
//			includedEntries.trimToSize();
//			return includedEntries;
//		}
//
//		private java.util.List getExclusionList() {
//			return exclusionList;
//		}
//
//		private java.io.PrintStream getStream() {
//			return stream;
//		}
//
//		private boolean isExcluded(String value) {
//			java.util.List list = getExclusionList();
//			java.util.Iterator iterator = list.iterator();
//			boolean found = false;
//
//			while (found == false && iterator.hasNext() == true) {
//				String exclusion = (String) iterator.next();
//				found = value.startsWith(exclusion);
//			}
//
//			return found;
//		}
//
//		void print() {
//			FactoryUtility utility = FactoryUtility.getInstance();
//			ICharBuffer buffer = utility.createCharBuffer(1000);
//			writeOn(buffer);
//			writeLineSeparatorOn(buffer);
//			String text = buffer.toString();
//			byte[] bytes = text.getBytes();
//			write(bytes);
//		}
//
//		private void setExclusionList(java.util.List exclusionList) {
//			this.exclusionList = exclusionList;
//		}
//
//		private void setStream(java.io.PrintStream stream) {
//			this.stream = stream;
//		}
//
//		private String toString(Object value) {
//			String result;
//
//			if (value instanceof org.osgi.framework.Bundle) {
//				org.osgi.framework.Bundle bundle = (org.osgi.framework.Bundle) value;
//				result = bundle.getSymbolicName();
//				long id = bundle.getBundleId();
//				result += " [" + id + ']';  //$NON-NLS-1$ // $codepro.audit.disable disallowStringConcatenation
//			} else {
//				result = value.toString();
//			}
//
//			return result;
//		}
//
//		private void write(byte[] bytes) {
//			java.io.PrintStream stream = getStream();
//
//			try {
//				synchronized (stream) {
//					stream.write(bytes);
//				}
//			}
//			catch (java.io.IOException exception) {
//				exception.printStackTrace();
//			}
//
//			stream.flush();
//		}
//
//		private void writeLineSeparatorOn(ICharBuffer buffer) {
//			String lineSeparator = System.getProperty("line.separator");  //$NON-NLS-1$
//			buffer.append(lineSeparator);
//		}
//
//		private void writeOn(ICharBuffer buffer) {
//			final String none = "<None>";  //$NON-NLS-1$
//			final String dashedLine = "-------------------------------------------";  //$NON-NLS-1$
//
//			IDependencyTracker tracker = DependencyTracker.this;
//			int hashCode = tracker.hashCode();
//
//			writeLineSeparatorOn(buffer);
//			buffer.append(dashedLine);
//			buffer.append(" Dependency Tracker ");  //$NON-NLS-1$
//			buffer.append(dashedLine);
//			writeLineSeparatorOn(buffer);
//			buffer.append(tracker);
//			buffer.append('@');
//			buffer.append(hashCode);
//			writeLineSeparatorOn(buffer);
//			writeLineSeparatorOn(buffer);
//
//			List list;
//			int maximumLength;
//			Object entry;
//			List entries;
//			Iterator iterator;
//
//			buffer.append("Prerequisite -> Dependents");  //$NON-NLS-1$
//			writeLineSeparatorOn(buffer);
//
//			synchronized (tracker) {
//				if (tracker.hasPrerequisites() == true) {
//					list = tracker.getPrerequisites();
//					maximumLength = calculateMaximumEntryLength(list);
//					iterator = list.iterator();
//
//					while (iterator.hasNext() == true) {
//						entry = iterator.next();
//						entries = tracker.getDependents(entry);
//						writeOn(buffer, entry, entries, maximumLength);
//					}
//				} else {
//					writeTabOn(buffer);
//					buffer.append(none);
//					writeLineSeparatorOn(buffer);
//				}
//
//				writeLineSeparatorOn(buffer);
//				buffer.append("Dependent -> Prerequisites");  //$NON-NLS-1$
//				writeLineSeparatorOn(buffer);
//
//				if (tracker.hasDependents() == true) {
//					list = tracker.getDependents();
//					maximumLength = calculateMaximumEntryLength(list);
//					iterator = list.iterator();
//
//					while (iterator.hasNext() == true) {
//						entry = iterator.next();
//						entries = tracker.getPrerequisites(entry);
//						writeOn(buffer, entry, entries, maximumLength);
//					}
//				} else {
//					writeTabOn(buffer);
//					buffer.append(none);
//					writeLineSeparatorOn(buffer);
//				}
//			}
//
//			writeLineSeparatorOn(buffer);
//			buffer.append(dashedLine);
//			buffer.append(" oOo ");  //$NON-NLS-1$
//			buffer.append(dashedLine);
//
//			writeLineSeparatorOn(buffer);
//			writeLineSeparatorOn(buffer);
//		}
//
//		private void writeOn(ICharBuffer buffer, Object entry, List entries, int maximumLength) {
//			String name = toString(entry);
//			boolean exclude = isExcluded(name);
//			if (exclude == true)
//				return;  // Early return.
//
//			List includedEntries = collectIncludedEntries(entries);
//			int size = includedEntries.size();
//			if (size == 0)
//				return;  // Early return.
//
//			writeTabOn(buffer);
//			buffer.append(name);
//
//			int padding = 1 + maximumLength - name.length();
//
//			for (int i = 0; i < padding; i++) {
//				buffer.append('.');
//			}
//
//			buffer.append("{ ");  //$NON-NLS-1$
//
//			Iterator iterator = includedEntries.iterator();
//
//			while (iterator.hasNext() == true) {
//				Object value = iterator.next();
//				buffer.append(value);
//
//				if (iterator.hasNext() == true) {
//					buffer.append(", ");  //$NON-NLS-1$
//				}
//			}
//
//			buffer.append(" }");  //$NON-NLS-1$
//			writeLineSeparatorOn(buffer);
//		}
//
//		private void writeTabOn(ICharBuffer buffer) {
//			buffer.append('\t');
//		}
//	}
}