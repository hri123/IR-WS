/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework.interfaces;

import java.util.Dictionary;

import org.osgi.service.cm.ConfigurationException;

/**
 * The <code>IManagedServiceFactoryAdvisor</code> interface defines the API for
 * an object that knows how to create, destroy and update objects for a
 * <code>ManagedServiceFactory</code>.
 */
public interface IManagedServiceFactoryAdvisor {
	/**
	 * Create and return an object for the configuration with the specified
	 * persistent ID using the specified properties.  The specified manager may
	 * be used to perform OSGi responsibilities, such as registering the object
	 * as an exported service.
	 *
	 * @param pid         The persistent ID for the configuration.
	 * @param properties  The properties for the configuration.
	 * @param manager     The configurations's <code>IBundleActivationManager</code>.
	 * @return The object created for the configuration.  If, for some reason,
	 * an object could not be created, return <code>null</code>.
	 */
	public Object create(String pid, Dictionary properties, IBundleActivationManager manager);

	/**
	 * Create the imported service filters for the configuration with the
	 * specified persistent ID and properties.  The filter is an LDAP filter and
	 * must be added using the specified manager.
	 *
	 * @param pid            The persistent ID for the configuration.
	 * @param oldProperties  The old properties for the configuration.
	 * @param properties     The properties for the configuration.
	 * @param manager        The configurations's <code>IBundleActivationManager</code>.
	 */
	public void createImportedServiceFilters(String pid, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager);

	/**
	 * Destroy the specified object with the specified persistent ID.
	 *
	 * @param pid         The persistent ID for the configuration.
	 * @param object      The object to destroy.
	 * @param properties  The properties for the configuration.
	 * @param manager     The configurations's <code>IBundleActivationManager</code>.
	 */
	public void destroy(String pid, Object object, Dictionary properties, IBundleActivationManager manager);

	/**
	 * Get the imported service names for the configuration with the specified
	 * persistent ID.
	 *
	 * @param pid            The persistent ID for the configuration.
	 * @param oldProperties  The old configuration properties.
	 * @param properties     The new configuration properties
	 * @param manager        The configuration's
	 *                       <code>IBundleActivationManager</code>.
	 * @return               The imported service names for the configuration.
	 */
	public String[] getImportedServiceNames(String pid, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager);

	/**
	 * Get the optional imported service names for the configuration with the
	 * specified persistent ID.
	 *
	 * @param pid            The persistent ID for the configuration.
	 * @param oldProperties  The old configuration properties.
	 * @param properties     The new configuration properties
	 * @param manager        The configuration's
	 *                       <code>IBundleActivationManager</code>.
	 * @return               The imported service names for the configuration.
	 */
	public String[] getOptionalImportedServiceNames(String pid, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager);

	/**
	 * This method is called when an optional imported service has been
	 * acquired.
	 *
	 * @param pid                  The persistent id for the configuration.
	 * @param object               The configured object for the specified
	 *                             persistent ID.
	 * @param importedServiceName  The fully-qualified name of the optional
	 *                             imported service.
	 * @param importedService      The acquired optional imported service.
	 * @param manager              The configuration's
	 *                             <code>IBundleActivationManager</code>.
	 */
	public void handleAcquiredOptionalImportedService(String pid, Object object, String importedServiceName, Object importedService, IBundleActivationManager manager);

	/**
	 * When all imported services are not required, this method is called when
	 * an imported service has been released.
	 *
	 * @param pid                  The persistent id for the configuration.
	 * @param object               The object for the specified persistent ID.
	 * @param importedServiceName  The fully-qualified name of the optional
	 *                             imported service.
	 * @param importedService      The released optional imported service.
	 * @param manager              The configurations's
	 *                             <code>IBundleActivationManager</code>.
	 */
	public void handleReleasedOptionalImportedService(String pid, Object object, String importedServiceName, Object importedService, IBundleActivationManager manager);

	/**
	 * Update and return an object for the configuration with the specified
	 * persistent ID using the specified properties.  The specified manager may
	 * be used to perform OSGi responsibilities, such as registering the object
	 * as an exported service.
	 *
	 * @param pid             The persistent ID for the configuration.
	 * @param object          The object for the specified persistent ID.
	 * @param oldProperties   The old properties for the object.
	 * @param properties      The properties for the object.
	 * @param manager         The configurations's <code>IBundleActivationManager</code>.
	 *
	 * @return The created object must be returned.  If, for some reason, an
	 * object could not be updated, return <code>null</code>.
	 */
	public Object update(String pid, Object object, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager);

	/**
	 * Validate the configuration, throwing a ConfigurationException if the
	 * configuration is deemed to be invalid.
	 *
	 * @param pid         The persistent ID for the configuration.
	 * @param properties  The properties for the configuration.
	 * @throws ConfigurationException
	 */
	public void validateConfiguration(String pid, Dictionary properties) throws ConfigurationException;
}