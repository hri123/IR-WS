/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework.interfaces;

import java.util.List;

/**
 * The <code>IDependencyTracker</code> interface defines the API for a container
 * that holds pairs of objects that represent a relationship.  When adding
 * a pair of objects to the container there is always a <i>dependent</i>
 * object that <i>depends on</i> a prerequisite object, and there is always a
 * <i>prerequisite</i> object that is a <i>prerequisite of</i> the dependent
 * object.  An implementation of this interface is a generally useful object
 * container for tracking dependencies between objects.  For example, you could
 * track parent-child relationships using an implementation of this interface.
 */
public interface IDependencyTracker/*<D, P>*/ {
	/**
	 * The <code>IXmlProvider</code> interface defines the API for converting a
	 * <i>dependent</i> object and a <i>prerequisite</i> object into XML.  This
	 * interface is designed to be used by the various <code>toXml</code>
	 * methods defined by the <code>IDependencyTracker</code> interface.
	 */
	public interface IXmlProvider {
		/**
		 * Convert the specified dependent into XML.
		 *
		 * @param dependent  The dependent <code>Object</code> to convert to XML.
		 * @param indent     The indentation level.
		 * @return String
		 */
		public String convertDependentToXml(Object dependent, int indent);

		/**
		 * Convert the specified prerequisite into XML.
		 *
		 * @param prerequisite  The prerequisite <code>Object</code> to convert
		 *                      to XML.
		 * @param indent        The indentation level.
		 * @return String
		 */
		public String convertPrerequisiteToXml(Object prerequisite, int indent);
	}

	/**
	 * Create a dependent and prerequisite relationship.
	 *
	 * @param dependent     An <code>Object</code> that is a dependent of a
	 *                      prerequisite <code>Object</code>.
	 * @param prerequisite  An <code>Object</code> that is a prerequisite of a
	 *                      dependent <code>Object</code>.
	 *
	 * @return If the dependency relationship was added return
	 * <code>true</code>, otherwise <code>false</code>.
	 */
	public boolean add(Object dependent, Object prerequisite);

	/**
	 * Answers all the dependents of a prerequisite.
	 *
	 * @param prerequisite  An <code>Object</code> that is a prerequisite.
	 * @return <code>List</code>
	 */
	public List/*<D>*/ getAllDependents(Object prerequisite);

	/**
	 * Answers all the prerequisites of a dependent.
	 *
	 * @param dependent  An <code>Object</code> that is a dependent.
	 * @return <code>List</code>
	 */
	public List/*<P>*/ getAllPrerequisites(Object dependent);

	/**
	 * Answers all the entries that are dependents.
	 *
	 * @return <code>List</code>
	 */
	public List/*<D>*/ getDependents();

	/**
	 * Answers the immediate dependents of an entry.
	 *
	 * @param prerequisite  An <code>Object</code> that is a prerequisite.
	 *
	 * @return <code>List</code>
	 */
	public List/*<D>*/ getDependents(Object prerequisite);

	/**
	 * Answers all the entries that are prerequisites.
	 *
	 * @return <code>List</code>
	 */
	public List/*<P>*/ getPrerequisites();

	/**
	 * Answers the immediate prerequisites of an entry.
	 *
	 * @param dependent  An <code>Object</code> that is a dependent.
	 * @return <code>List</code>
	 */
	public List/*<P>*/ getPrerequisites(Object dependent);

	/**
	 * Answers a list of all the objects in the <code>IDependencyTracker</code>.
	 *
	 * @return List
	 */
	public List/*<Object>*/ getValues();

	/**
	 * Answers <code>true</code> if an entry has circular references otherwise
	 * <code>false</code>.
	 *
	 * @param entry Any object stored in the <code>IDependencyTracker</code>.
	 * @return <code>boolean</code>
	 */
	public boolean hasCircularReferences(Object entry);

	/**
	 * Answers <code>true</code> if dependent entries exist, otherwise
	 * <code>false</code>.
	 *
	 * @return <code>boolean</code>
	 */
	public boolean hasDependents();

	/**
	 * Answers <code>true</code> if prerequisite entries exist, otherwise
	 * <code>false</code>.
	 *
	 * @return <code>boolean</code>
	 */
	public boolean hasPrerequisites();

	/**
	 * Answers <code>true</code> if the DepenencyTrackerService is empty,
	 * otherwise <code>false</code>.
	 *
	 * @return <code>boolean</code>
	 */
	public boolean isEmpty();

	/**
	 * Removes an <code>Object</code>, severing its dependent and prerequisite
	 * relationships.
	 *
	 * @param entry  An <code>Object</code> in the <code>IDependencyTracker</code>.
	 */
	public void remove(Object entry);

	/**
	 * Destroy a dependent and prerequisite relationship.
	 *
	 * @param dependent     An <code>Object</code> that is dependent of a
	 *                      prerequisite object.
	 * @param prerequisite  An <code>Object</code> that is a prerequisite of a
	 *                      dependent object.
	 *
	 * @return If the dependent or prerequisite was removed return
	 *         <code>true</code>, otherwise <code>false</code>.
	 */
	public boolean remove(Object dependent, Object prerequisite);

	/**
	 * Removes all the objects from the <code>IDependencyTracker</code>.
	 */
	public void removeAll();

	/**
	 * Utility that removes a dependent entry.
	 *
	 * @param entry  A dependent <code>Object</code>.
	 */
	public void removeDependent(Object entry);

	/**
	 * Utility that removes a prerequisite entry.
	 *
	 * @param entry  A prerequisite <code>Object</code>.
	 */
	public void removePrerequisite(Object entry);

	/**
	 * Removes an entry, along with all its prerequisites that are only
	 * dependents of the entry.  Answers the prerequisites that were removed.
	 *
	 * @param entry  An dependent <code>Object</code>.
	 * @return <code>List</code>
	 */
	public List/*<P>*/ removeWithAllPrerequisites(Object entry);

	/**
	 * Removes an entry, along with its prerequisites that are only dependents
	 * of the entry.  Answers the prerequisites that were removed.
	 *
	 * @param entry  A dependent <code>Object</code>.
	 * @return The immediate prerequisites of the dependent entry that were
	 *         removed.
	 */
	public List/*<P>*/ removeWithPrerequisites(Object entry);

	/**
	 * Answers the number of entries in the <code>IDependencyTracker</code>.
	 *
	 * @return int
	 */
	public int size();

	/**
	 * Answers an XML representation of the <code>IDependencyTracker</code>.
	 * This method uses the default implementation of the interface
	 * <code>IDependencyTracker.IXmlProvider</code>, which simply returns the
	 * value of the dependent and prerequisite object without performing a
	 * conversion.  This is most appropriate for cases where the dependent
	 * <i>and</i> prerequisite objects are instances of the class
	 * <code>String</code>.
	 *
	 * @param name  The value of the name attribute in the top-most
	 *              <code>&lt;dependencyTracker&gt;</code> element.
	 *
	 * @return The XML representation of the <code>IDependencyTracker</code>.
	 */
	public String toXml(String name);

	/**
	 * Answers an XML representation of the <code>IDependencyTracker</code>
	 * using the specified implementation of the interface
	 * <code>IDependencyTracker.IXmlProvider</code>.  This is most
	 * appropriate for cases where the dependent <i>or</i> prerequisite objects
	 * are <i>not</i> instances of the class <code>String</code>.
	 *
	 * @param name         The value of the name attribute in the top-most
	 *                     <code>&lt;dependencyTracker&gt;</code> element.
	 *
	 * @param xmlProvider  An custom implementation of the interface
	 *                     <code>IDependencyTracker.IXmlProvider</code>
	 *                     responsible for converting the dependent and
	 *                     prerequisite objects into XML.
	 *
	 * @return The XML representation of the <code>IDependencyTracker</code>.
	 */
	public String toXml(String name, IDependencyTracker.IXmlProvider xmlProvider);

	/**
	 * Answers an XML representation of the <code>IDependencyTracker</code>.
	 * This method uses the default implementation of the interface
	 * <code>IDependencyTracker.IXmlProvider</code>, which simply returns the
	 * value of the dependent and prerequisite object without performing a
	 * conversion.  This is most appropriate for cases where the dependent
	 * <i>and</i> prerequisite objects are instances of the class
	 * <code>String</code>.
	 *
	 * @param name    The value of the name attribute in the top-most
	 *                <code>&lt;dependencyTracker&gt;</code> element.
	 *
	 * @param indent  The indent level at which to start.
	 *
	 * @return The XML representation of the <code>IDependencyTracker</code>.
	 */
	public String toXml(String name, int indent);

	/**
	 * Answers an XML representation of the <code>IDependencyTracker</code>
	 * using the specified implementation of the interface
	 * <code>IDependencyTracker.IXmlProvider</code>.  This is most
	 * appropriate for cases where the dependent <i>or</i> prerequisite objects
	 * are <i>not</i> instances of the class <code>String</code>.
	 *
	 * @param name         The value of the name attribute in the top-most
	 *                     <code>&lt;dependencyTracker&gt;</code> element.
	 *
	 * @param indent       The indent level at which to start.
	 *
	 * @param xmlProvider  An custom implementation of the interface
	 *                     <code>IDependencyTracker.IXmlProvider</code>
	 *                     responsible for converting the dependent and
	 *                     prerequisite objects into XML.
	 *
	 * @return The XML representation of the <code>IDependencyTracker</code>.
	 */
	public String toXml(String name, int indent, IDependencyTracker.IXmlProvider xmlProvider);
}