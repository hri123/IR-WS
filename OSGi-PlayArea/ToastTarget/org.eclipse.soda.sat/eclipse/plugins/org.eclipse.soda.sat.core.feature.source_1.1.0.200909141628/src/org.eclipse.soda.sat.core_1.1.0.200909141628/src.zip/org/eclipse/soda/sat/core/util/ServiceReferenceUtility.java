/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.osgi.framework.Constants;
import org.osgi.framework.ServiceReference;

/**
 * The <code>ServiceReferenceUtility</code> class is a utility that simplifies
 * working with <code>ServiceReference</code> objects.
 * <p>
 * <i>Note:</i> This is a singleton class, accessible only via the static method
 * <code>getInstance()</code>.  For example:
 * <pre>
 * ServiceReferenceUtility utility = ServiceReferenceUtility.getInstance();
 * String[] names = utility.getServiceNames(reference);
 * </pre>
 *
 * @see org.osgi.framework.ServiceReference
 */
public final class ServiceReferenceUtility extends Object {
	//
	// Static Fields
	//

	// Singleton
	private static final ServiceReferenceUtility INSTANCE = new ServiceReferenceUtility();

	//
	// Static Methods
	//

	/**
	 * Public getter for the <code>ServiceReferenceUtility</code> singleton
	 * instance.
	 *
	 * @return The <code>ServiceReferenceUtility</code> singleton instance.
	 */
	public static ServiceReferenceUtility getInstance() {
		return ServiceReferenceUtility.INSTANCE;
	}

	/**
	 * Constructor.  Instances of this class cannot be created.
	 */
	private ServiceReferenceUtility() {
		super();
	}

	//
	// Instance Methods
	//

	private int compareByServiceRanking(ServiceReference left, ServiceReference right) {
		// Sort by HIGHEST service ranking...
		int leftRanking = getServiceRanking(left);
		int rightRanking = getServiceRanking(right);
		int result = rightRanking - leftRanking;

		if (result == 0) {
			// When service rankings are equal, sort by LOWEST service id.
			long leftServiceId = getServiceId(left);
			long rightServiceId = getServiceId(right);
			result = (int) (leftServiceId - rightServiceId); // $codepro.audit.disable lossOfPrecisionInCast
		}

		return result;
	}

	/**
	 * Create a <code>Comparator</code> for sorting an array or collection of
	 * <code>ServiceReference</code> objects by service rank (highest to lowest)
	 * and then by service id (lowest to highest).
	 *
	 * @return Comparator
	 */
	public Comparator createServiceRankingComparator() {
		return new Comparator() {
			public int compare(Object left, Object right) {
				ServiceReference leftReference = (ServiceReference) left;
				ServiceReference rightReference = (ServiceReference) right;
				int result = ServiceReferenceUtility.this.compareByServiceRanking(leftReference, rightReference);
				return result;
			}
		};
	}

	/**
	 * Gets the <code>Constants.SERVICE_ID</code> property from the specified
	 * <code>ServiceReference</code> objects.
	 *
	 * @param reference  A <code>ServiceReference</code>.
	 * @return The <code>Constants.SERVICE_ID</code> property value.
	 */
	public long getServiceId(ServiceReference reference) {
		Assertion.checkArgumentIsNotNull(reference, "reference");  //$NON-NLS-1$
		Number wrapper = (Number) reference.getProperty(Constants.SERVICE_ID);
		long id = wrapper.intValue();
		return id;
	}

	/**
	 * Gets the <code>Constants.SERVICE_ID</code> properties from an array of
	 * <code>ServiceReference</code> objects.
	 *
	 * @param references  An array of <code>ServiceReference</code> objects.
	 * @return An array of <code>Constants.SERVICE_ID</code> property values.
	 */
	public long[] getServiceIds(ServiceReference[] references) {
		Assertion.checkArgumentIsNotNull(references, "references");  //$NON-NLS-1$
		int length = references.length;
		long[] ids = new long [ length ];

		for (int i = 0; i < length; i++) {
			ServiceReference reference = references [ i ];
			long id = getServiceId(reference);
			ids [ i ] = id;
		}

		return ids;
	}

	/**
	 * Answers an array of service names available from the specified
	 * <code>ServiceReference</code>.
	 *
	 * @param reference  The <code>ServiceReference</code> to be queried.
	 * @return A list of fully qualifed type names.
	 */
	public List/*<String>*/ getServiceNames(ServiceReference reference) {
		Assertion.checkArgumentIsNotNull(reference, "reference");  //$NON-NLS-1$
		String[] names = (String[]) reference.getProperty(Constants.OBJECTCLASS);
		if (names == null)
			return new ArrayList/*<String>*/(0);  // Early return.
		List/*<String>*/ list = new ArrayList/*<String>*/(names.length);
		for (int i = 0; i < names.length; i++) {
			String name = names [ i ];
			list.add(name);
		}
		return list;
	}

	/**
	 * Gets the service names from an array of <code>ServiceReference</code>
	 * objects.
	 *
	 * @param references  An array of <code>ServiceReference</code> objects.
	 * @return An list of service names.
	 */
	public List/*<String>*/ getServiceNames(ServiceReference[] references) {
		Assertion.checkArgumentIsNotNull(references, "references");  //$NON-NLS-1$
		CollectionUtility utility = CollectionUtility.getInstance();
		int size = utility.estimateHashedCollectionSize(references.length * 4);
		Set/*<String>*/ set = new HashSet/*<String>*/(size);

		for (int i = 0; i < references.length; i++) {
			ServiceReference reference = references [ i ];
			List/*<String>*/ names = getServiceNames(reference);
			set.addAll(names);
		}

		int count = set.size();
		List/*<String>*/ list = new ArrayList/*<String>*/(count);
		list.addAll(set);
		return list;
	}

	private int getServiceRanking(ServiceReference reference) {
		Object value = reference.getProperty(Constants.SERVICE_RANKING);
		int ranking;

		if (value instanceof Integer) { // $codepro.audit.disable disallowInstanceof
			Number wrapper = (Number) value;
			ranking = wrapper.intValue();
		} else {
			ranking = 0;
		}
		return ranking;
	}

	/**
	 * Answers true if the <code>ServiceReference</code> is an instance of the
	 * service name.
	 *
	 * @param reference  The <code>ServiceReference</code> to be queried.
	 * @param name       A fully qualified type name of a service.
	 * @return If the <code>ServiceReference</code> represents the service
	 * name return <code>true</code>, otherwise <code>false</code>.
	 */
	public boolean isServiceInstanceOf(ServiceReference reference, String name) {
		Assertion.checkArgumentIsNotNull(reference, "reference");  //$NON-NLS-1$
		Assertion.checkArgumentIsNotNull(name, "name");  //$NON-NLS-1$
		boolean match = false;
		List/*<String>*/ serviceNames = getServiceNames(reference);
		Iterator/*<String>*/ iterator = serviceNames.iterator();

		while (match == false && iterator.hasNext() == true) {
			String serviceName = (String) iterator.next();
			match = name.equals(serviceName);
		}

		return match;
	}

	/**
	 * Select an appropriate <code>ServiceReference</code> from an array.  The
	 * criteria for selection is as follows:
	 * <ul>
	 *   <li>
	 *       The <code>ServiceReference</code> with the highest ranking as
	 *       specified in its <code>Constants.SERVICE_RANKING</code> property is
	 *       selected.
	 *   </li>
	 *   <li>
	 *       If there is a tie in ranking, the <code>ServiceReference</code>
	 *       with the lowest service ID, as specified in its
	 *       <code>Constants.SERVICE_ID</code> property, is selected.
	 *   </li>
	 * </ul>
	 *
	 * @param references  An array of <code>ServiceReference</code> objects from
	 *                    which to select.
	 * @return The matching <code>ServiceReference</code> or <code>null</code>.
	 */
	public ServiceReference select(ServiceReference[] references) {
		Assertion.checkArgumentIsNotNull(references, "references");  //$NON-NLS-1$
		int length = references.length;
		if (length == 0)
			return null;  // Early return.
		sortByServiceRanking(references);
		ServiceReference result = references [ 0 ];
		return result;
	}

	private void sortByServiceRanking(ServiceReference[] references) {
		Assertion.checkArgumentIsNotNull(references, "references");  //$NON-NLS-1$
		Comparator comparator = createServiceRankingComparator();
		Arrays.sort(references, comparator);
	}
}