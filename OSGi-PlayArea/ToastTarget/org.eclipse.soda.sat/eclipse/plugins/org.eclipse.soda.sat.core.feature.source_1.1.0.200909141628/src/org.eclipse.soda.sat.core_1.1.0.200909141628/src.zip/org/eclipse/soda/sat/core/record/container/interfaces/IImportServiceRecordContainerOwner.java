/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.record.container.interfaces;

/**
 * When an <code>IImportServiceRecordContainer</code> is created it must be
 * given an owner that will handle call-back notifications.  The
 * <code>IImportServiceRecordContainerOwner</code> interface declares the role
 * of a container's owner, which has the following responsibilities:
 *
 * <h4>Strict Container Responsibilities</h4>
 * These responsibilities only apply to a <i>strict container</i>.  A strict
 * container only cares when all its import service records are acquired, and
 * then when one of its import service records is released.
 * <ul>
 *   <li>
 *     Handle the course of action to be taken when the container is considered
 *     <i>acquired</i>, meaning that the container was previously released,
 *     and <b>all</b> of its import service records have been <i>acquired</i>.
 *   </li>
 *   <li>
 *     Handle the course of action to be taken when the container is considered
 *     <i>released</i>, meaning that the container was previously acquired, and
 *     <b>one</b> of its import service records has been <i>released</i>.
 *   </li>
 * </ul>
 * <p>
 * <i>Note:</i> Since this abstraction is used internally by the SAT bundle
 * this interface is typically not used directly by bundle developers.
 */
public interface IImportServiceRecordContainerOwner {
	/**
	 * The owned <code>IImportServiceRecordContainer</code> has been acquired.
	 * If the container is <i>strict</i> this call-back is only sent when <i>all
	 * imported services have been acquired</i>.  In this case, the call-back is
	 * executed on the OSGi notification thread.  This call-back will be sent
	 * every time the container had at least one released service that is
	 * subsequently acquired.
	 * <p>
	 * If the container is <i>lenient</i> this call-back is sent only once as
	 * a result of calling the <code>IImportServiceRecordContainer</code>
	 * method <code>acquire(IImportServiceRecordContainerOwner)</code>.  In this
	 * case, the call-back is executed on the thread that called
	 * <code>acquire()</code>.
	 *
	 * @param container  The owned IImportServiceRecordContainer.
	 *
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainer#acquire()
	 */
	public void acquired(IImportServiceRecordContainer container);

	/**
	 * The owned <code>IImportServiceRecordContainer</code> has been released.
	 * If the container is <i>strict</i> this call-back is only sent when <i>one
	 * of the imported services have been released</i>.  In this case, the
	 * call-back is executed on the OSGi notification thread.  This call-back
	 * will be sent every time the container has acquired all imported services
	 * and an imported service is subsequently released.
	 * <p>
	 * Regardless of whether the container is <i>strict</i> or not, this
	 * call-back is sent as a result of calling the
	 * <code>IImportServiceRecordContainer</code> method <code>release()</code>.
	 * In this case, the call-back is executed on the thread that called
	 * <code>release()</code>.
	 *
	 * @param container  The owned container.
	 *
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainer#release()
	 */
	public void released(IImportServiceRecordContainer container);
}