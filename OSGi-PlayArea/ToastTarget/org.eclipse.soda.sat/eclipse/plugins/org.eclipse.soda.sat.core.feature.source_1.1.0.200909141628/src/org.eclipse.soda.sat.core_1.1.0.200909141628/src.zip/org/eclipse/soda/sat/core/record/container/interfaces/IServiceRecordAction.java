/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.record.container.interfaces;

import org.eclipse.soda.sat.core.record.interfaces.IServiceRecord;

/**
 * The <code>IServiceRecordAction</code> interface declares an API for executing
 * an action against <code>IServiceRecord</code> objects within an
 * <code>IServiceRecordContainer</code>.  A single responsibilities is
 * declared:
 * <ul>
 *   <li>
 *     Executing itself against a given service record.
 *   </li>
 * </ul>
 * <p>
 * An implementation of <code>IServiceRecordAction</code> is typically
 * state-less since it is usually executed against multiple service records.
 * This interface is used by the <code>IServiceRecordContainer</code> method
 * <code>doForEach(IServiceRecordAction, Object)</code> and is typically
 * anonymously implemented.  For example, an action that collects the
 * names of the services within a container could be written and executed as
 * follows:
 * <pre>
 * IServiceRecordAction action = new IServiceRecordAction() {
 *     public boolean execute(IServiceRecord record, Object parameter) {
 *         String name = record.getName();
 *         Collection names = (Collection) parameter;
 *         names.add(name);
 *         return true;
 *     }
 * };
 *
 * Collection names = new ArrayList();
 * container.doForEach(action, names);
 * </pre>
 * <i>Note:</i> Since this abstraction is used internally by the SAT bundle
 * this interface is typically not used directly by bundle developers.
 *
 * @see org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordContainer#doForEach(org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordAction, java.lang.Object)
 */
public interface IServiceRecordAction {
	/**
	 * Execute against the specified <code>IServiceRecord</code>, with an
	 * optional parameter.
	 *
	 * @param record     The <code>IServiceRecord</code> on which to operate.
	 * @param parameter  An optional execution parameter.
	 *
	 * @return True to tell the <code>IServiceRecordContainer</code> to keep
	 * iterating, false to stop.
	 *
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordContainer#doForEach(org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordAction, java.lang.Object)
	 */
	public boolean execute(IServiceRecord record, Object parameter);
}