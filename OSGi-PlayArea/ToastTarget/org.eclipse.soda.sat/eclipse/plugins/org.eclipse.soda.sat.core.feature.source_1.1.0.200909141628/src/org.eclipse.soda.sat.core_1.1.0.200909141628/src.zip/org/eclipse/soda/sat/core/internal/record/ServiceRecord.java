/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.record;

import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.record.interfaces.IServiceRecord;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceEvent;
import org.osgi.framework.ServiceListener;
import org.osgi.framework.ServiceReference;

/**
 * The abstract <code>ServiceRecord</code> class is the superclass to all
 * service records, such as import service records and export service records.
 * The class is an implementation of the <code>IServiceRecord</code> interface.
 */
abstract class ServiceRecord extends Object implements IServiceRecord {
	//
	// Static Fields
	//

	// Externalized Strings Keys
	private static final String UNKNOWN_PROPERTY_KEY = "ServiceRecord.UnknownProperty";  //$NON-NLS-1$
	private static final String UNKNOWN_SERVICE_EVENT_KEY = "ServiceRecord.UnknownServiceEvent";  //$NON-NLS-1$

	// Misc
	protected static final String[] NO_PROPERTY_KEYS = new String [ 0 ];

	//
	// Instance Fields
	//

	private BundleContext bundleContext;
	private volatile Object service;
	private ServiceListener serviceListener;
	private Object lock;

	//
	// Constructors
	//

	/**
	 * Constructor.
	 *
	 * @param bundleContext  The <code>BundleContext</code> handle back to the
	 * framework.
	 */
	protected ServiceRecord(BundleContext bundleContext) {
		super();
		setBundleContext(bundleContext);
		setService(null);
	}

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceRecord#basicToString()
	 */
	public final String basicToString() {
		String value = super.toString();
		return value;
	}

	/**
	 * Create the LDAP service filter.
	 *
	 * @return The LDAP service filter.
	 */
	protected abstract String createServiceFilter();

	/**
	 * Create a filter <code>String</code> for the specified service on the
	 * specified buffer in the format:
	 * <pre>
	 *   (objectClass=<service-name>)
	 * </pre>
	 * for example:
	 * <pre>
	 *   (objectClass=org.osgi.service.http.HttpService)
	 * </pre>
	 *
	 * @param buffer  The buffer on which to create the filter.
	 * @param name    The name of the service.
	 */
	protected final void createServiceFilterOn(StringBuffer buffer, String name) {
		buffer.append('(');
		buffer.append(Constants.OBJECTCLASS);
		buffer.append('=');
		buffer.append(name);
		buffer.append(')');
	}

	/**
	 * Create the receiver's <code>ServiceListener</code>.
	 *
	 * @return ServiceListener
	 */
	private ServiceListener createServiceListener() {
		return new ServiceListener() {
			public void serviceChanged(ServiceEvent event) {
				ServiceRecord.this.serviceChanged(event);
			}
		};
	}

	/**
	 * Estimate the size of the <code>StringBuffer</code> used by
	 * <code>toString()</code>.
	 *
	 * @return The size of the StringBuffer.
	 */
	protected int estimateToStringBufferSize() {
		return 100;
	}

	/**
	 * Answers the service record's <code>Bundle</code>.
	 *
	 * @return The <code>Bundle</code> to which the receiver's service belongs.
	 */
	protected final Bundle getBundle() {
		BundleContext bundleContext = getBundleContext();
		Bundle bundle = null;

		try {
			bundle = bundleContext.getBundle();
		} catch (IllegalStateException exception) {
			// The BundleContext is disposed.
		}

		return bundle;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceRecord#getBundleContext()
	 */
	public final BundleContext getBundleContext() {
		return bundleContext;
	}

	/**
	 * Answers the service id.
	 *
	 * @return The service id.
	 */
	private long getId() {
		Long wrapper = (Long) getProperty(Constants.SERVICE_ID);
		long id = wrapper.longValue();
		return id;
	}

	/**
	 * Protected <code>lock</code> getter.
	 *
	 * @return The lock.
	 */
	protected Object getLock() {
		synchronized (this) {
			if (lock == null) {
				lock = new Object();
			}

			return lock;
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceRecord#getProperty(String)
	 */
	public Object getProperty(String key) {
		Assertion.checkArgumentIsNotNull(key, "key");  //$NON-NLS-1$
		ServiceReference serviceReference = getServiceReference();
		if (serviceReference == null)
			return null;  // Early return.

		Object property = serviceReference.getProperty(key);

		if (property == null) {
			signalUnknownProperty(key);
		}

		return property;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceRecord#getPropertyKeys()
	 */
	public String[] getPropertyKeys() {
		ServiceReference serviceReference = getServiceReference();
		if (serviceReference == null)
			return ServiceRecord.NO_PROPERTY_KEYS;  // Early return.

		String[] keys = serviceReference.getPropertyKeys();
		return keys;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceRecord#getService()
	 */
	public Object getService() {
		return service;
	}

	/**
	 * Private serviceListener getter.
	 *
	 * @return The ServiceListener.
	 */
	private ServiceListener getServiceListener() {
		return serviceListener;
	}

	/**
	 * Answers the <code>ServiceReference</code> for the service.
	 *
	 * @return The <code>ServiceReference</code> for the receiver's service.
	 */
	protected abstract ServiceReference getServiceReference();

	/**
	 * An <code>InvalidSyntaxException</code> has been thrown.
	 *
	 * @param exception  org.osgi.framework.InvalidSyntaxException
	 */
	protected void handleInvalidSyntaxException(InvalidSyntaxException exception) {
		exception.printStackTrace();
		String message = exception.getMessage();
		LogUtility.logError(message);
	}

	/**
	 * Handle the case where the OSGi service represented by the
	 * <code>ServiceReference</code> has been modified.  This is sent by the
	 * <code>ServiceRecord</code> method <code>serviceChanged(ServiceEvent)</code>
	 * as a result of being notified by the OSGi framework.
	 *
	 * @param serviceReference  The <code>ServiceReference</code> for the
	 * modified service.
	 */
	protected void handleModifiedService(ServiceReference serviceReference) {
		// No-op
	}

	/**
	 * Handle the case where the OSGi service represented by the
	 * <code>ServiceReference</code> has been registered.  This is sent by the
	 * <code>ServiceRecord</code> method <code>serviceChanged(ServiceEvent)</code>
	 * as a result of being notified by the OSGi framework.
	 *
	 * @param serviceReference  The <code>ServiceReference</code> for the
	 * registered service.
	 */
	protected void handleRegisteredService(ServiceReference serviceReference) {
		// No-op
	}

	/**
	 * Handles the case where an unknown <code>ServiceEvent</code> is received.
	 *
	 * @param event  The unknown <code>ServiceEvent</code>.
	 */
	private void handleUnknownServiceEvent(ServiceEvent event) {
		String pattern = Messages.getString(ServiceRecord.UNKNOWN_SERVICE_EVENT_KEY);
		String message = MessageFormatter.format(pattern, event);
		LogUtility.logDebug(message);
	}

	/**
	 * Handle the case where the OSGi service represented by the
	 * <code>ServiceReference</code> is being unregistering.  This is sent by
	 * the <code>ServiceRecord</code> method <code>serviceChanged(ServiceEvent)</code>
	 * as a result of being notified by the OSGi framework.
	 *
	 * @param serviceReference  The <code>ServiceReference</code>to the
	 *                          unregistering service.
	 */
	protected void handleUnregisteringService(ServiceReference serviceReference) {
		// No-op
	}

	/**
	 * Query whether the receiver has a <code>ServiceReference</code> or not.
	 *
	 * @return boolean.
	 */
	private boolean hasServiceReference() {
		ServiceReference reference = getServiceReference();
		boolean result = reference != null;
		return result;
	}

	/**
	 * Query whether we are registered for <code>ServiceEvent</code> objects.
	 *
	 * @return boolean.
	 */
	protected final boolean isRegisteredForServiceEvents() {
		Object listener = getServiceListener();
		boolean registered = listener != null;
		return registered;
	}

	/**
	 * Prints the service id on the buffer.
	 *
	 * @param buffer  A buffer on which to print the service id.
	 */
	private void printIdOn(StringBuffer buffer) {
		buffer.append(", id=");  //$NON-NLS-1$

		if (hasServiceReference() == true) {
			long id = getId();
			buffer.append(id);
		} else {
			buffer.append("<none>");  //$NON-NLS-1$
		}
	}

	/**
	 * Prints a description of the service record on the buffer.
	 *
	 * @param buffer  A buffer on which to print a description of the receiver.
	 */
	protected void printOn(StringBuffer buffer) {
		printIdOn(buffer);
		printServiceOn(buffer);
	}

	/**
	 * Prints an <code>Object</code> on a buffer.  This method simply provides a
	 * way to print an <code>Object.toString()</code> description of an
	 * <code>Object</code> on a <code>StringBuffer</code> regardless of whether
	 * its <code>toString()</code> method has been overridden.
	 *
	 * @param buffer  A buffer on which to print the <code>Object</code>.
	 * @param object  The object to print on the buffer.
	 */
	protected final void printOn(StringBuffer buffer, Object object) {
		if (object == null) {
			buffer.append(object);
		} else {
			Class clazz = object.getClass();
			String name = clazz.getName();
			int hashCode = object.hashCode();
			String hexHashCode = Integer.toHexString(hashCode);

			buffer.append(name);
			buffer.append('@');
			buffer.append(hexHashCode);
		}
	}

	/**
	 * Prints the <code>service</code> on the buffer.
	 *
	 * @param buffer  A buffer on which to print a service.
	 */
	protected final void printServiceOn(StringBuffer buffer) {
		buffer.append(", service=");  //$NON-NLS-1$
		Object service = getService();
		printOn(buffer, service);
	}

	/**
	 * Register as a <code>ServiceListener</code>.
	 */
	protected final void registerAsServiceListener() {
		boolean registered = isRegisteredForServiceEvents();
		if (registered == true)
			return;  // Early return.

		ServiceListener listener = createServiceListener();
		setServiceListener(listener);

		BundleContext bundleContext = getBundleContext();
		String filter = createServiceFilter();

		try {
			bundleContext.addServiceListener(listener, filter);
		} catch (InvalidSyntaxException exception) {
			handleInvalidSyntaxException(exception);
		}
	}

	/**
	 * Receives notification that a bundle has had a change occur in its
	 * life-cycle.  This method cracks the ServiceEvent open and dispatches its
	 * <code>ServiceReference</code> to the appropriate method based on the type
	 * of the <code>ServiceEvent</code>.  The methods for handling the
	 * difference type of <code>ServiceEvent</code> objects are typically
	 * overridden by subclasses.
	 *
	 * @param event  An event for a service that changed.
	 */
	private void serviceChanged(ServiceEvent event) {
		ServiceReference serviceReference = getServiceReference();
		ServiceReference changedServiceReference = event.getServiceReference();

		if (serviceReference != null) {
			boolean match = changedServiceReference.equals(serviceReference);
			if (match == false)
				return;  // Early return.
		}

		int type = event.getType();

		switch (type) {
			case ServiceEvent.MODIFIED:
				handleModifiedService(changedServiceReference);
				break;

			case ServiceEvent.REGISTERED:
				handleRegisteredService(changedServiceReference);
				break;

			case ServiceEvent.UNREGISTERING:
				handleUnregisteringService(changedServiceReference);
				break;

			default:
				handleUnknownServiceEvent(event);
				break;
		}
	}

	/**
	 * Private <code>bundleContext</code> setter.
	 *
	 * @param bundleContext  The <code>BundleContext</code> handle back to the
	 *                       framework.
	 */
	private final void setBundleContext(BundleContext bundleContext) {
		Assertion.checkArgumentIsNotNull(bundleContext, "bundleContext");  //$NON-NLS-1$
		this.bundleContext = bundleContext;
	}

	/**
	 * Set the service.
	 * @param service  The service.
	 */
	protected final void setService(Object service) {
		this.service = service;
	}

	/**
	 * Private serviceListener setter.
	 *
	 * @param serviceListener  The receiver's <code>ServiceListener</code>.
	 */
	private void setServiceListener(ServiceListener serviceListener) {
		this.serviceListener = serviceListener;
	}

	/**
	 * Signal that the property is unknown.
	 *
	 * @param key  A service property key.
	 */
	protected final void signalUnknownProperty(String key) {
		String pattern = Messages.getString(ServiceRecord.UNKNOWN_PROPERTY_KEY);
		String message = MessageFormatter.format(pattern, key);
		throw new IllegalArgumentException(message);
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public final String toString() {
		int size = estimateToStringBufferSize();
		StringBuffer buffer = new StringBuffer(size);
		Object value = basicToString();
		buffer.append(value);
		printOn(buffer);
		String description = buffer.toString();
		return description;
	}

	/**
	 * Unregister as a <code>ServiceListener</code>.
	 */
	protected final void unregisterAsServiceListener() {
		boolean registered = isRegisteredForServiceEvents();
		if (registered == false)
			return;  // Early return.

		BundleContext bundleContext = getBundleContext();
		ServiceListener listener = getServiceListener();

		try {
			bundleContext.removeServiceListener(listener);
		} catch (IllegalStateException exception) {
			// The BundleContext is disposed.
		} finally {
			setServiceListener(null);
		}
	}
}