/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.eclipse.soda.sat.core.internal.framework.bundle.LazyBundeActivatorProperties;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainer;
import org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainerOwner;
import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Filter;
import org.osgi.framework.InvalidSyntaxException;

/**
 * LazyBundleActivator
 */
public final class LazyBundleActivator extends Object implements BundleActivator {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String STARTED_BUNDLE_KEY = "LazyBundleActivator.StartedBundle";  //$NON-NLS-1$
	private static final String STOPPED_BUNDLE_KEY = "LazyBundleActivator.StoppedBundle";  //$NON-NLS-1$

	//
	// Instance Fields
	//

	private BundleContext bundleContext;
	private BundleActivator bundleActivator;
	private IImportServiceRecordContainer container;
	private LazyBundeActivatorProperties lazyBundleActivatorProperties;

	//
	// Instance Methods
	//

	private void acquireImportedServices() throws InvalidSyntaxException, IOException {
		IImportServiceRecordContainer container = createImportServiceRecordContainer();
		setContainer(container);
		populateContainer();
		IImportServiceRecordContainerOwner owner = createContainerOwner();
		container.setOwner(owner);
		container.acquire();
	}

	private BundleActivator createBundleActivator() throws ClassNotFoundException, IllegalAccessException, InstantiationException, IOException {
		BundleActivator activator = null;
		Class clazz = getBundleActivatorClass();
		if (clazz != null) {
			activator = (BundleActivator) clazz.newInstance();
		}
		return activator;
	}

	private IImportServiceRecordContainerOwner createContainerOwner() {
		return new IImportServiceRecordContainerOwner() {
			public void acquired(IImportServiceRecordContainer container) {
				LazyBundleActivator.this.handleContainerAcquired();
			}

			public void released(IImportServiceRecordContainer container) {
				LazyBundleActivator.this.handleContainerReleased();
			}
		};
	}

	private Filter createFilter(String filterString) {
		BundleContext context = getBundleContext();
		Filter filter = null;

		try {
			filter = context.createFilter(filterString);
		} catch (InvalidSyntaxException exception) {
			String message = exception.getMessage();
			LogUtility.logError(this, message, exception);
		}

		return filter;
	}

	private Filter createFilterForService(String serviceName) {
		LazyBundeActivatorProperties properties = getLazyBundeActivatorProperties();
		String filterString = properties.getImportedServiceFilter(serviceName);
		if (filterString == null)
			return null;  // Early return.
		Filter filter = createFilter(filterString);
		return filter;
	}

	private IImportServiceRecord createImportServiceRecord(String name, Filter filter) {
		FactoryUtility utility = getFactoryUtility();
		BundleContext context = getBundleContext();
		IImportServiceRecord record = utility.createImportServiceRecord(context, name, filter);
		return record;
	}

	private IImportServiceRecordContainer createImportServiceRecordContainer() {
		FactoryUtility utility = getFactoryUtility();
		IImportServiceRecordContainer container = utility.createImportServiceRecordContainer();
		return container;
	}

	private Bundle getBundle() {
		BundleContext bundleContext = getBundleContext();
		Bundle bundle = null;
		try {
			bundle = bundleContext.getBundle();
		} catch (IllegalStateException exception) {
			// The BundleContext is disposed.
		}
		return bundle;
	}

	private BundleActivator getBundleActivator() {
		return bundleActivator;
	}

	private Class getBundleActivatorClass() throws ClassNotFoundException, IOException {
		Class clazz = null;
		Bundle bundle = getBundle();
		if (bundle != null) {
			String className = getBundleActivatorClassName();
			clazz = bundle.loadClass(className);
		}
		return clazz;
	}

	private String getBundleActivatorClassName() throws IOException {
		LazyBundeActivatorProperties properties = getLazyBundeActivatorProperties();
		String value = properties.getBundleActivator();
		return value;
	}

	private BundleContext getBundleContext() {
		return bundleContext;
	}

	private String getBundleSymbolicName() {
		String symbolicName = null;
		Bundle bundle = getBundle();
		if (bundle != null) {
			symbolicName = bundle.getSymbolicName();
		}
		return symbolicName;
	}

	private IImportServiceRecordContainer getContainer() {
		return container;
	}

	private FactoryUtility getFactoryUtility() {
		return FactoryUtility.getInstance();
	}

	private LazyBundeActivatorProperties getLazyBundeActivatorProperties() {
		return lazyBundleActivatorProperties;
	}

	private void handleContainerAcquired() {
		releaseImportedServices();

		try {
			BundleActivator activator = createBundleActivator();
			setBundleActivator(activator);
			startBundleActivator();
		} catch (Exception exception) {
			handleException(exception);
		}
	}

	private void handleContainerReleased() {
		// No-op
	}

	private void handleException(Exception exception) {
		String message = exception.getMessage();
		LogUtility.logError(this, message, exception);
	}

	private void logStarted() {
		String symbolicName = getBundleSymbolicName();
		if (symbolicName == null)
			return;
		String pattern = Messages.getString(LazyBundleActivator.STARTED_BUNDLE_KEY);
		String message = MessageFormatter.format(pattern, symbolicName);
		LogUtility.logDebug(this, message);
	}

	private void logStopped() {
		String symbolicName = getBundleSymbolicName();
		if (symbolicName == null)
			return;
		String pattern = Messages.getString(LazyBundleActivator.STOPPED_BUNDLE_KEY);
		String message = MessageFormatter.format(pattern, symbolicName);
		LogUtility.logDebug(this, message);
	}

	private void populateContainer() throws IOException {
		IImportServiceRecordContainer container = getContainer();
		LazyBundeActivatorProperties properties = getLazyBundeActivatorProperties();
		List/*<String>*/ serviceNames = properties.getImportedServiceNames();
		Iterator/*<String>*/ iterator = serviceNames.iterator();

		while (iterator.hasNext() == true) {
			String serviceName = (String) iterator.next();
			Filter filter = createFilterForService(serviceName);
			IImportServiceRecord record = createImportServiceRecord(serviceName, filter);
			container.add(record);
		}
	}

	private void releaseImportedServices() {
		IImportServiceRecordContainer container = getContainer();
		container.release();
		setContainer(null);
	}

	private void setBundleActivator(BundleActivator bundleActivator) {
		this.bundleActivator = bundleActivator;
	}

	private void setBundleContext(BundleContext bundleContext) {
		this.bundleContext = bundleContext;
	}

	private void setContainer(IImportServiceRecordContainer container) {
		this.container = container;
	}

	private void setLazyBundleActivatorProperties(LazyBundeActivatorProperties lazyBundleActivatorProperties) {
		this.lazyBundleActivatorProperties = lazyBundleActivatorProperties;
	}

	/**
	 * @see org.osgi.framework.BundleActivator#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext context) throws Exception {
		Assertion.checkArgumentIsNotNull(context, "context");  //$NON-NLS-1$
		setBundleContext(context);
		setLazyBundleActivatorProperties(new LazyBundeActivatorProperties(context));
		logStarted();
		acquireImportedServices();
	}

	private void startBundleActivator() throws Exception {
		BundleActivator activator = getBundleActivator();
		BundleContext context = getBundleContext();
		activator.start(context);
	}

	/**
	 * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext context) throws Exception {
		stopBundleActivator();
		setLazyBundleActivatorProperties(null);
		setBundleContext(null);
	}

	private void stopBundleActivator() throws Exception {
		BundleActivator activator = getBundleActivator();

		if (activator != null) {
			try {
				BundleContext context = getBundleContext();
				activator.stop(context);
			} finally {
				setBundleActivator(null);
			}
		}

		logStopped();
	}
}
