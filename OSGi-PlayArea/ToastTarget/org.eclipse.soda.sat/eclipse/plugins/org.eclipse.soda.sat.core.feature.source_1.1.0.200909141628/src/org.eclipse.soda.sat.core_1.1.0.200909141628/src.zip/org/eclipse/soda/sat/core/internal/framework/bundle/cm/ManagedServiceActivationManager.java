/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle.cm;

import java.util.Dictionary;
import java.util.Enumeration;

import org.eclipse.soda.sat.core.framework.BundleActivationManagerOwnerAdapter;
import org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager;
import org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner;
import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceActivationManager;
import org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceAdvisor;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.service.cm.ConfigurationException;

/**
 * ManagedServiceActivationManager.java
 */
public class ManagedServiceActivationManager extends Object implements IManagedServiceActivationManager {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String FAILED_TO_CREATE_IMPORTED_SERVICE_FILTER_FOR_PID_KEY = "ManagedServiceActivationManager.FailedToCreateImportedServiceFilterForPid";  //$NON-NLS-1$
	private static final String FAILED_TO_CREATE_OBJECT_FOR_PID_KEY = "ManagedServiceActivationManager.FailedToCreateObjectForPid";  //$NON-NLS-1$
	private static final String FAILED_TO_DESTROY_OBJECT_FOR_PID_KEY = "ManagedServiceActivationManager.FailedToDestroyObjectForPid";  //$NON-NLS-1$
	private static final String FAILED_TO_HANDLE_ACQUIRED_OPTIONAL_IMPORTED_SERVICE_FOR_PID_KEY = "ManagedServiceActivationManager.FailedToHandleAcquiredOptionalImportedServiceServiceForPid";  //$NON-NLS-1$
	private static final String FAILED_TO_HANDLE_RELEASED_OPTIONAL_IMPORTED_SERVICE_FOR_PID_KEY = "ManagedServiceActivationManager.FailedToHandleReleasedOptionalImportedServiceServiceForPid";  //$NON-NLS-1$
	private static final String FAILED_TO_START_BUNDLE_ACTIVATION_MANAGER_KEY = "ManagedServiceActivationManager.FailedToStartBundleActivationManager";  //$NON-NLS-1$
	private static final String FAILED_TO_STOP_BUNDLE_ACTIVATION_MANAGER_KEY = "ManagedServiceActivationManager.ManagedServiceActivationManager.FailedToStopBundleActivationManager";  //$NON-NLS-1$
	private static final String FAILED_TO_UPDATE_OBJECT_FOR_PID_KEY = "ManagedServiceActivationManager.FailedToUpdateObjectForPid";  //$NON-NLS-1$

	// Misc
	private static final String LINE_SEPARATOR = System.getProperty("line.separator");  //$NON-NLS-1$

	//
	// Instance Fields
	//

	private IManagedServiceAdvisor advisor;
	private BundleContext bundleContext;
	private ConfigurationData configurationData;

	// Locks
	private final Object startLock = new Object();

	//
	// Constructors
	//

	/**
	 * Constructor
	 *
	 * @param advisor  The advisor.
	 */
	public ManagedServiceActivationManager(IManagedServiceAdvisor advisor) {
		super();
		setAdvisor(advisor);
	}

	//
	// Instance Methods
	//

	/**
	 * Create the object for the configuration.
	 */
	private void create() {
		IManagedServiceAdvisor advisor = getAdvisor();
		String pid = getPid();
		Dictionary properties = getProperties();
		IBundleActivationManager manager = getBundleActivationManager();

		try {
			Object object = advisor.create(pid, properties, manager);
			setObject(object);
		} catch (Throwable throwable) {
			logError(pid, throwable, ManagedServiceActivationManager.FAILED_TO_CREATE_OBJECT_FOR_PID_KEY);
		}
	}

	/**
	 * Create an <code>IBundleActivationManagerOwner</code> for the specified
	 * PID.
	 *
	 * @param pid  The persistent ID for a configuration.
	 * @return The owner of an <code>IBundleActivationManager</code>.
	 */
	private IBundleActivationManagerOwner createBundleActivationManagerOwner() {
		return new BundleActivationManagerOwnerAdapter() {
			public void activate() {
				ManagedServiceActivationManager.this.create();
			}

			public void deactivate() {
				ManagedServiceActivationManager.this.destroy();
			}

			public String[] getImportedServiceNames() {
				return ManagedServiceActivationManager.this.getImportedServiceNames();
			}

			public String[] getOptionalImportedServiceNames() {
				return ManagedServiceActivationManager.this.getOptionalImportedServiceNames();
			}

			public void handleAcquiredOptionalImportedService(String serviceName, Object service) {
				ManagedServiceActivationManager.this.handleAcquiredOptionalImportedService(serviceName, service);
			}

			public void handleReleasedOptionalImportedService(String serviceName, Object service) {
				ManagedServiceActivationManager.this.handleReleasedOptionalImportedService(serviceName, service);
			}

			public void start() {
				ManagedServiceActivationManager.this.createImportedServiceFilters();
			}
		};
	}

	/**
	 * Create the imported service filters.
	 */
	private Object createImportedServiceFilters() {
		Object object = null;
		IManagedServiceAdvisor advisor = getAdvisor();
		String pid = getPid();
		Dictionary oldProperties = getOldProperties();
		Dictionary properties = getProperties();
		IBundleActivationManager manager = getBundleActivationManager();

		try {
			advisor.createImportedServiceFilters(pid, oldProperties, properties, manager);
			object = getObject();
		} catch (Throwable throwable) {
			logError(pid, throwable, ManagedServiceActivationManager.FAILED_TO_CREATE_IMPORTED_SERVICE_FILTER_FOR_PID_KEY);
		}

		return object;
	}

	/**
	 * Destroy the object.
	 */
	private void destroy() {
		IManagedServiceAdvisor advisor = getAdvisor();
		String pid = getPid();
		Object object = getObject();
		Dictionary properties = getProperties();
		IBundleActivationManager manager = getBundleActivationManager();

		try {
			advisor.destroy(pid, object, properties, manager);
		} catch (Throwable throwable) {
			logError(pid, throwable, ManagedServiceActivationManager.FAILED_TO_DESTROY_OBJECT_FOR_PID_KEY);
		} finally {
			setObject(null);
		}
	}

	/**
	 * Compare the value of two Dictionary objects.
	 *
	 * @param dictionary1  A Dictionary.
	 * @param dictionary2  A Dictionary.
	 * @return True if the two Dictionary objects are equal, otherwise false.
	 */
	private boolean equal(Dictionary dictionary1, Dictionary dictionary2) {
		// Identical objects are always equal.
		if (dictionary1 == dictionary2) // $codepro.audit.disable useEquals
			return true;  // Early return.

		// If one of the parameters is null then they cannot be equal.
		if (dictionary1 == null || dictionary2 == null)
			return false;  // Early return.

		// If one Dictionary is larger than the other then they cannot be equal.
		int size1 = dictionary1.size();
		int size2 = dictionary2.size();
		boolean equal = size1 == size2;
		if (equal == false)
			return false;  // Early return.

		// Compare the key/value pairs...
		Enumeration keys = dictionary1.keys();

		while (equal == true && keys.hasMoreElements() == true) {
			Object key = keys.nextElement();
			Object value1 = dictionary1.get(key);
			Object value2 = dictionary2.get(key);
			equal = value1.equals(value2);
		}

		return equal;
	}

	/**
	 * Private advisor getter.
	 *
	 * @return The advisor for the <code>ManagedServiceActivationManager</code>.
	 */
	private IManagedServiceAdvisor getAdvisor() {
		return advisor;
	}

	private Bundle getBundle() {
		BundleContext bundleContext = getBundleContext();
		Bundle bundle = null;
		try {
			bundle = bundleContext.getBundle();
		} catch (IllegalStateException exception) {
			// The BundleContext is disposed.
		}
		return bundle;
	}

	/**
	 * Private bundleActivationManager getter.
	 *
	 * @return An <code>IBundleActivationManager</code>.
	 */
	private IBundleActivationManager getBundleActivationManager() {
		ConfigurationData data = getConfigurationData();
		if (data == null)
			return null;  // Early return.
		IBundleActivationManager manager = data.getBundleActivationManager();
		return manager;
	}

	/**
	 * The <code>BundleContext</code> for the owning <code>Bundle</code>.
	 *
	 * @return A <code>BundleContext</code>.
	 */
	private BundleContext getBundleContext() {
		return bundleContext;
	}

	/**
	 * Get the <code>Bundle-SymbolicName</code> of the owning
	 * <code>Bundle</code>.
	 *
	 * @return The <code>Bundle-SymbolicName</code>.
	 */
	private String getBundleSymbolicName() {
		String symbolicName = null;
		Bundle bundle = getBundle();
		if (bundle != null) {
			symbolicName = bundle.getSymbolicName();
		}
		return symbolicName;
	}

	private ConfigurationData getConfigurationData() {
		return configurationData;
	}

	/**
	 *  Get the names of the imported services.
	 *
	 * @return An array of the imported service names.
	 */
	private String[] getImportedServiceNames() {
		IManagedServiceAdvisor advisor = getAdvisor();
		String pid = getPid();
		Dictionary oldProperties = getOldProperties();
		Dictionary properties = getProperties();
		IBundleActivationManager manager = getBundleActivationManager();
		String[] names = advisor.getImportedServiceNames(pid, oldProperties, properties, manager);
		return names;
	}

	private Object getObject() {
		ConfigurationData data = getConfigurationData();
		Object object = data.getObject();
		return object;
	}

	private Dictionary getOldProperties() {
		ConfigurationData data = getConfigurationData();
		Dictionary properties = data.getOldProperties();
		return properties;
	}

	/**
	 * Get the names of the optional imported services.
	 *
	 * @return An array of the optional imported service names.
	 */
	private String[] getOptionalImportedServiceNames() {
		IManagedServiceAdvisor advisor = getAdvisor();
		String pid = getPid();
		Dictionary oldProperties = getOldProperties();
		Dictionary properties = getProperties();
		IBundleActivationManager manager = getBundleActivationManager();
		String[] names = advisor.getOptionalImportedServiceNames(pid, oldProperties, properties, manager);
		return names;
	}

	private String getPid() {
		Dictionary properties = getProperties();
		String pid = getPid(properties);
		return pid;
	}

	private String getPid(Dictionary properties) {
		String pid = properties != null ? (String) properties.get(Constants.SERVICE_PID) : null;
		return pid;
	}

	private Dictionary getProperties() {
		ConfigurationData data = getConfigurationData();
		Dictionary properties = data != null ? data.getProperties() : null;
		return properties;
	}

	/**
	 * Private startLock getter.
	 *
	 * @return The lock using during start and stop.
	 */
	private Object getStartLock() {
		return startLock;
	}

	private void handleAcquiredOptionalImportedService(String importedServiceName, Object importedService) {
		Object object = getObject();
		if (object == null)
			return;  // Early return.

		IManagedServiceAdvisor advisor = getAdvisor();
		String pid = getPid();
		IBundleActivationManager manager = getBundleActivationManager();

		try {
			advisor.handleAcquiredOptionalImportedService(pid, object, importedServiceName, importedService, manager);
		} catch (Throwable throwable) {
			String pattern = Messages.getString(ManagedServiceActivationManager.FAILED_TO_HANDLE_ACQUIRED_OPTIONAL_IMPORTED_SERVICE_FOR_PID_KEY);
			Object[] values = new Object[] {
				importedService, pid
			};
			String message = MessageFormatter.format(pattern, values);
			logError(message, throwable);
		}
	}

	private void handleReleasedOptionalImportedService(String importedServiceName, Object importedService) {
		Object object = getObject();
		if (object == null)
			return;  // Early return.

		IManagedServiceAdvisor advisor = getAdvisor();
		String pid = getPid();
		IBundleActivationManager manager = getBundleActivationManager();

		try {
			advisor.handleReleasedOptionalImportedService(pid, object, importedServiceName, importedService, manager);
		} catch (Throwable throwable) {
			String pattern = Messages.getString(ManagedServiceActivationManager.FAILED_TO_HANDLE_RELEASED_OPTIONAL_IMPORTED_SERVICE_FOR_PID_KEY);
			Object[] values = new Object[] {
				importedService, pid
			};
			String message = MessageFormatter.format(pattern, values);
			logError(message, throwable);
		}
	}

	/**
	 * Answers whether the <code>ManagedServiceActivationManager</code>
	 * is started or not.
	 *
	 * @return True when started, otherwise false.
	 */
	private boolean isStarted() {
		BundleContext bundleContext = getBundleContext();
		boolean started = bundleContext != null;
		return started;
	}

	private void logError(String message, Throwable throwable) {
		LogUtility.logError(this, message, throwable);
	}

	private void logError(String pid, Throwable throwable, String key) {
		String pattern = Messages.getString(key);
		String message = MessageFormatter.format(pattern, pid);
		logError(message, throwable);
	}

	/**
	 * Print a description of the configuration on the specified buffer.
	 *
	 * @param buffer  The buffer on which to print the configuration.
	 */
	private void printConfigurationOn(ICharBuffer buffer) {
		final char tab = '\t';
		String pid = getPid();
		Object object = getObject();
		Dictionary properties = getProperties();

		Enumeration enumeration = properties.keys();

		buffer.append(tab);
		buffer.append("Persistent ID: ");  //$NON-NLS-1$
		buffer.append(pid);
		buffer.append(ManagedServiceActivationManager.LINE_SEPARATOR);

		buffer.append(tab);
		buffer.append(tab);
		buffer.append("Object: ");  //$NON-NLS-1$
		buffer.append(object);
		buffer.append(ManagedServiceActivationManager.LINE_SEPARATOR);

		buffer.append(tab);
		buffer.append(tab);
		buffer.append("Properties:");  //$NON-NLS-1$
		buffer.append(ManagedServiceActivationManager.LINE_SEPARATOR);

		while (enumeration.hasMoreElements() == true) {
			Object key = enumeration.nextElement();
			Object value = properties.get(key);
			buffer.append(tab);
			buffer.append(tab);
			buffer.append(tab);
			buffer.append("Key=");  //$NON-NLS-1$
			buffer.append(key);
			buffer.append(", Value=");  //$NON-NLS-1$
			buffer.append(value);
			buffer.append(ManagedServiceActivationManager.LINE_SEPARATOR);
		}

		buffer.append(ManagedServiceActivationManager.LINE_SEPARATOR);
	}

	private void printOn(ICharBuffer buffer) {
		String value = super.toString();
		buffer.append(value);

		String bundleSymbolicName = getBundleSymbolicName();
		buffer.append(", bundleSymbolicName=");  //$NON-NLS-1$
		buffer.append(bundleSymbolicName);

		IManagedServiceAdvisor advisor = getAdvisor();
		buffer.append(", advisor=");  //$NON-NLS-1$
		buffer.append(advisor);

		buffer.append(ManagedServiceActivationManager.LINE_SEPARATOR);
		printConfigurationOn(buffer);
	}

	/**
	 * Private advisor setter.
	 *
	 * @param advisor  An <code>IManagedServiceAdvisor</code>
	 */
	private void setAdvisor(IManagedServiceAdvisor advisor) {
		Assertion.checkArgumentIsNotNull(advisor, "advisor");  //$NON-NLS-1$
		this.advisor = advisor;
	}

	/**
	 * Private bundleContext setter.
	 *
	 * @param bundleContext  The <code>BundleContext</code> for the
	 *                 <code>ManagedService</code>.
	 */
	private void setBundleContext(BundleContext bundleContext) {
		this.bundleContext = bundleContext;
	}

	/**
	 * Private configurationData setter.
	 *
	 * @param configurationData  The <code>ConfigurationData</code> for the
	 *                           configuration.
	 */
	private void setConfigurationData(ConfigurationData configurationData) {
		this.configurationData = configurationData;
	}

	/**
	 * Set the object for the configuration.
	 *
	 * @param object  An <code>Object</code>.
	 */
	private void setObject(Object object) {
		ConfigurationData data = getConfigurationData();
		data.setObject(object);
	}

	/**
	 * Private properties getter.
	 *
	 * @param properties  The properties for the managed service.
	 */
	private void setProperties(Dictionary properties) {
		ConfigurationData data = getConfigurationData();
		data.setProperties(properties);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceActivationManager#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext bundleContext) {
		Assertion.checkArgumentIsNotNull(bundleContext, "bundleContext");  //$NON-NLS-1$
		Object lock = getStartLock();

		synchronized (lock) {
			boolean started = isStarted();
			if (started == true)
				return;  // Early return.
			setBundleContext(bundleContext);
		}
	}

	/**
	 * Start the <code>IBundleActivationManager</code>.
	 */
	private void startBundleActivationManager() {
		IBundleActivationManager manager = getBundleActivationManager();
		BundleContext bundleContext = getBundleContext();
		IBundleActivationManagerOwner owner = createBundleActivationManagerOwner();

		try {
			manager.start(bundleContext, owner);
		} catch (Exception exception) {
			String pid = getPid();
			logError(pid, exception, ManagedServiceActivationManager.FAILED_TO_START_BUNDLE_ACTIVATION_MANAGER_KEY);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceActivationManager#stop()
	 */
	public void stop() {
		Object lock = getStartLock();

		synchronized (lock) {
			boolean started = isStarted();
			if (started == false)
				return;  // Early return.
			stopBundleActivationManager();
			setBundleContext(null);
		}
	}

	/**
	 * Stop the <code>IBundleActivationManager</code>.
	 */
	private void stopBundleActivationManager() {
		IBundleActivationManager manager = getBundleActivationManager();
		if (manager == null)
			return;  // Early return.

		try {
			manager.stop();
		} catch (Exception exception) {
			String pid = getPid();
			logError(pid, exception, ManagedServiceActivationManager.FAILED_TO_STOP_BUNDLE_ACTIVATION_MANAGER_KEY);
		}
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public final String toString() {
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(350);
		printOn(buffer);
		String result = buffer.toString();
		return result;
	}

	/**
	 * Update the object.
	 */
	private void update() {
		IManagedServiceAdvisor advisor = getAdvisor();
		String pid = getPid();
		Object object = getObject();
		Dictionary oldProperties = getOldProperties();
		Dictionary properties = getProperties();
		IBundleActivationManager manager = getBundleActivationManager();
		Object updatedObject = advisor.update(pid, object, oldProperties, properties, manager);
		setObject(updatedObject);
	}

	private void update(Dictionary properties) {
		// Compare current and the new properties.  Ignore update if the
		// properties have not changed.
		Dictionary currentProperties = getProperties();
		boolean match = equal(currentProperties, properties);
		if (match == true)
			return;  // Early return.

		// Store the changed properties.
		setProperties(properties);

		// Cache the current object.
		Object object = getObject();

		// Recreate and apply the imported service filters.  New imported
		// service filters might cause the object to be destroyed and recreated.
		Object newObject = createImportedServiceFilters();

		// Update the object only if it was not recreated as a result of
		// creating new imported service filters.
		boolean update = object != null && object == newObject; // $codepro.audit.disable useEquals
		if (update == false)
			return;  // Early return.

		update();
	}

	/**
	 * @see org.osgi.service.cm.ManagedService#updated(java.util.Dictionary)
	 */
	public void updated(Dictionary properties) throws ConfigurationException {
		Object lock = getStartLock();

		synchronized (lock) {
			boolean started = isStarted();
			if (started == false)
				return;  // Early return.

			ConfigurationData data = getConfigurationData();

			if (properties == null) {
				if (data == null)
					return;  // Early return.
				stopBundleActivationManager();
				setConfigurationData(null);
			} else {
				try {
					validateConfiguration(properties);

					if (data == null) {
						data = new ConfigurationData(properties);
						setConfigurationData(data);
						startBundleActivationManager();
					} else {
						update(properties);
					}
				} catch (Throwable throwable) {
					String pid = getPid(properties);
					logError(pid, throwable, ManagedServiceActivationManager.FAILED_TO_UPDATE_OBJECT_FOR_PID_KEY);
				}
			}
		}
	}

	/**
	 * Validate the configuration's properties.  If the properties are found to
	 * be invalid a <code>ConfigurationException</code> is thrown.
	 *
	 * @param properties  The configuration properties.
	 * @throws ConfigurationException
	 */
	private void validateConfiguration(Dictionary properties) throws ConfigurationException {
		IManagedServiceAdvisor advisor = getAdvisor();
		String pid = getPid();
		advisor.validateConfiguration(pid, properties);
	}
}
