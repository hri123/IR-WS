/*******************************************************************************
 * Copyright (c) 2001, 2009 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.util;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Dictionary;

import org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager;
import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker;
import org.eclipse.soda.sat.core.framework.interfaces.IFileLog;
import org.eclipse.soda.sat.core.framework.interfaces.ILineReader;
import org.eclipse.soda.sat.core.framework.interfaces.ILineWriter;
import org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceActivationManager;
import org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceAdvisor;
import org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryActivationManager;
import org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryAdvisor;
import org.eclipse.soda.sat.core.framework.interfaces.IProxyServiceHandler;
import org.eclipse.soda.sat.core.framework.interfaces.IQueue;
import org.eclipse.soda.sat.core.framework.interfaces.ITokenizer;
import org.eclipse.soda.sat.core.internal.framework.bundle.BundleActivationManager;
import org.eclipse.soda.sat.core.internal.framework.bundle.cm.ManagedServiceActivationManager;
import org.eclipse.soda.sat.core.internal.framework.bundle.cm.ManagedServiceFactoryActivationManager;
import org.eclipse.soda.sat.core.internal.record.ExportProxyServiceRecord;
import org.eclipse.soda.sat.core.internal.record.ExportServiceRecord;
import org.eclipse.soda.sat.core.internal.record.ImportServiceRecord;
import org.eclipse.soda.sat.core.internal.record.ServiceDetecter;
import org.eclipse.soda.sat.core.internal.record.container.ExportServiceRecordContainer;
import org.eclipse.soda.sat.core.internal.record.container.ImportServiceRecordContainer;
import org.eclipse.soda.sat.core.internal.util.CharBuffer;
import org.eclipse.soda.sat.core.internal.util.ConsoleLog;
import org.eclipse.soda.sat.core.internal.util.DependencyTracker;
import org.eclipse.soda.sat.core.internal.util.FileLog;
import org.eclipse.soda.sat.core.internal.util.LineReader;
import org.eclipse.soda.sat.core.internal.util.LineWriter;
import org.eclipse.soda.sat.core.internal.util.OutputStreamLog;
import org.eclipse.soda.sat.core.internal.util.Queue;
import org.eclipse.soda.sat.core.internal.util.Tokenizer;
import org.eclipse.soda.sat.core.record.container.interfaces.IExportServiceRecordContainer;
import org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainer;
import org.eclipse.soda.sat.core.record.interfaces.IExportProxyServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IServiceDetecter;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Filter;
import org.osgi.service.log.LogService;


/**
 * The <code>FactoryUtility</code> class provides an API through which instances
 * of many of the SAT abstractions may be created.  The goal of this class is to
 * keep the SAT implementation classes private, while allowing objects to be
 * created and shared via public interfaces.
 * <p>
 * <i>Note:</i> This is a singleton class, accessible only via the static method
 * <code>getInstance()</code>.  For example:
 * <pre>
 * FactoryUtility utility = FactoryUtility.getInstance();
 * IExportServiceRecordContainer container = utility.createExportServiceRecordContainer();
 * </pre>
 */
public final class FactoryUtility extends Object {
	//
	// Static Fields
	//

	// Singleton
	private static final FactoryUtility INSTANCE = new FactoryUtility();

	//
	// Static Methods
	//

	/**
	 * Public getter for the <code>FactoryUtility</code> singleton instance.
	 *
	 * @return <code>FactoryUtility</code>
	 */
	public static FactoryUtility getInstance() {
		return FactoryUtility.INSTANCE;
	}

	/**
	 * Constructor.
	 */
	private FactoryUtility() {
		super();
	}

	//
	// Instance Methods
	//

	/**
	 * Create an <code>IBundleActivationManager</code>.
	 *
	 * @return The created <code>IBundleActivationManager</code>.
	 */
	public IBundleActivationManager createBundleActivationManager() {
		return new BundleActivationManager();
	}

	/**
	 * Create an <code>IBundleActivationManager</code>.
	 *
	 * @param id  The id of the <code>IBundleActivationManager</code>.
	 * @return The created <code>IBundleActivationManager</code>.
	 */
	public IBundleActivationManager createBundleActivationManager(String id) {
		Assertion.checkArgumentIsNotNull(id, "id");  //$NON-NLS-1$
		return new BundleActivationManager(id);
	}

	/**
     * Create a char buffer with the specified initial capacity.
     *
     * @param initialCapacity  The initial capacity of the buffer.
     * @return The created <code>ICharBuffer</code>.
     */
	public ICharBuffer createCharBuffer(int initialCapacity) {
		return new CharBuffer(initialCapacity);
	}

	/**
     * Create a console log.
     *
     * @return A console log implementation of the <code>LogService</code>.
     */
	public LogService createConsoleLog() {
		return new ConsoleLog();
	}

	/**
	 * Create a dependency tracker.
	 *
	 * @param prerequisites  A hint to the number of prerequisites.
	 * @param dependents     A hint to the number of dependents.
	 * @return IDependencyTracker
	 */
	public IDependencyTracker createDependencyTracker(int prerequisites, int dependents) {
		return new DependencyTracker(prerequisites, dependents);
	}

	/**
	 * Create an <code>IExportProxyServiceRecord</code> with properties that
	 * implements multiple interfaces.
	 *
	 * @param bundleContext  The <code>BundleContext</code> handle back to the
	 *                       framework.
	 * @param interfaceType  The interface type used to create the proxy
	 *                       service and register it with the OSGi framework.
	 * @param handler        An <code>IProxyServiceHandler</code>.
	 * @param properties     The properties of the exported service.
	 * @return The created <code>IExportProxyServiceRecord</code>.
	 */
	public IExportProxyServiceRecord createExportProxyServiceRecord(BundleContext bundleContext, Class interfaceType, IProxyServiceHandler handler, Dictionary properties) {
		Assertion.checkArgumentIsNotNull(interfaceType, "interfaceType");  //$NON-NLS-1$
		Class[] interfaceTypes = new Class[] { interfaceType };
		return createExportProxyServiceRecord(bundleContext, interfaceTypes, handler, properties);
	}

	/**
	 * Create an <code>IExportProxyServiceRecord</code> with properties that
	 * implements multiple interfaces.
	 *
	 * @param bundleContext  The <code>BundleContext</code> handle back to the
	 *                       framework.
	 * @param interfaceTypes The interface types used to create the proxy
	 *                       service and register it with the OSGi framework.
	 * @param handler        An <code>IProxyServiceHandler</code>.
	 * @param properties     The properties of the exported service.
	 * @return The created <code>IExportProxyServiceRecord</code>.
	 */
	public IExportProxyServiceRecord createExportProxyServiceRecord(BundleContext bundleContext, Class[] interfaceTypes, IProxyServiceHandler handler, Dictionary properties) {
		return new ExportProxyServiceRecord(bundleContext, interfaceTypes, handler, properties);
	}

	/**
	 * Create an <code>IExportServiceRecord</code>.
	 *
	 * @param bundleContext  The <code>BundleContext</code> handle back to the
	 *                       framework.
	 * @param name           The fully qualified type name of the exported
	 *                       service.
	 * @param service        The exported service.
	 * @param properties     The properties of the exported service.
	 * @return The created <code>IExportServiceRecord</code>.
	 */
	public IExportServiceRecord createExportServiceRecord(BundleContext bundleContext, String name, Object service, Dictionary properties) {
		Assertion.checkArgumentIsNotNull(name, "name");  //$NON-NLS-1$
		String[] names = new String[] { name };
		return createExportServiceRecord(bundleContext, names, service, properties);
	}

	/**
	 * Create an <code>IExportServiceRecord</code>.
	 *
	 * @param bundleContext  The <code>BundleContext</code> handle back to the
	 *                       framework.
	 * @param names          The fully qualified type names of the exported
	 *                       service.
	 * @param service        The exported service.
	 * @param properties     The properties of the exported service.
	 * @return The created <code>IExportServiceRecord</code>.
	 */
	public IExportServiceRecord createExportServiceRecord(BundleContext bundleContext, String[] names, Object service, Dictionary properties) {
		return new ExportServiceRecord(bundleContext, names, service, properties);
	}

	/**
	 * Create an <code>IExportServiceRecordContainer</code>.
	 *
	 * @return The created <code>IExportServiceRecordContainer</code>.
	 */
	public IExportServiceRecordContainer createExportServiceRecordContainer() {
		return new ExportServiceRecordContainer();
	}

	/**
	 * Create an <code>IFileLog</code>.
	 *
	 * @param file  The file.
	 * @return The created <code>IFileLog</code>.
	 */
	public IFileLog createFileLog(File file) {
		return new FileLog(file);
	}

	/**
	 * Create an <code>IImportServiceRecord</code>.
	 *
	 * @param bundleContext  The <code>BundleContext</code> handle back to the
	 *                       framework.
	 * @param name           The fully qualified type name of the imported
	 *                       service.
	 * @param filter         The LDAP filter used to acquire the imported
	 *                       service.
	 * @return The created <code>IImportServiceRecord</code>.
	 */
	public IImportServiceRecord createImportServiceRecord(BundleContext bundleContext, String name, Filter filter) {
		return new ImportServiceRecord(bundleContext, name, filter);
	}

	/**
	 * Create a "strict" <code>IImportServiceRecordContainer</code>.
	 *
	 * @return The created <code>IImportServiceRecordContainer</code>.
	 */
	public IImportServiceRecordContainer createImportServiceRecordContainer() {
		return new ImportServiceRecordContainer();
	}

	/**
	 * Create a line reader.
	 *
	 * @param stream   The stream from which to read.
	 * @return ILineReader
	 */
	public ILineReader createLineReader(InputStream stream) {
		return new LineReader(stream);
	}

	/**
	 * Create a line reader.
	 *
	 * @param stream   The stream from which to read.
	 * @param advisor  The reader's advisor.
	 * @return ILineReader
	 */
	public ILineReader createLineReader(InputStream stream, ILineReader.IAdvisor advisor) {
		return new LineReader(stream, advisor);
	}

	/**
	 * Create a line reader.
	 *
	 * @param stream   The stream from which to read.
	 * @param size     A hint to the size of the stream.
	 * @return ILineReader
	 */
	public ILineReader createLineReader(InputStream stream, int size) {
		return new LineReader(stream, size);
	}

	/**
	 * Create a line reader.
	 *
	 * @param stream   The stream from which to read.
	 * @param size     A hint to the size of the stream.
	 * @param advisor  The reader's advisor.
	 * @return ILineReader
	 */
	public ILineReader createLineReader(InputStream stream, int size, ILineReader.IAdvisor advisor) {
		return new LineReader(stream, size, advisor);
	}

	/**
	 * Create a line reader.
	 *
	 * @param stream             The stream from which to read.
	 * @param characterEncoding  The character encoding to use.
	 * @return ILineReader
	 */
	public ILineReader createLineReader(InputStream stream, String characterEncoding) {
		return new LineReader(stream, characterEncoding);
	}

	/**
	 * Create a line reader.
	 *
	 * @param stream             The stream from which to read.
	 * @param characterEncoding  The character encoding to use.
	 * @param advisor            The reader's advisor.
	 * @return ILineReader
	 */
	public ILineReader createLineReader(InputStream stream, String characterEncoding, ILineReader.IAdvisor advisor) {
		return new LineReader(stream, characterEncoding, advisor);
	}

	/**
	 * Create a line reader.
	 *
	 * @param stream             The stream from which to read.
	 * @param characterEncoding  The character encoding to use.
	 * @param size               A hint to the size of the stream.
	 * @return ILineReader
	 */
	public ILineReader createLineReader(InputStream stream, String characterEncoding, int size) {
		return new LineReader(stream, characterEncoding, size);
	}

	/**
	 * Create a line reader.
	 *
	 * @param stream             The stream from which to read.
	 * @param characterEncoding  The character encoding to use.
	 * @param size               A hint to the size of the stream.
	 * @param advisor            The reader's advisor.
	 * @return ILineReader
	 */
	public ILineReader createLineReader(InputStream stream, String characterEncoding, int size, ILineReader.IAdvisor advisor) {
		return new LineReader(stream, characterEncoding, size, advisor);
	}

	/**
	 * Create a line writer.
	 *
	 * @param stream  The stream to which to write.
	 * @return ILineWriter
	 */
	public ILineWriter createLineWriter(OutputStream stream) {
		return new LineWriter(stream);
	}

	/**
	 * Create a line writer.
	 *
	 * @param stream  The stream to which to write.
	 * @param size    A hint to the size of the stream.
	 * @return ILineWriter
	 */
	public ILineWriter createLineWriter(OutputStream stream, int size) {
		return new LineWriter(stream, size);
	}

	/**
	 * Create a line writer.
	 *
	 * @param stream             The stream to which to write.
	 * @param characterEncoding  The character encoding to use.
	 * @return ILineWriter
	 */
	public ILineWriter createLineWriter(OutputStream stream, String characterEncoding) {
		return new LineWriter(stream, characterEncoding);
	}

	/**
	 * Create a line writer.
	 *
	 * @param stream             The stream to which to write.
	 * @param characterEncoding  The character encoding to use.
	 * @param size               A hint to the size of the stream.
	 * @return ILineWriter
	 */
	public ILineWriter createLineWriter(OutputStream stream, String characterEncoding, int size) {
		return new LineWriter(stream, characterEncoding, size);
	}

	/**
	 * Create an <code>IManagedServiceActivationManager</code>.
	 *
	 * @param advisor  The advisor for the <code>ManagedService</code>.
	 * @return The created <code>IManagedServiceActivationManager</code>.
	 */
	public IManagedServiceActivationManager createManagedServiceActivationManager(IManagedServiceAdvisor advisor) {
		return new ManagedServiceActivationManager(advisor);
	}

	/**
	 * Create an <code>IManagedServiceFactoryActivationManager</code>.
	 *
	 * @param name     The name of the <code>ManagedServiceFactory</code>.
	 * @param advisor  The advisor for the <code>ManagedServiceFactory</code>.
	 * @return The created <code>IManagedServiceFactoryActivationManager</code>.
	 */
	public IManagedServiceFactoryActivationManager createManagedServiceFactoryActivationManager(String name, IManagedServiceFactoryAdvisor advisor) {
		return new ManagedServiceFactoryActivationManager(name, advisor);
	}

	/**
	 * Create an <code>IManagedServiceFactoryActivationManager</code>.
	 *
	 * @param name                        The name of the
	 *                                    <code>ManagedServiceFactory</code>.
	 * @param advisor                     The advisor for the
	 *                                    <code>ManagedServiceFactory</code>.
	 * @param numberOfConfigurationsHint  A hint to the number of
	 *                                    configurations.
	 * @return The created <code>IManagedServiceFactoryActivationManager</code>.
	 */
	public IManagedServiceFactoryActivationManager createManagedServiceFactoryActivationManager(String name, IManagedServiceFactoryAdvisor advisor, int numberOfConfigurationsHint) {
		return new ManagedServiceFactoryActivationManager(name, advisor, numberOfConfigurationsHint);
	}

	/**
     * Create a OutputStream log.
     *
	 * @param errorOutputStream    The error <code>OutputStream</code>.
	 * @param warningOutputStream  The warning <code>OutputStream</code>.
	 * @param infoOutputStream     The info <code>OutputStream</code>.
	 * @param debugOutputStream    The debug <code>OutputStream</code>.
     *
     * @return An OutputStream log implementation of the <code>LogService</code>.
     */
	public LogService createOutputStreamLog(OutputStream errorOutputStream, OutputStream warningOutputStream, OutputStream infoOutputStream, OutputStream debugOutputStream) {
		return new OutputStreamLog(errorOutputStream, warningOutputStream, infoOutputStream, debugOutputStream);
	}

	/**
	 * Create an <code>IQueue</code>.
	 *
	 * @param capacity  The initial capacity of the queue.
	 * @return The created <code>IQueue</code>.
	 */
	public IQueue createQueue(int capacity) {
		return new Queue(capacity);
	}

	/**
	 * Create an <code>IServiceDetecter</code>.
	 *
	 * @param bundleContext  The <code>BundleContext</code> handle back to the
	 *                       framework.
	 * @param name           The fully qualified type name of the imported
	 *                       service.
	 * @return The created <code>IServiceDetecter</code>.
	 */
	public IServiceDetecter createServiceDetecter(BundleContext bundleContext, String name) {
		return new ServiceDetecter(bundleContext, name);
	}

	/**
	 * Create an <code>ITokenizer</code>.
	 *
	 * @param value  The text to tokenize.
	 * @return ITokenizer
	 */
	public ITokenizer createTokenizer(String value) {
		return new Tokenizer(value);
	}

	/**
	 * Create an <code>ITokenizer</code>.
	 *
	 * @param value      The text to tokenize.
	 * @param delimiter  The delimiter.
	 * @return ITokenizer
	 */
	public ITokenizer createTokenizer(String value, char delimiter) {
		return new Tokenizer(value, delimiter);
	}

	/**
	 * Create an <code>ITokenizer</code>.
	 *
	 * @param value      The text to tokenize.
	 * @param delimiter  The delimiter.
	 * @param index      The index at which to start tokenizing the text.
	 * @return ITokenizer
	 */
	public ITokenizer createTokenizer(String value, char delimiter, int index) {
		return new Tokenizer(value, delimiter, index);
	}

	/**
	 * Create an <code>ITokenizer</code>.
	 *
	 * @param value  The text to tokenize.
	 * @param index  The index at which to start tokenizing the text.
	 * @return ITokenizer
	 */
	public ITokenizer createTokenizer(String value, int index) {
		return new Tokenizer(value, index);
	}
}
