/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.record.container.interfaces;

import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord;

/**
 * When an <code>IImportServiceRecordContainer</code> is created it must be
 * given an owner that will handle call-back notifications.  The
 * <code>IImportServiceRecordContainerLenientOwner</code> interface declares the
 * role of a container's owner, which has the following responsibilities:
 *
 * <h4>Lenient Container Responsibilities</h4>
 * These responsibilities only apply to a <i>lenient container</i>.  A lenient
 * container is more complicated than a strict container since it cares when
 * each of the import service records is acquired and released.
 * <ul>
 *   <li>
 *     Handle the course of action to be taken when the container is considered
 *     <i>acquired</i>, meaning that the <code>IImportServiceContainer</code>
 *     method <code>acquire(IImportServiceRecordContainerOwner)</code> has been
 *     called.  When a lenient container is acquired, there are <b>no
 *     guarantees</b> as to whether any or all of its import service records
 *     are acquired.
 *   </li>
 *   <li>
 *     Handle the course of action to be taken when <b>one</b> of the
 *     container's import service records is <i>acquired</i>.
 *   </li>
 *   <li>
 *     Handle the course of action to be taken when <b>one</b> of the
 *     container's import service records is <i>released</i>.
 *   </li>
 *   <li>
 *     Handle the course of action to be taken when the container is considered
 *     <i>released</i>, meaning that the <code>IImportServiceContainer</code>
 *     method <code>release()</code> has been called.  When a lenient container
 *     is release, <b>all</b> its import service records are released.
 *   </li>
 * </ul>
 * <p>
 * <i>Note:</i> Since this abstraction is used internally by the SAT bundle
 * this interface is typically not used directly by bundle developers.
 */
public interface IImportServiceRecordContainerLenientOwner extends IImportServiceRecordContainerOwner{
	/**
	 * One of the container's <code>IImportServiceRecord</code> objects has been
	 * acquired.  This call-back is only sent when the container is
	 * <i>non-strict</i>.  The purpose of this call-back is to inform the
	 * container's owner that it should handle the acquisition of an imported
	 * service.
	 * <p>
	 * Typically the container's owner responds by starting to use the imported
	 * service.  Just because this call-back is sent, does not mean that the
	 * container itself is fully acquired, although it might be.  Use the
	 * <code>IImportServiceRecordContainer</code> method <code>isAcquired()</code>
	 * to query whether it is acquired or not.
	 *
	 * @param container  The owned container.
	 * @param record     The acquired import service record.
	 */
	public void serviceAcquired(IImportServiceRecordContainer container, IImportServiceRecord record);

	/**
	 * One of the container's <code>IImportServiceRecord</code> objects has been
	 * released.  This call-back is only sent when the container is
	 * <i>non-strict</i>.  The purpose of this call-back is to inform the
	 * container's owner that it should handle the release of an imported
	 * service.
	 * <p>
	 * Typically the container's owner responds by stopping using the imported
	 * service, although it would be equally legal for the owner to update the
	 * <code>IImportServiceRecord</code> object's properties and attempt to
	 * <i>reacquire</i> the released service.
	 *
	 * @param container  The owned container.
	 * @param record  The acquired import service record.
	 */
	public void serviceReleased(IImportServiceRecordContainer container, IImportServiceRecord record);
}
