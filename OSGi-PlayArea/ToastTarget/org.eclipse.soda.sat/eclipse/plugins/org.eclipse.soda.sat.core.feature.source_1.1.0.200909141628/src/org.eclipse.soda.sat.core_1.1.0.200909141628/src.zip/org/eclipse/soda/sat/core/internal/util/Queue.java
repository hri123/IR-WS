/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.soda.sat.core.framework.interfaces.IQueue;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.util.Assertion;

public class Queue/*<T>*/ extends Object implements IQueue/*<T>*/ {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String TIMEOUT_MUST_BE_GREATER_THAN_OR_EQUAL_TO_ZERO_KEY = "Queue.TimeoutMustBeGreaterThanOrEqualToZero";  //$NON-NLS-1$

	//
	// Instance Fields
	//

	private List/*<T>*/ items;

	//
	// Constructors
	//

	/**
	 * Construct a queue with the specified capacity.  The queue will increase
	 * its capacity if necessary.
	 *
	 * @param capacity  The initial capacity of the queue.
	 */
	public Queue(int capacity) {
		super();
		setItems(new ArrayList/*<T>*/(capacity));
	}

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IQueue#add(java.lang.Object)
	 */
	public void add(Object item) {
		Assertion.checkArgumentIsNotNull(item, "item");  //$NON-NLS-1$
		List/*<T>*/ items = getItems();

		synchronized (this) {
			items.add(item);
			notifyAll();
		}
	}

	private void checkTimeout(long timeout) {
		if (timeout >= 0)
			return;  // Early return.
		String message = Messages.getString(Queue.TIMEOUT_MUST_BE_GREATER_THAN_OR_EQUAL_TO_ZERO_KEY);
		throw new IllegalArgumentException(message);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IQueue#contains(java.lang.Object)
	 */
	public boolean contains(Object item) {
		Assertion.checkArgumentIsNotNull(item, "item");  //$NON-NLS-1$
		List/*<T>*/ items = getItems();
		Iterator/*<T>*/ iterator = items.iterator();
		boolean exists = false;

		synchronized (this) {
			while (exists == false && iterator.hasNext() == true) {
				Object object = iterator.next();
				exists = object == item; // $codepro.audit.disable useEquals
			}
		}

		return exists;
	}

	private List/*<T>*/ getItems() {
		return items;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IQueue#isEmpty()
	 */
	public boolean isEmpty() {
		List/*<T>*/ items = getItems();
		boolean empty = items.isEmpty();
		return empty;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IQueue#remove()
	 */
	public Object remove() throws InterruptedException {
		long timeout = 0;
		Object item = remove(timeout);
		return item;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IQueue#remove(long)
	 */
	public Object remove(long timeout) throws InterruptedException {
		List/*<T>*/ items = getItems();
		Object item = null;

		synchronized (this) {
			boolean notEmpty = waitUntilNotEmpty(timeout);

			if (notEmpty == true) {
				item = items.get(0);
				items.remove(0);
			}
		}

		return item;
	}

	private void setItems(List/*<T>*/ items) {
		this.items = items;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IQueue#size()
	 */
	public int size() {
		List/*<T>*/ items = getItems();
		int size = items.size();
		return size;
	}

	private boolean waitUntilNotEmpty(long timeout) throws InterruptedException {
		checkTimeout(timeout);
		long startTime = System.currentTimeMillis();
		long duration = 0;

		while (isEmpty() == true) {
			if (timeout == 0) {
				wait();
			} else {
				if (duration >= timeout)
					return false;  // Early return.
				wait(timeout);
				long wakeTime = System.currentTimeMillis();
				duration = wakeTime - startTime;
			}
		}

		return true;
	}
}
