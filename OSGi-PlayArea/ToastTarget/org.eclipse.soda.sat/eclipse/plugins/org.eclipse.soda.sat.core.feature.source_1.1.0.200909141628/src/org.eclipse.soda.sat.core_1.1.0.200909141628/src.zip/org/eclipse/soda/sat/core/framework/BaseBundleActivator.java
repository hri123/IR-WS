/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Dictionary;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager;
import org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner;
import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryAdvisor;
import org.eclipse.soda.sat.core.framework.interfaces.IProxyServiceHandler;
import org.eclipse.soda.sat.core.internal.framework.bundle.LazyBundeActivatorProperties;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.internal.util.WarningMessageUtility;
import org.eclipse.soda.sat.core.util.BundleManifestUtility;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleException;
import org.osgi.framework.Filter;

/**
 * <code>BaseBundleActivator</code> is an abstract class from which all SAT
 * bundles typically derive their <code>BundleActivator</code>.  The
 * <code>BaseBundleActivator</code> class is central to SAT since it prescribes
 * the algorithm for managing the life cycle of a bundle.
 * <p>
 * The <code>BaseBundleActivator</code> class is implemented using the
 * <i>Template Method Pattern</i>, providing hook and configuration methods
 * that subclasses can override, and supporting query methods.
 * <p>
 * Subclasses of <code>BaseBundleActivator</code> are often created using the
 * Eclipse-based <b>SAT Bundle Activator wizard</b>.  The wizard can be
 * accessed by selecting <b>File > New > Other...</b> and selecting the
 * <b>Service Activator Toolkit</b> category from the dialog.
 * <p>
 * While subclassing the <code>BaseBundleActivator</code> is by far the most
 * common way of using SAT, this is not the only way.  A bundle that needs to
 * be highly customized can have its activator built using the SAT abstractions
 * that are available via the <code>FactoryUtility</code> class.
 */
public abstract class BaseBundleActivator extends Object implements BundleActivator {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String FAILED_TO_FIND_PROPERTIES_FILE_KEY = "BaseBundleActivator.FailedToFindPropertiesFile";  //$NON-NLS-1$
	private static final String FAILED_TO_FIND_PROPERTIES_RESOURCE_KEY = "BaseBundleActivator.FailedToFindPropertiesResource";  //$NON-NLS-1$
	private static final String FAILED_TO_GET_IMPORTED_SERVICE_KEY = "BaseBundleActivator.FailedToGetImportedService";  //$NON-NLS-1$
	private static final String FILENAME_KEY = "BaseBundleActivator.Filename";  //$NON-NLS-1$
	private static final String RESOURCE_KEY = "BaseBundleActivator.Resource";  //$NON-NLS-1$
	private static final String SAT_CORE_KEY = "Common.SatCore";  //$NON-NLS-1$
	private static final String SERVICE_KEY = "Common.Service";  //$NON-NLS-1$
	private static final String SHOULD_HAVE_OVERRIDDEN_METHOD_KEY = "Common.ShouldHaveOverriddenMethod";  //$NON-NLS-1$

	// Misc
	private static final String LAZY_BUNDLE_ACTIVATOR = LazyBundleActivator.class.getName();
	protected static final String[] NO_SERVICES = new String [ 0 ];

	//
	// Instance Fields
	//

	private IBundleActivationManager bundleActivationManager;
	private LazyBundeActivatorProperties lazyBundeActivatorProperties;

	//
	// Instance Methods
	//

	/**
	 * <i>Configuration API:</i> Acquire the specified imported services.  This
	 * method is typically <i>not used by subclasses</i>, except in rare cases.
	 * For an example see the method <code>releaseImportedService(String)</code>.
	 *
	 * @param name  The name of an imported service.
	 * @return Object
	 *
	 * @see BaseBundleActivator#releaseImportedService(java.lang.String)
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#acquireImportedService(java.lang.String)
	 */
	protected final Object acquireImportedService(String name) {
		IBundleActivationManager manager = getBundleActivationManager();
		Object service = manager.acquireImportedService(name);
		return service;
	}

	/**
	 * <i>Configuration API:</i> Acquire all the imported services.  This
	 * method is typically <i>not used by subclasses</i>, except in rare cases.
	 * For an example see the method <code>releaseImportedServices()</code>.
	 *
	 * @see BaseBundleActivator#releaseImportedServices()
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#acquireImportedServices()
	 * */
	protected final void acquireImportedServices() {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.acquireImportedServices();
	}

	/**
	 * <i>Configuration API:</i> Acquire all the optional imported services.
	 * This method is typically <i>not used by subclasses</i>, except in rare
	 * cases.
	 *
	 * @see BaseBundleActivator#releaseOptionalImportedServices()
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#acquireOptionalImportedServices()
	 * */
	protected final void acquireOptionalImportedServices() {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.acquireOptionalImportedServices();
	}

	/**
	 * <i>Hook API:</i> This method is overridden by subclasses that wish to
	 * execute domain specific activation.  For example:
	 *
	 * <pre>
	 * protected void activate() {
	 *     MyDomainObject object = (MyDomainObject) getExportedService(MyService.SERVICE_NAME);
	 *     object.startup();
	 * }
	 * </pre>
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#activate()
	 */
	protected void activate() {
		//...
	}

	/**
	 * <i>Configuration API:</i> Add an exported proxy service.
	 *
	 * <pre>
	 * protected void createExportedServices() {
	 *     IProxyServiceHandler handler = new ProxyServiceAdapter() {
	 *         public Object createService() {
	 *             return new HotdogVendor();
	 *         }
	 *     };
	 *
	 *     Dictionary properties = new Hashtable(11);
	 *     properties.put("cn", "simona");
	 *     properties.put("o", "OTI");
	 *     properties.put("c", "US");
	 *
	 *     addExportedProxyService(VendorService.class, handler, properties);
	 * }
	 * </pre>
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#addExportedProxyService(java.lang.Class, org.eclipse.soda.sat.core.framework.interfaces.IProxyServiceHandler, java.util.Dictionary)
	 */
	protected final void addExportedProxyService(Class interfaceType, IProxyServiceHandler handler, Dictionary properties) {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.addExportedProxyService(interfaceType, handler, properties);
	}

	/**
	 * <i>Configuration API:</i> Add an exported proxy service.
	 *
	 * <pre>
	 * protected void createExportedServices() {
	 *     Class[] interfaceTypes = new Class[] {
	 *         VendorService.class,
	 *         TicketService.class
	 *     };
	 *
	 *     IProxyServiceHandler handler = new ProxyServiceAdapter() {
	 *         public Object createService() {
	 *             return new HotdogVendor();
	 *         }
	 *     };
	 *
	 *     Dictionary properties = new Hashtable(11);
	 *     properties.put("cn", "simona");
	 *     properties.put("o", "OTI");
	 *     properties.put("c", "US");
	 *
	 *     addExportedProxyService(interfaceTypes, handler, properties);
	 * }
	 * </pre>
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#addExportedProxyServices(java.lang.Class[], org.eclipse.soda.sat.core.framework.interfaces.IProxyServiceHandler, java.util.Dictionary)
	 */
	protected final void addExportedProxyServices(Class[] interfaceTypes, IProxyServiceHandler handler, Dictionary properties) {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.addExportedProxyServices(interfaceTypes, handler, properties);
	}

	/**
	 * <i>Configuration API:</i> Add an exported service with properties.
	 * For example:
	 *
	 * <pre>
	 * protected void createExportedServices() {
	 *     VendorService vendor = new HotdogVendor();
	 *
	 *     Dictionary properties = new Hashtable(11);
	 *     properties.put("cn", "simona");
	 *     properties.put("o", "OTI");
	 *     properties.put("c", "US");
	 *
	 *     addExportedService(VendorService.SERVICE_NAME, vendor, properties);
	 * }
	 * </pre>
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#addExportedService(java.lang.String, java.lang.Object, java.util.Dictionary)
	 */
	protected final void addExportedService(String name, Object service, Dictionary properties) {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.addExportedService(name, service, properties);
	}

	/**
	 * <i>Configuration API:</i> Add multiple exported service with
	 * properties.  For example:
	 *
	 * <pre>
	 * protected void createExportedServices() {
	 *     String[] names = new String[] {
	 *         VendorService.SERVICE_NAME,
	 *         TicketService.SERVICE_NAME
	 *     };
	 *
	 *     Object vendor = new HotdogVendor();
	 *
	 *     Dictionary properties = new Hashtable(11);
	 *     properties.put("cn", "simona");
	 *     properties.put("o", "OTI");
	 *     properties.put("c", "US");
	 *
	 *     addExportedService(names, vendor, properties);
	 * }
     * </pre>
     *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#addExportedServices(java.lang.String[], java.lang.Object, java.util.Dictionary)
	 */
	protected final void addExportedServices(String[] names, Object service, Dictionary properties) {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.addExportedServices(names, service, properties);
	}

	/**
	 * <i>Configuration API:</i> Add an LDAP filter to an imported service.  For
	 * example:
	 *
	 * <pre>
	 * protected void start() {
	 *     BundleContext context = getBundleContext();
	 *     addImportedServiceFilter(YourService.SERVICE_NAME, "(o=IBM)");
	 * }
	 * </pre>
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#addImportedServiceFilter(java.lang.String, java.lang.String)
	 */
	protected final void addImportedServiceFilter(String name, String filterString) {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.addImportedServiceFilter(name, filterString);
	}

	private void addLazyImportedServiceFilter(String name) {
		LazyBundeActivatorProperties properties = getLazyBundleActivatorProperties();
		String filter = properties.getImportedServiceFilter(name);
		if (filter == null)
			return;  // Early return.
		addImportedServiceFilter(name, filter);
	}

	private void addLazyImportedServiceFilters() {
		boolean lazy = isLazy();
		if (lazy == false)
			return;  // Early return.

		LazyBundeActivatorProperties properties = getLazyBundleActivatorProperties();
		List/*<String>*/ names = properties.getImportedServiceNames();
		Iterator/*<String>*/ iterator = names.iterator();

		while (iterator.hasNext() == true) {
			String name = (String) iterator.next();
			addLazyImportedServiceFilter(name);
		}
	}

	/**
	 * <i>Configuration API:</i> Add an LDAP filter to an optional imported
	 * service.  For example:
	 *
	 * <pre>
	 * protected void start() {
	 *     BundleContext context = getBundleContext();
	 *     addOptionalImportedServiceFilter(YourService.SERVICE_NAME, "(o=IBM)");
	 * }
	 * </pre>
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#addOptionalImportedServiceFilter(java.lang.String, java.lang.String)
	 */
	protected final void addOptionalImportedServiceFilter(String name, String filterString) {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.addOptionalImportedServiceFilter(name, filterString);
	}

	/**
	 * Get the imported service names.  This is the a basic implementation that
	 * collects the imported service names by delegating to the subclass.
	 *
	 * @return An array of imported service names.
	 */
	protected final String[] basicGetImportedServiceNames() {
		Set/*<String>*/ serviceNames = collectImportedServiceNames();
		String[] result = toStringArray(serviceNames);
		return result;
	}

	/**
	 * Get the optional imported service names.  This is the a basic
	 * implementation that collects the optional imported service names by
	 * delegating to the subclass.
	 *
	 * @return An array of optional imported service names.
	 */
	protected final String[] basicGetOptionalImportedServiceNames() {
		Set/*<String>*/ serviceNames = collectOptionalImportedServiceNames();
		String[] result = toStringArray(serviceNames);
		return result;
	}

	private void basicStart() {
		addLazyImportedServiceFilters();
	}

	/**
	 * Check that the named imported service is not <code>null</code>.  Since
	 * the method <code>getImportedService(String)</code> should never return
	 * <code>null</code>, this method provides some sanity checking for
	 * developers.  This method checks for cases where the instance is also an
	 * instance of <code>IManagedServiceFactoryAdvisor</code>; see the
	 * <code>BundleActivationManager</code> method with the same name that does
	 * more basic checking.
	 *
	 * @param name     The name of the service.
	 * @param service  The service object.
	 *
	 * @see org.eclipse.soda.sat.core.internal.framework.bundle.BundleActivationManager#checkImportedServiceIsNotNull(java.lang.String, java.lang.Object)
	 */
	private void checkImportedServiceIsNotNull(String name, Object service) {
		if (service != null)
			return;  // Early return.
		if (this instanceof IManagedServiceFactoryAdvisor == false) // $codepro.audit.disable useOfInstanceOfWithThis
			return;  // Early return.
		WarningMessageUtility utility = WarningMessageUtility.getInstance();
		String component = Messages.getString(BaseBundleActivator.SAT_CORE_KEY);
		Object source = getBundleSymbolicName();
		String label = Messages.getString(BaseBundleActivator.SERVICE_KEY);
		String warning = Messages.getString(BaseBundleActivator.FAILED_TO_GET_IMPORTED_SERVICE_KEY);
		utility.warn(component, source, warning, label, name);
	}

	private Set/*<String>*/ collectImportedServiceNames() {
		Set/*<String>*/ serviceNames = new HashSet/*<String>*/(13);
		collectImportedServiceNames(serviceNames);
		collectLazyImportedServiceNames(serviceNames);
		return serviceNames;
	}

	/**
	 * <i>Hook API:</i> This method is extended by subclasses that have
	 * required imported services.  <b>Note:</b> This method is an alternative
	 * to implementing <code>getImportedServiceNames()</code>.
	 *
	 * @param serviceNames  A <code>Set</code> into which collected service
	 *                      names must be added.
	 */
	protected void collectImportedServiceNames(Set/*<String>*/ serviceNames) {
		// No-op
	}

	private void collectLazyImportedServiceNames(Set/*<String>*/ serviceNames) {
		boolean lazy = isLazy();
		if (lazy == false)
			return;  // Early return.
		List/*<String>*/ lazyServiceNames = getLazyImportedServiceNames();
		serviceNames.addAll(lazyServiceNames);
	}

	private Set/*<String>*/ collectOptionalImportedServiceNames() {
		Set/*<String>*/ serviceNames = new HashSet/*<String>*/(13);
		collectOptionalImportedServiceNames(serviceNames);
		return serviceNames;
	}

	/**
	 * <i>Hook API:</i> This method is extended by subclasses that have
	 * optional imported services.  <b>Note:</b> This method is an alternative
	 * to implementing <code>getOptionalImportedServiceNames()</code>.
	 *
	 * @param serviceNames  A <code>Set</code> into which collected service
	 *                      names must be added.
	 */
	protected void collectOptionalImportedServiceNames(Set/*<String>*/ serviceNames) {
		// No-op
	}

	/**
	 * Create an owner for the bundle activation manager.  The owner simple
	 * provides a conduit between the <code>BaseBundleActivator</code> instance
	 * and its <code>BundleActivattionManager</code>.
	 *
	 * @return An IBundleActivationManagerOwner.
	 */
	private IBundleActivationManagerOwner createBundleActivationManagerOwner() {
		return new IBundleActivationManagerOwner() {
			public void activate() {
				BaseBundleActivator.this.activate();
			}

			public void deactivate() {
				BaseBundleActivator.this.deactivate();
			}

			public int getAsyncStartPriority() {
				return BaseBundleActivator.this.getAsyncStartPriority();
			}

			public String[] getImportedServiceNames() {
				return BaseBundleActivator.this.getImportedServiceNames();
			}

			public String[] getOptionalImportedServiceNames() {
				return BaseBundleActivator.this.getOptionalImportedServiceNames();
			}

			public InputStream getPropertiesInputStream() throws IOException {
				return BaseBundleActivator.this.getPropertiesInputStream();
			}

			public void handleAcquiredOptionalImportedService(String serviceName, Object service) {
				BaseBundleActivator.this.handleAcquiredOptionalImportedService(serviceName, service);
			}

			public boolean handleException(Exception exception) {
				return BaseBundleActivator.this.handleException(exception);
			}

			public void handleFailedToFindProperties(String filename) {
				BaseBundleActivator.this.handleFailedToFindProperties(filename);
			}

			public void handleReleasedOptionalImportedService(String serviceName, Object service) {
				BaseBundleActivator.this.handleReleasedOptionalImportedService(serviceName, service);
			}

			public boolean isStartAsync() {
				return BaseBundleActivator.this.isStartAsync();
			}

			public boolean isTransient() {
				return BaseBundleActivator.this.isTransient();
			}

			public boolean isUninstallable() {
				return BaseBundleActivator.this.isUninstallable();
			}

			public void start() throws Exception {
				BaseBundleActivator.this.basicStart();
				BaseBundleActivator.this.start();
			}

			public void stop() throws Exception {
				BaseBundleActivator.this.stop();
			}
		};
	}

	/**
	 * <i>Hook API:</i> You have been deactivated.  Concrete subclasses
	 * sometimes override this method to execute domain specific deactivation.
	 * For example:
	 *
	 * <pre>
	 * protected void deactivate() {
	 *     MyDomainObject object = (MyDomainObject) getExportedService(MyService.SERVICE_NAME);
	 *     object.shutdown();
	 * }
	 * </pre>
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#deactivate()
	 */
	protected void deactivate() {
		//...
	}

	/**
	 * <i>Configuration Parameter API:</i> Get the async start thread
	 * priority.  This method is overridden by bundles that have overridden the
	 * method <code>isStartAsync()</code> to return <code>true</code> and wish
	 * to specify a thread priority other than <code>Thread.NORM_PRIORITY
	 * </code>.  For example:
	 *
	 * <pre>
	 * protected int getAsyncStartPriority() {
	 *     return Thread.NORM_PRIORITY + 1;
	 * }
	 * </pre>
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#getAsyncStartPriority()
	 */
	protected int getAsyncStartPriority() {
		return Thread.NORM_PRIORITY;
	}

	/**
	 * <i>OSGi Query API:</i> Get the bundle.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getBundle()
	 */
	protected final Bundle getBundle() {
		IBundleActivationManager manager = getBundleActivationManager();
		Bundle bundle = manager.getBundle();
		return bundle;
	}

	/**
	 * Protected bundleActivationManager getter.
	 *
	 * @return The IBundleActivationManager.
	 */
	protected final IBundleActivationManager getBundleActivationManager() {
		return bundleActivationManager;
	}

	/**
	 * <i>OSGi Query API:</i> Get the bundle context.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getBundleContext()
	 */
	protected final BundleContext getBundleContext() {
		IBundleActivationManager manager = getBundleActivationManager();
		BundleContext bundleContext = manager.getBundleContext();
		return bundleContext;
	}

	/**
	 * <i>OSGi Query API:</i> Query the bundle's manifest for its
	 * <code>Bundle-SymbolicName</code> header.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getBundleSymbolicName()
	 */
	protected final String getBundleSymbolicName() {
		IBundleActivationManager manager = getBundleActivationManager();
		String name = manager.getBundleSymbolicName();
		return name;
	}

	/**
	 * <i>Persistent Bundle Storage API:</i> Get the bundle's private data
	 * directory.  The data directory is where it stores persistent
	 * data files.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getDataDirectory()
	 */
	protected final File getDataDirectory() {
		IBundleActivationManager manager = getBundleActivationManager();
		File file = manager.getDataDirectory();
		return file;
	}

	/**
	 * <i>Persistent Bundle Storage API:</i> Open a data file contained in
	 * the bundle's private data directory.  If the file does not exist, then it
	 * is created.  The data file resides persistently in the bundle's private
	 * data directory within the bundle store.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getDataFile(java.lang.String)
	 */
	protected final File getDataFile(String filename) {
		IBundleActivationManager manager = getBundleActivationManager();
		File file = manager.getDataFile(filename);
		return file;
	}

	/**
	 * <i>Query API:</i> Get a named exported service object.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getExportedService(java.lang.String)
	 */
	protected final Object getExportedService(String name) {
		IBundleActivationManager manager = getBundleActivationManager();
		Object service = manager.getExportedService(name);
		return service;
	}

	/**
	 * <i>Query API:</i> Answers the names of all the services that are
	 * documented in the bundle's manifest as exported.
	 *
	 * @return Array of String service names.
	 * @deprecated OSGi R4 has deprecated the Export-Service header.
	 */
	protected final String[] getExportedServiceNamesFromManifest() {
		IBundleActivationManager manager = getBundleActivationManager();
		String[] names = manager.getExportedServiceNamesFromManifest();
		return names;
	}

	/**
	 * <i>Query API:</i> Answers the properties of an exported service.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getExportedServiceProperties(java.lang.String)
	 */
	protected final Dictionary getExportedServiceProperties(String name) {
		IBundleActivationManager manager = getBundleActivationManager();
		Dictionary properties = manager.getExportedServiceProperties(name);
		return properties;
	}

	/**
	 * <i>Query API:</i> Answers the properties of a specific exported
	 * service.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getExportedServiceProperties(java.lang.String, java.lang.Object)
	 */
	protected final Dictionary getExportedServiceProperties(String name, Object service) {
		IBundleActivationManager manager = getBundleActivationManager();
		Dictionary properties = manager.getExportedServiceProperties(name, service);
		return properties;
	}

	/**
	 * <i>Query API:</i> Query the exported services.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getExportedServices()
	 */
	protected final Map/*<String, List<Object>>*/ getExportedServices() {
		IBundleActivationManager manager = getBundleActivationManager();
		Map/*<String, List<Object>>*/ map = manager.getExportedServices();
		return map;
	}

	/**
	 * <i>Query API:</i> Query the exported services.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getExportedServices(java.lang.String)
	 */
	protected final Object[] getExportedServices(String name) {
		IBundleActivationManager manager = getBundleActivationManager();
		Object[] services = manager.getExportedServices(name);
		return services;
	}

	/**
	 * <i>Query API:</i> Create an input stream on the default properties
	 * file.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getFilePropertiesInputStream()
	 */
	protected final InputStream getFilePropertiesInputStream() throws IOException {
		IBundleActivationManager manager = getBundleActivationManager();
		InputStream stream = manager.getFilePropertiesInputStream();
		return stream;
	}

	/**
	 * <i>Query API:</i> Create an input stream on the specified properties
	 * file.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getFilePropertiesInputStream(java.lang.String)
	 */
	protected final InputStream getFilePropertiesInputStream(String filename) throws IOException {
		IBundleActivationManager manager = getBundleActivationManager();
		InputStream stream = manager.getFilePropertiesInputStream(filename);
		return stream;
	}

	/**
	 * <i>Query API:</i> Get the named imported service.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getImportedService(java.lang.String)
	 */
	protected final Object getImportedService(String name) {
		IBundleActivationManager manager = getBundleActivationManager();
		Object service = manager.getImportedService(name);
		checkImportedServiceIsNotNull(name, service);
		return service;
	}

	/**
	 * <i>Query API:</i> Search for an imported service filter.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getImportedServiceFilter(java.lang.String)
	 */
	protected final Filter getImportedServiceFilter(String name) {
		IBundleActivationManager manager = getBundleActivationManager();
		Filter filter = manager.getImportedServiceFilter(name);
		return filter;
	}

	/**
	 * <i>Query API:</i> Answers the names of all the services that are
	 * imported by the bundle.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#getImportedServiceNames()
	 */
	protected String[] getImportedServiceNames() {
		String[] serviceNames = basicGetImportedServiceNames();
		return serviceNames;
	}

	/**
	 * <i>Query API:</i> Answers the names of all the services that are
	 * documented in the bundle's manifest as imported.
	 *
	 * @return Array of String service names.
	 * @deprecated OSGi R4 has deprecated the Import-Service header.
	 */
	protected final String[] getImportedServiceNamesFromManifest() {
		IBundleActivationManager manager = getBundleActivationManager();
		String[] names = manager.getImportedServiceNamesFromManifest();
		return names;
	}

	/**
	 * <i>Query API:</i> Get the value of an imported service's property.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getImportedServiceProperty(java.lang.String, java.lang.String)
	 */
	protected final Object getImportedServiceProperty(String name, String key) {
		IBundleActivationManager manager = getBundleActivationManager();
		Object value = manager.getImportedServiceProperty(name, key);
		return value;
	}

	/**
	 * <i>Query API:</i> Get the keys of an imported service's properties.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getImportedServicePropertyKeys(java.lang.String)
	 */
	protected final String[] getImportedServicePropertyKeys(String name) {
		IBundleActivationManager manager = getBundleActivationManager();
		String[] keys = manager.getImportedServicePropertyKeys(name);
		return keys;
	}

	/**
	 * <i>Query API:</i> Query the imported services.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getImportedServices()
	 */
	protected final Map/*<String, List<Object>>*/ getImportedServices() {
		IBundleActivationManager manager = getBundleActivationManager();
		Map/*<String, List<Object>>*/ map = manager.getImportedServices();
		return map;
	}

	private LazyBundeActivatorProperties getLazyBundleActivatorProperties() {
		synchronized (this) {
			if (lazyBundeActivatorProperties == null) {
				BundleContext context = getBundleContext();
				setLazyBundleActivatorProperties(new LazyBundeActivatorProperties(context));
			}

			return lazyBundeActivatorProperties;
		}
	}

	private List/*<String>*/ getLazyImportedServiceNames() {
		LazyBundeActivatorProperties properties = getLazyBundleActivatorProperties();
		List/*<String>*/ serviceNames = properties.getImportedServiceNames();
		return serviceNames;
	}

	/**
	 * <i>Query API:</i> Get the named optional imported service.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getOptionalImportedService(java.lang.String)
	 */
	protected final Object getOptionalImportedService(String name) {
		IBundleActivationManager manager = getBundleActivationManager();
		Object service = manager.getOptionalImportedService(name);
		return service;
	}

	/**
	 * <i>Query API:</i> Search for an optional imported service filter.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getOptionalImportedServiceFilter(java.lang.String)
	 */
	protected final Filter getOptionalImportedServiceFilter(String name) {
		IBundleActivationManager manager = getBundleActivationManager();
		Filter filter = manager.getOptionalImportedServiceFilter(name);
		return filter;
	}

	/**
	 * <i>Query API:</i> Answers the names of all the services that are
	 * optionally imported by the bundle.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#getOptionalImportedServiceNames()
	 */
	protected String[] getOptionalImportedServiceNames() {
		String[] serviceNames = basicGetOptionalImportedServiceNames();
		return serviceNames;
	}

	/**
	 * <i>Query API:</i> Get the value of an optional imported service's
	 * property.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getOptionalImportedServiceProperty(java.lang.String, java.lang.String)
	 */
	protected final Object getOptionalImportedServiceProperty(String name, String key) {
		IBundleActivationManager manager = getBundleActivationManager();
		Object value = manager.getOptionalImportedServiceProperty(name, key);
		return value;
	}

	/**
	 * <i>Query API:</i> Get the keys of an optional imported service's
	 * properties.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getOptionalImportedServicePropertyKeys(java.lang.String)
	 */
	protected final String[] getOptionalImportedServicePropertyKeys(String name) {
		IBundleActivationManager manager = getBundleActivationManager();
		String[] keys = manager.getOptionalImportedServicePropertyKeys(name);
		return keys;
	}

	/**
	 * <i>Query API:</i> Query the optional imported services.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getOptionalImportedServices()
	 */
	protected final Map/*<String, List<Object>>*/ getOptionalImportedServices() {
		IBundleActivationManager manager = getBundleActivationManager();
		Map/*<String, List<Object>>*/ map = manager.getOptionalImportedServices();
		return map;
	}

	/**
	 * <i>Query API:</i> Create a <code>Properties</code> object out of the
	 * bundle's properties.  The properties are obtained using the query method
	 * <code>getPropertiesInputStream()</code>, which is typically overridden by
	 * subclasses that define properties.
	 *
	 * @return The bundle's properties.
	 */
	protected final Properties getProperties() {
		IBundleActivationManager manager = getBundleActivationManager();
		Properties properties = manager.getProperties();
		return properties;
	}

	/**
	 * <i>Hook API:</i> Get an input stream to the bundle's properties.  This
	 * method is overridden by subclasses that possess properties.  For example,
	 * if the properties file is stored as a resource in the same package as the
	 * <code>BundleActivator</code>:
	 *
	 * <pre>
	 * protected InputStream getPropertiesInputStream() throws IOException {
	 *     return getResourcePropertiesInputStream();
	 * }
	 * </pre>
	 *
	 * And if the properties are stored as a file in the local file system:
	 *
	 * <pre>
	 * protected InputStream getPropertiesInputStream() throws IOException {
	 *     return getFilePropertiesInputStream();
	 * }
	 * </pre>
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#getPropertiesInputStream()
	 */
	protected InputStream getPropertiesInputStream() throws IOException {
		return null;
	}

	/**
	 * <i>Query API:</i> Get the value of a property.
	 *
	 * @param key          The property key.
	 * @param defaultValue The default value for the property.
	 * @return The value of the property, or the default value if the key is
	 * not found.
	 */
	protected String getProperty(String key, String defaultValue) {
		IBundleActivationManager manager = getBundleActivationManager();
		String value = manager.getProperty(key, defaultValue);
		return value;
	}

	/**
	 * <i>Query API:</i> Create an input stream on the default resource
	 * properties.
	 *
	 * @throws java.io.IOException
	 * @return An input stream to the default resource properties.
	 */
	protected final InputStream getResourcePropertiesInputStream() throws IOException {
		String symbolicName = getBundleSymbolicName();  // OSGi Query Method.
		int length = symbolicName.length() + 11;
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(length);
		buffer.append(symbolicName);
		buffer.append(".properties");  //$NON-NLS-1$
		String filename = buffer.toString();
		InputStream stream = getResourcePropertiesInputStream(filename);  // Query Method.
		return stream;
	}

	/**
	 * <i>Query API:</i> Create an input stream on the specified resource
	 * file.
	 *
	 * @param filename  The name of the properties resource file.
	 * @throws java.io.IOException
	 * @return An input stream to the resource properties.
	 */
	protected final InputStream getResourcePropertiesInputStream(String filename) throws IOException {
		Class clazz = getClass();
		InputStream stream = clazz.getResourceAsStream(filename);

		if (stream == null) {
			WarningMessageUtility utility = WarningMessageUtility.getInstance();
			String component = Messages.getString(BaseBundleActivator.SAT_CORE_KEY);
			Bundle bundle = getBundle();  // OSGi Query Method.
			Object source = bundle.getSymbolicName();
			String warning = Messages.getString(BaseBundleActivator.FAILED_TO_FIND_PROPERTIES_RESOURCE_KEY);
			String label = Messages.getString(BaseBundleActivator.RESOURCE_KEY);
			utility.warn(component, source, warning, label, filename);
		} else {
			stream = new BufferedInputStream(stream);
		}

		return stream;
	}

	/**
	 * <i>Hook Handler API:</i> When an optional imported service is acquired,
	 * this method is called.  Subclasses should override this method to handle
	 * the domain specific case where an optional imported service is acquired.
	 * For example:
	 *
	 * <pre>
	 * protected void handleAcquiredOptionalImportedService(String serviceName, Object service) {
	 *     if (serviceName.equals(PrinterApplicationService.SERVICE_NAME)) {
	 *         PrinterApplicationWindow window = getWindow();
	 *         PrinterApplicationService model = (PrinterApplicationService) service;
	 *         window.setModel(model);
	 *     } else {
	 *         super.handleAcquiredOptionalImportedService(serviceName, service);
	 *     }
	 * }
	 * </pre>
	 *
	 * Since all acquired optional imported services will arrive via this
	 * method, it is important to separately handle each imported service.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#handleAcquiredOptionalImportedService(java.lang.String, java.lang.Object)
	 */
	protected void handleAcquiredOptionalImportedService(String serviceName, Object service) {
		warnShouldHaveOverriddenMethod("handleAcquiredOptionalImportedService(String, Object)");  //$NON-NLS-1$
	}

	/**
	 * <i>Hook Handler API:</i> Handles a thrown exception.  This method can
	 * be overridden by subclasses that wish to handle thrown exceptions
	 * themselves.
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#handleException(java.lang.Exception)
	 */
	protected boolean handleException(Exception exception) {
		exception.printStackTrace();
		return false;
	}

	/**
	 * <i>Hook Handler API:</i> Handle the fact that the specified properties
	 * file could not be found.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#handleFailedToFindProperties(java.lang.String)
	 */
	protected void handleFailedToFindProperties(String filename) {
		WarningMessageUtility utility = WarningMessageUtility.getInstance();
		String component = Messages.getString(BaseBundleActivator.SAT_CORE_KEY);
		Bundle bundle = getBundle();  // OSGi Query Method.
		Object source = bundle.getSymbolicName();
		String warning = Messages.getString(BaseBundleActivator.FAILED_TO_FIND_PROPERTIES_FILE_KEY);
		String label = Messages.getString(BaseBundleActivator.FILENAME_KEY);
		utility.warn(component, source, warning, label, filename);
	}

	/**
	 * <i>Hook Handler API:</i> When an optional imported service is released,
	 * this method is called.  Subclasses should override this method to handle
	 * the domain specific case where an optional imported service is released.
	 * For example:
	 *
	 * <pre>
	 * protected void handleReleasedOptionalImportedService(String serviceName, Object service) {
	 *     if (serviceName.equals(PrinterApplicationService.SERVICE_NAME)) {
	 *         PrinterApplicationWindow window = getWindow();
	 *         window.setModel(null);
	 *     } else {
	 *         super.handleReleasedOptionalImportedService(serviceName, service);
	 *     }
	 * }
	 * </pre>
	 *
	 * Since all acquired optional imported services will arrive via this
	 * method, it is important to separately handle each imported service.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#handleReleasedOptionalImportedService(java.lang.String, java.lang.Object)
	 */
	protected void handleReleasedOptionalImportedService(String serviceName, Object service) {
		warnShouldHaveOverriddenMethod("handleReleasedOptionalImportedService(String, Object)");  //$NON-NLS-1$
	}

	private boolean isLazy() {
		Bundle bundle = getBundle();
		BundleManifestUtility utility = BundleManifestUtility.getInstance();
		String bundleActivator = utility.getBundleActivator(bundle);
		boolean lazy = BaseBundleActivator.LAZY_BUNDLE_ACTIVATOR.equals(bundleActivator);
		return lazy;
	}

	/**
	 * <i>Configuration Parameter API:</i> Specifies whether the bundle
	 * should start asynchronously.  This method should be overridden by
	 * bundles that wish to start asynchronously.  For example:
	 *
	 * <pre>
	 * protected boolean isStartAsync() {
	 *     return true;
	 * }
	 * </pre>
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#isStartAsync()
	 */
	protected boolean isStartAsync() {
		return false;
	}

	/**
	 * <i>Configuration Parameter API:</i> Specify whether the bundle should
	 * be treated as transient.  Transient bundles are automatically uninstalled
	 * once they have started and entered the <code>Bundle.ACTIVE</code> state.
	 * This method should be overridden by bundles that are to be considered
	 * transient.  For example:
	 *
	 * <pre>
	 * protected boolean isTransient() {
	 *     return true;
	 * }
	 * </pre>
	 *
	 * <i>Note:</i>
	 * <ul>
	 *   <li>
	 *     A transient bundle typically does not export any services.
	 *   </li>
	 *   <li>
	 *     It makes no sense for a transient bundle to also override the
	 *     method <code>isUninstallable()</code>.
	 *   </li>
	 * </ul>
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#isTransient()
	 */
	protected boolean isTransient() {
		return false;
	}

	/**
	 * <i>Configuration Parameter API:</i> Specify whether the bundle should
	 * be treated as uninstalled.  Uninstalled bundles are automatically
	 * uninstalled when their last dependent bundle is uninstalled.  This method
	 * should be overridden to return <code>true</code> by bundles that are
	 * uninstallable prerequisites.  For example:
	 *
	 * <pre>
	 * protected boolean isUninstallable() {
	 *     return true;
	 * }
	 * </pre>
	 *
	 * <p>
	 * <i>Note:</i>
	 * <ul>
	 *   <li>
	 *     An uninstallable bundle is always a prerequisite of another bundle.
	 *   </li>
	 *   <li>
	 *     It makes no sense for an uninstallable bundle to also override the
	 *     method <code>isTransient()</code>.
	 *   </li>
	 * </ul>
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#isUninstallable()
	 */
	protected boolean isUninstallable() {
		return false;
	}

	/**
	 * <i>Configuration API:</i> Release the specified  imported services.  This
	 * method is typically <i>not used by subclasses</i>, except in rare cases.
	 * For example, when a bundle imports multiple services using filters, and
	 * needs to change <i>multiple</i> filters atomically.  Before calling the
	 * method <code>addImportedServiceFilter(String, String)</code> to change
	 * the filter for each imported service, it is necessary to call the method
	 * <code>releaseImportedService(String)</code> for each imported service
	 * that has a filter first.  Once the filters have been changed, call the
	 * method <code>acquireImportedService(String)</code> for each imported
	 * service that has a filter to re-acquire the imported services.  Doing so
	 * ensures that the bundle only ever atomically acquires services with the
	 * the appropriate filters.
	 *
	 * <pre>
	 * ...
	 * try {
	 *   releaseImportedService(VendorService.SERVICE_NAME);
	 *   releaseImportedService(NapkinService.SERVICE_NAME);
	 *   addImportedServiceFilter(VendorService.SERVICE_NAME, "(spiciness=5)");
	 *   addImportedServiceFilter(NapkinService.SERVICE_NAME, "(ply=2)");
	 * } finally {
	 *   acquireImportedService(VendorService.SERVICE_NAME);
	 *   acquireImportedService(NapkinService.SERVICE_NAME);
	 * }
	 * ...
	 * </pre>
	 *
	 * Using <code>try</code>/<code>finally</code> is not strictly necessary,
	 * but does nicely ensure that the imported services will always be
	 * re-acquired in the face of a thrown exception, however unlikely.
	 *
	 * @param name  The name of an imported service.
	 *
	 * @see BaseBundleActivator#acquireImportedService(java.lang.String)
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#releaseImportedService(java.lang.String)
	 */
	protected final void releaseImportedService(String name) {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.releaseImportedService(name);
	}

	/**
	 * <i>Configuration API:</i> Release all the imported services.  This
	 * method is typically <i>not used by subclasses</i>, except in rare cases.
	 * For example, when a bundle imports multiple services using filters, and
	 * needs to change <i>multiple</i> filters atomically.  Before calling the
	 * method <code>addImportedServiceFilter(String, String)</code> to change
	 * the filter for each imported service, it is necessary to call the method
	 * <code>releaseImportedServices()</code> first.  Once both filters have
	 * been changed, call the method <code>acquireImportedServices()</code> to
	 * re-acquire the services.  Doing so ensures that the bundle only ever
	 * atomically acquires services with appropriate filters.
	 *
	 * <pre>
	 * ...
	 * try {
	 *   releaseImportedServices();
	 *   addImportedServiceFilter(VendorService.SERVICE_NAME, "(spiciness=5)");
	 *   addImportedServiceFilter(NapkinService.SERVICE_NAME, "(ply=2)");
	 * } finally {
	 *   acquireImportedServices();
	 * }
	 * ...
	 * </pre>
	 *
	 * Using <code>try</code>/<code>finally</code> is not strictly necessary,
	 * but does nicely ensure that the imported services will always be
	 * re-acquired in the face of a thrown exception, however unlikely.
	 *
	 * @see BaseBundleActivator#acquireImportedServices()
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#releaseImportedServices()
	 */
	protected final void releaseImportedServices() {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.releaseImportedServices();
	}

	/**
	 * <i>Configuration API:</i> Release all the optional imported services.
	 *
	 * @see BaseBundleActivator#acquireOptionalImportedServices()
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#releaseOptionalImportedServices()
	 */
	protected final void releaseOptionalImportedServices() {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.releaseOptionalImportedServices();
	}

	/**
	 * <i>Configuration API:</i> Remove the exported service record of the
	 * specified type.
	 * <p>
	 * <i>Note:</i> All exported services are automatically removed by SAT when
	 * the bundle is deactivated.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#removeExportedService(java.lang.String)
	 */
	protected final void removeExportedService(String name) {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.removeExportedService(name);
	}

	/**
	 * <i>Configuration API:</i> Removes the specified exported service.
	 * <p>
	 * <i>Note:</i> All exported services are automatically removed by SAT when
	 * the bundle is deactivated.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#removeExportedService(java.lang.String, java.lang.Object)
	 */
	protected final void removeExportedService(String name, Object service) {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.removeExportedService(name, service);
	}

	/**
	 * <i>Configuration API:</i> Remove the named exported service domain
	 * object.  While this method is visible to subclasses, it is not typically
	 * used.
	 * <p>
	 * <i>Note:</i> All exported services are automatically removed by SAT when
	 * the bundle is deactivated.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#removeExportedServices(java.lang.String)
	 */
	protected final void removeExportedServices(String name) {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.removeExportedServices(name);
	}

	/**
	 * <i>Configuration API:</i> Removes the LDAP filter for an imported
	 * service.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#removeImportedServiceFilter(java.lang.String)
	 */
	protected final void removeImportedServiceFilter(String name) {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.removeImportedServiceFilter(name);
	}

	/**
	 * <i>Configuration API:</i> Removes the LDAP filter for an optional
	 * imported service.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#removeOptionalImportedServiceFilter(java.lang.String)
	 */
	protected final void removeOptionalImportedServiceFilter(String name) {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.removeOptionalImportedServiceFilter(name);
	}

	/**
	 * <i>OSGi Framework API:</i> Stop and restart the OSGi framework.  If
	 * the bundle has been stopped, this method does nothing.
	 * <p>
	 * <b>Note</b>: Sadly, this method does not work on Equinox 3.3.0. See
	 * Eclipse bug <a href="https://bugs.eclipse.org/bugs/show_bug.cgi?id=128531">128531</a>
	 * for more details.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#restartFramework()
	 */
	protected final void restartFramework() throws BundleException {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.restartFramework();
	}

	/**
	 * Private bundleActivationManager setter.
	 *
	 * @param bundleActivationManager  An IBundleActivationManager.
	 */
	private void setBundleActivationManager(IBundleActivationManager bundleActivationManager) {
		this.bundleActivationManager = bundleActivationManager;
	}

	/**
	 * <i>Configuration API:</i> Sets the properties of an exported service.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#setExportedServiceProperties(String, java.util.Dictionary)
	 */
	protected final void setExportedServiceProperties(String name, Dictionary properties) {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.setExportedServiceProperties(name, properties);
	}

	/**
	 * <i>Configuration API:</i> Sets the properties of an exported service.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#setExportedServiceProperties(java.lang.String, java.lang.Object, java.util.Dictionary)
	 */
	protected final void setExportedServiceProperties(String name, Object service, Dictionary properties) {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.setExportedServiceProperties(name, service, properties);
	}

	private void setLazyBundleActivatorProperties(LazyBundeActivatorProperties lazyBundeActivatorProperties) {
		this.lazyBundeActivatorProperties = lazyBundeActivatorProperties;
	}

	/**
	 * <i>OSGi Framework API:</i> Shutdown the OSGi framework.  If the bundle
	 * has been stopped, this method does nothing.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#shutdownFramework()
	 */
	protected final void shutdownFramework() throws BundleException {
		IBundleActivationManager manager = getBundleActivationManager();
		manager.shutdownFramework();
	}

	/**
	 * <i>Hook API:</i> This method is called by <code>start(BundleContext)
	 * </code>.  This method is typically overridden by subclasses that wish to
	 * perform behavior exactly once when the bundle starts. For example:
	 *
	 * <pre>
	 * protected void start() {
	 *     PrinterApplicationWindow window = getWindow();
	 *     WindowListener listener = getWindowListener();
	 *     window.addWindowListener(listener);
	 *     window.open();
	 * }
	 * </pre>
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#start()
	 */
	protected void start() throws Exception {
		//...
	}

	/**
	 * <i>Bundle Activator API:</i> This is where the bundle activator starts
	 * its execution.
	 *
	 * @see org.osgi.framework.BundleActivator#start(org.osgi.framework.BundleContext)
	 */
	public final void start(BundleContext bundleContext) throws Exception {
		FactoryUtility utility = FactoryUtility.getInstance();
		IBundleActivationManager manager = utility.createBundleActivationManager();
		setBundleActivationManager(manager);
		IBundleActivationManagerOwner owner = createBundleActivationManagerOwner();
		manager.start(bundleContext, owner);
	}

	/**
	 * <i>Hook API:</i> This method is called by <code>stop(BundleContext)
	 * </code>.  This method is overridden by subclasses that wish to perform
	 * behavior exactly once when the bundle stops.
	 * For example:
	 *
	 * <pre>
	 * protected void stop() {
	 *     PrinterApplicationWindow window = getWindow();
	 *     window.close();
	 *     WindowListener listener = getWindowListener();
	 *     window.removeWindowListener(listener);
	 * }
	 * </pre>
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#stop()
	 */
	protected void stop() throws Exception {
		//...
	}

	/**
	 * <i>Bundle Activator API:</i> This is where the bundle activator stops
	 * its execution.
	 *
	 * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundleContext)
	 */
	public final void stop(BundleContext bundleContext) throws Exception {
		IBundleActivationManager manager = getBundleActivationManager();
		if (manager == null)
			return;  // Early return.
		manager.stop();
		setBundleActivationManager(null);
	}

	private String[] toStringArray(Set/*<String>*/ setOfStrings) {
		int size = setOfStrings.size();
		if (size == 0)
			return BaseBundleActivator.NO_SERVICES;  // Early return.
		String[] result = new String [ size ];
		setOfStrings.toArray(result);
		Arrays.sort(result);
		return result;
	}

	/**
	 * Warn that the named method should have been overridden.
	 *
	 * @param method  The method signature of the method that should have been
	 *                overridden.
	 */
	private void warnShouldHaveOverriddenMethod(String method) {
		WarningMessageUtility utility = WarningMessageUtility.getInstance();
		boolean warn = utility.isOn();
		if (warn == false)
			return;  // Early return.

		String component = Messages.getString(BaseBundleActivator.SAT_CORE_KEY);
		Bundle bundle = getBundle();  // OSGi Query Method.
		Object source = bundle.getSymbolicName();
		String pattern = Messages.getString(BaseBundleActivator.SHOULD_HAVE_OVERRIDDEN_METHOD_KEY);
		String warning = MessageFormatter.format(pattern, method);
		utility.warn(component, source, warning, null, null);
	}
}