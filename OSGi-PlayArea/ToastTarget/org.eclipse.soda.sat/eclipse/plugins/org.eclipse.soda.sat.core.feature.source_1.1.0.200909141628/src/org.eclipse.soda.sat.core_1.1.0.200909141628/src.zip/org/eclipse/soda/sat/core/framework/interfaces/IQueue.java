/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework.interfaces;

/**
 * The <code>IQueue</code> interface defines a FIFO container.  An instance of
 * <code>IQueue</code> can be created using the <code>FactoryUtility</code>
 * singleton.
 *
 * <pre>
 * FactoryUtility utility = FactoryUtility.getInstance();
 * IQueue queue = utility.createQueue(10);
 * </pre>
 *
 * Objects are added to the queue using the <code>add(Object)</code> method.
 *
 * <pre>
 * queue.add("Monday");
 * queue.add("Tuesday");
 * queue.add("Wednesday");
 * </pre>
 *
 * Objects are removed from the queue using the <code>remove()</code> method
 * that blocks while the queue is empty.
 *
 * <pre>
 * try {
 *   while (true) {
 *     String day = (String) queue.remove();
 *     processDay(day);
 *   }
 * } catch (InterruptedException exception);
 *   // OK
 * }
 * </pre>
 *
 * Object can also be removed from the queue using the <code>remove(long)</code>
 * method that blocks for at least the specified millisecond timeout while the
 * queue is empty.
 *
 * <pre>
 * try {
 *   while (true) {
 *     String day = (String) queue.remove(1000);  // Block for at least 1 second.
 *     if (day == null)
 *       break;  // The queue is empty.
 *     processDay(day);
 *   }
 * } catch (InterruptedException exception);
 *   // OK
 * }
 * </pre>
 *
 * @see org.eclipse.soda.sat.core.util.FactoryUtility
 */
public interface IQueue/*<T>*/ {
	/**
	 * Add the specified item to the queue.
	 *
	 * @param item  The item to add to the queue.
	 */
	public void add(Object item);

	/**
	 * Check to see if the specified item exists in the queue.
	 *
	 * @param item  The item to check for.
	 * @return True if the item exists, otherwise false.
	 */
	public boolean contains(Object item);

	/**
	 * Check to see if the queue is empty.
	 *
	 * @return True if the queue is empty, otherwise false.
	 */
	public boolean isEmpty();

	/**
	 * Remove and return the next item in the queue.  This method blocks the
	 * calling thread indefinitely while the queue is empty.
	 *
	 * @return The item removed from the queue.
	 * @throws InterruptedException
	 */
	public Object remove() throws InterruptedException;

	/**
	 * Remove and return the next item in the queue.  This method blocks the
	 * calling thread for at least the specified timeout while the queue is
	 * empty.
	 *
	 * @param timeout  The number of milliseconds to wait for the queue to no
	 * longer be empty.
	 * @return The item removed from the queue.
	 * @throws InterruptedException
	 */
	public Object remove(long timeout) throws InterruptedException;

	/**
	 * Query the size of the queue.
	 *
	 * @return The size of the queue.
	 */
	public int size();
}