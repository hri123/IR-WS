/*******************************************************************************
 * Copyright (c) 2001, 2009 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util;

import java.util.Enumeration;

import org.eclipse.soda.sat.core.framework.interfaces.ITokenizer;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.util.Assertion;

/**
 * The <code>Tokenizer</code> class tokenizes a <code>String</code> of
 * delimited values into separate <code>String</code> objects.  This class was
 * implemented after measuring the startup performance and identifying that
 * using the standard Java class <code>StringTokenizer</code> was taking an
 * excessive amount of time.
 * <p>
 * This class is implement such that it should be easy to use, especially if
 * you are already familiar with the <code>Enumeration</code> interface or the
 * <code>StringTokenizer</code> class.
 */
public class Tokenizer extends Object implements Enumeration, ITokenizer {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String INDEX_PARAMETER_MUST_BE_POSITIVE_INTEGER_KEY = "Tokenizer.IndexParameterMustBePositiveInteger";  //$NON-NLS-1$

	// Misc
	private static final char COMMA = ',';

	//
	// Instance Fields
	//

	private char delimiter;
	private int index;
	private String token;
	private String value;
	private boolean emptyTokenIsValid;
	private boolean trimToken;

	//
	// Constructors
	//

	/**
	 * Constructor
	 *
	 * @param value  The string to be tokenizer.
	 */
	public Tokenizer(String value) {
		this(value, Tokenizer.COMMA);
	}

	/**
	 * Constructor
	 *
	 * @param value      The string to be tokenized.
	 * @param delimiter  The token delimiter character.
	 */
	public Tokenizer(String value, char delimiter) {
		this(value, delimiter, 0);
	}

	/**
	 * Constructor
	 *
	 * @param value      The string to be tokenized.
	 * @param delimiter  The token delimiter character.
	 * @param index      The start index within the string.
	 */
	public Tokenizer(String value, char delimiter, int index) {
		super();
		setValue(value);
		setDelimiter(delimiter);
		setToken(null);
		checkIndex(index);
		setIndex(index);
		setEmptyTokenIsValid(true);
		setTrimToken(true);
	}

	/**
	 * Constructor
	 *
	 * @param value  The string to be tokenized.
	 * @param index  The start index within the string.
	 */
	public Tokenizer(String value, int index) {
		this(value, Tokenizer.COMMA, index);
	}

	/**
	 * Check that the specified index is legal.  The index must be >= 0.
	 *
	 * @param index  The index.
	 * @throws IllegalArgumentException
	 */
	private void checkIndex(int index) {
		if (index >= 0)
			return;  // Early return.
		String message = Messages.getString(Tokenizer.INDEX_PARAMETER_MUST_BE_POSITIVE_INTEGER_KEY);
		throw new IllegalArgumentException(message);
	}

	//
	// Instance Methods
	//

	/**
	 * Private delimiter getter.
	 *
	 * @return char
	 */
	private char getDelimiter() {
		return delimiter;
	}

	private boolean getEmptyTokenIsValid() {
		return emptyTokenIsValid;
	}

	/**
	 * Private index getter.
	 *
	 * @return int
	 */
	private int getIndex() {
		return index;
	}

	/**
	 * Get the next token from the value string.
	 *
	 * @return String
	 */
	private String getNextToken() {
		String token = null;
		String value = getValue();
		int length = value.length();
		int start = getIndex();
		boolean trim = getTrimToken();

		while (start < length && isTokenValid(token) == false) {
			char delimiter = getDelimiter();
			int stop = value.indexOf(delimiter, start);

			if (stop == -1) {
				token = value.substring(start);
				start = length;
			} else {
				token = value.substring(start, stop);
				start = stop + 1;
			}
			setIndex(start);

			if (trim == true) {
				token = token.trim();
			}
		}

		return token;
	}

	/**
	 * Private token getter.
	 *
	 * @return String
	 */
	private String getToken() {
		if (token == null) {
			token = getNextToken();
		}

		return token;
	}

	private boolean getTrimToken() {
		return trimToken;
	}

	/**
	 * Private value getter.
	 *
	 * @return String
	 */
	private String getValue() {
		return value;
	}

	/**
	 * @see java.util.Enumeration#hasMoreElements()
	 */
	public boolean hasMoreElements() {
		return hasMoreTokens();
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ITokenizer#hasMoreTokens()
	 */
	public boolean hasMoreTokens() {
		String token = getToken();
		boolean more = token != null;
		return more;
	}

	private boolean isTokenValid(String token) {
		if (token == null)
			return false;
		int length = token.length();
		if (length != 0)
			return true;
		boolean valid = getEmptyTokenIsValid();
		return valid;
	}

	/**
	 * @see java.util.Enumeration#nextElement()
	 */
	public Object nextElement() {
		return nextToken();
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ITokenizer#nextToken()
	 */
	public String nextToken() {
		String token = getToken();
		setToken(null);
		return token;
	}

	/**
	 * Private delimiter setter.
	 *
	 * @param delimiter  The delimiter character.
	 */
	private void setDelimiter(char delimiter) {
		this.delimiter = delimiter;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ITokenizer#setEmptyTokenIsValid(boolean)
	 */
	public void setEmptyTokenIsValid(boolean emptyTokenIsValid) {
		this.emptyTokenIsValid = emptyTokenIsValid;
	}

	/**
	 * Private index setter.
	 *
	 * @param index  The current index.
	 */
	private void setIndex(int index) {
		this.index = index;
	}

	/**
	 * Private token setter.
	 *
	 * @param token  The current token.
	 */
	private void setToken(String token) {
		this.token = token;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ITokenizer#setTrimToken(boolean)
	 */
	public void setTrimToken(boolean trimToken) {
		this.trimToken = trimToken;
	}

	/**
	 * Private value setter.
	 *
	 * @param value  The <code>String</code> to be tokenized.
	 */
	private void setValue(String value) {
		Assertion.checkArgumentIsNotNull(value, "value");  //$NON-NLS-1$
		this.value = value;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ITokenizer#toSynchronizedTokenizer()
	 */
	public ITokenizer toSynchronizedTokenizer() {
		return new SynchronizedTokenizer(this);
	}
}
