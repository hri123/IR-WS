/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle.cm;

import java.util.Dictionary;

import org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.osgi.framework.Constants;

/**
 * ConfigurationData.java
 */
class ConfigurationData extends Object {
	//
	// Instance Fields
	//

	private String pid;
	private IBundleActivationManager bundleActivationManager;
	private Object object;
	private Dictionary oldProperties;
	private Dictionary properties;

	//
	// Constructors
	//

	/**
	 * Constructor.
	 *
	 * @param properties  The PID's properties.
	 */
	ConfigurationData(Dictionary properties) {
		super();
		setProperties(properties);
		setPid(createPid());
		setBundleActivationManager(createBundleActivationManager());
	}

	//
	// Instance Methods
	//

	/**
	 * Create an <code>IBundleActivationManager</code>.
	 *
	 * @return An <code>IBundleActivationManager</code>.
	 */
	private IBundleActivationManager createBundleActivationManager() {
		String pid = getPid();
		FactoryUtility utility = FactoryUtility.getInstance();
		IBundleActivationManager manager = utility.createBundleActivationManager(pid);
		return manager;
	}

	private String createPid() {
		Dictionary properties = getProperties();
		String pid = (String) properties.get(Constants.SERVICE_PID);
		return pid;
	}

	/**
	 * Private bundleActivationManager getter.
	 *
	 * @return An <code>IBundleActivationManager</code>.
	 */
	IBundleActivationManager getBundleActivationManager() {
		return bundleActivationManager;
	}

	/**
	 * Private object getter.
	 *
	 * @return The managed service.
	 */
	Object getObject() {
		return object;
	}

	/**
	 * Private oldProperties getter.
	 *
	 * @return The old properties for the managed service.
	 */
	Dictionary getOldProperties() {
		return oldProperties;
	}

	private String getPid() {
		return pid;
	}

	/**
	 * Private properties getter.
	 *
	 * @return The properties for the managed service.
	 */
	Dictionary getProperties() {
		synchronized (this) {
			return properties;
		}
	}

	/**
	 * Private bundleActivationManager setter.
	 *
	 * @param bundleActivationManager  An <code>IBundleActivationManager</code>.
	 */
	private void setBundleActivationManager(IBundleActivationManager bundleActivationManager) {
		this.bundleActivationManager = bundleActivationManager;
	}

	/**
	 * Private object setter.
	 *
	 * @param object  The object.
	 */
	void setObject(Object object) {
		this.object = object;
	}

	/**
	 * Private oldProperties getter.
	 *
	 * @param oldProperties  The old properties for the managed service.
	 */
	private void setOldProperties(Dictionary oldProperties) {
		this.oldProperties = oldProperties;
	}

	private void setPid(String pid) {
		this.pid = pid;
	}

	/**
	 * Private properties getter.
	 *
	 * @param properties  The properties for the managed service.
	 */
	void setProperties(Dictionary properties) {
		synchronized (this) {
			setOldProperties(this.properties);
			this.properties = properties;
		}
	}
}
