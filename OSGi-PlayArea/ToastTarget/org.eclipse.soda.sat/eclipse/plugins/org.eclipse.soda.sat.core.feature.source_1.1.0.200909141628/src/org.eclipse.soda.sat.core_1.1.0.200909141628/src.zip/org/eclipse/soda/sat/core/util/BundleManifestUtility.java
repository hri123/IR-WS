/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.util;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.List;

import org.eclipse.soda.sat.core.framework.interfaces.ITokenizer;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.osgi.framework.Bundle;
import org.osgi.framework.Constants;
import org.osgi.service.component.ComponentConstants;

/**
 * The <code>BundleManifestUtility</code> class is a utility that simplifies
 * working with the manifest file of a <code>Bundle</code> object.
 * <p>
 * <i>Note:</i> This is a singleton class, accessible only via the static method
 * <code>getInstance()</code>.  For example:
 * <pre>
 * BundleManifestUtility utility = BundleManifestUtility.getInstance();
 * String[] packages = utility.getImportedPackages(bundle);
 * </pre>
 */
public final class BundleManifestUtility extends Object {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String DEPRECATED_EXPORTED_SERVICE_HEADER_SHOULD_NOT_BE_USED_KEY = "BundleManifestUtility.DeprecatedExportedServiceHeaderShouldNotBeUsed";  //$NON-NLS-1$
	private static final String DEPRECATED_IMPORTED_SERVICE_HEADER_SHOULD_NOT_BE_USED_KEY = "BundleManifestUtility.DeprecatedImportedServiceHeaderShouldNotBeUsed";  //$NON-NLS-1$

	// Misc
	private static final String[] NO_STRINGS = new String [ 0 ];

	// Singleton
	private static final BundleManifestUtility INSTANCE = new BundleManifestUtility();

	//
	// Static Methods
	//

	/**
	 * Public getter for the <code>BundleManifestUtility</code> singleton
	 * instance.
	 *
	 * @return The <code>BundleManifestUtility</code> singleton instance.
	 */
	public static BundleManifestUtility getInstance() {
		return BundleManifestUtility.INSTANCE;
	}

	/**
	 * Constructor.  Instances of this class cannot be created; use the static
	 * method <code>getInstance()</code>.
	 */
	private BundleManifestUtility() {
		super();
	}

	//
	// Instance Methods
	//

	/**
	 * Temporary check to make sure that a deprecated header is not used.
	 * Currently used by the methods getExportedServices(Bundle) and
	 * getImportedServices(Bundle).
	 */
	private void checkIsEmpty(Bundle bundle, String[] values, String messageKey) {
		if (values.length == 0)
			return;  // Early return.
		String id = bundle.getSymbolicName();
		String message = Messages.getString(messageKey);
		LogUtility.logWarning(id, message);
	}

	/**
	 * Answers the <code>Bundle-Activator</code> value from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code>
	 */
	public String getBundleActivator(Bundle bundle) {
		String value = getUnlocalizedHeader(bundle, Constants.BUNDLE_ACTIVATOR);
		return value;
	}

	/**
	 * Answers the <code>Bundle-Category</code> value from the bundle's MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code>
	 */
	public String getBundleCategory(Bundle bundle) {
		String value = getHeader(bundle, Constants.BUNDLE_CATEGORY);
		return value;
	}

	/**
	 * Answers the <code>Bundle-Classpath</code> value from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code>
	 */
	public String getBundleClasspath(Bundle bundle) {
		String value = getUnlocalizedHeader(bundle, Constants.BUNDLE_CLASSPATH);
		return value;
	}

	/**
	 * Answers the <code>Bundle-ContactAddress</code> value from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code>
	 */
	public String getBundleContactAddress(Bundle bundle) {
		String value = getHeader(bundle, Constants.BUNDLE_CONTACTADDRESS);
		return value;
	}

	/**
	 * Answers the <code>Bundle-Copyright</code> value from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code>
	 */
	public String getBundleCopyright(Bundle bundle) {
		String value = getHeader(bundle, Constants.BUNDLE_COPYRIGHT);
		return value;
	}

	/**
	 * Answers the <code>Bundle-Description</code> value from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code>
	 */
	public String getBundleDescription(Bundle bundle) {
		String value = getHeader(bundle, Constants.BUNDLE_DESCRIPTION);
		return value;
	}

	/**
	 * Answers the <code>Bundle-DocURL</code> value from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code>
	 */
	public String getBundleDocUrl(Bundle bundle) {
		String value = getUnlocalizedHeader(bundle, Constants.BUNDLE_DOCURL);
		return value;
	}

	/**
	 * Answers the <code>Bundle-Localization</code> value from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code>
	 */
	public String getBundleLocalization(Bundle bundle) {
		String value = getUnlocalizedHeader(bundle, Constants.BUNDLE_LOCALIZATION);
		return value;
	}

	/**
	 * Answers the <code>Bundle-ManifestVersion</code> value from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code>
	 */
	public String getBundleManifestVersion(Bundle bundle) {
		String value = getUnlocalizedHeader(bundle, Constants.BUNDLE_MANIFESTVERSION);
		return value;
	}

	/**
	 * Answers the <code>Bundle-Name</code> value from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code>
	 */
	public String getBundleName(Bundle bundle) {
		String value = getHeader(bundle, Constants.BUNDLE_NAME);
		return value;
	}

	/**
	 * Answers the <code>Bundle-NativeCode</code> value from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code>
	 */
	public String getBundleNativeCode(Bundle bundle) {
		String value = getUnlocalizedHeader(bundle, Constants.BUNDLE_NATIVECODE);
		return value;
	}

	/**
	 * Answers the <code>Bundle-RequiredExecutionEnvironment</code> values from
	 * the bundle's MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code> array
	 */
	public String[] getBundleRequiredExecutionEnvironments(Bundle bundle) {
		String value = getUnlocalizedHeader(bundle, Constants.BUNDLE_REQUIREDEXECUTIONENVIRONMENT);
		String[] values = tokenizeManifestValue(value);
		return values;
	}

	/**
	 * Answers the <code>Bundle-SymbolicName</code> value from the bundle's
	 * MANIFEST.MF.  This method is new for OSGi R4 support.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code>
	 */
	public String getBundleSymbolicName(Bundle bundle) {
		String value = getBundleSymbolicName(bundle, true);
		return value;
	}

	/**
	 * Answers the <code>Bundle-SymbolicName</code> value from the bundle's
	 * MANIFEST.MF.  This method is new for OSGi R4 support.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @param includeParameters  Whether to include parameters or not.
	 * @return <code>String</code>
	 */
	public String getBundleSymbolicName(Bundle bundle, boolean includeParameters) {
		String value = getUnlocalizedHeader(bundle, Constants.BUNDLE_SYMBOLICNAME);
		if (includeParameters == false) {
			value = removeParameters(value);
		}
		return value;
	}

	/**
	 * Answers the <code>Bundle-UpdateLocation</code> value from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code>
	 */
	public String getBundleUpdateLocation(Bundle bundle) {
		String value = getUnlocalizedHeader(bundle, Constants.BUNDLE_CLASSPATH);
		return value;
	}

	/**
	 * Answers the <code>Bundle-Vender</code> value from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code>
	 */
	public String getBundleVendor(Bundle bundle) {
		String value = getHeader(bundle, Constants.BUNDLE_VENDOR);
		return value;
	}

	/**
	 * Answers the <code>Bundle-Version</code> value from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code>
	 */
	public String getBundleVersion(Bundle bundle) {
		String value = getUnlocalizedHeader(bundle, Constants.BUNDLE_VERSION);
		return value;
	}

	/**
	 * Answers the <code>DynamicImport-Package</code> values from the bundle's MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code> array
	 */
	public String[] getDynamicImportPackages(Bundle bundle) {
		String value = getUnlocalizedHeader(bundle, Constants.DYNAMICIMPORT_PACKAGE);
		String[] values = tokenizeManifestValue(value);
		return values;
	}

	/**
	 * Answers the <code>Export-Service</code> values from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code> array
	 */
	public String[] getExportPackages(Bundle bundle) {
		String[] values = getExportPackages(bundle, true);
		return values;
	}

	/**
	 * Answers the <code>Export-Service</code> values from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @param includeParameters  Whether to include parameters or not.
	 * @return <code>String</code> array
	 */
	public String[] getExportPackages(Bundle bundle, boolean includeParameters) {
		String value = getUnlocalizedHeader(bundle, Constants.EXPORT_PACKAGE);
		String[] values = tokenizeManifestValue(value, includeParameters);
		return values;
	}

	/**
	 * Answers the <code>Export-Service</code> values from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code> array
	 * @deprecated OSGi R4 has deprecated the Export-Service header.
	 */
	public String[] getExportServices(Bundle bundle) {
		String value = getUnlocalizedHeader(bundle, Constants.EXPORT_SERVICE);
		String[] values = tokenizeManifestValue(value);
		checkIsEmpty(bundle, values, BundleManifestUtility.DEPRECATED_EXPORTED_SERVICE_HEADER_SHOULD_NOT_BE_USED_KEY);
		return values;
	}

	/**
	 * Answers the <code>Fragment-Host</code> value from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code>
	 */
	public String getFragmentHost(Bundle bundle) {
		String value = getFragmentHost(bundle, true);
		return value;
	}

	/**
	 * Answers the <code>Fragment-Host</code> value from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @param includeParameters  Whether to include parameters or not.
	 * @return <code>String</code>
	 */
	public String getFragmentHost(Bundle bundle, boolean includeParameters) {
		String value = getUnlocalizedHeader(bundle, Constants.FRAGMENT_HOST);
		if (includeParameters == false) {
			value = removeParameters(value);
		}
		return value;
	}

	/**
	 * Retrieves the localized value, represented by the key, from the bundle's
	 * MANIFEST.MF file.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @param key     The key to the MANIFEST.MF entry.
	 * @return <code>String</code>
	 */
	public String getHeader(Bundle bundle, String key) {
		String locale = null;  // Get the default locale value/
		String value = getHeader(bundle, key, locale);
		return value;
	}

	/**
	 * Retrieves the localized value, represented by the key, from the bundle's
	 * MANIFEST.MF file, using the specified locale.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @param key     The key to the MANIFEST.MF entry.
	 * @param locale  The locale to use.
	 * @return <code>String</code>
	 */
	public String getHeader(Bundle bundle, String key, String locale) {
		Assertion.checkArgumentIsNotNull(bundle, "bundle");  //$NON-NLS-1$
		Assertion.checkArgumentIsNotNull(key, "key");  //$NON-NLS-1$
		Dictionary headers = bundle.getHeaders(locale);
		String value = (String) headers.get(key);
		return value;
	}

	/**
	 * Answers the <code>Import-Package</code> values from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code> array
	 */
	public String[] getImportPackages(Bundle bundle) {
		String[] values = getImportPackages(bundle, true);
		return values;
	}

	/**
	 * Answers the <code>Import-Package</code> values from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
     * @param includeParameters  Whether to include parameters or not.
	 * @return <code>String</code> array
	 */
	public String[] getImportPackages(Bundle bundle, boolean includeParameters) {
		String value = getUnlocalizedHeader(bundle, Constants.IMPORT_PACKAGE);
		String[] values = tokenizeManifestValue(value, includeParameters);
		return values;
	}

	/**
	 * Answers the <code>Import-Service</code> values from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code> array
	 * @deprecated OSGi R4 has deprecated the Import-Service header.
	 */
	public String[] getImportServices(Bundle bundle) {
		String value = getUnlocalizedHeader(bundle, Constants.IMPORT_SERVICE);
		String[] values = tokenizeManifestValue(value);
		checkIsEmpty(bundle, values, BundleManifestUtility.DEPRECATED_IMPORTED_SERVICE_HEADER_SHOULD_NOT_BE_USED_KEY);
		return values;
	}

	/**
	 * Answers the <code>Require-Bundle</code> values from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code> array
	 */
	public String[] getRequireBundles(Bundle bundle) {
		String[] values = getRequireBundles(bundle, true);
		return values;
	}

	/**
	 * Answers the <code>Require-Bundle</code> values from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle             The bundle whose MANIFEST.MF will be read.
	 * @param includeParameters  Whether to include parameters or not.
	 * @return <code>String</code> array
	 */
	public String[] getRequireBundles(Bundle bundle, boolean includeParameters) {
		String value = getUnlocalizedHeader(bundle, Constants.REQUIRE_BUNDLE);
		String[] values = tokenizeManifestValue(value, includeParameters);
		return values;
	}

	/**
	 * Answers the <code>Service-Component</code> values from the bundle's
	 * MANIFEST.MF.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @return <code>String</code> array
	 */
	public String[] getServiceComponents(Bundle bundle) {
		String value = getUnlocalizedHeader(bundle, ComponentConstants.SERVICE_COMPONENT);
		String[] values = tokenizeManifestValue(value);
		return values;
	}

	/**
	 * Retrieves the unlocalized value, represented by the key, from the
	 * bundle's MANIFEST.MF file.
	 *
	 * @param bundle  The bundle whose MANIFEST.MF will be read.
	 * @param key     The key to the MANIFEST.MF entry.
	 * @return <code>String</code>
	 */
	public String getUnlocalizedHeader(Bundle bundle, String key) {
		String locale = new String();  // Get the unlocalized value.
		String value = getHeader(bundle, key, locale);
		return value;
	}

	private String removeParameters(String value) {
		int index = value.indexOf(';');
		if (index == -1)
			return value;  // Early return.
		String result = value.substring(0, index);
		return result;
	}

	/**
	 * Tokenizes the comma-separated <code>String</code> value returned from a
	 * bundle MANIFEST.MF.  Answers an array of <code>String</code> objects.
	 *
	 * @param value  The manifest entry that needs to be tokenized.
	 * @return <code>String</code> array
	 */
	private String[] tokenizeManifestValue(String value) {
		String[] values =  tokenizeManifestValue(value, true);
		return values;
	}

	/**
	 * Tokenizes the comma-separated <code>String</code> value returned from a
	 * bundle MANIFEST.MF.  Answers an array of <code>String</code> objects.
	 *
	 * @param value              The manifest entry that needs to be tokenized.
	 * @param includeParameters  Whether to include parameters or not.
	 * @return <code>String</code> array
	 */
	private String[] tokenizeManifestValue(String value, boolean includeParameters) {
		String[] result = BundleManifestUtility.NO_STRINGS;

		if (value != null) {
			FactoryUtility utility = FactoryUtility.getInstance();
			ITokenizer tokenizer = utility.createTokenizer(value, ',');
			List/*<String>*/ tokens = new ArrayList/*<String>*/(20);

			while (tokenizer.hasMoreTokens() == true) {
				String token = tokenizer.nextToken();
				if (includeParameters == false) {
					token = removeParameters(token);
				}
				token = token.trim();
				tokens.add(token);
			}

			int length = tokens.size();
			result = new String [ length ];
			tokens.toArray(result);
		}

		return result;
	}
}