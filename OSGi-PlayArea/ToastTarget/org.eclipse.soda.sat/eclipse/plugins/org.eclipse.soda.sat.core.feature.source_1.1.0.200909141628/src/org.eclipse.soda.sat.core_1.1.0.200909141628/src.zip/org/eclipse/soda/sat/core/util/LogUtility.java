/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.util;

import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.internal.util.LogProxy;
import org.osgi.service.log.LogService;

/**
 * The <code>LogUtility</code> class provides access to an instance of the OSGi
 * defined interface <code>LogService</code> that is guaranteed to never change
 * identity.
 * <p>
 * The class provides an implementation of the <code>LogService</code> whose
 * identity never changes.  This implementation must wrap a target instance of
 * the <code>LogService</code> that can be changed.  Operations on the
 * <code>LogService</code> provided by this class will be delegated to the
 * target <code>LogService</code>.  The class also provides a way for the target
 * <code>LogService</code> to be changed.
 * <p>
 * This class is an anomaly and should never needs to be used under normal
 * circumstances.  While coupling an application to the OSGi framework is
 * rarely a good design choice, arguably there are benefits to allowing an
 * application's business model to use the <code>LogService</code>.  Therefore,
 * this utility class provides static access to an implementation of the
 * <code>LogService</code>.
 * <p>
 * This class also includes static methods as a convenient way of logging the
 * four categories of message as defined by the <code>LogService</code>, namely:
 * <code>
 * <ul>
 *   <li>LogService.ERROR</li>
 *   <li>LogService.WARNING</li>
 *   <li>LogService.INFO</li>
 *   <li>LogService.DEBUG</li>
 * </ul>
 * </code>
 * <p>
 * For example, the following methods are provided for logging errors:
 * <code>
 * <ul>
 *   <li>logError(Object id, String message)</li>
 *   <li>logError(Object id, String message, Throwable throwable)</li>
 *   <li>logError(String message)</li>
 *   <li>logError(String message, Throwable throwable)</li>
 * </ul>
 * </code>
 * <p>
 * In addition to the following convenience static method have been provided for
 * querying the current logging level:
 * <code>
 * <ul>
 *   <li>isLoggingDebug()</li>
 *   <li>isLoggingError()</li>
 *   <li>isLoggingInfo()</li>
 *   <li>isLoggingWarning()</li>
 * </ul>
 * </code>
 * <p>
 * The static method <code>setLoggingLevel(int)</code> may be used to set the
 * current logging level to one of the LogService values defined above.
 * <p>
 * <i>Note:</i> This is a singleton class, accessible only via the static method
 * <code>getInstance()</code>.  For example:
 * <code>
 * <pre>
 * LogUtility utility = LogUtility.getInstance();
 * LogService log = utility.getLog();
 * </pre>
 * </code>
 *
 * @see org.osgi.service.log.LogService
 */
public final class LogUtility extends Object {
	//
	// Static Fields
	//

	// Property Keys
	private static final String LOG_LEVEL_PROPERTY = "org.eclipse.soda.sat.core.util.logLevel";  //$NON-NLS-1$
	private static final String TRACE_PROPERTY = "org.eclipse.soda.sat.core.util.trace";  //$NON-NLS-1$

	// Externalized String Keys
	private static final String LOG_LEVEL_DEBUG_KEY = "Common.LogLevelDebug";  //$NON-NLS-1$
	private static final String LOG_LEVEL_ERROR_KEY = "Common.LogLevelError";  //$NON-NLS-1$
	private static final String LOG_LEVEL_INFO_KEY = "Common.LogLevelInfo";  //$NON-NLS-1$
	private static final String LOG_LEVEL_WARNING_KEY = "Common.LogLevelWarning";  //$NON-NLS-1$

	// Externalized String Values
	private static final String LOG_LEVEL_ERROR_VALUE = Messages.getString(LogUtility.LOG_LEVEL_ERROR_KEY);
	private static final String LOG_LEVEL_WARNING_VALUE = Messages.getString(LogUtility.LOG_LEVEL_WARNING_KEY);
	private static final String LOG_LEVEL_INFO_VALUE = Messages.getString(LogUtility.LOG_LEVEL_INFO_KEY);
	private static final String LOG_LEVEL_DEBUG_VALUE = Messages.getString(LogUtility.LOG_LEVEL_DEBUG_KEY);

	// Default Properties
	private static final String DEFAULT_LOG_LEVEL = LogUtility.LOG_LEVEL_DEBUG_VALUE;
	private static final boolean DEFAULT_TRACE = false;

	// Properties
	private static final String INITIAL_LOG_LEVEL = System.getProperty(LogUtility.LOG_LEVEL_PROPERTY, LogUtility.DEFAULT_LOG_LEVEL);
	private static boolean TRACING = LogUtility.getBooleanProperty(LogUtility.TRACE_PROPERTY, LogUtility.DEFAULT_TRACE);

	// Misc
	private static final int DEFAULT_BUFFER_SIZE = 1024;  // 1K

	// Singleton
	private static final LogUtility INSTANCE = new LogUtility();

	//
	// Static Methods
	//

	private static boolean getBooleanProperty(String key, boolean defaultValue) {
		MiscUtility utility = MiscUtility.getInstance();
		boolean value = utility.getBooleanProperty(key, defaultValue);
		return value;
	}

	private static int getInitialLogLevelValue() {
		if (LogUtility.INITIAL_LOG_LEVEL.equalsIgnoreCase(LogUtility.LOG_LEVEL_ERROR_VALUE))
			return LogService.LOG_ERROR;  // Early return.
		if (LogUtility.INITIAL_LOG_LEVEL.equalsIgnoreCase(LogUtility.LOG_LEVEL_WARNING_VALUE))
			return LogService.LOG_WARNING;  // Early return.
		if (LogUtility.INITIAL_LOG_LEVEL.equalsIgnoreCase(LogUtility.LOG_LEVEL_INFO_VALUE))
			return LogService.LOG_INFO;  // Early return.
		if (LogUtility.INITIAL_LOG_LEVEL.equalsIgnoreCase(LogUtility.LOG_LEVEL_DEBUG_VALUE))
			return LogService.LOG_DEBUG;  // Early return.
		return LogService.LOG_DEBUG;  // Just in case LOG_LEVEL is invalid.
	}

	/**
	 * Public getter for the <code>LogUtility</code> singleton instance.
	 *
	 * @return The <code>LogUtility</code> singleton instance.
	 */
	public static LogUtility getInstance() {
		return LogUtility.INSTANCE;
	}

	/**
	 * Get the current logging level.
	 *
	 * @return	One of the <code>org.osgi.service.log.LogService</code>
	 * constants.
	 */
	public static int getLoggingLevel() {
		LogUtility instance = LogUtility.getInstance();
		int level = instance.getLogLevel();
		return level;
	}
	/**
	 * Query the current log level.
	 *
	 * @param level  The level to compare against.
	 * @return True if the log level is equal or greater than the specified
	 * level, otherwise false.
	 */
	private static boolean isLogging(int level) {
		LogUtility instance = LogUtility.getInstance();
		LogProxy proxy = instance.getProxy();
		boolean logging = proxy.isLogging(level);
		return logging;
	}

	/**
	 * Query whether debug messages are being logged.
	 *
	 * @return True if debug message are being logged, otherwise false.
	 */
	public static boolean isLoggingDebug() {
		return LogUtility.isLogging(LogService.LOG_DEBUG);
	}

	/**
	 * Query whether error messages are being logged.
	 *
	 * @return True if error message are being logged, otherwise false.
	 */
	public static boolean isLoggingError() {
		return LogUtility.isLogging(LogService.LOG_ERROR);
	}

	/**
	 * Query whether info messages are being logged.
	 *
	 * @return True if info message are being logged, otherwise false.
	 */
	public static boolean isLoggingInfo() {
		return LogUtility.isLogging(LogService.LOG_INFO);
	}

	/**
	 * Query whether debug messages are being logged.
	 *
	 * @return True if debug message are being logged, otherwise false.
	 */
	public static boolean isLoggingWarning() {
		return LogUtility.isLogging(LogService.LOG_WARNING);
	}

	/**
	 * Query the tracing field.  Answers <code>true</code> when
	 * tracing in on, and <code>false</code> when tracing is off.
	 *
	 * @return True if tracing is enabled, otherwise false.
	 */
	public static boolean isTracing() {
		return LogUtility.TRACING;
	}

	/**
	 * @param level      The level of the message being logged.  See the OSGi
	 *                   defined <code>org.osgi.service.log.LogService</code>.
	 * @param id         An object that uniquely identifies the source of the
	 *                   message to logged.
	 * @param message    The message to log.
	 * @param throwable  An accompanying Throwable.
	 * @see org.osgi.service.log.LogService
	 */
	private static void log(int level, Object id, String message, Throwable throwable) {
		boolean logging = LogUtility.isLogging(level);
		if (logging == false)
			return;  // Early return.

		LogUtility instance = LogUtility.getInstance();
		LogService log = instance.getLog();
		String formattedMessage = instance.formatMessage(id, message);
		log.log(level, formattedMessage, throwable);
	}

	/**
	 * Log a <code>LogService.LOG_DEBUG</code> message.
	 *
	 * @param id       An object that uniquely identifies the source of the
	 *                 message to logged.
	 * @param message  The message to log.
	 */
	public static void logDebug(Object id, String message) {
		LogUtility.logDebug(id, message, null);
	}

	/**
	 * Log a <code>LogService.LOG_DEBUG</code> level message.
	 *
	 * @param id         An object that identifies who is logging the message.
	 * @param message    The message that will be logged.
	 * @param throwable  An accompanying Throwable.
	 */
	public static void logDebug(Object id, String message, Throwable throwable) {
		LogUtility.log(LogService.LOG_DEBUG, id, message, throwable);
	}

	/**
	 * Log a <code>LogService.LOG_DEBUG</code> message.
	 *
	 * @param message  The message to log.
	 */
	public static void logDebug(String message) {
		LogUtility.logDebug(null, message, null);
	}

	/**
	 * Log a <code>LogService.LOG_DEBUG</code> level message.
	 *
	 * @param message    The message that will be logged.
	 * @param throwable  An accompanying Throwable.
	 */
	public static void logDebug(String message, Throwable throwable) {
		LogUtility.logDebug(null, message, throwable);
	}

	/**
	 * Log a <code>LogService.LOG_ERROR</code> message.
	 *
	 * @param id       An object that uniquely identifies the source of the
	 *                 message to logged.
	 * @param message  The message to log.
	 */
	public static void logError(Object id, String message) {
		LogUtility.logError(id, message, null);
	}

	// Error

	/**
	 * Log a <code>LogService.LOG_ERROR</code> level message.
	 *
	 * @param id         An object that identifies who is logging the message.
	 * @param message    The message that will be logged.
	 * @param throwable  An accompanying Throwable.
	 */
	public static void logError(Object id, String message, Throwable throwable) {
		LogUtility.log(LogService.LOG_ERROR, id, message, throwable);
	}

	/**
	 * Log a <code>LogService.LOG_ERROR</code> message.
	 *
	 * @param message  The message to log.
	 */
	public static void logError(String message) {
		LogUtility.logError(null, message, null);
	}

	/**
	 * Log a <code>LogService.LOG_ERROR</code> level message.
	 *
	 * @param message    The message that will be logged.
	 * @param throwable  An accompanying Throwable.
	 */
	public static void logError(String message, Throwable throwable) {
		LogUtility.logError(null, message, throwable);
	}

	/**
	 * Log a <code>LogService.LOG_INFO</code> message.
	 *
	 * @param id       An object that uniquely identifies the source of the
	 *                 message to logged.
	 * @param message  The message to log.
	 */
	public static void logInfo(Object id, String message) {
		LogUtility.logInfo(id, message, null);
	}

	/**
	 * Log a <code>LogService.LOG_INFO</code> level message.
	 *
	 * @param id         An object that identifies who is logging the message.
	 * @param message    The message that will be logged.
	 * @param throwable  An accompanying Throwable.
	 */
	public static void logInfo(Object id, String message, Throwable throwable) {
		LogUtility.log(LogService.LOG_INFO, id, message, throwable);
	}

	/**
	 * Log a <code>LogService.LOG_INFO</code> message.
	 *
	 * @param message  The message to log.
	 */
	public static void logInfo(String message) {
		LogUtility.logInfo(null, message, null);
	}

	/**
	 * Log a <code>LogService.LOG_INFO</code> level message.
	 *
	 * @param message    The message that will be logged.
	 * @param throwable  An accompanying Throwable.
	 */
	public static void logInfo(String message, Throwable throwable) {
		LogUtility.logInfo(null, message, throwable);
	}

	/**
	 * Log a <code>LogService.DEBUG_INFO</code> level trace message.
	 *
	 * @param id       An object that identifies who is logging the message.
	 * @param message  The message that will be logged.
	 */
	public static void logTrace(Object id, String message) {
		LogUtility.logTrace(id, message, null);
	}

	/**
	 * Log a <code>LogService.DEBUG_INFO</code> level trace message.
	 *
	 * @param id         An object that identifies who is logging the message.
	 * @param message    The message that will be logged.
	 * @param throwable  An accompanying Throwable.
	 */
	public static void logTrace(Object id, String message, Throwable throwable) {
		boolean tracing = LogUtility.isTracing();
		if (tracing == false)
			return;  // Early return.
		LogUtility.log(LogService.LOG_DEBUG, id, message, throwable);
	}

	/**
	 * Log a <code>LogService.DEBUG_INFO</code> level trace message.
	 *
	 * @param message  The message that will be logged.
	 */
	public static void logTrace(String message) {
		LogUtility.logTrace(null, message, null);
	}

	/**
	 * Log a <code>LogService.DEBUG_INFO</code> level trace message.
	 *
	 * @param message    The message that will be logged.
	 * @param throwable  An accompanying Throwable.
	 */
	public static void logTrace(String message, Throwable throwable) {
		LogUtility.logTrace(null, message, throwable);
	}

	/**
	 * Log a <code>LogService.LOG_INFO</code> message.
	 *
	 * @param id       An object that uniquely identifies the source of the
	 *                 message to logged.
	 * @param message  The message to log.
	 */
	public static void logWarning(Object id, String message) {
		LogUtility.logWarning(id, message, null);
	}

	/**
	 * Log a <code>LogService.LOG_WARNING</code> level message.
	 *
	 * @param id         An object that identifies who is logging the message.
	 * @param message    The message that will be logged.
	 * @param throwable  An accompanying Throwable.
	 */
	public static void logWarning(Object id, String message, Throwable throwable) {
		LogUtility.log(LogService.LOG_WARNING, id, message, throwable);
	}

	/**
	 * Log a <code>LogService.LOG_WARNING</code> message.
	 *
	 * @param message  The message to log.
	 */
	public static void logWarning(String message) {
		LogUtility.logWarning(null, message, null);
	}

	/**
	 * Log a <code>LogService.LOG_WARNING</code> level message.
	 *
	 * @param message    The message that will be logged.
	 * @param throwable  An accompanying Throwable.
	 */
	public static void logWarning(String message, Throwable throwable) {
		LogUtility.logWarning(null, message, throwable);
	}

	/**
	 * Set the current logging level.
	 *
	 * @param level  One of the <code>org.osgi.service.log.LogService</code>
	 *               constants.
	 */
	public static void setLoggingLevel(int level) {
		LogUtility instance = LogUtility.getInstance();
		instance.setLogLevel(level);
	}

	/**
	 * Set the tracing field to <code>true</code> or <code>false</code>.
	 *
	 * @param tracing  The value of <code>true</code> turns tracing on, and a
	 *                 value of <code>false</code> turns tracing off.
	 */
	public static void setTracing(boolean tracing) {
		LogUtility.TRACING = tracing;
	}

	//
	// Instance Fields
	//

	private ICharBuffer buffer;

	//
	// Constructors
	//

	private LogProxy proxy;

	//
	// Instance Methods
	//

	/**
	 * Constructor.  Instances of this class cannot be created.
	 */
	private LogUtility() {
		super();
		setProxy(new LogProxy());
		setLogLevel(LogUtility.getInitialLogLevelValue());
		setBuffer(createBuffer());
	}

	private ICharBuffer createBuffer() {
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(LogUtility.DEFAULT_BUFFER_SIZE);
		return buffer;
	}

	/**
	 * Format the specified object using <code>toString()</code>.  If the
	 * object's class has not implemented <code>toString()</code> the result
	 * of calling <code>toString()</code> is truncated to included just the
	 * class name, the at-sign and the id object's hash code.
	 *
	 * @param id  The object to be formatted.
	 * @return The formatted object.
	 */
	private String formatId(Object object) {
		if (object instanceof String) { // $codepro.audit.disable disallowInstanceof
			String name = (String) object;
			name = name.trim();
			return name;  // Early return.
		} else if (object instanceof Class) { // $codepro.audit.disable disallowInstanceof
			Class clazz = (Class) object;
			String name = clazz.getName();
			name = getClassName(name);
			return name;  // Early return.
		}

		String name = object.toString();
		name = name.trim();
		Class clazz = object.getClass();
		String className = clazz.getName();
		boolean match = name.startsWith(className);
		if (match == true) {
			name = getClassName(className);
		}
		return name;
	}

	/**
	 * Format the specified id and message so they can be written to the log.
	 *
	 * @param id       An object that uniquely identifies the source of the
	 *                 message being logged.
	 * @param message  The message to log.
	 * @return A formatted message.
	 */
	private String formatMessage(Object id, String message) {
		String formattedMessage = message;

		if (id != null) {
			String formattedId = formatId(id);
			ICharBuffer buffer = getBuffer();

			// It is very important to synchronize on the buffer to ensure that
			// only one thread uses the buffer at a time.  A buffer is used to
			// improve performance and reduce garbage generation.
			synchronized (buffer) {
				// Since the buffer reused, it must be emptied before it can be
				// used to format another message.
				buffer.setLength(0);

				int formattedIdLength = formattedId.length();
				if (formattedIdLength != 0) {
					buffer.append(formattedId);
					buffer.append(": ");  //$NON-NLS-1$
				}

				buffer.append(message);
				formattedMessage = buffer.toString();
			}
		}

		return formattedMessage;
	}

	/**
	 * Private buffer getter.
	 *
	 * @return The LogUtility instance's buffer that is used to format logged
	 * messages.
	 */
	private ICharBuffer getBuffer() {
		return buffer;
	}

	private String getClassName(String fullyQualifiedClassName) {
		int index = fullyQualifiedClassName.lastIndexOf('.');
		String name = fullyQualifiedClassName.substring(index + 1);
		return name;
	}

	/**
	 * Get the <code>org.osgi.service.log.LogService</code>.
	 *
	 * @return The log service.
	 */
	public LogService getLog() {
		LogService log = getProxy();
		return log;
	}

	/**
	 * Private logLevel getter.
	 *
	 * @return The log level.
	 * @see org.osgi.service.log.LogService
	 */
	private int getLogLevel() {
		LogProxy proxy = getProxy();
		int logLevel = proxy.getLogLevel();
		return logLevel;
	}

	/**
	 * Private proxy getter.
	 *
	 * @return The log proxy.
	 */
	private LogProxy getProxy() {
		return proxy;
	}

	/**
	 * Private buffer setter.
	 *
	 * @param buffer  The buffer used for formatting logged messages.
	 */
	private void setBuffer(ICharBuffer buffer) {
		this.buffer = buffer;
	}

	/**
	 * Set the <code>org.osgi.service.log.LogService</code>.
	 *
	 * @param log  A log service.
	 */
	public void setLog(LogService log) {
		LogProxy proxy = getProxy();
		proxy.setLog(log);
	}

	/**
	 * Private logLevel setter.
	 *
	 * @param logLevel  The current log level.
	 */
	private void setLogLevel(int logLevel) {
		LogProxy proxy = getProxy();
		proxy.setLogLevel(logLevel);
	}

	/**
	 * Private proxy setter.
	 *
	 * @param proxy  A log proxy
	 */
	private void setProxy(LogProxy proxy) {
		this.proxy = proxy;
	}
}