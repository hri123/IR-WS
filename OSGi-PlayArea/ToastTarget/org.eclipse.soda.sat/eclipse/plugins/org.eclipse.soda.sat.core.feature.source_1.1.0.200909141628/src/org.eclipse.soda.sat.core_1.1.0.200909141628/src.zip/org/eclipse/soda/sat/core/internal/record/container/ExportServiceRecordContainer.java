/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.record.container;

import org.eclipse.soda.sat.core.record.container.interfaces.IExportServiceRecordContainer;
import org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordAction;
import org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IServiceRecord;
import org.eclipse.soda.sat.core.util.Assertion;

/**
 * The <code>ExportServiceRecordContainer</code> class models a container of
 * services that are exported by a bundle and registered with the OSGi
 * framework.  This class is an implementation of the
 * <code>ExportServiceRecordContainer</code> interface.
 */
public final class ExportServiceRecordContainer extends ServiceRecordContainer implements IExportServiceRecordContainer {
	//
	// Static Fields
	//

	private static IServiceRecordAction isRegisteredAction;
	private static IServiceRecordAction registerAction;
	private static IServiceRecordAction unregisterAction;

	//
	// Static Methods
	//

	/**
	 * Create an IServiceRecordAction for testing whether all the
	 * IExportServiceRecord objects are registered.
	 *
	 * @return The "is registered?" IServiceRecordAction.
	 */
	private static IServiceRecordAction createIsRegisteredAction() {
		return new IServiceRecordAction() {
			public boolean execute(IServiceRecord record, Object parameter) {
				IExportServiceRecord exportServiceRecord = (IExportServiceRecord) record;
				boolean registered = exportServiceRecord.isRegistered();
				return registered;
			}
		};
	}

	/**
	 * Create an IServiceRecordAction for registering all the
	 * IExportServiceRecord objects.
	 *
	 * @return The "register" IServiceRecordAction.
	 */
	private static IServiceRecordAction createRegisterAction() {
		return new IServiceRecordAction() {
			public boolean execute(IServiceRecord record, Object parameter) {
				IExportServiceRecord exportServiceRecord = (IExportServiceRecord) record;
				exportServiceRecord.register();
				return true;
			}
		};
	}

	/**
	 * Create an IServiceRecordAction for unregistering all the
	 * IExportServiceRecord objects.
	 *
	 * @return The "unregister" IServiceRecordAction.
	 */
	private static IServiceRecordAction createUnregisterAction() {
		return new IServiceRecordAction() {
			public boolean execute(IServiceRecord record, Object parameter) {
				IExportServiceRecord exportServiceRecord = (IExportServiceRecord) record;
				exportServiceRecord.unregister();
				return true;
			}
		};
	}

	/**
	 * Answers an IServiceRecordAction for testing whether a container's
	 * IServiceRecord objects are registered or not.  For example:
	 * <pre>
	 * IServiceRecordAction action = container.getIsRegisteredAction();
	 * boolean registered = container.doForEach(action);
	 * </pre>
	 * This IServiceRecordAction is typically used to implement the container's
	 * isRegistered() method, but could also be used to implement other higher
	 * level actions.
	 *
	 * @return The "is registered?" IServiceRecordAction.
	 */
	private static IServiceRecordAction getIsRegisteredAction() {
		synchronized (ExportServiceRecordContainer.class) {
			if (ExportServiceRecordContainer.isRegisteredAction == null) {
				ExportServiceRecordContainer.setIsRegisteredAction(ExportServiceRecordContainer.createIsRegisteredAction());
			}

			return ExportServiceRecordContainer.isRegisteredAction;
		}
	}

	/**
	 * Answers an IServiceRecordAction registering a container's IServiceRecord
	 * objects.  For example:
	 * <pre>
	 * IServiceRecordAction action = ExportServiceRecordContainer..getRegisterAction();
	 * container.doForEach(action);
	 * </pre>
	 * This IServiceRecordAction is typically used to implement the container's
	 * register() method, but could also be used to implement other higher
	 * level actions.
	 *
	 * @return The "register" IServiceRecordAction.
	 */
	private static IServiceRecordAction getRegisterAction() {
		synchronized (ExportServiceRecordContainer.class) {
			if (ExportServiceRecordContainer.registerAction == null) {
				ExportServiceRecordContainer.setRegisterAction(ExportServiceRecordContainer.createRegisterAction());
			}

			return ExportServiceRecordContainer.registerAction;
		}
	}

	/**
	 * Answers an IServiceRecordAction unregistering a container's
	 * IServiceRecord objects.  For example:
	 * <pre>
	 * IServiceRecordAction action = ExportServiceRecordContainer.getUnregisterAction();
	 * container.doForEach(action);
	 * </pre>
	 * This IServiceRecordAction is typically used to implement the container's
	 * unregister() method, but could also be used to implement other higher
	 * level actions.
	 *
	 * @return The "unregister" IServiceRecordAction.
	 */
	private static IServiceRecordAction getUnregisterAction() {
		synchronized (ExportServiceRecordContainer.class) {
			if (ExportServiceRecordContainer.unregisterAction == null) {
				ExportServiceRecordContainer.setUnregisterAction(ExportServiceRecordContainer.createUnregisterAction());
			}

			return ExportServiceRecordContainer.unregisterAction;
		}
	}

	/**
	 * Private isRegisteredAction setter.
	 *
	 * @param isRegisteredAction  The IServiceRecordAction for testing whether
	 *                            the IExportServiceRecord objects are
	 *                            registered.
	 */
	private static void setIsRegisteredAction(IServiceRecordAction isRegisteredAction) {
		ExportServiceRecordContainer.isRegisteredAction = isRegisteredAction;
	}

	/**
	 * Private registerAction setter.
	 *
	 * @param registerAction  The IServiceRecordAction for registering services.
	 */
	private static void setRegisterAction(IServiceRecordAction registerAction) {
		ExportServiceRecordContainer.registerAction = registerAction;
	}

	/**
	 * Private unregisterAction setter.
	 *
	 * @param unregisterAction  The IServiceRecordAction for unregistering
	 *                          services.
	 */
	private static void setUnregisterAction(IServiceRecordAction unregisterAction) {
		ExportServiceRecordContainer.unregisterAction = unregisterAction;
	}

	//
	// Instance Fields
	//

	private boolean registered;

	//
	// Constructors
	//

	/**
	 * Constructor.
	 */
	public ExportServiceRecordContainer() {
		super();
		setRegistered(false);
	}

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IExportServiceRecordContainer#add(org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord)
	 */
	public boolean add(IExportServiceRecord record) {
		Assertion.checkArgumentIsNotNull(record, "record");  //$NON-NLS-1$

		synchronized (this) {
			String[] names = record.getNames();
			int count = names.length;
			int index = 0;
			boolean added = true;

			while (added == true && index < count) {
				String name = names [ index ];
				added = add(name, record);
				index++;
			}

			boolean registeredRecord = record.isRegistered();

			if (registeredRecord == false) {
				setRegistered(false);
			}

			return added;
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.record.container.ServiceRecordContainer#createStringBufferSize()
	 */
	protected int createStringBufferSize() {
		return super.createStringBufferSize() + 75;
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.record.container.ServiceRecordContainer#createTableCapacity()
	 */
	protected int createTableCapacity() {
		return 5;
	}

	private boolean getRegistered() {
		return registered;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IExportServiceRecordContainer#isRegistered()
	 */
	public boolean isRegistered() {
		boolean empty = isEmpty();
		if (empty == true)
			return false;  // Early return.

		boolean registered;

		synchronized (this) {
			registered = getRegistered();
			if (registered == true)
				return true;  // Early return.
			IServiceRecordAction action = ExportServiceRecordContainer.getIsRegisteredAction();
			registered = doForEach(action, null);
		}

		return registered;
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.record.container.ServiceRecordContainer#printOn(StringBuffer)
	 */
	protected void printOn(StringBuffer buffer) {
		super.printOn(buffer);

		boolean registered = isRegistered();
		buffer.append(", registered=");  //$NON-NLS-1$
		buffer.append(registered);
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IExportServiceRecordContainer#register()
	 */
	public void register() {
		synchronized (this) {
			boolean registered = getRegistered();
			if (registered == true)
				return;  // Early return.

			IServiceRecordAction action = ExportServiceRecordContainer.getRegisterAction();
			doForEach(action, null);
			setRegistered(true);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IExportServiceRecordContainer#remove(org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord)
	 */
	public boolean remove(IExportServiceRecord record) {
		Assertion.checkArgumentIsNotNull(record, "record");  //$NON-NLS-1$

		synchronized (this) {
			boolean removed = true;
			String[] names = record.getNames();
			int count = names.length;
			int index = 0;

			while (removed == true && index < count) {
				String name = names [ index ];
				removed = remove(name, record);
				index++;
			}

			return removed;
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IExportServiceRecordContainer#removeAll(java.lang.String)
	 */
	public boolean removeAll(String name) {
		boolean removed = true;

		synchronized (this) {
			IServiceRecord[] records = getAll(name);
			int length = records.length;
			int index = 0;

			while (removed == true && index < length) {
				IExportServiceRecord record = (IExportServiceRecord) records [ index ];
				removed = remove(record);
				index++;
			}
		}

		return removed;
	}

	private void setRegistered(boolean registered) {
		this.registered = registered;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IExportServiceRecordContainer#unregister()
	 */
	public void unregister() {
		synchronized (this) {
			IServiceRecordAction action = ExportServiceRecordContainer.getUnregisterAction();
			doForEach(action, null);
			setRegistered(false);
		}
	}
}