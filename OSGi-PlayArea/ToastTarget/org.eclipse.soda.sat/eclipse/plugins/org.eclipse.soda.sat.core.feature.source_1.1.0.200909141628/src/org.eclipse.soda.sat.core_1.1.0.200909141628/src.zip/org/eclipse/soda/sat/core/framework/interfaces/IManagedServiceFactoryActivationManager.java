/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework.interfaces;

import org.osgi.framework.BundleContext;
import org.osgi.service.cm.ManagedServiceFactory;

/**
 * The <code>IManagedServiceFactoryActivationManager</code> interface defines
 * the core API for SAT's managed service factory activation strategy.  This
 * interface extends the OSGi defined <code>ManagedServiceFactory</code>
 * interface.
 */
public interface IManagedServiceFactoryActivationManager extends ManagedServiceFactory {
	/**
	 * Start the managed service factory activation manager.
	 *
	 * @param context  The bundle's <code>BundleContext</code>.
	 */
	public void start(BundleContext context);

	/**
	 * Stop the managed service factory activation manager.
	 */
	public void stop();
}