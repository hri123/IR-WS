/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.record.interfaces;

import java.util.List;

import org.osgi.framework.InvalidSyntaxException;

/**
 * The <code>IServiceDetecter</code> interface defines the API of an object that
 * will detect the registration and unregistration of services of a specified
 * type. The following responsibilities are declared:
 * <ul>
 *   <li>
 *     Acquiring the existing services and detected future services.
 *   </li>
 *   <li>
 *     Releasing the detected services.
 *   </li>
 *   <li>
 *     Knowing the services detected so far.
 *   </li>
 *   <li>
 *     Knowing the filter used to detect services.
 *   </li>
 * </ul>
 * <p>
 * An <code>IServiceDetecter</code> can have listeners that are an
 * implementation of the interface <code>ServiceDetecterListener</code> that are
 * notified when a service of the specified type has been added to, or removed
 * from, the <code>IServiceDetecter</code>.  An <code>IServiceDetecter</code>
 * may include a filter that allows for finer grained service detection within a
 * specified type.
 * <p>
 * <i>Note:</i> In most situations it is simply not necessary to use an
 * <code>IServiceDetecter</code>, since explicit service registration is
 * preferable.  Situations where using <code>IServiceDetecter</code> is
 * helpful include:
 * <ul>
 *   <li>
 *     When there is a need to pick from one of many registered services of a
 *     particular type.  Service selection could be based on either the
 *     ranking of the registered service, or on some aspect of the domain model.
 *   </li>
 *   <li>
 *     For the detection of services to which you do not have the source code.
 *     For example, detecting when <code>LogService</code> objects are
 *     registered or unregistered.
 *   </li>
 * </ul>
 * <p>
 * <i>Note:</i> Instances of this interface can be created using the
 * <code>FactoryUtility</code> class.
 */
public interface IServiceDetecter {
	/**
	 * Acquire the imported services.
	 */
	public void acquire();

	/**
	 * Add <code>ServiceDetecterListener</code> to the detecter.
	 *
	 * @param listener  A <code>ServiceDetecterListener</code>.
	 */
	public void addServiceDetecterListener(ServiceDetecterListener listener);

	/**
	 * Get the name of the service being detected.
	 *
	 * @return A service name.
	 */
	public String getName();

	/**
	 * Query the service references that have been detected.
	 *
	 * @return The detected service reference objects.
	 */
	public List/*<ServiceReference>*/ getServiceReferences();

	/**
	 * Query the service references that have been detected, filtered by
	 * the specified LDAP filter.
	 *
	 * @param filter  An LDAP filter with which to filter the service
	 *                references objects.
	 * @return The detected service reference objects.
	 * @throws InvalidSyntaxException when the filter parameter is invalid.
	 */
	public List/*<ServiceReference>*/ getServiceReferences(String filter) throws InvalidSyntaxException;

	/**
	 * Query the services that have been detected.
	 *
	 * @return The detected service objects.
	 */
	public List/*<Object>*/ getServices();

	/**
	 * Query the services that have been detected, filtered by the specified
	 * LDAP filter.
	 *
	 * @param filter  An LDAP filter with which to filter the service objects.
	 * @return The detected service objects.
	 * @throws InvalidSyntaxException when the filter parameter is invalid.
	 */
	public List/*<Object>*/ getServices(String filter) throws InvalidSyntaxException;

	/**
	 * Query whether the detecter is acquired or not.
	 * @return True if the detecter is acquired, otherwise false.
	 */
	public boolean isAcquired();

	/**
	 * Release the services contained in the <code>IServiceDetecter</code>.
	 */
	public void release();

	/**
	 * Add <code>ServiceDetecterListener</code> to the detecter.
	 *
	 * @param listener  A <code>ServiceDetecterListener</code>.
	 */
	public void removeServiceDetecterListener(ServiceDetecterListener listener);

	/**
	 * Sets the <code>IServiceDetecter</code> object's service filter.  The
	 * filter is applied to existing services and services that are subsequently
	 * registered with the OSGi framework.  Services that do not match the
	 * filter are removed from the <code>IServiceDetecter</code>.  Registered
	 * services that match the filter, will be added to the
	 * <code>IServiceDetecter</code>.
	 *
	 * @param filter  The LDAP service filter.
	 * @throws org.osgi.framework.InvalidSyntaxException when the specified
	 * filter is invalid.
	 */
	public void setFilter(String filter) throws InvalidSyntaxException;
}