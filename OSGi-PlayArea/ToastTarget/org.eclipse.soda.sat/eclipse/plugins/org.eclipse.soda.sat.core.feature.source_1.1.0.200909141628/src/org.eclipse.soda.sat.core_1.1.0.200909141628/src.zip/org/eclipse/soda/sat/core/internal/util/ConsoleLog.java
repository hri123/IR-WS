/*******************************************************************************
 * Copyright (c) 2001, 2009 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util;

import org.osgi.framework.ServiceReference;
import org.osgi.service.log.LogService;

/**
 * The <code>ConsoleLog</code> is an implementation of the OSGi defined
 * interface <code>LogService</code> that logs to the console.
 */
public class ConsoleLog extends Object implements LogService {
	//
	// Instance Fields
	//

	private LogService log;

	//
	// Constructors
	//

	/**
	 * Construct a new ConsoleLog.
	 */
	public ConsoleLog() {
		super();
		setLog(createLog());
	}

	//
	// Instance Methods
	//

	private LogService createLog() {
		return new OutputStreamLog(System.err, System.err, System.out, System.out);
	}

	private LogService getLog() {
		return log;
	}

	/**
	 * @see org.osgi.service.log.LogService#log(int, String)
	 */
	public void log(int level, String message) {
		LogService log = getLog();
		log.log(null, level, message, null);
	}

	/**
	 * @see org.osgi.service.log.LogService#log(int, String, Throwable)
	 */
	public void log(int level, String message, Throwable throwable) {
		LogService log = getLog();
		log.log(null, level, message, throwable);
	}

	/**
	 * @see org.osgi.service.log.LogService#log(ServiceReference, int, String)
	 */
	public void log(ServiceReference reference, int level, String message) {
		LogService log = getLog();
		log.log(reference, level, message, null);
	}

	/**
	 * @see org.osgi.service.log.LogService#log(ServiceReference, int, String, Throwable)
	 */
	public void log(ServiceReference reference, int level, String message, Throwable throwable) {
		LogService log = getLog();
		log.log(reference, level, message, throwable);
	}

	private void setLog(LogService log) {
		this.log = log;
	}
}