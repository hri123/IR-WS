/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.record.container;

import java.util.ArrayList;
import java.util.Collection;

import org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainer;
import org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainerLenientOwner;
import org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainerOwner;
import org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordAction;
import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecordOwner;
import org.eclipse.soda.sat.core.record.interfaces.IServiceRecord;
import org.eclipse.soda.sat.core.util.Assertion;
import org.osgi.framework.Filter;

/**
 * The <code>ImportServiceRecordContainer</code> class models a container of
 * services that are imported by a bundle and acquired from the OSGi framework.
 * The class is an implementation of the <code>IImportServiceRecordContainer</code>
 * interface.
 */
public final class ImportServiceRecordContainer extends ServiceRecordContainer implements IImportServiceRecordContainer {
	//
	// Static Fields
	//

	// Externalized String Keys
//	private static final String ILLEGAL_OPERATION_WHILE_CONTAINER_IS_ACQUIRED_KEY = "ImportServiceRecordContainer.IllegalOperationWhileContainerIsAcquired";  //$NON-NLS-1$

	// Misc
	private static final String[] NO_SERVICE_NAMES = new String [ 0 ];

	// Actions
	private static IServiceRecordAction acquireAction;
	private static IServiceRecordAction collectUnacquiredServiceNamesAction;
	private static IServiceRecordAction isAcquiredAction;
	private static IServiceRecordAction releaseAction;

	//
	// Static Methods
	//

	/**
	 * Create and answer the service record action for acquiring services.
	 *
	 * @return IServiceRecordAction
	 */
	private static IServiceRecordAction createAcquireAction() {
		return new IServiceRecordAction() {
			public boolean execute(IServiceRecord record, Object parameter) {
				IImportServiceRecord importServiceRecord = (IImportServiceRecord) record;
				IImportServiceRecordOwner owner = (IImportServiceRecordOwner) parameter;
				importServiceRecord.setOwner(owner);
				importServiceRecord.acquire();
				return true;
			}
		};
	}

	/**
	 * Create and answer the service record action for collecting the names
	 * of the services that have not been acquired.
	 *
	 * @return IServiceRecordAction
	 */
	private static IServiceRecordAction createCollectUnacquiredServiceNamesAction() {
		return new IServiceRecordAction(){
			public boolean execute(IServiceRecord record, Object parameter) {
				IImportServiceRecord importServiceRecord = (IImportServiceRecord) record;
				boolean acquired = importServiceRecord.isAcquired();

				if (acquired == false) {
					String name = importServiceRecord.getName();
					Collection/*<String>*/ collection = (Collection/*<String>*/) parameter;
					collection.add(name);
				}

				return true;
			}
		};
	}

	/**
	 * Create and answer the service record action for tested whether an import
	 * service record is acquired.
	 *
	 * @return IServiceRecordAction
	 */
	private static IServiceRecordAction createIsAcquiredAction() {
		return new IServiceRecordAction() {
			public boolean execute(IServiceRecord record, Object parameter) {
				IImportServiceRecord importServiceRecord = (IImportServiceRecord) record;
				boolean acquired = importServiceRecord.isAcquired();
				return acquired;
			}
		};
	}

	/**
	 * Create and answer the service record action for releasing the import
	 * service record objects.
	 *
	 * @return IServiceRecordAction
	 */
	private static IServiceRecordAction createReleaseAction() {
		return new IServiceRecordAction() {
			public boolean execute(IServiceRecord record, Object parameter) {
				IImportServiceRecord importServiceRecord = (IImportServiceRecord) record;
				importServiceRecord.release();
				return true;
			}
		};
	}

	/**
	 * Answers a service record action  for acquiring the container's export
	 * service record objects.  For example:
	 * <pre>
	 * IServiceRecordAction action = container.getAcquireAction();
	 * container.doForEach(action);
	 * </pre>
	 * This service record action is typically used to implement the container's
	 * acquire() method, but could also be used to implement other higher level
	 * actions.
	 *
	 * @return IServiceRecordAction
	 */
	private static IServiceRecordAction getAcquireAction() {
		synchronized (ImportServiceRecordContainer.class) {
			if (ImportServiceRecordContainer.acquireAction == null) {
				ImportServiceRecordContainer.setAcquireAction(ImportServiceRecordContainer.createAcquireAction());
			}

			return ImportServiceRecordContainer.acquireAction;
		}
	}

	/**
	 * Answers a service record action  for collecting the names of the services
	 * that have not yet been acquired. For example:
	 * <pre>
	 * Collection names = new ArrayList(25);
	 * IServiceRecordAction action = container.getCollectUnacquiredServicesAction();
	 * container.doForEach(action, names);
	 * </pre>
	 * This service record action is typically used to implement the container's
	 * getUnacquiredServiceNames() method, but could also be used to implement
	 * other higher level actions.
	 *
	 * @return IServiceRecordAction
	 */
	private static IServiceRecordAction getCollectUnacquiredServiceNamesAction() {
		synchronized (ImportServiceRecordContainer.class) {
			if (ImportServiceRecordContainer.collectUnacquiredServiceNamesAction == null) {
				ImportServiceRecordContainer.setCollectUnacquiredServiceNamesAction(ImportServiceRecordContainer.createCollectUnacquiredServiceNamesAction());
			}

			return ImportServiceRecordContainer.collectUnacquiredServiceNamesAction;
		}
	}

	/**
	 * Answers a service record  for testing whether the container's export
	 * service record objects have been acquired or not.  For example:
	 * <pre>
	 * IServiceRecordAction action = container.getIsAcquiredAction();
	 * boolean acquired = container.doForEach(action);
	 * </pre>
	 * This service record action is typically used to implement the container's
	 * acquire() method, but could also be used to implement other higher level
	 * actions.
	 *
	 * @return IServiceRecordAction
	 */
	private static IServiceRecordAction getIsAcquiredAction() {
		synchronized (ImportServiceRecordContainer.class) {
			if (ImportServiceRecordContainer.isAcquiredAction == null) {
				ImportServiceRecordContainer.setIsAcquiredAction(ImportServiceRecordContainer.createIsAcquiredAction());
			}

			return ImportServiceRecordContainer.isAcquiredAction;
		}
	}

	/**
	 * Answers an service record action for releasing the container's export
	 * service record objects.  For example:
	 * <pre>
	 * IServiceRecordAction action = container.getReleaseAction();
	 * container.doForEach(action);
	 * </pre>
	 * This service record action is typically used to implement the container's
	 * release() method, but could also be used to implement other higher level
	 * actions.
	 *
	 * @return IServiceRecordAction
	 */
	private static IServiceRecordAction getReleaseAction() {
		synchronized (ImportServiceRecordContainer.class) {
			if (ImportServiceRecordContainer.releaseAction == null) {
				ImportServiceRecordContainer.setReleaseAction(ImportServiceRecordContainer.createReleaseAction());
			}

			return ImportServiceRecordContainer.releaseAction;
		}
	}

	/**
	 * Private acquireAction setter.
	 *
	 * @param acquireAction  The service record action for acquiring services.
	 */
	private static void setAcquireAction(IServiceRecordAction acquireAction) {
		ImportServiceRecordContainer.acquireAction = acquireAction;
	}

	/**
	 * Private collectUnacquiredServicesAction setter.
	 *
	 * @param collectUnacquiredServiceNamesAction  The service record action for
	 * collecting the names of the services that have not been acquired.
	 */
	private static void setCollectUnacquiredServiceNamesAction(IServiceRecordAction collectUnacquiredServiceNamesAction) {
		ImportServiceRecordContainer.collectUnacquiredServiceNamesAction = collectUnacquiredServiceNamesAction;
	}

	/**
	 * Private isAcquiredAction setter.
	 *
	 * @param isAcquiredAction  The service record action for testing whether
	 *                          the import service record action objects are
	 *                          acquired.
	 */
	private static void setIsAcquiredAction(IServiceRecordAction isAcquiredAction) {
		ImportServiceRecordContainer.isAcquiredAction = isAcquiredAction;
	}

	/**
	 * Private releaseAction setter.
	 *
	 * @param releaseAction  The service record action for releasing services.
	 */
	private static void setReleaseAction(IServiceRecordAction releaseAction) {
		ImportServiceRecordContainer.releaseAction = releaseAction;
	}

	//
	// Instance Fields
	//

	private boolean acquired;
	private IImportServiceRecordContainerOwner owner;
	private IImportServiceRecordOwner serviceRecordOwner;

	//
	// Constructors
	//

	/**
	 * Constructor.
	 */
	public ImportServiceRecordContainer() {
		super();
		setAcquired(false);
	}

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainer#acquire()
	 */
	public void acquire() {
		Object lock = getLock();

		synchronized (lock) {
			boolean acquired = getAcquired();
			if (acquired == true)
				return;  // Early return.
			boolean empty = isEmpty();
			if (empty == true) {
				setAcquired(true);
				IImportServiceRecordContainerOwner owner = getOwner();
				if (owner != null) {
					owner.acquired(this);
				}
				return;  // Early return.
			}

			IServiceRecordAction action = ImportServiceRecordContainer.getAcquireAction();
			IImportServiceRecordOwner serviceRecordOwner = getServiceRecordOwner();
			doForEach(action, serviceRecordOwner);

			IImportServiceRecordContainerOwner owner = getOwner();
			boolean lenient = owner instanceof IImportServiceRecordContainerLenientOwner;
			if (lenient == false)
				return;  // Early return.
			setAcquired(true);
			if (owner != null) {
				owner.acquired(this);
			}
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainer#add(org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord)
	 */
	public boolean add(IImportServiceRecord record) {
		Assertion.checkArgumentIsNotNull(record, "record");  //$NON-NLS-1$
		boolean added;
		Object lock = getLock();
		synchronized (lock) {
			String name = record.getName();
			added = add(name, record);
			boolean acquired = getAcquired();
			if (acquired == true) {
				IImportServiceRecordOwner owner = getServiceRecordOwner();
				record.setOwner(owner);
				record.acquire();
				boolean recordAcquired = record.isAcquired();
				if (recordAcquired == false) {
					serviceReleased(record);
				}
			}
		}
		return added;
	}

	/**
	 * Create and answer the import service record owner.
	 *
	 * @return IImportServiceRecordOwner
	 */
	private IImportServiceRecordOwner createServiceRecordOwner() {
		return new IImportServiceRecordOwner() {
			public Object getLock() {
				return ImportServiceRecordContainer.this.getLock();
			}

			public void serviceAcquired(IImportServiceRecord record) {
				ImportServiceRecordContainer.this.serviceAcquired(record);
			}

			public void serviceReleased(IImportServiceRecord record) {
				ImportServiceRecordContainer.this.serviceReleased(record);
			}
		};
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.record.container.ServiceRecordContainer#createStringBufferSize()
	 */
	protected int createStringBufferSize() {
		return super.createStringBufferSize() + 100;
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.record.container.ServiceRecordContainer#createTableCapacity()
	 */
	protected int createTableCapacity() {
		return 10;
	}

	/**
	 * Private acquired getter.
	 *
	 * @return boolean
	 */
	private boolean getAcquired() {
		return acquired;
	}

	private Object getLock() {
		return this;
	}

	/**
	 * Private owner getter.
	 *
	 * @return An import service record container owner
	 */
	private IImportServiceRecordContainerOwner getOwner() {
		return owner;
	}

	/**
	 * Private recordOwnwer getter.  The recordOwner field is lazy initialized.
	 *
	 * @return An import service record owner.
	 */
	private IImportServiceRecordOwner getServiceRecordOwner() {
		Object lock = getLock();

		synchronized (lock) {
			if (serviceRecordOwner == null) {
				IImportServiceRecordOwner owner = createServiceRecordOwner();
				setServiceRecordOwner(owner);
			}

			return serviceRecordOwner;
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainer#getUnacquiredServiceNames()
	 */
	public String[] getUnacquiredServiceNames() {
		int sizeHint = basicSize();
		Collection/*<String>*/ names = new ArrayList/*<String>*/(sizeHint);
		IServiceRecordAction action = ImportServiceRecordContainer.getCollectUnacquiredServiceNamesAction();
		doForEach(action, names);

		int size = names.size();
		if (size == 0)
			return ImportServiceRecordContainer.NO_SERVICE_NAMES;  // Early return.

		String[] result = new String [ size ];
		names.toArray(result);
		return result;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainer#getWithFilter(java.lang.String, org.osgi.framework.Filter)
	 */
	public IImportServiceRecord getWithFilter(String name, Filter filter) {
		IImportServiceRecord record = null;

		if (filter == null) {
			record = (IImportServiceRecord) get(name);
		} else {
			boolean found = false;
			IServiceRecord[] records = getAll(name);
			int length = records.length;
			int index = 0;

			while (found == false && index < length) {
				record = (IImportServiceRecord) records [ index ];
				Filter recordFilter = record.getFilter();
				found = filter.equals(recordFilter);
				index++;
			}

			record = found == true ? record : null;
		}

		return record;
	}

	private boolean isAcquired() {
		boolean acquired = false;
		Object lock = getLock();

		synchronized (lock) {
			acquired = getAcquired();
			if (acquired == false) {
				IServiceRecordAction action = ImportServiceRecordContainer.getIsAcquiredAction();
				acquired = doForEach(action, null);
			}
		}

		return acquired;
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.record.container.ServiceRecordContainer#printOn(StringBuffer)
	 */
	protected void printOn(StringBuffer buffer) {
		super.printOn(buffer);
		Object owner = getOwner();
		buffer.append(", owner=");  //$NON-NLS-1$
		buffer.append(owner);
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainer#release()
	 */
	public void release() {
		Object lock = getLock();

		synchronized (lock) {
			boolean empty = isEmpty();
			if (empty == true) {
				setAcquired(false);
				IImportServiceRecordContainerOwner owner = getOwner();
				if (owner != null) {
					owner.released(this);
				}
				return;  // Early return.
			}

			IServiceRecordAction action = ImportServiceRecordContainer.getReleaseAction();
			doForEach(action, null);

			IImportServiceRecordContainerOwner owner = getOwner();
			boolean lenient = owner instanceof IImportServiceRecordContainerLenientOwner;
			if (lenient == false)
				return;  // Early return.
			setAcquired(false);
			if (owner != null) {
				owner.released(this);
			}
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainer#remove(org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord)
	 */
	public boolean remove(IImportServiceRecord record) {
		Assertion.checkArgumentIsNotNull(record, "record");  //$NON-NLS-1$
		boolean removed;
		String name = record.getName();
		Object lock = getLock();

		synchronized (lock) {
			removed = remove(name, record);
			if (removed == true) {
				record.setOwner(null);
				record.release();
			}
		}
		return removed;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordContainer#removeAll(java.lang.String)
	 */
	public boolean removeAll(String name) {
		Object lock = getLock();

		synchronized (lock) {
			boolean acquired = getAcquired();
			if (acquired == true)
				return false;  // Early return.

			IServiceRecord[] records = getAll(name);
			int length = records.length;
			boolean removed = true;
			int index = 0;

			while (removed == true && index < length) {
				IImportServiceRecord record = (IImportServiceRecord) records [ index ];
				removed = remove(record);
				index++;
			}

			return removed;
		}
	}

	/**
	 * An imported service has been acquired.
	 *
	 * @param record  The import service record for the acquired service.
	 */
	private void serviceAcquired(IImportServiceRecord record) {
		Object lock = getLock();

		synchronized (lock) {
			IImportServiceRecordContainerOwner owner = getOwner();
			boolean lenient = owner instanceof IImportServiceRecordContainerLenientOwner;

			if (lenient == true) {
				IImportServiceRecordContainerLenientOwner lenientOwner = (IImportServiceRecordContainerLenientOwner) owner;
				lenientOwner.serviceAcquired(this, record);
			} else {
				boolean acquired = isAcquired();
				if (acquired == false)
					return;  // Early return.
				setAcquired(true);
				if (owner != null) {
					owner.acquired(this);
				}
			}
		}
	}

	/**
	 * An imported service has been released.
	 *
	 * @param record  The import service record for the released service.
	 */
	private void serviceReleased(IImportServiceRecord record) {
		Object lock = getLock();

		synchronized (lock) {
			IImportServiceRecordContainerOwner owner = getOwner();
			boolean lenient = owner instanceof IImportServiceRecordContainerLenientOwner;

			if (lenient == true) {
				IImportServiceRecordContainerLenientOwner lenientOwner = (IImportServiceRecordContainerLenientOwner) owner;
				setAcquired(false);
				lenientOwner.serviceReleased(this, record);
			} else {
				boolean acquired = getAcquired();
				if (acquired == false)
					return;  // Early return.
				setAcquired(false);
				if (owner != null) {
					owner.released(this);
				}
			}
		}
	}

	/**
	 * Private acquired setter.
	 *
	 * @param acquired  True or false.
	 */
	private void setAcquired(boolean acquired) {
		Object lock = getLock();

		synchronized (lock) {
			this.acquired = acquired;
		}
	}

	/**
	 * Private owner setter.
	 *
	 * @param owner  An import service record container owner.
	 */
	public void setOwner(IImportServiceRecordContainerOwner owner) {
		Object lock = getLock();

		synchronized (lock) {
			this.owner = owner;
		}
	}

	/**
	 * Private serviceRecordOwner setter.
	 *
	 * @param serviceRecordOwner  The owner of the import service records.
	 */
	private void setServiceRecordOwner(IImportServiceRecordOwner serviceRecordOwner) {
		this.serviceRecordOwner = serviceRecordOwner;
	}
}