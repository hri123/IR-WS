/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.record.container.interfaces;

import org.eclipse.soda.sat.core.record.interfaces.IServiceRecord;

/**
 * The <code>IServiceRecordContainer</code> interface declares the API for
 * service record containers.
 * <p>
 * This interface does not declare a responsibility for adding records to the
 * container, since for type-safety reasons this is left for the sub-interfaces
 * to define.
 * <p>
 * <i>Note:</i> Since this abstraction is used internally by the SAT bundle
 * this interface is typically not used directly by bundle developers.
 */
public interface IServiceRecordContainer {
	/**
	 * Query the container for the existence of a service record.
	 *
	 * @param record  A service record.
	 *
	 * @return True if the service record exists, otherwise false.
	 */
	public boolean contains(IServiceRecord record);

	/**
	 * For each service record execute an action.  If executing the action
	 * answers <code>false</code>, stop iterating through the service records.
	 *
	 * @param action     An action to perform.
	 * @param parameter  Optional parameter passed to the service record.
	 *
	 * @return False if all service records were not visited, otherwise true.
	 */
	public boolean doForEach(IServiceRecordAction action, Object parameter);

	/**
	 * Empty the container by removing all the records.
	 */
	public void empty();

	/**
	 * Get the service record for a named service in the container.
	 *
	 * @param name  A Service name.
	 *
	 * @return The service record.  Returns <code>null</code> if the a service
	 * record for the service does not exist.
	 */
	public IServiceRecord get(String name);

	/**
	 * Get the service record for the specified service.
	 *
	 * @param name     A service name.
	 * @param service  A service.
	 *
	 * @return The service record for the specified name and service object, or
	 * <code>null</code> if a service record does not exist.
	 */
	public IServiceRecord get(String name, Object service);

	/**
	 * Get all the service records in the container.
	 *
	 * @return An array of service record in the container.  Returns an array
	 * of zero elements if the container does not contain any service records.
	 */
	public IServiceRecord[] getAll();

	/**
	 * Get all the service records in the container for the specified name.
	 *
	 * @param name     A service name.
	 *
	 * @return An array of service record in the container.  Returns an array
	 * of zero elements if the container does not contain any service records.
	 */
	public IServiceRecord[] getAll(String name);

	/**
	 * Query whether the receiver is empty.
	 *
	 * @return True if the container is empty, otherwise false.
	 */
	public boolean isEmpty();

	/**
	 * Remove from the container all the service with a name matching the
	 * specified name.
	 *
	 * @param name  The name of the services to remove.
	 *
	 * @return True if at least one service with the specified name was removed,
	 * otherwise false.
	 */
	public boolean removeAll(String name);

	/**
	 * Query the size of the container.
	 *
	 * @return The size of the container.
	 */
	public int size();
}
