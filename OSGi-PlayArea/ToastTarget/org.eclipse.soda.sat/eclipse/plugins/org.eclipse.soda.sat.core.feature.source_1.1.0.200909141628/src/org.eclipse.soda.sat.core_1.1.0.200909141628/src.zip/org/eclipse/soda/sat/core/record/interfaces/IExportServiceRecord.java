/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.record.interfaces;

import java.util.Dictionary;

import org.osgi.framework.Constants;
import org.osgi.framework.ServiceReference;

/**
 * The <code>IExportServiceRecord</code> interface represents a service that is
 * exported by a bundle and registered with the OSGi framework.  The following
 * responsibilities are declared:
 * <ul>
 *   <li>
 *     Registering the exported service with the OSGi framework.
 *   </li>
 *   <li>
 *     Unregistering the exported service with the OSGi framework.
 *   </li>
 *   <li>
 *     Knowing the properties of an exported service.
 *   </li>
 *   <li>
 *     Setting the initial properties of an exported service and changing the
 *     properties after an exported service has been registered with the OSGi
 *     framework.
 *   </li>
 *   <li>
 *     Knowing the service names under which an export service will be
 *     registered with the OSGi framework.
 *   </li>
 * </ul>
 * <p>
 * <i>Note:</i> Since this abstraction is used internally by the SAT bundle
 * this interface is typically not used directly by bundle developers.  For
 * cases where subclassing the <code>BaseBundleActivator</code> is not
 * appropriate, instances of this interface can be created using the
 * <code>FactoryUtility</code> class.
 */
public interface IExportServiceRecord extends IServiceRecord {
	// Service Property Keys
	public static final String BUNDLE_ID_PROPERTY = "bundle.id";  //$NON-NLS-1$
	public static final String BUNDLE_VERSION_PROPERTY = "bundle.version";  //$NON-NLS-1$
	public static final String SERVICE_REGISTRATION_TIMESTAMP_PROPERTY = "service.registration.timestamp";  //$NON-NLS-1$
	public static final String SERVICE_VENDOR_PROPERTY = Constants.SERVICE_VENDOR;

	/**
	 * Get the exported service's service names.
	 *
	 * @return An array of exported service names.  An exported service is
	 * always guaranteed to have at least one service name.
	 */
	public String[] getNames();

	/**
	 * Get the properties of the exported service.
	 *
	 * @return The properties of the exported service, or <code>null</code> if
	 * the exported service does not have properties.
	 */
	public Dictionary getProperties();

	/**
	 * Answers the ServiceReference for the service.
	 *
	 * @return The ServiceReference for the receiver's service.
	 */
	public ServiceReference getServiceReference();

	/**
	 * Query whether the exported service is a proxy.
	 *
	 * @return True if the exported service is a proxy, otherwise false.
	 */
	public boolean isProxy();

	/**
	 * Query whether the exported services has been registered.
	 *
	 * @return True if the exported service has been registered, otherwise
	 * false.
	 */
	public boolean isRegistered();

	/**
	 * Register the exported service with the OSGi framework.
	 */
	public void register();

	/**
	 * Sets the export service properties.  This method can be called regardless
	 * of whether the exported service is registered with the OSGi framework or
	 * not.  If the exported service is registered, calling this method will
	 * cause an OSGi <code>ServiceEvent.MODIFIED</code> to be fired to
	 * registered <code>ServiceListener</code> objects.
	 *
	 * @param properties  The exported service properties.
	 */
	public void setProperties(Dictionary properties);

	/**
	 * Unregister the exported service with the OSGi framework.
	 */
	public void unregister();
}