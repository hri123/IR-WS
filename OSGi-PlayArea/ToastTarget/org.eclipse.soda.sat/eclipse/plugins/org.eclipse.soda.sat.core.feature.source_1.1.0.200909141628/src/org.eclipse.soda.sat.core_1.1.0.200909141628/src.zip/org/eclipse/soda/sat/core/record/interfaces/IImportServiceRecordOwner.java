/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.record.interfaces;

/**
 * When an <code>IImportServiceRecord</code> is created it must have an owner to
 * handle call-back notifications.  The <code>IImportServiceRecordOwner</code>
 * interface declares the role of an import service record's owner:
 * <ul>
 *   <li>
 *     Handle the course of action to be taken when the import service record
 *     is <i>acquired</i>.
 *   </li>
 *   <li>
 *     Handle the course of action to be taken when the import service record
 *     is <i>released</i>.
 *   </li>
 * </ul>
 * <p>
 * <i>Note:</i> Since this abstraction is used internally by the SAT bundle
 * this interface is typically not used directly by bundle developers.
 */
public interface IImportServiceRecordOwner {
	/**
	 * Get the owner's lock. This method is used by an
	 * <code>IImportServiceRecord</code> to get access to an object for which a
	 * lock must be held before doing such things as acquiring and releasing
	 * itself. This method was added to ensure that lock ordering was maintained
	 * between an <code>IImportServiceRecord</code> and its
	 * <code>IImportServiceRecordContainer</code>.  See bug
	 * <a href="https://bugs.eclipse.org/bugs/show_bug.cgi?id=245021">245021</a>.
	 *
	 * @return Object
	 */
	public Object getLock();

	/**
	 * An imported service has been acquired.  The owner typically starts using
	 * an imported service once it has been acquired.
	 *
	 * @param record  The import service record of the acquired service.
	 */
	public void serviceAcquired(IImportServiceRecord record);

	/**
	 * An imported service has been released.  The owner must stop using an
	 * imported service once it has been released.
	 * <p>
	 * When an imported service has been released the
	 * <code>IImportServiceRecordOwner</code> might consider changing the import
	 * service record's filter by calling the <code>IImportServiceRecord</code>
	 * method <code>setFilter(Filter)</code>.
	 *
	 * @param record  The import service record of the released service.
	 *
	 * @see org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord#setFilter(org.osgi.framework.Filter)
	 */
	public void serviceReleased(IImportServiceRecord record);
}