/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework;

import java.util.Arrays;
import java.util.Dictionary;
import java.util.HashSet;
import java.util.Set;

import org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager;
import org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryAdvisor;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.internal.util.WarningMessageUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.osgi.service.cm.ConfigurationException;

/**
 * <code>BaseManagedServiceFactoryAdvisor</code> is an abstract class from which
 * bundles typically derive their <code>IManagedServiceFactoryAdvisor</code>.
 * <p>
 * This class provides reasonable defaults and no-op implementations of optional
 * methods from <code>IManagedServiceFactoryAdvisor</code>, making it easier to
 * create an advisor.
 */
public abstract class BaseManagedServiceFactoryAdvisor extends Object implements IManagedServiceFactoryAdvisor {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String SAT_CORE_KEY = "Common.SatCore";  //$NON-NLS-1$
	private static final String SHOULD_HAVE_OVERRIDDEN_METHOD_KEY = "Common.ShouldHaveOverriddenMethod";  //$NON-NLS-1$

	// Misc
	protected static final String[] NO_SERVICES = new String [ 0 ];

	//
	// Instance Methods
	//

	/**
	 * Get the imported service names.  This is the a basic implementation that
	 * collects the imported service names by delegating to the subclass.
	 *
	 * @param pid            The persistent id for the configuration.
	 * @param oldProperties  The configuration's old properties.
	 * @param properties     The configuration's new properties.
	 * @param manager        The configurations's <code>IBundleActivationManager</code>.
	 * @return An array of imported service names.
	 */
	protected final String[] basicGetImportedServiceNames(String pid, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager) {
		Set/*<String>*/ serviceNames = collectImportedServiceNames(pid, oldProperties, properties, manager);
		String[] result = toStringArray(serviceNames);
		return result;
	}

	/**
	 * Get the optional imported service names.  This is the a basic
	 * implementation that collects the optional imported service names by
	 * delegating to the subclass.
	 *
	 * @param pid            The persistent id for the configuration.
	 * @param oldProperties  The configuration's old properties.
	 * @param properties     The configuration's new properties.
	 * @param manager        The configurations's <code>IBundleActivationManager</code>.
	 * @return An array of optional imported service names.
	 */
	protected final String[] basicGetOptionalImportedServiceNames(String pid, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager) {
		Set/*<String>*/ serviceNames = collectOptionalImportedServiceNames(pid, oldProperties, properties, manager);
		String[] result = toStringArray(serviceNames);
		return result;
	}

	private Set/*<String>*/ collectImportedServiceNames(String pid, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager) {
		Set/*<String>*/ serviceNames = new HashSet/*<String>*/(13);
		collectImportedServiceNames(pid, oldProperties, properties, manager, serviceNames);
		return serviceNames;
	}

	/**
	 * <i>Hook API:</i> This method is extended by subclasses that have
	 * required imported services.  <b>Note:</b> This method is an alternative
	 * to implementing <code>getImportedServiceNames()</code>.
	 *
	 * @param pid            The persistent id for the configuration.
	 * @param oldProperties  The configuration's old properties.
	 * @param properties     The configuration's new properties.
	 * @param manager        The configurations's <code>IBundleActivationManager</code>.
	 * @param serviceNames  A <code>Set</code> into which collected service
	 *                      names must be added.
	 */
	protected void collectImportedServiceNames(String pid, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager, Set/*<String>*/ serviceNames) {
		// No-op
	}

	private Set/*<String>*/ collectOptionalImportedServiceNames(String pid, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager) {
		Set/*<String>*/ serviceNames = new HashSet/*<String>*/(13);
		collectOptionalImportedServiceNames(pid, oldProperties, properties, manager, serviceNames);
		return serviceNames;
	}

	/**
	 * <i>Hook API:</i> This method is extended by subclasses that have
	 * required imported services.  <b>Note:</b> This method is an alternative
	 * to implementing <code>getOptionalImportedServiceNames()</code>.
	 *
	 * @param pid            The persistent id for the configuration.
	 * @param oldProperties  The configuration's old properties.
	 * @param properties     The configuration's new properties.
	 * @param manager        The configurations's <code>IBundleActivationManager</code>.
	 * @param serviceNames  A <code>Set</code> into which collected service
	 *                      names must be added.
	 */
	protected void collectOptionalImportedServiceNames(String pid, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager, Set/*<String>*/ serviceNames) {
		// No-op
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryAdvisor#createImportedServiceFilters(java.lang.String, java.util.Dictionary, java.util.Dictionary, org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager)
	 */
	public void createImportedServiceFilters(String pid, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager) {
		// No-op
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryAdvisor#destroy(java.lang.String, java.lang.Object, java.util.Dictionary, org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager)
	 */
	public void destroy(String pid, Object object, Dictionary properties, IBundleActivationManager manager) {
		// No-op
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryAdvisor#getImportedServiceNames(java.lang.String, java.util.Dictionary, java.util.Dictionary, org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager)
	 */
	public String[] getImportedServiceNames(String pid, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager) {
		String[] serviceNames = basicGetImportedServiceNames(pid, oldProperties, properties, manager);
		return serviceNames;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryAdvisor#getOptionalImportedServiceNames(java.lang.String, java.util.Dictionary, java.util.Dictionary, org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager)
	 */
	public String[] getOptionalImportedServiceNames(String pid, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager) {
		String[] serviceNames = basicGetOptionalImportedServiceNames(pid, oldProperties, properties, manager);
		return serviceNames;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryAdvisor#handleAcquiredOptionalImportedService(java.lang.String, java.lang.Object, java.lang.String, java.lang.Object, org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager)
	 */
	public void handleAcquiredOptionalImportedService(String pid, Object object, String importedServiceName, Object importedService, IBundleActivationManager manager) {
		warnShouldHaveOverriddenMethod("handleAcquiredOptionalImportedService(String, Object, String, Object, IBundleActivationManager)");  //$NON-NLS-1$
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryAdvisor#handleReleasedOptionalImportedService(java.lang.String, java.lang.Object, java.lang.String, java.lang.Object, org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager)
	 */
	public void handleReleasedOptionalImportedService(String pid, Object object, String importedServiceName, Object importedService, IBundleActivationManager manager) {
		warnShouldHaveOverriddenMethod("handleReleasedOptionalImportedService(String, Object, String, Object, IBundleActivationManager)");  //$NON-NLS-1$
	}

	private String[] toStringArray(Set/*<String>*/ setOfStrings) {
		int size = setOfStrings.size();
		if (size == 0)
			return BaseManagedServiceFactoryAdvisor.NO_SERVICES;  // Early return.
		String[] result = new String [ size ];
		setOfStrings.toArray(result);
		Arrays.sort(result);
		return result;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryAdvisor#validateConfiguration(java.lang.String, java.util.Dictionary)
	 */
	public void validateConfiguration(String pid, Dictionary properties) throws ConfigurationException {
		// No-op
	}

	/**
	 * Warn that the named method should have been overridden.
	 *
	 * @param method  The method signature of the method that should have been
	 *                overridden.
	 */
	private void warnShouldHaveOverriddenMethod(String method) {
		WarningMessageUtility utility = WarningMessageUtility.getInstance();
		boolean warn = utility.isOn();
		if (warn == false)
			return;  // Early return.

		String component = Messages.getString(BaseManagedServiceFactoryAdvisor.SAT_CORE_KEY);
		Object source = this;
		String pattern = Messages.getString(BaseManagedServiceFactoryAdvisor.SHOULD_HAVE_OVERRIDDEN_METHOD_KEY);
		String warning = MessageFormatter.format(pattern, method);
		utility.warn(component, source, warning, null, null);
	}
}