/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework.interfaces;

import java.io.IOException;

/**
 * The <code>ILineWriter</code> interface defines the API for line-oriented
 * writing of an <code>OutputStream</code>.  An instance of
 * <code>ILineWriter</code> can be created using the <code>FactoryUtility</code>
 * singleton.
 *
 * <pre>
 * FactoryUtility utility = FactoryUtility.getInstance();
 * OutputStream stream = ...
 * try {
 *   ILineWriter writer = utility.createLineWriter(stream);
 *   try {
 *     ...
 *   } finally {
 *     writer.close();
 *   }
 * } catch (IOException exception) {
 *   ...
 * }
 * </pre>
 *
 * Lines are written to the stream using either <code>write(String)</code> or
 * <code>writeLine(String)</code>.  The method <code>newLine()</code> is used
 * to add a new line to the stream.  Flushing the stream is done using the
 * method <code>flush()</code>, although this is implied when the
 * <code>close()</code> method is called.
 *
 * @see org.eclipse.soda.sat.core.util.FactoryUtility
 */
public interface ILineWriter {
	/**
	 * Close the receiver.
	 *
	 * @throws java.io.IOException
	 */
	public void close() throws IOException;

	/**
	 * Flush the receiver.
	 *
	 * @throws java.io.IOException
	 */
	public void flush() throws IOException;

	/**
	 * Write a new line.
	 *
	 * @throws java.io.IOException
	 */
	public void newLine() throws IOException;

	/**
	 * Write a line of text.
	 *
	 * @param line   The line of text to write.
	 * @throws java.io.IOException
	 */
	public void write(String line) throws IOException;

	/**
	 * Write a line of text, followed by a new line.
	 *
	 * @param line   The line of text to write.
	 * @throws java.io.IOException
	 */
	public void writeLine(String line) throws IOException;
}