/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.record.container;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.internal.util.WarningMessageUtility;
import org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordAction;
import org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordContainer;
import org.eclipse.soda.sat.core.record.interfaces.IServiceRecord;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.CollectionUtility;

/**
 * The abstract <code>ServiceRecordContainer</code> class is the superclass to
 * all service containers, such as import service record containers and export
 * service record containers.  The class is an implementation of the
 * <code>IServiceRecordContainer</code> interface.
 */
abstract class ServiceRecordContainer extends Object implements IServiceRecordContainer {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String SAT_CORE_KEY = "Common.SatCore";  //$NON-NLS-1$
	private static final String RECORD_ALREADY_EXISTS_IN_CONTAINER_KEY = "ServiceRecordContainer.RecordAlreadyExistsInContainer";  //$NON-NLS-1$

	// Misc
	private static final IServiceRecord[] NO_SERVICE_RECORDS = new IServiceRecord [ 0 ];

	// Actions
	private static IServiceRecordAction collectAction;
	private static IServiceRecordAction findAction;

	//
	// Static Methods
	//

	/**
	 * Creates the service record action for collecting a service record from
	 * the container.
	 *
	 * @return IServiceRecordAction
	 */
	private static IServiceRecordAction createCollectAction() {
		return new IServiceRecordAction() {
			public boolean execute(IServiceRecord record, Object parameter) {
				Collection/*<IServiceRecord>*/ records = (Collection/*<IServiceRecord>*/) parameter;
				records.add(record);
				return true;
			}
		};
	}

	/**
	 * Creates the service record action for finding a service record in the
	 * container.
	 *
	 * @return IServiceRecordAction
	 */
	private static IServiceRecordAction createFindAction() {
		return new IServiceRecordAction() {
			public boolean execute(IServiceRecord record, Object parameter) {
				boolean found = record.equals(parameter);
				return found == false;
			}
		};
	}

	/**
	 * Answers an action for collecting records.  This action expects a
	 * <code>Collection</code> to be passed as a parameter to its
	 * <code>execute(IServiceRecord, Object)<code>
	 * method into which the records will be placed.  For example:
	 * <pre>
	 * IServiceRecordAction action = ServiceRecordContainer.getCollectAction();
	 * Collection records = new ArrayList();
	 * container.doForEach(action, records);
	 * </pre>
	 *
	 * @return A service record action.
	 */
	private static IServiceRecordAction getCollectAction() {
		synchronized (ServiceRecordContainer.class) {
			if (ServiceRecordContainer.collectAction == null) {
				ServiceRecordContainer.setCollectAction(ServiceRecordContainer.createCollectAction());
			}

			return ServiceRecordContainer.collectAction;
		}
	}

	/**
	 * Answers the service record action for finding a service record in the
	 * container.
	 *
	 * @return IServiceRecordAction
	 */
	private static IServiceRecordAction getFindAction() {
		synchronized (ServiceRecordContainer.class) {
			if (ServiceRecordContainer.findAction == null) {
				ServiceRecordContainer.setFindAction(ServiceRecordContainer.createFindAction());
			}

			return ServiceRecordContainer.findAction;
		}
	}

	/**
	 * Private collectAction setter.
	 *
	 * @param collectAction  The service record action for collecting the
	 *                       container's service records.
	 */
	private static void setCollectAction(IServiceRecordAction collectAction) {
		ServiceRecordContainer.collectAction = collectAction;
	}

	/**
	 * Private findAction setter.
	 *
	 * @param findAction  The service record action for find a service record in
	 *                    the container.
	 */
	private static void setFindAction(IServiceRecordAction findAction) {
		ServiceRecordContainer.findAction = findAction;
	}

	//
	// Instance Fields
	//

	private Map/*<String, Object>*/ table;

	protected ServiceRecordContainer() {
		super();
		setTable(createTable());
	}

	//
	// Instance Methods
	//

	/**
	 * Add a key/value pair to the container.
	 *
	 * @param key    The key to store the value under.
	 * @param record The object to be added.
	 * @return True if the add was successful, otherwise false.
	 */
	protected final boolean add(String key, IServiceRecord record) {
		boolean added = false;

		Object table = getTable();
		synchronized (table) {
			Object value = basicGet(key);

			if (value == null) {
				basicAdd(key, record);
				added = true;
			} else {
				Assertion.checkArgumentIsNotNull(record, "record");  //$NON-NLS-1$
				boolean exists;

				if (value instanceof Collection) {
					Collection/*<IServiceRecord>*/ collection = (Collection/*<IServiceRecord>*/) value;
					exists = collection.contains(record);
					if (exists == false) {
						added = collection.add(record);
					}
				} else {
					exists = value == record; // $codepro.audit.disable useEquals
					if (exists == false) {
						basicRemove(key);
						Collection/*<IServiceRecord>*/ composite = new ArrayList/*<IServiceRecord>*/(2);
						composite.add(value);
						composite.add(record);
						basicAdd(key, composite);
						added = true;
					}
				}

				if (exists == true) {
					warnRecordAlreadyExists(key, record);
				}
			}
		}

		return added;
	}

	/**
	 * Add a key/value pair to the container.  This method is final to ensure
	 * that basic adding behavior is always available to subclasses, regardless
	 * of whether <code>add(String, Object)</code> is extended or overridden.
	 *
	 * @param key    The key to store the value under.
	 * @param value  The value to be stored.
	 */
	protected final void basicAdd(String key, Object value) {
		Assertion.checkArgumentIsNotNull(key, "key");  //$NON-NLS-1$
		Assertion.checkArgumentIsNotNull(value, "value");  //$NON-NLS-1$
		Map/*<String, Object>*/ table = getTable();
		synchronized (table) {
			table.put(key, value);
		}
	}

	/**
	 * Get the value at a specified key.
	 *
	 * @param key  The String key.
	 *
	 * @return Object
	 */
	protected final Object basicGet(String key) {
		Assertion.checkArgumentIsNotNull(key, "key");  //$NON-NLS-1$
		Map/*<String, Object>*/ table = getTable();
		synchronized (table) {
			return table.get(key);
		}
	}

	/**
	 * Remove a key/value pair from the container.  This method is final to
	 * ensure that basic removing behavior is always available to subclasses
	 * regardless of whether <code>remove(String, Object)</code> is extended or
	 * overridden.
	 *
	 * @param key    The key under which the value is stored.
	 * @return boolean
	 */
	protected final boolean basicRemove(String key) {
		Map/*<String, Object>*/ table = getTable();
		synchronized (table) {
			Object value = table.remove(key);
			boolean removed = value != null;
			return removed;
		}
	}

	/**
	 * Remove all key/value pairs from the container.  This method is final to
	 * ensure that basic remove all behavior is always available to subclasses
	 * regardless of whether <code>removeAll()</code> is extended or overridden.
	 */
	protected final void basicRemoveAll() {
		synchronized (this) {
			setTable(createTable());
		}
	}

	/**
	 * Query the size of the container.
	 * @return The size of the container.
	 */
	protected final int basicSize() {
		Map/*<String, Object>*/ table = getTable();
		synchronized (table) {
			return table.size();
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordContainer#contains(org.eclipse.soda.sat.core.record.interfaces.IServiceRecord)
	 */
	public final boolean contains(IServiceRecord record) {
		Assertion.checkArgumentIsNotNull(record, "record");  //$NON-NLS-1$
		IServiceRecordAction action = ServiceRecordContainer.getFindAction();
		boolean result = doForEach(action, record);
		boolean found = result == false;
		return found;
	}

	/**
	 * Get the size of the StringBuffer used by toString().
	 * @return The size of the StringBuffer.
	 */
	protected int createStringBufferSize() {
		return 75;
	}

	/**
	 * Create the container's table.
	 *
	 * @return Map
	 */
	private Map/*<String, Object>*/ createTable() {
		int capacity = createTableCapacity();
		int size = estimateHashedCollectionSize(capacity);
		Map/*<String, Object>*/ table = new HashMap/*<String, Object>*/(size);
		return table;
	}

	/**
	 * Answer the services table's initial capacity.
	 *
	 * @return The service table's initial capacity.
	 */
	protected abstract int createTableCapacity();

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordContainer#doForEach(org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordAction, java.lang.Object)
	 */
	public final boolean doForEach(IServiceRecordAction action, Object parameter) {
		Assertion.checkArgumentIsNotNull(action, "action");  //$NON-NLS-1$
		boolean result = true;
		Map/*<String, Object>*/ table = getTable();
		synchronized (table) {
			Set/*<String>*/ keys = table.keySet();
			Iterator/*<String>*/ iterator = keys.iterator();
			while (result == true && iterator.hasNext() == true) {
				String name = (String) iterator.next();
				result = doForService(name, action, parameter);
			}
		}

		return result;
	}

	/**
	 * Execute the service record action for the service type.
	 *
	 * @param name       The name of the service.
	 * @param action     The IServiceRecordAction to perform.
	 * @param parameter  Optional parameter passed to the IServiceRecordAction.
	 *
	 * @return boolean
	 */
	private boolean doForService(String name, IServiceRecordAction action, Object parameter) {
		Object value = basicGet(name);
		if (value == null)
			return true;  // Early return.
		boolean result = true;

		if (value instanceof Collection) {
			Collection/*<IServiceRecord>*/ composite = (Collection/*<IServiceRecord>*/) value;
			Iterator/*<IServiceRecord>*/ iterator = composite.iterator();
			IServiceRecord record;

			while (result == true && iterator.hasNext() == true) {
				record = (IServiceRecord) iterator.next();
				result = action.execute(record, parameter);
			}
		} else {
			IServiceRecord record = (IServiceRecord) value;
			result = action.execute(record, parameter);
		}

		return result;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordContainer#empty()
	 */
	public final void empty() {
		basicRemoveAll();
	}

	private int estimateHashedCollectionSize(int capacity) {
		CollectionUtility utility = CollectionUtility.getInstance();
		int size = utility.estimateHashedCollectionSize(capacity);
		return size;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordContainer#get(java.lang.String)
	 */
	public IServiceRecord get(String name) {
		Assertion.checkArgumentIsNotNull(name, "name");  //$NON-NLS-1$
		IServiceRecord[] records = getAll(name);
		int length = records.length;
		if (length == 0)
			return null;  // Early return.
		IServiceRecord record = records [ 0 ];
		return record;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordContainer#get(java.lang.String, java.lang.Object)
	 */
	public IServiceRecord get(String name, Object service) {
		IServiceRecord record = null;

		Object table = getTable();
		synchronized (table) {
			Object value = basicGet(name);
			if (value == null)
				return null;  // Early return.
			Assertion.checkArgumentIsNotNull(service, "service");  //$NON-NLS-1$

			if (value instanceof Collection) {
				Collection/*<IServiceRecord>*/ composite = (Collection/*<IServiceRecord>*/) value;
				boolean found = false;
				Iterator/*<IServiceRecord>*/ iterator = composite.iterator();
				Object recordService;

				while (found == false && iterator.hasNext() == true) {
					record = (IServiceRecord) iterator.next();
					recordService = record.getService();
					found = service.equals(recordService);
				}

				if (found == false) {
					record = null;
				}
			} else {
				record = (IServiceRecord) value;
				Object recordService = record.getService();
				record = service.equals(recordService) ? record : null;
			}
		}

		return record;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordContainer#getAll()
	 */
	public IServiceRecord[] getAll() {
		IServiceRecordAction action = ServiceRecordContainer.getCollectAction();
		Collection/*<IServiceRecord>*/ collection = new ArrayList/*<IServiceRecord>*/(10);
		doForEach(action, collection);

		int length = collection.size();
		IServiceRecord[] records = new IServiceRecord [ length ];
		collection.toArray(records);
		return records;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordContainer#getAll(java.lang.String)
	 */
	public IServiceRecord[] getAll(String name) {
		IServiceRecord[] records = null;

		Object table = getTable();
		synchronized (table) {
			Object value = basicGet(name);
			if (value == null)
				return ServiceRecordContainer.NO_SERVICE_RECORDS;  // Early return.

			if (value instanceof List) {
				List/*<IServiceRecord>*/ composite = (List/*<IServiceRecord>*/) value;
				int size = composite.size();
				records = new IServiceRecord [ size ];
				composite.toArray(records);
			} else {
				IServiceRecord record = (IServiceRecord) value;
				records = new IServiceRecord [ 1 ];
				records [ 0 ] = record;
			}
		}

		return records;
	}

	/**
	 * Private table getter.
	 *
	 * @return Map
	 */
	private Map/*<String, Object>*/ getTable() {
		return table;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordContainer#isEmpty()
	 */
	public final boolean isEmpty() {
		int size = size();
		boolean empty = size == 0;
		return empty;
	}

	/**
	 * Print a human-readable description of the container on the StringBuffer.
	 *
	 * @param buffer  The StringBuffer on which to write.
	 */
	protected void printOn(StringBuffer buffer) {
		Assertion.checkArgumentIsNotNull(buffer, "buffer");  //$NON-NLS-1$
		int size = size();
		buffer.append(", size=");  //$NON-NLS-1$
		buffer.append(size);
	}

	/**
	 * Remove a key/value pair from the container.
	 *
	 * @param key    The key with which the value is stored.
	 * @param record The object to be removed.
	 *
	 * @return True if the key/value pair was removed from the container,
	 * otherwise false.
	 */
	protected final boolean remove(String key, IServiceRecord record) {
		boolean removed = false;

		Object table = getTable();
		synchronized (table) {
			Object value = basicGet(key);
			if (value == null)
				return false;  // Early return.
			Assertion.checkArgumentIsNotNull(record, "record");  //$NON-NLS-1$

			if (value instanceof List) {
				List/*<IServiceRecord>*/ composite = (List/*<IServiceRecord>*/) value;
				removed = composite.remove(record);
				if (removed == false)
					return false;  // Early return.
				int size = composite.size();

				if (size < 2) {
					basicRemove(key);

					if (size == 1) {
						Object single = composite.get(0);
						basicAdd(key, single);
					}
				}
			} else if (value == record) { // $codepro.audit.disable useEquals
				removed = basicRemove(key);
			}
		}

		return removed;
	}

	/**
	 * Private table setter.
	 *
	 * @param table  The table used to contain the IServiceRecord objects.
	 */
	private void setTable(Map/*<String, Object>*/ table) {
		this.table = table;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordContainer#size()
	 */
	public int size() {
		int size = basicSize();
		Collection/*<IServiceRecord>*/ records = new ArrayList/*<IServiceRecord>*/(size * 2);
		IServiceRecordAction action = ServiceRecordContainer.getCollectAction();
		doForEach(action, records);
		size = records.size();
		return size;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public final String toString() {
		int size = createStringBufferSize();
		StringBuffer buffer = new StringBuffer(size);
		buffer.append(super.toString());
		printOn(buffer);
		String description = buffer.toString();
		return description;
	}

	private void warnRecordAlreadyExists(String key, IServiceRecord record) {
		WarningMessageUtility utility = WarningMessageUtility.getInstance();
		String component = Messages.getString(ServiceRecordContainer.SAT_CORE_KEY);
		String warning = Messages.getString(ServiceRecordContainer.RECORD_ALREADY_EXISTS_IN_CONTAINER_KEY);
		String label = "IServiceRecord";  //$NON-NLS-1$
		String message = record.toString();
		utility.warn(component, this, warning, label, message);
	}
}