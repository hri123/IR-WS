/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.eclipse.soda.sat.core.util.MiscUtility;
import org.osgi.service.log.LogService;

/**
 * The <code>WarningMessageUtility</code> class is used to write warning
 * messages to either the console or a file.  This internal class is used to
 * warn the developer that they have made an error, such as forgetting to call
 * or implement a particular method.
 * <p>
 * <i>Note:</i> This is a singleton class, accessible only via the static method
 * <code>getInstance()</code>.  For example:
 * <pre>
 * WarningMessageUtility utility = WarningMessageUtility.getInstance();
 * utility.sendOuputToFile("warnings.txt");
 * </pre>
 */
public final class WarningMessageUtility extends Object {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String BUNDLE_WARNING_MESSAGE_1_KEY = "WarningMessageUtility.BundleWarningMessage1";  //$NON-NLS-1$
	private static final String BUNDLE_WARNING_MESSAGE_2_KEY = "WarningMessageUtility.BundleWarningMessage2";  //$NON-NLS-1$
	private static final String WARNING_FILE_KEY = "org.eclipse.soda.sat.core.warning.file";  //$NON-NLS-1$
	private static final String WARNING_MESSAGE_KEY = "WarningMessageUtility.WarningMessage";  //$NON-NLS-1$
	private static final String WARNING_STATUS_KEY = "org.eclipse.soda.sat.core.warning.status";  //$NON-NLS-1$

	// Misc
	private static final String LINE_SEPARATOR = System.getProperty("line.separator");  //$NON-NLS-1$

	// Singleton
	private static final WarningMessageUtility INSTANCE = new WarningMessageUtility();

	//
	// Static Methods
	//

	/**
	 * Public getter for the <code>WarningMessageUtility</code> singleton
	 * instance.
	 *
	 * @return The <code>WarningMessageUtility</code> singleton instance.
	 */
	public static WarningMessageUtility getInstance() {
		return WarningMessageUtility.INSTANCE;
	}

	//
	// Instance Fields
	//

	private boolean on;
	private OutputStream outputStream;

	//
	// Constructors
	//

	/**
	 * Constructor.  Instances of this class cannot be created.
	 */
	private WarningMessageUtility() {
		super();
		setOn(getInitialState());
		setOutputStream(getInitialOutputStream());
	}

	//
	// Instance Methods
	//

	/**
	 * Create a <code>FileOutputStream</code> connected to the specified file.
	 *
	 * @param filename  The name of a file to write to.
	 * @param append    Whether to append or overwrite the file.
	 *
	 * @return <code>FileOutputStream</code>
	 */
	private FileOutputStream createFileOutputStream(String filename, boolean append) {
		FileOutputStream stream = null;

		try {
			stream = new FileOutputStream(filename, append);
		} catch (IOException exception) {
			exception.printStackTrace();
		}

		return stream;
	}

	/**
	 * Create and answer a warning message.
	 *
	 * @param issuer   The issuer of the warning.
	 * @param source   The source to which the warning refers.
	 * @param warning  The warning message text.
	 * @param label    Label for an option message.
	 * @param message  An optional message.
	 * @return String
	 */
	private String createWarningMessage(String issuer, Object source, String warning, String label, String message) {
		String pattern;
		Object[] values = new Object[] {
			issuer,
			warning,
			label,
			message,
			null
		};

		if (source == null) {
			pattern = Messages.getString(WarningMessageUtility.WARNING_MESSAGE_KEY);
		} else {
			if (label == null && message == null) {
				pattern = Messages.getString(WarningMessageUtility.BUNDLE_WARNING_MESSAGE_1_KEY);
			} else {
				pattern = Messages.getString(WarningMessageUtility.BUNDLE_WARNING_MESSAGE_2_KEY);
			}

			values [ 4 ] = source;
		}

		String text = MessageFormatter.format(pattern, values);
		return text;
	}

	/**
	 * Get the <code>OutputStream</code> to the console.
	 *
	 * @return <code>OutputStream</code>
	 */
	private OutputStream getConsoleOutputStream() {
		return System.err;
	}

	/**
	 * Read the initial <code>OutputStream</code> from the System Property
	 * <code>WARNING_FILE</code>.
	 *
	 * @return <code>boolean</code>
	 */
	private OutputStream getInitialOutputStream() {
		OutputStream stream = null;
		String filename = System.getProperty(WarningMessageUtility.WARNING_FILE_KEY);

		if (filename == null) {
			stream = getConsoleOutputStream();
		} else {
			stream = createFileOutputStream(filename, false);

			if (stream == null) {
				stream = getConsoleOutputStream();
			}
		}

		return stream;
	}

	/**
	 * Read the initial state from the System Property
	 * <code>WARNING_STATUS</code>.
	 *
	 * @return <code>boolean</code>
	 */
	private boolean getInitialState() {
		MiscUtility utility = MiscUtility.getInstance();
		boolean state = utility.getBooleanProperty(WarningMessageUtility.WARNING_STATUS_KEY, true);
		return state;
	}

	/**
	 * Private stream getter.
	 *
	 * @return <code>OutputStream</code>
	 */
	private OutputStream getOutputStream() {
		return outputStream;
	}

	/**
	 * Answer <code>true</code> when the log level is set to debug, otherwise
	 * <code>false</code>.
	 *
	 * @return <code>boolean</code>
	 */
	private boolean isDebugging() {
		int level = LogUtility.getLoggingLevel();
		boolean debugging = level == LogService.LOG_DEBUG;
		return debugging;
	}

	/**
	 * Answers <code>true</code> if warnings are on, otherwise
	 * <code>false</code>.
	 *
	 * @return <code>boolean</code>
	 */
	public boolean isOn() {
		return on;
	}

	/**
	 * Send output to the console.
	 */
	public void sendOutputToConsole() {
		OutputStream stream = getConsoleOutputStream();
		setOutputStream(stream);
	}

	/**
	 * Send the output to a file.
	 *
	 * @param filename  The name of the output file.
	 */
	public void sendOutputToFile(String filename) {
		OutputStream stream = createFileOutputStream(filename, true);
		setOutputStream(stream);
	}

	/**
	 * Private on setter.
	 *
	 * @param on  The new state (<code>true</code>=ON, <code>false</code>=OFF)
	 *            of the <code>WarningMessageUtility</code>.
	 */
	private void setOn(boolean on) {
		this.on = on;
	}

	/**
	 * Private outputStream setter.
	 *
	 * @param outputStream  The <code>OutputStream</code> to which warnings
	 *                      will be written.
	 */
	private void setOutputStream(OutputStream outputStream) {
		if (this.outputStream instanceof FileOutputStream) { // $codepro.audit.disable disallowInstanceof
			try {
				this.outputStream.close(); // $codepro.audit.disable closeInFinally
			} catch (IOException exception) {
				exception.printStackTrace();
			}
		}

		this.outputStream = outputStream;
	}

	/**
	 * Turn warnings off.
	 */
	public void turnOff() {
		setOn(false);
	}

	/**
	 * Turn warnings on.
	 */
	public void turnOn() {
		setOn(true);
	}

	/**
	 * Display a warning message.
	 *
	 * @param issuer   The issuer of the warning.
	 * @param source   The source to which the warning refers.
	 * @param warning  The warning message text.
	 * @param label    The label for an optional message.
	 * @param message  An optional message.
	 */
	public void warn(String issuer, Object source, String warning, String label, String message) {
		boolean on = isOn();
		if (on == false)
			return;  // Early return.

		boolean debugging = isDebugging();
		if (debugging == false)
			return;  // Early return.

		String text = createWarningMessage(issuer, source, warning, label, message);
		write(text);
	}

	/**
	 * Write message to the stream.
	 *
	 * @param message  The warning message to be written to the
	 *                 <code>OutputStream</code>.
	 */
	private void write(String message) {
		byte[] data = message.getBytes();
		OutputStream stream = getOutputStream();
		byte[] lineSeparatorBytes = WarningMessageUtility.LINE_SEPARATOR.getBytes();

		try {
			synchronized (stream) {
				stream.write(data);
				stream.write(lineSeparatorBytes);
				stream.write(lineSeparatorBytes);
				stream.flush();
			}
		} catch (IOException exception) {
			exception.printStackTrace();
			sendOutputToConsole();
		}
	}
}