/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.eclipse.soda.sat.core.framework.interfaces.IFileLog;
import org.eclipse.soda.sat.core.framework.interfaces.ILineWriter;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;

/**
 * FileLog.java
 */
public class FileLog extends Object implements IFileLog {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String CREATED_LOG_FILE_KEY = "FileLog.CreatedLogFile";  //$NON-NLS-1$
	private static final String FILE_IS_NOT_OPEN_KEY = "FileLog.FileIsNotOpen";  //$NON-NLS-1$
	private static final String SAT_CORE_KEY = "Common.SatCore";  //$NON-NLS-1$

	// Misc
	private static final Long DEFAULT_TIME_WRAPPER = new Long(0);

	//
	// Instance Fields
	//

	private File file;
	private ILineWriter writer;
	private ThreadLocal threadLocal;
	private final Object lock = new Object();

	//
	// Constructors
	//

	/**
	 * Construct a <code>FileLog</code> on the specified file.
	 *
	 * @param file  The file.
	 */
	public FileLog(File file) {
		super();
		setFile(file);
	}

	//
	// Instance Methods
	//

	private void checkIsOpen() throws IOException {
		boolean open = isOpen();
		if (open == true)
			return;  // Early return.
		String path = getAbsolutePath();
		String pattern = Messages.getString(FileLog.FILE_IS_NOT_OPEN_KEY);
		String message = MessageFormatter.format(pattern, path);
		throw new IOException(message);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IFileLog#close()
	 */
	public void close() throws IOException {
		Object lock = getLock();

		synchronized (lock) {
			boolean open = isOpen();
			if (open == false)
				return;  // Early return.
			setThreadLocal(null);
			ILineWriter writer = getWriter();
			writer.close(); // $codepro.audit.disable closeInFinally
			setWriter(null);
		}
	}

	private ILineWriter createLineWriter() throws FileNotFoundException {
		File file = getFile();
		String path = file.getAbsolutePath();
		OutputStream outputStream = new FileOutputStream(path, false);
		String component = Messages.getString(FileLog.SAT_CORE_KEY);
		String pattern = Messages.getString(FileLog.CREATED_LOG_FILE_KEY);
		String message = MessageFormatter.format(pattern, path);
		LogUtility.logInfo(component, message);
		FactoryUtility utility = FactoryUtility.getInstance();
		ILineWriter writer = utility.createLineWriter(outputStream);
		return writer;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IFileLog#delete()
	 */
	public boolean delete() throws IOException {
		Object lock = getLock();

		synchronized (lock) {
			close(); // $codepro.audit.disable closeInFinally
			File file = getFile();
			boolean exists = file.exists();
			if (exists == false)
				return true;  // Early return.
			boolean deleted = file.delete();
			return deleted;
		}
	}

	/**
	 * @see java.lang.Object#finalize()
	 */
	protected void finalize() throws Throwable {  // $codepro.audit.disable com.instantiations.assist.eclipse.analysis.audit.rule.effectivejava.avoidFinalizers.avoidFinalizers, declaredExceptions
		close(); // $codepro.audit.disable closeInFinally
		super.finalize();
	}

	/**
	 * Format the specified id object using <code>toString()</code>.  If the
	 * id object's class has not implemented <code>toString()</code> the result
	 * of calling <code>toString()</code> is truncated to included just the
	 * class name, the at-sign and the id object's hash code.
	 *
	 * @param id  The object to be formatted.
	 * @return The formatted object.
	 */
	private String formatId(Object id) {
		String value = id.toString();
		Class clazz = id.getClass();
		String qualifiedClassName = clazz.getName();
		boolean match = value.startsWith(qualifiedClassName);

		if (match == true) {
			int index = value.lastIndexOf('.') + 1;
			value = value.substring(index);
		}

		return value;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IFileLog#getAbsolutePath()
	 */
	public String getAbsolutePath() {
		File file = getFile();
		String path = file.getAbsolutePath();
		return path;
	}

	private File getFile() {
		return file;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IFileLog#getFilename()
	 */
	public String getFilename() {
		File file = getFile();
		String name = file.getName();
		return name;
	}

	private Object getLock() {
		return lock;
	}

	/**
	 * Private threadLocal getter.  This method lazily initializes the
	 * threadLocal field.
	 *
	 * @return ThreadLocal
	 */
	private ThreadLocal getThreadLocal() {
		Object lock = getLock();

		synchronized (lock) {
			if (threadLocal == null) {
				ThreadLocal threadLocal = new ThreadLocal();
				setThreadLocal(threadLocal);
			}

			return threadLocal;
		}
	}

	/**
	 * Get the time value for the current thread.  This method must be
	 * synchronized by the caller.
	 *
	 * @return Long
	 */
	private Long getTime() {
		ThreadLocal threadLocal = getThreadLocal();
		Long timeWrapper = (Long) threadLocal.get();

		if (timeWrapper == null) {
			timeWrapper = FileLog.DEFAULT_TIME_WRAPPER;
			setTime(timeWrapper);
		}

		return timeWrapper;
	}

	private ILineWriter getWriter() {
		return writer;
	}

	/**
	 * Query whether the file is open.
	 *
	 * @return True if the file is open, otherwise false.
	 */
	private  boolean isOpen() {
		Object lock = getLock();

		synchronized (lock) {
			Object writer = getWriter();
			boolean open = writer != null;
			return open;
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IFileLog#log(java.lang.Object, java.lang.String)
	 */
	public void log(Object id, String message) throws IOException {
		Object lock = getLock();

		synchronized (lock) {
			checkIsOpen();
			logMessage(id, message);
		}
	}

	/**
	 * Log the specified message.  This method must be synchronized by the
	 * caller.
	 *
	 * @param id        An object that identifies who is logging the message.
	 * @param message   The message to log.
	 * @throws IOException
	 */
	private void logMessage(Object id, String message) throws IOException {
		Long timeWrapper = getTime();
		long time = timeWrapper.longValue();

		long now = System.currentTimeMillis();
		String nowValue = Long.toString(now);
		Long nowWrapper = new Long(now);
		setTime(nowWrapper);

		long duration = time == 0 ? 0 : now - time;
		String durationValue = Long.toString(duration);

		Thread thread = Thread.currentThread();
		String threadName = thread.getName();

		String formattedId = formatId(id);
		String delimiter = ", ";  //$NON-NLS-1$

		ILineWriter writer = getWriter();
		writer.write(nowValue);
		writer.write(delimiter);
		writer.write(durationValue);
		writer.write(delimiter);
		writer.write(threadName);
		writer.write(delimiter);
		writer.write(formattedId);
		writer.write(delimiter);
		writer.write(message);
		writer.newLine();
		writer.flush();
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IFileLog#open()
	 */
	public void open() throws FileNotFoundException {
		Object lock = getLock();

		synchronized (lock) {
			boolean open = isOpen();
			if (open == true)
				return;  // Early return.
			ILineWriter writer = createLineWriter();
			setWriter(writer);
		}
	}

	/**
	 * Private file setter.
	 *
	 * @param file  The file.
	 */
	private void setFile(File file) {
		Assertion.checkArgumentIsNotNull(file, "file");  //$NON-NLS-1$
		this.file = file;
	}

	/**
	 * Private threadLocal setter.
	 *
	 * @param threadLocal  An IThreadLocal.
	 */
//	private void setThreadLocal(IThreadLocal threadLocal) {
//		this.threadLocal = threadLocal;
//	}
	private void setThreadLocal(ThreadLocal threadLocal) {
		this.threadLocal = threadLocal;
	}

	/**
	 * Set the time value for the current thread.
	 *
	 * @param timeWrapper  A Long time value.
	 */
	private void setTime(Long timeWrapper) {
		ThreadLocal threadLocal = getThreadLocal();
		threadLocal.set(timeWrapper);
	}

	/**
	 * Private writer getter.
	 *
	 * @param writer  The ILineWriter.
	 */
	private void setWriter(ILineWriter writer) {
		this.writer = writer;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		File file = getFile();
		String path = file.getAbsolutePath();
		return path;
	}
}
