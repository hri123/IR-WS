/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;

import org.eclipse.soda.sat.core.framework.interfaces.ILineReader;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.LogUtility;

/**
 * The <code>LineReader</code> class is a utility that greatly simplifies
 * reading lines of text from an <code>InputStream</code>.  Subclasses can
 * extended or override the class' validation behavior, as well as provide
 * their own transformation behavior.
 */
public class LineReader extends Object implements ILineReader {
	//
	// Static Fields
	//

	private static final int EIGHT_K_BYTES = 8192;
	private static final String UTF8_CHARACTER_ENCODING = "UTF-8"; //$NON-NLS-1$
	private static final String DEFAULT_CHARACTER_ENCODING = System.getProperty("file.encoding", LineReader.UTF8_CHARACTER_ENCODING); //$NON-NLS-1$

	/**
	 * Create the default advisor.
	 *
	 * @return ILineReader.IAdvisor
	 */
	private static ILineReader.IAdvisor createAdvisor() {
		return new ILineReader.IAdvisor() {
			public boolean isValid(String line) {
				return true;
			}

			public String transform(String line) {
				return line;
			}
		};
	}
	//
	// Instance Fields
	//

	private BufferedReader bufferedReader;
	private String nextLine;
	private ILineReader.IAdvisor advisor;

	/**
	 * Constructor.
	 *
	 * @param inputStream  The stream from which to read.
	 */
	public LineReader(InputStream inputStream) {
		this(inputStream, LineReader.EIGHT_K_BYTES);
	}

	/**
	 * Constructor.
	 *
	 * @param inputStream  The stream from which to read.
	 * @param advisor      The line reader's advisor.
	 */
	public LineReader(InputStream inputStream, ILineReader.IAdvisor advisor) {
		this(inputStream, LineReader.EIGHT_K_BYTES, advisor);
	}

	/**
	 * Constructor.
	 *
	 * @param inputStream  The stream from which to read.
	 * @param size         The size of the read buffer.
	 */
	public LineReader(InputStream inputStream, int size) {
		this(inputStream, LineReader.DEFAULT_CHARACTER_ENCODING, size);
	}

	/**
	 * Constructor.
	 *
	 * @param inputStream  The stream from which to read.
	 * @param size         The size of the read buffer.
	 * @param advisor      The line reader's advisor.
	 */
	public LineReader(InputStream inputStream, int size, ILineReader.IAdvisor advisor) {
		this(inputStream, LineReader.DEFAULT_CHARACTER_ENCODING, size, advisor);
	}

	/**
	 * Constructor.
	 *
	 * @param inputStream        The stream from which to read.
	 * @param characterEncoding  The character encoding to use.
	 */
	public LineReader(InputStream inputStream, String characterEncoding) {
		this(inputStream, characterEncoding, LineReader.EIGHT_K_BYTES);
	}

	/**
	 * Constructor.
	 *
	 * @param inputStream        The stream from which to read.
	 * @param characterEncoding  The character encoding to use.
	 * @param advisor            The line reader's advisor.
	 */
	public LineReader(InputStream inputStream, String characterEncoding, ILineReader.IAdvisor advisor) {
		this(inputStream, characterEncoding, LineReader.EIGHT_K_BYTES, advisor);
	}

	/**
	 * Constructor.
	 *
	 * @param inputStream        The stream from which to read.
	 * @param characterEncoding  The character encoding to use.
	 * @param size               The size of the read buffer.
	 */
	public LineReader(InputStream inputStream, String characterEncoding, int size) {
		this(inputStream, characterEncoding, size, LineReader.createAdvisor());
	}

	/**
	 * Constructor.
	 *
	 * @param inputStream        The stream from which to read.
	 * @param characterEncoding  The character encoding to use.
	 * @param size               The size of the read buffer.
	 * @param advisor            The line reader's advisor.
	 */
	public LineReader(InputStream inputStream, String characterEncoding, int size, ILineReader.IAdvisor advisor) {
		super();
		setBufferedReader(createBufferedReader(inputStream, characterEncoding, size));
		setAdvisor(advisor);
	}

	//
	// Instance Methods
	//

	/**
	 * Read a line from the <code>InputStream</code>.
	 *
	 * @return <code>String</code>
	 * @throws <code>java.io.IOException</code>
	 */
	private String basicReadLine() throws IOException {
		BufferedReader bufferedReader = getBufferedReader();
		String line = bufferedReader.readLine();
		return line;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ILineReader#close()
	 */
	public void close() throws IOException {
		BufferedReader bufferedReader = getBufferedReader();
		bufferedReader.close(); // $codepro.audit.disable closeInFinally
	}

	private BufferedReader createBufferedReader(InputStream inputStream, String characterEncoding, int size) {
		Assertion.checkArgumentIsNotNull(inputStream, "inputStream");  //$NON-NLS-1$
		Assertion.checkArgumentIsNotNull(characterEncoding, "characterEncoding");  //$NON-NLS-1$
		InputStreamReader inputStreamReader;
		try {
			inputStreamReader = new InputStreamReader(inputStream, characterEncoding);
		} catch (UnsupportedEncodingException exception) {
			String message = exception.getMessage();
			LogUtility.logError(this, message, exception);
			inputStreamReader = new InputStreamReader(inputStream);
		}
		BufferedReader bufferedReader = new BufferedReader(inputStreamReader, size);
		return bufferedReader;
	}

	/**
	 * Private advisor getter.
	 *
	 * @return ILineReader.IAdvisor
	 */
	private ILineReader.IAdvisor getAdvisor() {
		return advisor;
	}

	/**
	 * Private bufferReader getter.
	 *
	 * @return The receiver's <code>BufferedReader</code> that wraps the source
	 *         <code>InputStream</code>.
	 */
	private BufferedReader getBufferedReader() {
		return bufferedReader;
	}

	/**
	 * Private nextLine getter.
	 *
	 * @return The cached next line from the source <code>InputStream</code>.
	 */
	private String getNextLine() {
		return nextLine;
	}

	/**
	 * Answers true if there are more lines to read, otherwise false.  This
	 * method is provided to allow the creation of an Enumeration object by the
	 * lines() method.
	 *
	 * @return If there are more lines to read return <code>true</code>,
	 * otherwise <code>false</code>.
	 */
	private boolean hasMoreLines() {
		String line = null;

		try {
			line = readLine();
			setNextLine(line);
		} catch (IOException exception) {
			exception.printStackTrace();
		}

		boolean result = line != null;
		return result;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ILineReader#lines()
	 */
	public Enumeration lines() {
		return new Enumeration() {
			public boolean hasMoreElements() {
				return LineReader.this.hasMoreLines();
			}

			public Object nextElement() {
				return LineReader.this.getNextLine();
			}
		};
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ILineReader#readLine()
	 */
	public String readLine() throws IOException {
		String line = null;
		boolean valid = false;
		ILineReader.IAdvisor advisor = getAdvisor();

		do {
			line = basicReadLine();
			if (line == null)
				break;  // No more lines.
			valid = advisor.isValid(line);
		} while (valid == false);

		if (line != null) {
			line = advisor.transform(line);
		}

		return line;
	}

	/**
	 * Private advisor setter.
	 *
	 * @param advisor  The line reader's advisor.
	 */
	private void setAdvisor(ILineReader.IAdvisor advisor) {
		Assertion.checkArgumentIsNotNull(advisor, "advisor");  //$NON-NLS-1$
		this.advisor = advisor;
	}

	/**
	 * Private bufferedReader setter.
	 *
	 * @param bufferedReader  The receiver's <code>BufferedReader</code> that
	 *                        wraps the source <code>InputStream</code>.
	 */
	private void setBufferedReader(BufferedReader bufferedReader) {
		this.bufferedReader = bufferedReader;
	}

	/**
	 * Private nextLine setter.
	 *
	 * @param nextLine  The next line to cache in the receiver's nextLine field.
	 */
	private void setNextLine(String nextLine) {
		this.nextLine = nextLine;
	}
}