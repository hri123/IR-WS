/*******************************************************************************
 * Copyright (c) 2001, 2009 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.soda.sat.core.framework.interfaces.BundleDependencyListener;
import org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager;
import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.service.BundleDependencyService;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.BundleManifestUtility;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.eclipse.soda.sat.core.util.MiscUtility;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleException;
import org.osgi.service.packageadmin.ExportedPackage;
import org.osgi.service.packageadmin.PackageAdmin;
import org.osgi.service.packageadmin.RequiredBundle;

/**
 * The <code>BundleDependencyManager</code> tracks the dependencies  between
 * installed bundles.  Both dependent and prerequisite relationships are managed
 * for both packages and services.  The <code>BundleDependencyManager</code> is
 * an implementation of the <code>BundleDependencyService</code> interface which
 * is exported by this bundle.
 */
public class BundleDependencyManager extends BundleManager implements BundleDependencyService {
	//
	// Static Fields
	//

	// Externalized Strings
	private static final String BUNDLE_ACTIVATION_MANAGER_ID_IS_NOT_UNIQUE_KEY = "BundleDependencyManager.BundleActivationManagerIdIsNotUnique";  //$NON-NLS-1$
	private static final String CAUGHT_EXCEPTION_THROWN_BY_CALLBACK_KEY = "Common.CaughtExceptionThrownByCallback"; //$NON-NLS-1$
	private static final String FAILED_TO_COMPUTE_UNIQUE_ID_FOR_BUNDLE_ACTIVATION_MANAGER_KEY = "BundleDependencyManager.FailedToComputeUniqueIdForBundleActivationManager";  //$NON-NLS-1$

	// Property Keys
	private static final String LOG_ID_NOT_UNIQUE_PROPERTY = "org.eclipse.soda.sat.core.framework.log.id.not.unique";  //$NON-NLS-1$

	// Default Property Values
	private static final boolean DEFAULT_LOG_ID_NOT_UNIQUE = false;

	// Properties
	private static final boolean LOG_ID_NOT_UNIQUE = BundleDependencyManager.getBooleanProperty(BundleDependencyManager.LOG_ID_NOT_UNIQUE_PROPERTY, BundleDependencyManager.DEFAULT_LOG_ID_NOT_UNIQUE);

	// Misc
	private static final int UNINSTALLABLE_CONTAINER_CAPACITY = 35;

	// Singleton
	private static final BundleDependencyManager INSTANCE = new BundleDependencyManager();

	//
	// Static Methods
	//

	private static boolean getBooleanProperty(String key, boolean defaultValue) {
		MiscUtility utility = MiscUtility.getInstance();
		boolean value = utility.getBooleanProperty(key, defaultValue);
		return value;
	}

	/**
	 * Answers the <code>BundleDependencyManager</code> singleton instance.
	 *
	 * @return BundleDependencyManager
	 */
	public static BundleDependencyManager getInstance() {
		return BundleDependencyManager.INSTANCE;
	}

	//
	// Instance Fields
	//

	private IDependencyTracker dependencyTracker;
	private IDependencyTracker.IXmlProvider xmlProvider;
	private List/*<BundleDependencyListener>*/ listeners;
	private PackageAdmin packageAdmin;
	private List/*<Bundle>*/ uninstallableBundles;
	private Map/*<String, IBundleActivationManager>*/ bundleActivationManagers;

	//
	// Constructors
	//

	/**
	 * Private constructor.
	 */
	private BundleDependencyManager() {
		super();
		setDependencyTracker(createDependencyTracker(251));
		setListeners(new ArrayList/*<BundleDependencyListener>*/(10));
		setUninstallableBundles(new ArrayList/*<Bundle>*/(BundleDependencyManager.UNINSTALLABLE_CONTAINER_CAPACITY));
		setBundleActivationManagers(new HashMap/*<String, IBundleActivationManager>*/(101));
	}

	//
	// Instance Methods
	//

	/**
	 * Add an <code>IBundleActivationManager</code>.
	 *
	 * @param bundleActivationManager  The <code>IBundleActivationManager</code>
	 *                                 to add.
	 */
	public void addBundleActivationManager(BundleActivationManager bundleActivationManager) {
		Assertion.checkArgumentIsNotNull(bundleActivationManager, "bundleActivationManager");  //$NON-NLS-1$
		String id = bundleActivationManager.getId();
		if (id == null)
			return;  // Early return.

		Map/*<String, IBundleActivationManager>*/ map = getBundleActivationManagers();
		String key = id;

		synchronized (map) {
			Object value = map.get(key);

			if (value != null) {
				boolean match = bundleActivationManager == value;
				if (match == true)
					return;  // Early return.
				String uniqueId = computeUniqueIdForBundleActivationManager(id);
				logBundleActivationManagerIdIsNotUnique(id, uniqueId);
				if (uniqueId == null)
					return;  // Early return.
				key = uniqueId;
			}

			map.put(key, bundleActivationManager);
		}

		boolean match = id.equals(key);
		if (match == true)
			return;  // Early return.
		bundleActivationManager.setId(key);  // Update the bundle activation manager's id.
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.BundleDependencyService#addBundleDependencyListener(BundleDependencyListener)
	 */
	public void addBundleDependencyListener(BundleDependencyListener listener) {
		Assertion.checkArgumentIsNotNull(listener, "listener");  //$NON-NLS-1$
		Collection/*<BundleDependencyListener>*/ listeners = getListeners();

		synchronized (listeners) {
			listeners.add(listener);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.BundleDependencyService#addUninstallableBundle(Bundle)
	 */
	public void addUninstallableBundle(Bundle bundle) {
		boolean uninstallable = isRegisteredAsUninstallable(bundle);
		if (uninstallable == true)
			return;  // Early return.

		Collection/*<Bundle>*/ uninstallableBundles = getUninstallableBundles();

		synchronized (uninstallableBundles) {
			uninstallableBundles.add(bundle);
		}
	}

	private String computeUniqueIdForBundleActivationManager(String id) {
		Map/*<String, IBundleActivationManager>*/ map = getBundleActivationManagers();
		int tries = 1;
		int maxTries = 5;

		do {
			long now = System.currentTimeMillis();
			String uniqueId = id + '-' + now;
			Object value;
			synchronized (map) {
				value = map.get(uniqueId);
			}
			if (value == null)
				return uniqueId;  // Early loop termination.
			long delayMs = 100;
			try {
				Thread.sleep(delayMs); // $codepro.audit.disable disallowSleepUsage
			} catch (InterruptedException exception) {
				break;  // Early loop termination.
			}
			tries++;
		} while (tries < maxTries);

		return null;
	}

	/**
	 * Convert the specified bundle name to XML.
	 *
	 * @param bundle  A bundle name.
	 * @return The XML representing the bundle name.
	 */
	private String convertBundleToXml(Bundle bundle) {
		String symbolicName = bundle.getSymbolicName();
		int size = symbolicName.length() + 12;
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(size);
		printXmlOn(buffer, symbolicName);
		String xml = buffer.toString();
		return xml;
	}

	/**
	 * Create a dependency tracker.
	 *
	 * @param size  The size of the dependency tracker.
	 * @return IDependencyTracker
	 */
	private IDependencyTracker createDependencyTracker(int size) {
		FactoryUtility utility = FactoryUtility.getInstance();
		IDependencyTracker tracker = utility.createDependencyTracker(size, size);
		return tracker;
	}

	/**
	 * Create the XML provider for the IDependencyTracker.
	 *
	 * @return IDependencyTracker.IXmlProvider
	 */
	private IDependencyTracker.IXmlProvider createXmlProvider() {
		return new IDependencyTracker.IXmlProvider() {
			public String convertDependentToXml(Object dependent, int indent) {
				Bundle bundle = (Bundle) dependent;
				return BundleDependencyManager.this.convertBundleToXml(bundle);
			}

			public String convertPrerequisiteToXml(Object prerequisite, int indent) {
				Bundle bundle = (Bundle) prerequisite;
				return BundleDependencyManager.this.convertBundleToXml(bundle);
			}
		};
	}

	private void depopulate() {
		IDependencyTracker tracker = getDependencyTracker();
		tracker.removeAll();
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.BundleDependencyService#getAllDependentsOf(Bundle)
	 */
	public List/*<Bundle>*/ getAllDependentsOf(Bundle bundle) {
		IDependencyTracker dependencyTracker = getDependencyTracker();
		List/*<Bundle>*/ dependents = dependencyTracker.getAllDependents(bundle);
		return dependents;
	}

	private ExportedPackage[] getAllExportedPackages() {
		PackageAdmin admin = getPackageAdmin();
		Bundle bundle = null;
		ExportedPackage[] exportedPackages = admin.getExportedPackages(bundle);
		return exportedPackages;
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.BundleDependencyService#getAllPrerequisitesOf(Bundle)
	 */
	public List/*<Bundle>*/ getAllPrerequisitesOf(Bundle bundle) {
		IDependencyTracker dependencyTracker = getDependencyTracker();
		List/*<Bundle>*/ prerequisites = dependencyTracker.getAllPrerequisites(bundle);
		return prerequisites;
	}

	private IBundleActivationManager getBundleActivationManager(String id) {
		Assertion.checkArgumentIsNotNull(id, "id");  //$NON-NLS-1$
		IBundleActivationManager value;
		Map/*<String, IBundleActivationManager>*/ map = getBundleActivationManagers();

		synchronized (map) {
			value = (IBundleActivationManager) map.get(id);
		}

		return value;
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.BundleDependencyService#getBundleActivationManagerIds()
	 */
	public List/*<String>*/ getBundleActivationManagerIds() {
		Map/*<String, IBundleActivationManager>*/ map = getBundleActivationManagers();
		Set/*<String>*/ keys;

		synchronized (map) {
			keys = map.keySet();
		}

		int size = keys.size();
		List/*<String>*/ ids = new ArrayList/*<String>*/(size);
		ids.addAll(keys);
		Collections.sort(ids);
		return ids;
	}

	private Map/*<String, IBundleActivationManager>*/ getBundleActivationManagers() {
		return bundleActivationManagers;
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.BundleDependencyService#getBundles()
	 */
	public Collection/*<Bundle>*/ getBundles() {
		IDependencyTracker dependencyTracker = getDependencyTracker();
		Collection/*<Bundle>*/ bundles = dependencyTracker.getValues();
		return bundles;
	}

	/**
	 * Private <code>dependencyTracker</code> getter.
	 *
	 * @return <code>IDependencyTracker</code>
	 */
	private IDependencyTracker getDependencyTracker() {
		return dependencyTracker;
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.BundleDependencyService#getDependentsOf(Bundle)
	 */
	public List/*<Bundle>*/ getDependentsOf(Bundle bundle) {
		IDependencyTracker dependencyTracker = getDependencyTracker();
		List/*<Bundle>*/ dependents = dependencyTracker.getDependents(bundle);
		return dependents;
	}

	/**
	 * Answers the names of the packages imported by a <code>Bundle</code>.
	 *
	 * @param bundle  The <code>Bundle</code> to be queried.
	 * @return String[]
	 */
	private String[] getImportedPackages(Bundle bundle) {
		BundleManifestUtility utility = BundleManifestUtility.getInstance();
		String[] packages = utility.getImportPackages(bundle, false);
		return packages;
	}

	/**
	 * Private <code>listeners</code> getter.
	 *
	 * @return List
	 */
	private List/*<BundleDependencyListener>*/ getListeners() {
		return listeners;
	}

	/**
	 * Get an iterator on the listeners.
	 *
	 * @return Iterator
	 */
	private Iterator/*<BundleDependencyListener>*/ getListenersIterator() {
		ArrayList/*<BundleDependencyListener>*/ listeners = (ArrayList/*<BundleDependencyListener>*/) getListeners();
		Collection/*<BundleDependencyListener>*/ clone;

		synchronized (listeners) {
			clone = (Collection/*<BundleDependencyListener>*/) listeners.clone();
		}

		Iterator/*<BundleDependencyListener>*/ iterator = clone.iterator();
		return iterator;
	}

	private PackageAdmin getPackageAdmin() {
		return packageAdmin;
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.BundleDependencyService#getPrerequisitesOf(Bundle)
	 */
	public List/*<Bundle>*/ getPrerequisitesOf(Bundle bundle) {
		IDependencyTracker dependencyTracker = getDependencyTracker();
		List/*<Bundle>*/ prerequisites = dependencyTracker.getPrerequisites(bundle);
		return prerequisites;
	}

	private String[] getRequireBundles(Bundle bundle) {
		BundleManifestUtility utility = BundleManifestUtility.getInstance();
		String[] symbolicNames = utility.getRequireBundles(bundle, false);
		return symbolicNames;
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.BundleDependencyService#getUnacquiredImportedServiceNames(java.lang.String)
	 */
	public List/*<String*/ getUnacquiredImportedServiceNames(String id) {
		IBundleActivationManager manager = getBundleActivationManager(id);
		if (manager == null)
			return null;  // Early return.
		String[] names = manager.getUnacquiredImportedServiceNames();
		List/*<String>*/ list = Arrays.asList(names);
		return list;
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.BundleDependencyService#getUnacquiredOptionalImportedServiceNames(java.lang.String)
	 */
	public List/*<String*/ getUnacquiredOptionalImportedServiceNames(String id) {
		IBundleActivationManager manager = getBundleActivationManager(id);
		if (manager == null)
			return null;  // Early return.
		String[] names = manager.getUnacquiredOptionalImportedServiceNames();
		List/*<String>*/ list = Arrays.asList(names);
		return list;
	}

	/**
	 * Private <code>uninstallableBundles</code> getter.
	 *
	 * @return List
	 */
	private List/*<Bundle>*/ getUninstallableBundles() {
		return uninstallableBundles;
	}

	/**
	 * Private <code>xmlProvider</code> getter.
	 *
	 * @return IDependencyTracker.IXmlProvider
	 */
	private IDependencyTracker.IXmlProvider getXmlProvider() {
		synchronized (this) {
			if (xmlProvider == null) {
				IDependencyTracker.IXmlProvider xmlProvider = createXmlProvider();
				setXmlProvider(xmlProvider);
			}

			return xmlProvider;
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.framework.bundle.BundleManager#handleBundleResolved(org.osgi.framework.Bundle)
	 */
	protected void handleBundleResolved(Bundle bundle) {
		registerImportedPackageDependencies(bundle);
		registerRequireBundleDependencies(bundle);
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.framework.bundle.BundleManager#handleBundleUninstalled(org.osgi.framework.Bundle)
	 */
	protected void handleBundleUninstalled(Bundle bundle) {
		uninstallPrerequisiteBundles(bundle);
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.framework.bundle.BundleManager#handleBundleUnresolved(org.osgi.framework.Bundle)
	 */
	protected void handleBundleUnresolved(Bundle bundle) {
		boolean remove = hasUninstallablePrerequisites(bundle) == false;
		if (remove == false)
			return;  // Early return.
		IDependencyTracker tracker = getDependencyTracker();
		tracker.removeDependent(bundle);
	}

	private void handleExceptionThrownByCallback(Throwable throwable, Object receiver) {
		String pattern = Messages.getString(BundleDependencyManager.CAUGHT_EXCEPTION_THROWN_BY_CALLBACK_KEY);
		String message = MessageFormatter.format(pattern, receiver);
		LogUtility.logError(this, message, throwable);
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.framework.bundle.BundleManager#handleManagerShutdown()
	 */
	protected void handleManagerShutdown() {
		depopulate();
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.framework.bundle.BundleManager#handleManagerStarted()
	 */
	protected void handleManagerStarted() {
//		new Printer(System.out);
		populate();
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.BundleDependencyService#hasCircularReferences(org.osgi.framework.Bundle)
	 */
	public boolean hasCircularReferences(Bundle bundle) {
		Assertion.checkArgumentIsNotNull(bundle, "bundle");  //$NON-NLS-1$
		IDependencyTracker tracker = getDependencyTracker();
		boolean result = tracker.hasCircularReferences(bundle);
		return result;
	}

	private boolean hasUninstallablePrerequisites(Bundle bundle) {
		List/*<Bundle>*/ uninstallableBundles = getUninstallableBundles();
		boolean empty = uninstallableBundles.isEmpty();
		if (empty == true)
			return false;  // Early return.

		List/*<Bundle>*/ prerequisites = getPrerequisitesOf(bundle);
		Iterator/*<Object>*/ iterator = prerequisites.iterator();
		boolean found = false;

		while (found == false && iterator.hasNext() == true) {
			Object prerequisite = iterator.next();
			found = uninstallableBundles.contains(prerequisite);
		}

		return found;
	}

	/**
	 * Answers true if a <code>Bundle</code> is in the <code>Bundle.ACTIVE</code>
	 * state, otherwise false.
	 *
	 * @param bundle  The <code>Bundle</code> to be queried.
	 * @return boolean
	 */
	private boolean isBundleActive(Bundle bundle) {
		int state = bundle.getState();
		boolean active = state == Bundle.ACTIVE;
		return active;
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.BundleDependencyService#isRegisteredAsUninstallable(Bundle)
	 */
	public boolean isRegisteredAsUninstallable(Bundle bundle) {
		Assertion.checkArgumentIsNotNull(bundle, "bundle");  //$NON-NLS-1$
		List/*<Bundle>*/ uninstallableBundles = getUninstallableBundles();
		boolean result = uninstallableBundles.contains(bundle);
		return result;
	}

	private void logBundleActivationManagerIdIsNotUnique(String id, String uniqueId) {
		if (BundleDependencyManager.LOG_ID_NOT_UNIQUE == false)
			return;  // Early return.

		String pattern;
		String message;

		if (uniqueId == null) {
			pattern = Messages.getString(BundleDependencyManager.FAILED_TO_COMPUTE_UNIQUE_ID_FOR_BUNDLE_ACTIVATION_MANAGER_KEY);
			message = MessageFormatter.format(pattern, id);
		} else {
			Object[] values = new Object[] {
				id,
				uniqueId
			};
			pattern = Messages.getString(BundleDependencyManager.BUNDLE_ACTIVATION_MANAGER_ID_IS_NOT_UNIQUE_KEY);
			message = MessageFormatter.format(pattern, values);
		}

		LogUtility.logInfo(this, message);
	}

	/**
	 * Populates the manager with the currently installed <code>Bundles</code>.
	 */
	private void populate() {
		BundleContext bundleContext = getBundleContext();
		Bundle[] bundles = bundleContext.getBundles();
		int count = bundles.length;
		if (count == 0)
			return;  // Early return.

		for (int i = 0; i < count; i++) {
			Bundle bundle = bundles [ i ];
			handleBundleResolved(bundle);
		}
	}

	/**
	 * Print indentation on the buffer.
	 *
	 * @param buffer  The buffer on which to print.
	 * @param level   The indentation level.
	 */
	private void printIndentOn(ICharBuffer buffer, int level) {
		Assertion.checkRange(level, "level", 0, Integer.MAX_VALUE);  //$NON-NLS-1$
		String indent = "  ";  //$NON-NLS-1$

		for (int i = 0; i < level; i++) {
			buffer.append(indent);
		}
	}

	/**
	 * Print the specified <code>Object</code> as XML on to the specified
	 * <code>StringBuffer</code>.
	 *
	 * @param buffer  The buffer on which to print.
	 * @param object  The object to print as XML.
	 */
	private void printXmlOn(ICharBuffer buffer, Object object) {
		buffer.append("<![CDATA[");  //$NON-NLS-1$
		buffer.append(object);
		buffer.append("]]>");  //$NON-NLS-1$
	}

	/**
	 * Register an importer <code>Bundle</code> as a dependent of an exporter
	 * <code>Bundle</code>.
	 *
	 * @param importer  A <code>Bundle</code> that imports a service (exported
	 *                  by the exporter).
	 * @param exporter  A <code>Bundle</code> that exports a service (imported
	 *                  by the importer).
	 */
	public void register(Bundle importer, Bundle exporter) {
		Assertion.checkArgumentIsNotNull(importer, "importer");  //$NON-NLS-1$
		Assertion.checkArgumentIsNotNull(exporter, "exporter");  //$NON-NLS-1$
		boolean recursive = importer.equals(exporter);
		if (recursive == true)
			return;  // Early return.
		registerDependency(importer, exporter);
	}

	/**
	 * Register an importer <code>Bundle</code> as a dependent of an exporter
	 * <code>Bundle</code>.
	 *
	 * @param dependent     A <code>Bundle</code> that depends on the
	 *                      prerequisite.
	 * @param prerequisite  A <code>Bundle</code> that is a prerequisite of the
	 *                      dependent.
	 */
	private void registerDependency(Bundle dependent, Bundle prerequisite) {
		IDependencyTracker tracker = getDependencyTracker();
		boolean added = tracker.add(dependent, prerequisite);
		if (added == false)
			return;  // Early return.

		Iterator/*<BundleDependencyListener>*/ iterator = getListenersIterator();
		BundleDependencyListener listener;

		while (iterator.hasNext() == true) {
			listener = (BundleDependencyListener) iterator.next();
			try {
				listener.registered(dependent, prerequisite);
			} catch (Throwable throwable) {
				handleExceptionThrownByCallback(throwable, listener);
			}
		}
	}

	/**
	 * Register the import package dependencies of a <code>Bundle</code>.
	 *
	 * @param dependent  A <code>Bundle</code>.
	 */
	private boolean registerImportedPackageDependencies(Bundle dependent) {
		ExportedPackage[] exportedPackages = getAllExportedPackages();
		if (exportedPackages == null)
			return false;  // Early return.

		boolean result = true;
		String[] packages = getImportedPackages(dependent);

		for (int i = 0; i < packages.length; i++) {
			String packageName = packages [ i ];
			boolean registered = registerImportedPackageDependency(exportedPackages, packageName, dependent);

			if (registered == false) {
				result = false;
			}
		}

		return result;
	}

	/**
	 * Register the import package dependency of a package and <code>Bundle</code>.
	 *
	 * @param packageName  The name of the imported package.
	 * @param dependent     A <code>Bundle</code> that imports the package.
	 */
	private boolean registerImportedPackageDependency(ExportedPackage[] exportedPackages, String packageName, Bundle dependent) {
		for (int i = 0; i < exportedPackages.length; i++) {
			ExportedPackage exportedPackage = exportedPackages [ i ];
			String name = exportedPackage.getName();
			boolean matchingPackageName = packageName.equals(name);
			if (matchingPackageName == false)
				continue;  // Skip to next iteration.

			Bundle prerequisite = exportedPackage.getExportingBundle();
			if (prerequisite == null)
				continue;  // ExportedPackage has become stale

			/* Removing the try/catch from the following block of code that was
			 * necessary to protect against a bug reported against SAT and
			 * Equinox.  This turned out to be an Equinox bug that was fixed in
			 * 3.3 M6.  See:
			 *   https://bugs.eclipse.org/bugs/show_bug.cgi?id=176773
			 *   https://bugs.eclipse.org/bugs/show_bug.cgi?id=176782
			 */

			Bundle[] importingBundles = exportedPackage.getImportingBundles();
			if (importingBundles == null)
				continue;  // ExportedPackage has become stale

			for (int j = 0; j < importingBundles.length; j++) {
				Bundle importingBundle = importingBundles [ j ];
				boolean match = importingBundle.equals(dependent);
				if (match == false)
					continue;  // Skip to next iteration.
				register(dependent, prerequisite);
				return true;  // Early return.
			}
		}

		return false;
	}

	private boolean registerRequireBundleDependencies(Bundle dependent) {
		boolean result = true;
		String[] symbolicNames = getRequireBundles(dependent);

		for (int i = 0; i < symbolicNames.length; i++) {
			String symbolicName = symbolicNames [ i ];
			boolean registered = registerRequireBundleDependency(symbolicName, dependent);

			if (registered == false) {
				result = false;
			}
		}

		return result;
	}

	private boolean registerRequireBundleDependency(String symbolicName, Bundle dependent) {
		PackageAdmin admin = getPackageAdmin();
		RequiredBundle[] requiredBundles = admin.getRequiredBundles(symbolicName);
		if (requiredBundles == null)
			return false;  // Early return.

		for (int i = 0; i < requiredBundles.length; i++) {
			RequiredBundle requiredBundle = requiredBundles [ i ];

			/* Removing the try/catch from the following block of code that was
			 * necessary to protect against a bug reported against SAT and
			 * Equinox.  This turned out to be an Equinox bug that was fixed in
			 * 3.3 M6.  See:
			 *   https://bugs.eclipse.org/bugs/show_bug.cgi?id=176773
			 *   https://bugs.eclipse.org/bugs/show_bug.cgi?id=176782
			 */

			Bundle[] requiringBundles = requiredBundle.getRequiringBundles();
			if (requiringBundles == null)
				continue;  // RequiredBundle has become stale.

			for (int j = 0; j < requiringBundles.length; j++) {
				Bundle requiringBundle = requiringBundles [ j ];
				boolean match = requiringBundle.equals(dependent);
				if (match == false)
					continue;  // Skip to next iteration.
				Bundle prerequisite = requiredBundle.getBundle();
				register(dependent, prerequisite);
				return true;  // Early return.
			}
		}

		return false;
	}

	/**
	 * Remove an <code>IBundleActivationManager</code>.
	 *
	 * @param bundleActivationManager  The <code>IBundleActivationManager</code>
	 *                                 to remove.
	 */
	public void removeBundleActivationManager(BundleActivationManager bundleActivationManager) {
		Assertion.checkArgumentIsNotNull(bundleActivationManager, "bundleActivationManager");  //$NON-NLS-1$
		String key = bundleActivationManager.getId();
		if (key == null)
			return;  // Early return.

		Map/*<String, IBundleActivationManager>*/ map = getBundleActivationManagers();

		synchronized (map) {
			map.remove(key);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.BundleDependencyService#removeBundleDependencyListener(BundleDependencyListener)
	 */
	public void removeBundleDependencyListener(BundleDependencyListener listener) {
		Assertion.checkArgumentIsNotNull(listener, "listener");  //$NON-NLS-1$
		Collection/*<BundleDependencyListener>*/ listeners = getListeners();

		synchronized (listeners) {
			listeners.remove(listener);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.BundleDependencyService#removeUninstallableBundle(Bundle)
	 */
	public void removeUninstallableBundle(Bundle bundle) {
		Assertion.checkArgumentIsNotNull(bundle, "bundle");  //$NON-NLS-1$
		Collection/*<Bundle>*/ uninstallableBundles = getUninstallableBundles();

		synchronized (uninstallableBundles) {
			uninstallableBundles.remove(bundle);
		}
	}

	private void setBundleActivationManagers(Map/*<String, IBundleActivationManager>*/ bundleActivationManagers) {
		this.bundleActivationManagers = bundleActivationManagers;
	}

	/**
	 * Private <code>dependencyTracker</code> setter.
	 *
	 * @param dependencyTracker  The manager's <code>DependencyTracker</code>.
	 */
	private void setDependencyTracker(IDependencyTracker dependencyTracker) {
		this.dependencyTracker = dependencyTracker;
	}

	/**
	 * Private <code>listeners</code> setter.
	 *
	 * @param listeners  A <code>List</code>.
	 */
	private void setListeners(List/*<BundleDependencyListener>*/ listeners) {
		this.listeners = listeners;
	}

	/**
	 * Set the PackageAdmin service.
	 *
	 * @param packageAdmin  The PackageAdmin service.
	 */
	public void setPackageAdmin(PackageAdmin packageAdmin) {
		this.packageAdmin = packageAdmin;
	}

	/**
	 * Private <code>uninstallableBundles</code> setter.
	 *
	 * @param uninstallableBundles  The manager's <code>List</code> of
	 *                              uninstallable <code>Bundles</code>.
	 */
	private void setUninstallableBundles(List/*<Bundle>*/ uninstallableBundles) {
		this.uninstallableBundles = uninstallableBundles;
	}

	/**
	 * Private <code>xmlProvider</code> setter.
	 *
	 * @param xmlProvider  The XML provider.
	 */
	private void setXmlProvider(IDependencyTracker.IXmlProvider xmlProvider) {
		this.xmlProvider = xmlProvider;
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.BundleDependencyService#toXml()
	 */
	public String toXml() {
		String xml = toXml(0);
		return xml;
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.BundleDependencyService#toXml(int)
	 */
	public String toXml(int indent) {
		IDependencyTracker.IXmlProvider xmlProvider = getXmlProvider();
		String result = toXml(indent, xmlProvider);
		return result;
	}

	private String toXml(int indent, IDependencyTracker.IXmlProvider xmlProvider) {
		IDependencyTracker dependencyTracker = getDependencyTracker();
		String xml = dependencyTracker.toXml(null, indent + 1, xmlProvider);
		int size = xml.length() + 25;
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(size);
		String newline = System.getProperty("line.separator");  //$NON-NLS-1$

		printIndentOn(buffer, indent);
		buffer.append("<bundleDependencyService>");  //$NON-NLS-1$
		buffer.append(xml);
		buffer.append(newline);
		printIndentOn(buffer, indent);
		buffer.append("</bundleDependencyService>");  //$NON-NLS-1$
		buffer.append(newline);

		String result = buffer.toString();
		return result;
	}

	/**
	 * Uninstall a <code>Bundle</code>.
	 *
	 * @param bundle  A <code>Bundle</code> to be uninstalled.
	 */
	private void uninstallBundle(Bundle bundle) {
		boolean active = isBundleActive(bundle);
		if (active == false)
			return;  // Early return.

		boolean uninstallable = isRegisteredAsUninstallable(bundle);
		if (uninstallable == false)
			return;  // Early return.

		try {
			bundle.uninstall();
		} catch (BundleException exception) {
			exception.printStackTrace();
			Throwable nested = exception.getNestedException();
			if (nested != null) {
				nested.printStackTrace();
			}
		}
	}

	/**
	 * Uninstall a <code>Bundle</code> and its prerequisites.
	 *
	 * @param bundle  A <code>Bundle</code>.
	 */
	private void uninstallPrerequisiteBundles(Bundle bundle) {
		IDependencyTracker tracker = getDependencyTracker();
		Collection/*<Bundle>*/ prerequisiteBundles = tracker.removeWithPrerequisites(bundle);
		Iterator/*<Bundle>*/ iterator = prerequisiteBundles.iterator();

		while (iterator.hasNext() == true) {
			Bundle prerequisiteBundle = (Bundle) iterator.next();
			uninstallBundle(prerequisiteBundle);
		}
	}

	/**
	 * Unregister an importer <code>Bundle</code> as a dependent of an exporter
	 * <code>Bundle</code>.  The relationship between the bundles is only
	 * unregistered if the importer <code>Bundle</code> does not import packages
	 * that have been exported by the exporter <code>Bundle</code>.
	 *
	 * @param importer  A <code>Bundle</code> that imports a service (exported
	 *                  by the exporter).
	 * @param exporter  A <code>Bundle</code> that exports a service (imported
	 *                  by the importer).
	 */
	public void unregister(Bundle importer, Bundle exporter) {
		Assertion.checkArgumentIsNotNull(importer, "impoter");  //$NON-NLS-1$
		Assertion.checkArgumentIsNotNull(exporter, "exporter");  //$NON-NLS-1$
		boolean recursive = importer.equals(exporter);
		if (recursive == true)
			return;  // Early return.
		unregisterDependency(importer, exporter);
	}

	/**
	 * Unregister an importer <code>Bundle</code> as a dependent of an exporter
	 * <code>Bundle</code>.
	 *
	 * @param importer  A <code>Bundle</code> that imports a service (exported
	 *                  by the exporter).
	 * @param exporter  A <code>Bundle</code> that exports a service (imported
	 *                  by the importer).
	 */
	private void unregisterDependency(Bundle importer, Bundle exporter) {
		IDependencyTracker tracker = getDependencyTracker();
		boolean removed = tracker.remove(importer, exporter);
		if (removed == false)
			return;  // Early return.

		Iterator/*<BundleDependencyListener>*/ iterator = getListenersIterator();

		while (iterator.hasNext() == true) {
			BundleDependencyListener listener = (BundleDependencyListener) iterator.next();
			try {
				listener.unregistered(importer, exporter);
			} catch (Throwable throwable) {
				handleExceptionThrownByCallback(throwable, listener);
			}
		}
	}

//	/**
//	 * BundleDependencyManager.Printer
//	 */
//	private class Printer extends Object implements BundleDependencyListener {
//		//
//		// Instance Fields
//		//
//
//		private final java.io.PrintStream stream;
//
//		//
//		// Constructors
//		//
//
//		Printer(java.io.PrintStream stream) {
//			super();
//			this.stream = stream;
//
//			BundleDependencyManager manager = BundleDependencyManager.this;
//			manager.addBundleDependencyListener(this);
//		}
//
//		//
//		// Instance Methods
//		//
//
//		protected void finalize() throws Throwable {
//			BundleDependencyManager manager = BundleDependencyManager.this;
//			manager.removeBundleDependencyListener(this);
//			super.finalize();
//		}
//
//		void print() {
//			BundleDependencyManager manager = BundleDependencyManager.this;
//			DependencyTracker tracker = (DependencyTracker) manager.getDependencyTracker();
//			tracker.print(stream);
//
//			StringBuffer buffer = new StringBuffer(1000);
//			writeOn(buffer);
//			String text = buffer.toString();
//			byte[] bytes = text.getBytes();
//			write(bytes);
//		}
//
//		public void registered(Bundle importer, Bundle exporter) {
//			print();
//		}
//
//		public void unregistered(Bundle importer, Bundle exporter) {
//			print();
//		}
//
//		private String toString(Object value) {
//			String result;
//
//			if (value instanceof Bundle) {
//				Bundle bundle = (Bundle) value;
//				result = bundle.getSymbolicName();
//				long id = bundle.getBundleId();
//				result += " [" + id + ']';  //$NON-NLS-1$
//			} else {
//				result = value.toString();
//			}
//
//			return result;
//		}
//
//		private void write(final byte[] bytes) {
//			try {
//				stream.write(bytes);
//			} catch (java.io.IOException exception) {
//				exception.printStackTrace();
//			}
//
//			stream.flush();
//		}
//
//		private void writeNewlineOn(StringBuffer buffer) {
//			String newline = System.getProperty("line.separator");  //$NON-NLS-1$
//			buffer.append(newline);
//		}
//
//		private void writeOn(StringBuffer buffer) {
//			BundleDependencyManager manager = BundleDependencyManager.this;
//
//			writeNewlineOn(buffer);
//			buffer.append("-------------------------------------------------");  //$NON-NLS-1$
//			buffer.append(" Exported Packages ");  //$NON-NLS-1$
//			buffer.append("-------------------------------------------------");  //$NON-NLS-1$
//			writeNewlineOn(buffer);
//			buffer.append(manager);
//			writeNewlineOn(buffer);
//			writeNewlineOn(buffer);
//
//			Map map = manager.getExportedPackagesMap();
//			int count = map.size();
//			String[] packageNames = new String [ count ];
//
//			java.util.Set set = map.keySet();
//			Iterator iterator = set.iterator();
//			String packageName;
//
//			for (int i = 0; i < count; i++) {
//				packageName = (String) iterator.next();
//				packageNames [ i ] = packageName;
//			}
//
//			java.util.Arrays.sort(packageNames);
//
//			for (int i = 0; i < count; i++) {
//				packageName = packageNames [ i ];
//				writeOn(buffer, packageName);
//			}
//
//			writeNewlineOn(buffer);
//			buffer.append("--------------------------------------------------------");  //$NON-NLS-1$
//			buffer.append(" oOo ");  //$NON-NLS-1$
//			buffer.append("--------------------------------------------------------");  //$NON-NLS-1$
//			writeNewlineOn(buffer);
//			writeNewlineOn(buffer);
//		}
//
//		private void writeOn(StringBuffer buffer, String packageName) {
//			BundleDependencyManager manager = BundleDependencyManager.this;
//			Map map = manager.getExportedPackagesMap();
//			Object value = map.get(packageName);
//			String name = toString(value);
//			buffer.append(packageName);
//
//			int pad = 80 - packageName.length();
//
//			for (int i = 0; i < pad; i++) {
//				buffer.append('.');
//			}
//
//			buffer.append(name);
//			writeNewlineOn(buffer);
//		}
//	}
}
