/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.record.container.interfaces;

import org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord;

/**
 * The <code>IExportServiceRecordContainer</code> interface declares the API for
 * export service record containers.
 * <p>
 * <i>Note:</i> Since this abstraction is used internally by the SAT bundle
 * this interface is typically not used directly by bundle developers.  For
 * cases where subclassing the <code>BaseBundleActivator</code> is not
 * appropriate, instances of this interface can be created using the
 * <code>FactoryUtility</code> class.
 */
public interface IExportServiceRecordContainer extends IServiceRecordContainer {
	/**
	 * Add an <code>IExportServiceRecord</code> to the container.
	 *
	 * @param record  The <code>IExportServiceRecord</code> to add.
	 * @return True if the record was added, otherwise false.
	 */
	public boolean add(IExportServiceRecord record);

	/**
	 * Answers true if the container's IExportServiceRecord objects have been
	 * registered, otherwise false.
	 *
	 * @return boolean
	 */
	public boolean isRegistered();

	/**
	 * Register the container's IExportedServiceRecord objects.
	 */
	public void register();

	/**
	 * Remove a export service record from the container.
	 *
	 * @param record  An export service record.
	 *
	 * @return True if the record was removed from the container, otherwise
	 * false.
	 */
	public boolean remove(IExportServiceRecord record);

	/**
	 * Unregister all the container's IExportedServiceRecord objects.
	 */
	public void unregister();
}
