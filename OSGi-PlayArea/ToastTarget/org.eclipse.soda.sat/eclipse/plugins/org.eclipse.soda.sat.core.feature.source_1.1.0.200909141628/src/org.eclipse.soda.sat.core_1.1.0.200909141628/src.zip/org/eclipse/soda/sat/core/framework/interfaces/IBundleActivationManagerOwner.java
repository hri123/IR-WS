/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework.interfaces;

import java.io.IOException;
import java.io.InputStream;

/**
 * The <code>IBundleActivatorManagerManagerOwner</code> interface is
 * implemented by the owner of an <code>IBundleActivationManager</code>
 * instance.  The owner is responsible for handling call-backs from the manager.
 */
public interface IBundleActivationManagerOwner {
	public static final String[] NO_SERVICES = new String [ 0 ];

	/**
	 * <i>Hook Method:</i> You have been activated.  This method is implemented
	 * by bundles that wish to execute domain specific activation.
	 */
	public void activate();

	/**
	 * <i>Hook Method:</i> You have been deactivated.  This method is
	 * implemented to execute domain specific deactivation.
	 */
	public void deactivate();

	/**
	 * <i>Configuration Parameter Method:</i> Get the async start thread
	 * priority.  This method is implemented by bundles that have implemented
	 * the method <code>isStartAsync()</code> to return <code>true</code> and
	 * wish to specify a thread priority other than <code>Thread.NORM_PRIORITY
	 * </code>.
	 *
	 * @return The async start thread priority.
	 * @see #isStartAsync()
	 */
	public int getAsyncStartPriority();

	/**
	 * <i>Query Method:</i> Answers the names of all the services that are
	 * imported by the bundle.
	 *
	 * @return A String array containing the imported service names, or an empty
	 * String array if there are no imported service names.
	 */
	public String[] getImportedServiceNames();

	/**
	 * <i>Query Method:</i> Answers the names of all the services that are
	 * optionally imported by the bundle.
	 *
	 * @return A String array containing the optionally imported service names,
	 * or an empty String array if there are no optionally imported service
	 * names.
	 */
	public String[] getOptionalImportedServiceNames();

	/**
	 * <i>Hook Method:</i> Get an input stream to the bundle's properties.  This
	 * method is implemented by bundles that possess properties.
	 *
	 * @return An input stream to the properties or <code>null</code> if the
	 *         bundle does not have any properties.
	 *
	 * @throws java.io.IOException
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getFilePropertiesInputStream()
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getFilePropertiesInputStream(String)
	 */
	public InputStream getPropertiesInputStream() throws IOException;

	/**
	 * <i>Hook Handler Method:</i> When an optional imported service is
	 * acquired, this method is called.  This method should be implemented to
	 * handle the domain specific case where an optional imported service is
	 * acquired.  Since all acquired optional imported services will arrive via
	 * this method, it is important to handle each service separately.
	 *
	 * @param serviceName  The fully-qualified name of the optional imported
	 *                     service.
	 * @param service      The acquired optional imported service.
	 */
	public void handleAcquiredOptionalImportedService(String serviceName, Object service);

	/**
	 * <i>Hook Handler Method:</i> Handles a thrown exception.  This method can
	 * be implemented by bundles that wish to handle thrown exceptions
	 * themselves.
	 *
	 * @param exception  The unhandled exception.
	 * @return True if the exception was fully handled, otherwise false.
	 */
	public boolean handleException(Exception exception);

	/**
	 * <i>Hook Handler Method:</i> Handle the fact that the specified properties
	 * file could not be found.
	 *
	 * @param filename  The name of the properties file.
	 */
	public void handleFailedToFindProperties(String filename);

	/**
	 * <i>Hook Handler Method:</i> When an optional imported service is released
	 * this method is called.  This method should be implemented to handle the
	 * domain specific case where an optional imported service is released.
	 * Since all released optional imported services will arrive via this
	 * method, it is important to handle each service separately.
	 *
	 * @param serviceName  The fully-qualified name of the optional imported
	 *                     service.
	 * @param service      The released optional imported service.
	 */
	public void handleReleasedOptionalImportedService(String serviceName, Object service);

	/**
	 * <i>Configuration Parameter Method:</i> Specifies whether the bundle
	 * should start asynchronously.  This method should be implemented by
	 * bundles that wish to start asynchronously.
	 *
	 * @return True if the bundle should start asynchronously, otherwise false.
	 */
	public boolean isStartAsync();

	/**
	 * <i>Configuration Parameter Method:</i> Specify whether the bundle should
	 * be treated as transient.  Transient bundles are automatically uninstalled
	 * once they have started and entered the <code>Bundle.ACTIVE</code> state.
	 * This method should be implemented by bundles that are to be considered
	 * transient.
	 *
	 * <i>Note:</i>
	 * <ul>
	 *   <li>
	 *     A transient bundle typically does not export any services.
	 *   </li>
	 *   <li>
	 *     It makes no sense for a transient bundle to also implement the
	 *     method <code>isUninstallable()</code>.
	 *   </li>
	 * </ul>
	 *
	 * @return True if the bundle should be treated as transient, otherwise
	 * false.
	 */
	public boolean isTransient();

	/**
	 * <i>Configuration Parameter Method:</i> Specify whether the bundle should
	 * be treated as uninstalled.  Uninstalled bundles are automatically
	 * uninstalled when their last dependent bundle is uninstalled.  This method
	 * should be implemented to return <code>true</code> by bundles that are
	 * uninstallable prerequisites.
	 * <p>
	 * <i>Note:</i>
	 * <ul>
	 *   <li>
	 *     An uninstallable bundle is always a prerequisite of another bundle.
	 *   </li>
	 *   <li>
	 *     It makes no sense for an uninstallable bundle to also implement the
	 *     method <code>isTransient()</code>.
	 *   </li>
	 * </ul>
	 *
	 * @return True if the bundle should be treated as uninstallable, otherwise
	 * false.
	 */
	public boolean isUninstallable();

	/**
	 * <i>Hook Method:</i> This method is called when the <code>
	 * IBundleActivatorManager</code> executes its <code>start(BundleContext)
	 * </code> method.  This method is implemented by bundles that wish to
	 * perform behavior exactly once when the bundle starts.
	 *
	 * @throws java.lang.Exception
	 */
	public void start() throws Exception;

	/**
	 * <i>Hook Method:</i> This method is called when the <code>
	 * IBundleActivatorManager</code> executes its <code>stop(BundleContext)
	 * </code> method.  This method is implemented by bundles that wish to
	 * perform behavior exactly once when the bundle stops.
	 *
	 * @throws java.lang.Exception
	 */
	public void stop() throws Exception;
}
