/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.service;

import java.util.Collection;
import java.util.List;

import org.eclipse.soda.sat.core.framework.interfaces.BundleDependencyListener;
import org.osgi.framework.Bundle;

/**
 * The <code>BundleDependencyService</code> declares an API that allows the
 * dependencies between installed bundles to be queried.  The interface supports
 * adding and removing an object as a <code>BundleDependencyListener</code>.
 * <p>
 * The interface also provides a way for bundles to communicate that they
 * should be considered <i>uninstallable</i>, meaning that they wish to be
 * automatically uninstalled when their last dependent bundle is uninstalled.
 */
public interface BundleDependencyService {
	public static final String BDS_STATUS_PROPERTY = "org.eclipse.soda.sat.core.bds.status";  //$NON-NLS-1$

	/**
	 * The OSGi service name for <code>BundleDependencyService</code>.
	 */
	public static final String SERVICE_NAME = BundleDependencyService.class.getName();

	/**
	 * Add a <code>BundleDependencyListener</code>.
	 *
	 * @param listener  A <code>BundleDependencyListener</code>.
	 */
	public void addBundleDependencyListener(BundleDependencyListener listener);

	/**
	 * Adds a <code>Bundle</code> to the collection of uninstallable bundles.
	 *
	 * @param bundle  An uninstallable <code>Bundle</code>.
	 */
	public void addUninstallableBundle(Bundle bundle);

	/**
	 * Query for all the dependents of the specified bundle.
	 *
	 * @param bundle  A <code>Bundle</code>.
	 * @return List
	 */
	public List/*<Bundle>*/ getAllDependentsOf(Bundle bundle);

	/**
	 * Query for all the prerequisites of the specified bundle.
	 *
	 * @param bundle  A <code>Bundle</code>.
	 * @return <code>List</code>
	 */
	public List/*<Bundle>*/ getAllPrerequisitesOf(Bundle bundle);

	/**
	 * Query for all the <code>BundleActivationManager</code> ids.
	 *
	 * @return <code>List</code>
	 */
	public List/*<String>*/ getBundleActivationManagerIds();

	/**
	 * Get all the bundles.
	 *
	 * @return <code>Collection</code>
	 */
	public Collection/*<Bundle>*/ getBundles();
	/**
	 * Query for the immediate dependents of the specified bundle.
	 *
	 * @param bundle  A <code>Bundle</code>.
	 * @return List
	 */
	public List/*<Bundle>*/ getDependentsOf(Bundle bundle);

	/**
	 * Query for the immediate prerequisites of the specified bundle.
	 *
	 * @param bundle  A <code>Bundle</code>.
	 * @return List
	 */
	public List/*<Bundle>*/ getPrerequisitesOf(Bundle bundle);

	/**
	 * Get the unacquired imported services of the
	 * <code>IBundleActivationManager</code> with the specified id.
	 *
	 * @param id  The id of a <code>IBundleActivationManager</code>.
	 * @return List
	 */
	public List/*<String*/ getUnacquiredImportedServiceNames(String id);

	/**
	 * Get the unacquired optional imported services of the
	 * <code>IBundleActivationManager</code> with the specified id.
	 *
	 * @param id  The id of a <code>IBundleActivationManager</code>.
	 * @return List
	 */
	public List/*<String*/ getUnacquiredOptionalImportedServiceNames(String id);

	/**
	 * Answers true if the specified bundle has circular references, otherwise
	 * false.
	 *
	 * @param bundle  The <code>Bundle</code> to be queried.
	 * @return boolean
	 */
	public boolean hasCircularReferences(Bundle bundle);

	/**
	 * Answers true if a bundle is registered as uninstallable, otherwise
	 * false.
	 *
	 * @param bundle  The <code>Bundle</code> to be queried.
	 *
	 * @return boolean
	 */
	public boolean isRegisteredAsUninstallable(Bundle bundle);

	/**
	 * Add a <code>BundleDependencyListener</code>.
	 *
	 * @param listener  a BundleDependencyListeer.
	 */
	public void removeBundleDependencyListener(BundleDependencyListener listener);

	/**
	 * Removes a <code>Bundle</code> from the collection of uninstallable bundles.
	 *
	 * @param bundle  An uninstallable <code>Bundle</code>.
	 */
	public void removeUninstallableBundle(Bundle bundle);

	/**
	 * Convert the state of the <code>BundleDependencyService</code> to XML.
	 *
	 * @return An XML representation of the state of the service.
	 */
	public String toXml();

	/**
	 * Convert the state of the <code>BundleDependencyService</code> to XML.
	 *
	 * @param indent  The indent level at which to start.
	 *
	 * @return An XML representation of the state of the service.
	 */
	public String toXml(int indent);
}
