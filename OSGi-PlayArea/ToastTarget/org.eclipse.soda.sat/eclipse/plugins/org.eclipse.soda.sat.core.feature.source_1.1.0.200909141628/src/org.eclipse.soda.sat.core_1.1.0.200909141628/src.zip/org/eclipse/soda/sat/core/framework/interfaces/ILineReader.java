/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework.interfaces;

import java.io.IOException;
import java.util.Enumeration;

/**
 * The <code>ILineReader</code> interface defines the API for line-oriented
 * reading of an <code>InputStream</code>.  An instance of
 * <code>ILineReader</code> can be created using the <code>FactoryUtility</code>
 * singleton.
 *
 * <pre>
 * FactoryUtility utility = FactoryUtility.getInstance();
 * InputStream stream = ...
 * try {
 *   ILineReader reader = utility.createLineReader(stream);
 *   try {
 *     ...
 *   } finally {
 *     reader.close();
 *   }
 * } catch (IOException exception) {
 *   ...
 * }
 * </pre>
 *
 * While a single line may be read using the <code>readLine()</code> method,
 * reading multiple lines is typically done by calling the <code>lines()</code>
 * method that returns an <code>Enumeration</code>.
 *
 * <pre>
 * Enumeration lines = reader.lines();
 * while (lines.hasMoreElements() == true) {
 *   String line = (String) lines.nextElement();
 *   ...
 * }
 * </pre>
 *
 * The nested <code>IAdvisor</code> interface defines the advice that can be
 * given an <code>ILineReader</code> as each line is read.
 *
 * @see ILineReader.IAdvisor
 * @see org.eclipse.soda.sat.core.util.FactoryUtility
 */
public interface ILineReader {
	/**
	 * The <code>IAdvisor</code> interface defines the advice that can be given
	 * to an <code>ILineReader</code> as each line is read.
	 * <pre>
	 * IAdvisor advisor = new IAdvisor() {
	 *   public boolean isValid(String line) {
	 *     return line.charAt(0) != '#';
	 *   }
	 *
	 *   public String transform(String line) {
	 *     String value = line.trim();
	 *     value = value.toLower();
	 *     return value;
	 *   }
	 * };
	 * </pre>
	 */
	public interface IAdvisor {
		/**
		 * Query whether a read line is valid.
		 *
		 * @param line  A read line.
		 * @return <code>boolean</code>.
		 */
		public boolean isValid(String line);

		/**
		 * Perform a transformation on a read line.  By default no
		 * transformation is performed.
		 *
		 * @param line  The read line to be transformed.
		 * @return <code>String</code>.
		 */
		public String transform(String line);
	}

	/**
	 * Close the receiver.
	 *
	 * @throws IOException
	 */
	public void close() throws IOException;

	/**
	 * Answers an <code>Enumeration</code> for reading lines.
	 *
	 * @return An <code>Enumeration</code> used for reading the lines from the
	 * <code>InputStream</code>.
	 */
	public Enumeration lines();

	/**
	 * Reads and answers a single line.
	 *
	 * @return A <code>String</code> containing single line from the source
	 * <code>InputStream</code>.
	 * @throws IOException
	 */
	public String readLine() throws IOException;
}