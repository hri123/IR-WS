/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.eclipse.soda.sat.core.framework.interfaces.IQueue;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.service.BundleUninstallService;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.BundleUtility;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.eclipse.soda.sat.core.util.MiscUtility;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleException;

public class BundleUninstallManager extends BundleManager implements BundleUninstallService {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String BUNDLE_CANNOT_BE_ADDED_KEY = "BundleUninstallManager.BundleCannotBeAdded";  //$NON-NLS-1$
	private static final String BUNDLE_MUST_BE_STARTING_KEY = "BundleUninstallManager.BundleMustBeStarting";  //$NON-NLS-1$
	private static final String FAILED_TO_UNINSTALL_BUNDLE_KEY = "BundleUninstallManager.FailedToUninstallBundle";  //$NON-NLS-1$
	private static final String OBJECT_IDENTITY_FAILURE_KEY = "BundleUninstallManager.ObjectIdentityFailure";  //$NON-NLS-1$

	// Property Keys
	private static final String THREAD_IDLE_TIMEOUT_PROPERTY_KEY = "org.eclipse.soda.sat.core.bundle.uninstaller.thread.idle.timeout";  //$NON-NLS-1$

	// Default Property Values
	private static final long DEFAULT_THREAD_IDLE_TIMEOUT = 10000;

	// Properties
	private static final long THREAD_IDLE_TIMEOUT = BundleUninstallManager.getLongProperty(BundleUninstallManager.THREAD_IDLE_TIMEOUT_PROPERTY_KEY, BundleUninstallManager.DEFAULT_THREAD_IDLE_TIMEOUT);

	// Singleton
	private static final BundleUninstallManager INSTANCE = new BundleUninstallManager();

	//
	// Static Methods
	//

	static BundleUninstallManager getInstance() {
		return BundleUninstallManager.INSTANCE;
	}

	private static long getLongProperty(String key, long defaultValue) {
		MiscUtility utility = MiscUtility.getInstance();
		long value = utility.getLongProperty(key, defaultValue);
		return value;
	}

	//
	// Instance Fields
	//

	private Thread thread;
	private int threadId;
	private Map/*<Object, Bundle>*/ pendingBundles;
	private IQueue uninstallableBundles;

	//
	// Constructors
	//

	private BundleUninstallManager() {
		super();
		setUninstallableBundles(createQueue(25));
		setPendingBundles(new HashMap/*<Object, Bundle>*/(101));
		setThreadId(0);
	}

	//
	// Instance Methods
	//

	private void addToPendingBundles(Bundle bundle) {
		checkBundleIsStarting(bundle);
		Map/*<Object, Bundle>*/ map = getPendingBundles();
		Object key = bundle.getSymbolicName();

		synchronized (map) {
			map.put(key, bundle);
		}
	}

	private void addToUninstallableBundles(Bundle bundle) {
		IQueue queue = getUninstallableBundles();

		synchronized (queue) {
			boolean exists = queue.contains(bundle);
			if (exists == true)
				return;  // Early return.
			queue.add(bundle);
		}

		startThreadIfNecessary();
	}

	private void checkBundleIdentity(Bundle bundle) {
		checkIsNotSystemBundle(bundle);
		checkIsNotOwner(bundle);
	}

	private void checkBundleIsStarting(Bundle bundle) {
		boolean starting = isBundleState(bundle, Bundle.STARTING);
		if (starting == true)
			return;  // Early return.
		String message = Messages.getString(BundleUninstallManager.BUNDLE_MUST_BE_STARTING_KEY);
		throw new IllegalArgumentException(message);
	}

	/**
	 * Check that the bundle being added to the manager is neither the System
	 * Bundle (with an ID of 0) nor the bundle that created the manager.
	 * <p>
	 * This check is necessary since the owner of the manager cannot be
	 * uninstalled once started.  Doing so would cause an exception to be
	 * thrown by the OSGi framework.
	 *
	 * @param bundle  A bundle.
	 */
	private void checkIsNotOwner(Bundle bundle) {
		Bundle owner = getBundle();
		if (bundle == null)
			return;  // Early return.
		boolean illegal = owner.equals(bundle);
		if (illegal == false)
			return;  // Early return.
		String location = bundle.getLocation();
		String pattern = Messages.getString(BundleUninstallManager.BUNDLE_CANNOT_BE_ADDED_KEY);
		String message = MessageFormatter.format(pattern, location);
		throw new IllegalArgumentException(message);
	}

	/**
	 * Check that the specified bundle is not the System Bundle.
	 *
	 * @param bundle  A bundle.
	 */
	private void checkIsNotSystemBundle(Bundle bundle) {
		long id = bundle.getBundleId();
		if (id == 0)
			return;  // Early return.
	}

	private void checkObjectIdentities(Object object1, Object object2) {
		boolean identical = object1 == object2; // $codepro.audit.disable useEquals
		if (identical == true)
			return;  // Early return.
		String message = Messages.getString(BundleUninstallManager.OBJECT_IDENTITY_FAILURE_KEY);
		throw new RuntimeException(message);
	}

	private IQueue createQueue(int capacity) {
		FactoryUtility utility = FactoryUtility.getInstance();
		IQueue queue = utility.createQueue(capacity);
		return queue;
	}

	private Runnable createRunnable() {
		return new Runnable(){
			public void run() {
				BundleUninstallManager.this.process();
			}
		};
	}

	private Map/*<Object, Bundle>*/ getPendingBundles() {
		return pendingBundles;
	}

	private Thread getThread() {
		return thread;
	}

	private int getThreadId() {
		return threadId;
	}

	private IQueue getUninstallableBundles() {
		return uninstallableBundles;
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.framework.bundle.BundleManager#handleBundleStarted(org.osgi.framework.Bundle)
	 */
	protected void handleBundleStarted(Bundle bundle) {
		super.handleBundleInstalled(bundle);
		uninstallPendingBundle(bundle);
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.framework.bundle.BundleManager#handleManagerShutdown()
	 */
	protected void handleManagerShutdown() {
		stopThreadIfNecessary();
		super.handleManagerShutdown();
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.framework.bundle.BundleManager#handleManagerStarted()
	 */
	protected void handleManagerStarted() {
		super.handleManagerStarted();
		uninstallActivePendingBundles();
		startThreadIfNecessary();
	}

	private boolean isBundleState(Bundle bundle, int state) {
		BundleUtility utility = BundleUtility.getInstance();
		boolean result = utility.isBundleState(bundle, state);
		return result;
	}

	private void process() {
		while (isStarted() == true) {
			Bundle bundle = removeFromQueue(BundleUninstallManager.THREAD_IDLE_TIMEOUT);
			if (bundle == null)
				break;  // Terminate loop.
			uninstallBundle(bundle);
		}

		setThread(null);
	}

	private Bundle removeFromQueue(long timeout) {
		IQueue queue = getUninstallableBundles();
		Bundle bundle = null;

		try {
			bundle = (Bundle) queue.remove(timeout);
		} catch (InterruptedException exception) {
			// OK
		}

		return bundle;
	}

	private void setPendingBundles(Map/*<Object, Bundle>*/ pendingBundles) {
		this.pendingBundles = pendingBundles;
	}

	private void setThread(Thread thread) {
		this.thread = thread;
	}

	private void setThreadId(int threadId) {
		this.threadId = threadId;
	}

	private void setUninstallableBundles(IQueue uninstallableBundles) {
		this.uninstallableBundles = uninstallableBundles;
	}

	private void startThread() {
		Runnable runnable = createRunnable();
		int id = getThreadId() + 1;
		setThreadId(id);
		String name = "SAT-BundleUninstallManager-" + id;  //$NON-NLS-1$ // $codepro.audit.disable disallowStringConcatenation
		Thread thread = new Thread(runnable, name);
		setThread(thread);
		thread.start();
	}

	private void startThreadIfNecessary() {
		IQueue queue = getUninstallableBundles();
		boolean empty = queue.isEmpty();
		if (empty == true)
			return;  // Early return.

		synchronized (this) {
			Thread thread = getThread();
			if (thread != null)
				return;  // Early return.
			startThread();
		}
	}

	private void stopThread() {
		Thread thread = getThread();
		thread.interrupt();

		try {
			thread.join();
		} catch (InterruptedException e) {
			// OK
		} finally {
			setThread(null);
		}
	}

	private void stopThreadIfNecessary() {
		synchronized (this) {
			Thread thread = getThread();
			if (thread == null)
				return;  // Early return.
			stopThread();
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.service.BundleUninstallService#uninstall(org.osgi.framework.Bundle)
	 */
	public void uninstall(Bundle bundle) {
		Assertion.checkArgumentIsNotNull(bundle, "bundle");  //$NON-NLS-1$
		checkBundleIdentity(bundle);
		boolean active = isBundleState(bundle, Bundle.ACTIVE);

		if (active == true) {
			addToUninstallableBundles(bundle);
		} else {
			addToPendingBundles(bundle);
		}
	}

	private void uninstallActivePendingBundles() {
		HashMap/*<Object, Bundle>*/ map = (HashMap/*<Object, Bundle>*/) getPendingBundles();

		synchronized (map) {
			Map/*<Object, Bundle>*/ clone = (Map/*<Object, Bundle>*/) map.clone();
			Set/*<Object>*/ keys = clone.keySet();
			Iterator/*<Object>*/ iterator = keys.iterator();

			while (iterator.hasNext() == true) {
				Object key = iterator.next();
				Bundle bundle = (Bundle) map.get(key);
				boolean active = isBundleState(bundle, Bundle.ACTIVE);
				if (active == false)
					continue;  // Skip to next iteration.
				uninstallBundle(bundle);
				map.remove(key);
			}
		}
	}

	private void uninstallBundle(Bundle bundle) {
		try {
			bundle.uninstall();
		} catch (BundleException exception) {
			Thread thread = Thread.currentThread();
			String id = thread.getName();
			String message = Messages.getString(BundleUninstallManager.FAILED_TO_UNINSTALL_BUNDLE_KEY);
			LogUtility.logError(id, message, exception);
		}
	}

	private void uninstallPendingBundle(Bundle bundle) {
		Map/*<Object, Bundle>*/ map = getPendingBundles();
		Object key = bundle.getSymbolicName();

		synchronized (map) {
			Object value = map.remove(key);
			if (value == null)
				return;  // Early return.
			checkObjectIdentities(bundle, value);
			uninstallBundle(bundle);
		}
	}
}
