/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.service;

import java.util.Enumeration;

import org.osgi.service.log.LogReaderService;

/**
 * The <code>LogReaderAggregatorService</code> provides a single point at which
 * to add a <code>LogListener</code> that will be notified of messages logged
 * to every registered <code>LogService</code>.  The service is helpful in that
 * it removes the responsibility of listening to multiple instances of the
 * <code>LogReaderService</code>.<br/>
 * <br/>
 * While the listener will be notified of each logged message, it will be
 * unaware of the <code>LogService</code> to which the message was logged, and
 * of the <code>LogReaderService</code> from which the message was read.
 */
public interface LogReaderAggregatorService extends LogReaderService {
	public static final String LOGGING_TO_CONSOLE_PROPERTY = "org.eclipse.soda.sat.core.log.to.console";  //$NON-NLS-1$
	public static final String SERVICE_NAME = LogReaderAggregatorService.class.getName();

	/**
	 * Get the contents of the log in the order in the log entries were written.
	 * This method is similar to the <code>LogReaderService</code> method
	 * <code>getLog()</code>.
	 *
	 * @return An <code>Enumeration</code> of <code>LogEntry</code> objects.
	 */
	public Enumeration/*<LogEntry>*/ getLogInOrder();

	/**
	 * Query whether logging to the console is enabled.
	 *
	 * @return True if logging to the console is enabled, otherwise false.
	 */
	public boolean isLoggingToConsole();

	/**
	 * Control whether logging to the console is enabled.
	 *
	 * @param logToConsole  A parameter of true will enable logging to the
	 *                      console, while a parameter of false will disable
	 *                      logging to the console.
	 */
	public void setLogToConsole(boolean logToConsole);
}
