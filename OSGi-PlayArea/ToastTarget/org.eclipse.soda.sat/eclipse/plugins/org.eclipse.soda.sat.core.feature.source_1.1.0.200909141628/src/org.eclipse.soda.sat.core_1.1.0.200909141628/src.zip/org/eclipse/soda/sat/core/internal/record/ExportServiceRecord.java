/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.record;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.Hashtable;

import org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.BundleManifestUtility;
import org.eclipse.soda.sat.core.util.MiscUtility;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.framework.ServiceRegistration;

/**
 * The <code>ExportServiceRecord</code> class models a service that is exported
 * by a bundle and registered with the OSGi framework.  The class is an
 * implementation of the <code>IExportServiceRecord</code> interface.
 */
public final class ExportServiceRecord extends ServiceRecord implements IExportServiceRecord {
	//
	// Static Fields
	//

	// Property Keys
	private static final String REGISTER_ADDITIONAL_PROPERTIES_PROPERTY = "org.eclipse.soda.sat.core.internal.record.register.additional.properties";  //$NON-NLS-1$

	// Default Property Values
	private static final boolean DEFAULT_REGISTER_ADDITIONAL_PROPERTIES = true;

	// Properties
	private static final boolean REGISTER_ADDITIONAL_PROPERTIES = ExportServiceRecord.getBooleanProperty(ExportServiceRecord.REGISTER_ADDITIONAL_PROPERTIES_PROPERTY, ExportServiceRecord.DEFAULT_REGISTER_ADDITIONAL_PROPERTIES);

	// Misc
	private static final int PROPERTIES_INITIAL_CAPACITY = 29;

	//
	// Static Methods
	//

	private static boolean getBooleanProperty(String key, boolean defaultValue) {
		MiscUtility utility = MiscUtility.getInstance();
		boolean value = utility.getBooleanProperty(key, defaultValue);
		return value;
	}

	//
	// Instance Fields
	//

	private String[] names;
	private Dictionary properties;
	private volatile ServiceRegistration registration;

	//
	// Constructors
	//

	/**
	 * Public constructor.
	 *
	 * @param bundleContext  The <code>BundleContext</code> handle back to the
	 *                       framework.
	 * @param names          The fully qualified type names of the exported
	 *                       services.
	 * @param service		 The exported service.
	 * @param properties     The properties of the exported service.
	 */
	public ExportServiceRecord(BundleContext bundleContext, String[] names, Object service, Dictionary properties) {
		super(bundleContext);
		Assertion.checkArgumentIsNotNull(service, "service");  //$NON-NLS-1$
		setNames(names);
		setService(service);
		setProperties(properties);
		setServiceRegistration(null);
	}

	//
	// Instance Methods
	//

	/**
	 * Private basic properties setter.
	 *
	 * @param properties  The exported service properties.
	 */
	private void basicSetProperties(Dictionary properties) {
		this.properties = properties;
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.record.ServiceRecord#createServiceFilter()
	 */
	protected String createServiceFilter() {
		int length = estimateServiceFilterLength();
		StringBuffer buffer = new StringBuffer(length);
		createServiceFilterOn(buffer);
		String result = buffer.toString();
		return result;
	}

	/**
	 * Create the service filter based on the export service names.
	 *
	 * @param buffer  The buffer on which to write the filter.
	 */
	private void createServiceFilterOn(StringBuffer buffer) {
		String[] names = getNames();

		if (names.length == 1) {
			String name = names [ 0 ];
			createServiceFilterOn(buffer, name);
		} else {
			buffer.append('(');
			buffer.append('|');  // LDAP OR operator

			for (int i = 0; i < names.length; i++) {
				String name = names [ i ];
				createServiceFilterOn(buffer, name);
			}

			buffer.append(')');
		}
	}

	/**
	 * Estimate the length of the service filter.  Too big is better than too
	 * small.
	 *
	 * @return The estimated length of the service filter.
	 */
	private int estimateServiceFilterLength() {
		String[] names = getNames();
		int size = 3;

		for (int i = 0; i < names.length; i++) {
			String name = names [ i ];
			int length = name.length();
			size += 14 + length;
		}

		return size;
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.record.ServiceRecord#estimateToStringBufferSize()
	 */
	protected int estimateToStringBufferSize() {
		return super.estimateToStringBufferSize() + 250;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord#getNames()
	 */
	public String[] getNames() {
		return names;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord#getProperties()
	 */
	public Dictionary getProperties() {
		synchronized (this) {
			if (properties == null) {
				Dictionary properties = new Hashtable(ExportServiceRecord.PROPERTIES_INITIAL_CAPACITY);
				basicSetProperties(properties);
			}

			return properties;
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceRecord#getProperty(String)
	 */
	public Object getProperty(String key) {
		Object property = super.getProperty(key);
		if (property != null)
			return property;  // Early return.

		Dictionary properties = getProperties();
		if (properties == null)
			return null;  // Early return.

		property = properties.get(key);

		if (property == null) {
			signalUnknownProperty(key);
		}

		return property;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceRecord#getPropertyKeys()
	 */
	public String[] getPropertyKeys() {
		String[] keys = super.getPropertyKeys();
		int length = keys.length;
		if (length != 0)
			return keys;  // Early return.

		Dictionary properties = getProperties();
		if (properties == null)
			return ServiceRecord.NO_PROPERTY_KEYS;  // Early return.

		int size = properties.size();
		keys = new String [ size ];
		Collection/*<String>*/ collection;

		if (properties instanceof Hashtable) { // $codepro.audit.disable disallowInstanceof
			Hashtable table = (Hashtable) properties;
			collection = table.keySet();
		} else {
			Enumeration enumeration = properties.keys();
			collection = new ArrayList/*<String>*/(size);

			while (enumeration.hasMoreElements() == true) {
				Object key = enumeration.nextElement();
				collection.add(key);
			}
		}

		collection.toArray(keys);
		return keys;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord#getServiceReference()
	 */
	public ServiceReference getServiceReference() {
		ServiceReference reference = null;
		ServiceRegistration registration = getServiceRegistration();

		if (registration != null) {
			reference = registration.getReference();
		}

		return reference;
	}

	/**
	 * Private registration getter.
	 *
	 * @return ServiceRegistration
	 */
	private ServiceRegistration getServiceRegistration() {
		return registration;
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.record.ServiceRecord#handleUnregisteringService(org.osgi.framework.ServiceReference)
	 */
	protected void handleUnregisteringService(ServiceReference serviceReference) {
		Object lock = getLock();

		synchronized (lock) {
			setServiceRegistration(null);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord#isProxy()
	 */
	public boolean isProxy() {
		return false;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord#isRegistered()
	 */
	public boolean isRegistered() {
		Object registration = getServiceRegistration();
		boolean registered = registration != null;
		return registered;
	}

	/**
	 * Populate the specified properties with some additional property key/value
	 * pairs.  For now we add the bundle vendor, bundle version and service
	 * registration timestamp.
	 *
	 * @param properties  Dictionary of properties.
	 */
	private void populateWithAdditionalProperties(Dictionary properties) {
		if (ExportServiceRecord.REGISTER_ADDITIONAL_PROPERTIES == false)
			return;  // Early return.
		setBundleIdProperty(properties);
		setServiceVendorProperty(properties);
		setBundleVersionProperty(properties);
		setServiceRegistrationTimestampProperty(properties);
	}

	/**
	 * Prints a the service names on the StringBuffer.
	 *
	 * @param buffer  A buffer on which to print the service names.
	 */
	private void printNamesOn(StringBuffer buffer) {
		buffer.append(", names=");  //$NON-NLS-1$
		Object[] names = getNames();
		int count = names.length;

		for (int i = 0; i < count; i++) {
			Object name = names [ i ];
			buffer.append(name);

			if (i < count - 1) {
				buffer.append(',');
				buffer.append(' ');
			}
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.record.ServiceRecord#printOn(java.lang.StringBuffer)
	 */
	protected void printOn(StringBuffer buffer) {
		super.printOn(buffer);
		printNamesOn(buffer);
		printPropertiesOn(buffer);
		printServiceRegistrationOn(buffer);
	}

	/**
	 * Print the properties on the specified buffer.
	 *
	 * @param buffer  The buffer on which to write.
	 */
	private void printPropertiesOn(StringBuffer buffer) {
		Object properties = getProperties();
		buffer.append(", properties=");  //$NON-NLS-1$
		buffer.append(properties);
	}

	/**
	 * Print the service registration on the specified buffer.
	 *
	 * @param buffer  The buffer on which to write.
	 */
	private void printServiceRegistrationOn(StringBuffer buffer) {
		Object registration = getServiceRegistration();
		buffer.append(", registration=");  //$NON-NLS-1$
		printOn(buffer, registration);
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord#register()
	 */
	public void register() {
		Object lock = getLock();

		synchronized (lock) {
			boolean registered = isRegistered();
			if (registered == true)
				return;  // Early return.
			registerAsServiceListener();
			registerServiceWithFramework();
		}
	}

	/**
	 * Register the service with the framework.
	 */
	private void registerServiceWithFramework() {
		BundleContext bundleContext = getBundleContext();
		Object service = getService();
		String[] names = getNames();
		Dictionary properties = getProperties();
		populateWithAdditionalProperties(properties);
		ServiceRegistration registration = bundleContext.registerService(names, service, properties);
		setServiceRegistration(registration);
	}

	/**
	 * Set the bundle id property key/value.
	 *
	 * @param properties  <code>Dictionary</code> of properties.
	 */
	private void setBundleIdProperty(Dictionary properties) {
		Object key = IExportServiceRecord.BUNDLE_ID_PROPERTY;
		Object value = properties.get(key);
		if (value != null)
			return;  // Early return.
		Bundle bundle = getBundle();
		if (bundle == null)
			return;  // Early return.
		long id = bundle.getBundleId();
		value = new Long(id);
		properties.put(key, value);
	}

	/**
	 * Set the bundle version property key/value.
	 *
	 * @param properties  <code>Dictionary</code> of properties.
	 */
	private void setBundleVersionProperty(Dictionary properties) {
		Object key = IExportServiceRecord.BUNDLE_VERSION_PROPERTY;
		Object value = properties.get(key);
		if (value != null)
			return;  // Early return.
		BundleManifestUtility utility = BundleManifestUtility.getInstance();
		Bundle bundle = getBundle();
		if (bundle == null)
			return;  // Early return.
		value = utility.getBundleVersion(bundle);
		if (value == null)
			return;  // Early return.
		properties.put(key, value);
	}

	/**
	 * Protected names setter.
	 *
	 * @param names  An array of service names.
	 */
	private void setNames(String[] names) {
		Assertion.checkArgumentIsNotNull(names, "names");  //$NON-NLS-1$
		this.names = names;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord#setProperties(Dictionary)
	 */
	public void setProperties(Dictionary properties) {
		synchronized (this) {
			basicSetProperties(properties);

			boolean registered = isRegistered();
			if (registered == false)
				return;  // Early return.

			Dictionary registrationProperties = getProperties();
			populateWithAdditionalProperties(registrationProperties);

			ServiceRegistration registration = getServiceRegistration();
			registration.setProperties(registrationProperties);
		}
	}

	/**
	 * Private registration setter.
	 *
	 * @param registration  A ServiceRegistration.
	 */
	private void setServiceRegistration(ServiceRegistration registration) {
		this.registration = registration;
	}

	/**
	 * Record the time the service was registered/modified using the timestamp
	 * property.
	 *
	 * @param properties  The properties of the exported service.
	 */
	private void setServiceRegistrationTimestampProperty(Dictionary properties) {
		long now = System.currentTimeMillis();
		Long value = new Long(now);
		properties.put(IExportServiceRecord.SERVICE_REGISTRATION_TIMESTAMP_PROPERTY, value);
	}

	/**
	 * Set the service vendor property key/value.
	 *
	 * @param properties  Dictionary of properties.
	 */
	private void setServiceVendorProperty(Dictionary properties) {
		Object key = IExportServiceRecord.SERVICE_VENDOR_PROPERTY;
		Object value = properties.get(key);
		if (value != null)
			return;  // Early return.
		BundleManifestUtility utility = BundleManifestUtility.getInstance();
		Bundle bundle = getBundle();
		if (bundle == null)
			return;  // Early return.
		value = utility.getBundleVendor(bundle);
		if (value == null)
			return;  // Early return.
		properties.put(key, value);
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord#unregister()
	 */
	public void unregister() {
		Object lock = getLock();

		synchronized (lock) {
			boolean registered = isRegistered();
			if (registered == false)
				return;  // Early return.
			unregisterServiceWithFramework();
			unregisterAsServiceListener();
		}
	}

	/**
	 * Unregister the service with the framework.
	 */
	private void unregisterServiceWithFramework() {
		ServiceRegistration registration = getServiceRegistration();

		try {
			registration.unregister();
		} catch (IllegalStateException exception) {
			// The BundleContext is disposed.
			setServiceRegistration(null);
		}
	}
}