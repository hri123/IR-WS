/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager;
import org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner;
import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.framework.interfaces.IProxyServiceHandler;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.internal.util.WarningMessageUtility;
import org.eclipse.soda.sat.core.record.container.interfaces.IExportServiceRecordContainer;
import org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainer;
import org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainerLenientOwner;
import org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainerOwner;
import org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordAction;
import org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordContainer;
import org.eclipse.soda.sat.core.record.interfaces.IExportProxyServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IServiceRecord;
import org.eclipse.soda.sat.core.service.BundleUninstallService;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.BundleManifestUtility;
import org.eclipse.soda.sat.core.util.CollectionUtility;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleException;
import org.osgi.framework.Constants;
import org.osgi.framework.Filter;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.service.startlevel.StartLevel;

/**
 * The <code>BundleActivationManager</code> class contains the core behavior for
 * SAT's bundle activation strategy.  Every instance of the class
 * <code>BaseBundleActivator</code> contains an instance of this class.  Most of
 * the <code>BaseBundleActivator</code> methods simply delegate to their
 * <code>BundleActivatorManager</code> instance.
 * <p>
 * When an instance of the <code>BundleActivationManager</code> is created, an
 * instance of the <code>IBundleActivationManagerOwner</code> interface must be
 * passed to the constructor for handling call-backs.
 * <p>
 * Once an instance has been created, the <code>BundleActivatorManager</code> is
 * started by calling the <code>start(BundleContext)</code> method, passing in
 * the bundle's <code>BundleContext</code>.  When the bundle stops it should
 * call the <code>stop(BundleContext)</code> method passing in the same instance
 * of <code>BundleContext</code>.
 */
public class BundleActivationManager extends Object implements IBundleActivationManager {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String ASYNC_START_UP_KEY = "BundleActivationManager.AsyncStartUp";  //$NON-NLS-1$
	private static final String ASYNC_START_UP_THREAD_HAS_STOPPED_KEY = "BundleActivationManager.AsyncStartUpThreadHasStopped";  //$NON-NLS-1$
	private static final String BUNDLE_ACTIVATION_MANAGER_IS_NOT_STARTED_KEY = "BundleActivationManager.BundleActivationManagerIsNotStarted";  //$NON-NLS-1$
	private static final String BUNDLES_SHOULD_BE_TRANSIENT_OR_UNINSTALLABLE_NOT_BOTH_KEY = "BundleActivationManager.BundleShouldBeTransientOrUninstallableNotBoth";  //$NON-NLS-1$
	private static final String CLASS_KEY = "BundleActivationManager.Class";  //$NON-NLS-1$

	// Actions
	private static IServiceRecordAction collectExportedServicesAction;
	private static IServiceRecordAction collectImportedServicesAction;
	private static final String FAILED_TO_ACQUIRE_THE_FOLLOWING_SERVICES_KEY = "BundleActivationManager.FailedToAcquireTheFollowingServices";  //$NON-NLS-1$
	private static final String FAILED_TO_GET_IMPORTED_SERVICE_KEY = "BundleActivationManager.FailedToGetImportedService";  //$NON-NLS-1$
	private static final String FAILED_TO_GET_PROPERTIES_KEY = "BundleActivationManager.FailedToGetProperties";  //$NON-NLS-1$
	private static final String FRAMEWORK_RESTARTED_BY_KEY = "BundleActivationManager.FrameworkRestartedBy";  //$NON-NLS-1$
	private static final String FRAMEWORK_SHUTDOWN_BY_KEY = "BundleActivationManager.FrameworkShutdownBy";  //$NON-NLS-1$
	private static final String INVALID_LDAP_FILTER_KEY = "BundleActivationManager.InvalidLdapFilter";  //$NON-NLS-1$
	private static final String SAT_CORE_KEY = "Common.SatCore";  //$NON-NLS-1$
	private static final String SERVICE_KEY = "Common.Service";  //$NON-NLS-1$

	private static final String NO_ID = "$NO_ID$";  //$NON-NLS-1$
	private static final String UNKNOWN_BUNDLE_CONTEXT_KEY = "Common.UnknownBundleContext";  //$NON-NLS-1$
	private static final String WAITING_FOR_ASYNC_START_UP_THREAD_TO_STOP_KEY = "BundleActivationManager.WaitingForAsyncStartUpThreadToStop";  //$NON-NLS-1$

	//
	// Static Methods
	//

	private static void collectServices(IExportServiceRecord record, Map/*<String, List<Object>>*/ map) {
		String[] names = record.getNames();
		Object service = record.getService();

		for (int i = 0; i < names.length; i++) {
			String name = names [ i ];
			List/*<Object>*/ value = (List/*<Object>*/) map.get(name);
			if (value == null) {
				value = new ArrayList/*<Object>*/(3);
				map.put(name, value);
			}
			value.add(service);
		}
	}

	private static void collectServices(IImportServiceRecord record, Map/*<String, Object>*/ map) {
		String name = record.getName();
		Object service = record.getService();
		map.put(name, service);
	}

	private static IServiceRecordAction createCollectExportedServicesAction() {
		return new IServiceRecordAction() {
			public boolean execute(IServiceRecord record, Object parameter) {
				IExportServiceRecord exportServiceRecord = (IExportServiceRecord) record;
				Map/*<String, List<Object>>*/ map = (Map/*<String, List<Object>>*/) parameter;
				BundleActivationManager.collectServices(exportServiceRecord, map);
				return true;
			}
		};
	}

	private static IServiceRecordAction createCollectImportedServicesAction() {
		return new IServiceRecordAction() {
			public boolean execute(IServiceRecord record, Object parameter) {
				IImportServiceRecord importServiceRecord = (IImportServiceRecord) record;
				Map/*<String, Object>*/ map = (Map/*<String, Object>*/) parameter;
				BundleActivationManager.collectServices(importServiceRecord, map);
				return true;
			}
		};
	}

	private static IServiceRecordAction getCollectExportedServicesAction() {
		synchronized (BundleActivationManager.class) {
			if (BundleActivationManager.collectExportedServicesAction == null) {
				BundleActivationManager.setCollectExportedServicesAction(BundleActivationManager.createCollectExportedServicesAction());
			}

			return BundleActivationManager.collectExportedServicesAction;
		}
	}

	private static IServiceRecordAction getCollectImportedServicesAction() {
		synchronized (BundleActivationManager.class) {
			if (BundleActivationManager.collectImportedServicesAction == null) {
				BundleActivationManager.setCollectImportedServicesAction(BundleActivationManager.createCollectImportedServicesAction());
			}

			return BundleActivationManager.collectImportedServicesAction;
		}
	}

	private static void setCollectExportedServicesAction(IServiceRecordAction collectExportedServicesAction) {
		BundleActivationManager.collectExportedServicesAction = collectExportedServicesAction;
	}

	private static void setCollectImportedServicesAction(IServiceRecordAction collectImportedServicesAction) {
		BundleActivationManager.collectImportedServicesAction = collectImportedServicesAction;
	}

	//
	// Instance Fields
	//

	private boolean activated;
	private final Object activationLock = new Object();
	private Thread asyncStartThread;
	private BundleContext bundleContext;
	private IExportServiceRecordContainer exportServiceRecords;
	private String id;
	private Map/*<String, Filter>*/ importedServiceFilters;
	private IImportServiceRecordContainer importServiceRecords;
	private Map/*<String, Filter>*/ optionalImportedServiceFilters;
	private IImportServiceRecordContainer optionalImportServiceRecords;
	private IBundleActivationManagerOwner owner;
	private Properties properties;
	private final Object startLock = new Object();

	//
	// Constructors
	//

	/**
	 * Constructor
	 */
	public BundleActivationManager() {
		super();
		setActivated(false);
	}

	/**
	 * Constructor
	 *
	 * @param id  A unique id.
	 */
	public BundleActivationManager(String id) {
		this();
		setId(id);
	}

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#acquireImportedService(java.lang.String)
	 */
	public Object acquireImportedService(String name) {
		IImportServiceRecord record = getImportServiceRecord(name);
		Object service = acquireImportServiceRecord(record);
		return service;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#acquireImportedServices()
	 */
	public void acquireImportedServices() {
		IImportServiceRecordContainer container = getImportServiceRecords();
		container.acquire();
		logTraceOfUnacquiredImportedServices();
	}

	private Object acquireImportServiceRecord(IImportServiceRecord record) {
		if (record == null)
			return null;  // Early return.
		record.acquire();
		Object service = record.getService();
		return service;
	}

	private void acquireImportServiceRecords() {
		IImportServiceRecordContainer container = getImportServiceRecords();
		IImportServiceRecordContainerOwner owner = createImportServiceRecordContainerOwner();
		container.setOwner(owner);
		acquireImportedServices();
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#acquireOptionalImportedService(java.lang.String)
	 */
	public Object acquireOptionalImportedService(String name) {
		IImportServiceRecord record = getOptionalImportServiceRecord(name);
		Object service = acquireImportServiceRecord(record);
		return service;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#acquireOptionalImportedServices()
	 */
	public void acquireOptionalImportedServices() {
		IImportServiceRecordContainer container = getOptionalImportServiceRecords();
		container.acquire();
	}

	private void acquireOptionalImportServiceRecords() {
		IImportServiceRecordContainer container = getOptionalImportServiceRecords();
		IImportServiceRecordContainerOwner owner = createOptionalImportServiceRecordContainerOwner();
		container.setOwner(owner);
		acquireOptionalImportedServices();
	}

	/**
	 * <i>Hook Method:</i> You have been activated.  Concrete subclasses
	 * sometimes implement this method to execute domain specific activation.
	 * For example:
	 * <pre>
	 * protected void activate() {
	 *     MyDomainObject object = (MyDomainObject) getExportedService(MyService.SERVICE_NAME);
	 *     object.startup();
	 * }
	 * </pre>
	 */
	private void activate() {
		IBundleActivationManagerOwner owner = getOwner();
		owner.activate();
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#addExportedProxyService(java.lang.Class, org.eclipse.soda.sat.core.framework.interfaces.IProxyServiceHandler, java.util.Dictionary)
	 */
	public void addExportedProxyService(Class interfaceType, IProxyServiceHandler handler, Dictionary properties) {
		IExportServiceRecord record = createExportProxyServiceRecord(interfaceType, handler, properties);
		addExportServiceRecord(record);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#addExportedProxyServices(java.lang.Class[], org.eclipse.soda.sat.core.framework.interfaces.IProxyServiceHandler, java.util.Dictionary)
	 */
	public void addExportedProxyServices(Class[] interfaceTypes, IProxyServiceHandler handler, Dictionary properties) {
		FactoryUtility factory = FactoryUtility.getInstance();
		BundleContext bundleContext = getBundleContext();
		IExportServiceRecord record = factory.createExportProxyServiceRecord(bundleContext, interfaceTypes, handler, properties);
		addExportServiceRecord(record);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#addExportedService(java.lang.String, java.lang.Object, java.util.Dictionary)
	 */
	public void addExportedService(String name, Object service, Dictionary properties) {
		IExportServiceRecord record = createExportServiceRecord(name, service, properties);
		addExportServiceRecord(record);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#addExportedServices(java.lang.String[], java.lang.Object, java.util.Dictionary)
	 */
	public void addExportedServices(String[] names, Object service, Dictionary properties) {
		FactoryUtility factory = FactoryUtility.getInstance();
		BundleContext bundleContext = getBundleContext();
		IExportServiceRecord record = factory.createExportServiceRecord(bundleContext, names, service, properties);
		addExportServiceRecord(record);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#addExportServiceRecord(org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord)
	 */
	public void addExportServiceRecord(IExportServiceRecord record) {
		checkIsStarted();
		checkExportedServiceRecord(record);
		IExportServiceRecordContainer container = getExportServiceRecords();
		boolean added = container.add(record);
		if (added == false)
			return;  // Early return.
		boolean register = isActivated();
		if (register == false)
			return;  // Early return.
		record.register();
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#addExportServiceRecords(org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord[])
	 */
	public void addExportServiceRecords(IExportServiceRecord[] records) {
		checkExportServiceRecords(records);
		int size = records.length;
		if (size == 0)
			return;  // Early return.

		IExportServiceRecordContainer container = getExportServiceRecords();

		for (int i = 0; i < size; i++) {
			IExportServiceRecord record = records [ i ];
			container.add(record);
		}

		boolean register = isActivated();
		if (register == false)
			return;  // Early return.
		registerExportServiceRecords(records);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#addImportedServiceFilter(java.lang.String, java.lang.String)
	 */
	public void addImportedServiceFilter(String name, String filterString) {
		Map/*<String, Filter>*/ filters = getImportedServiceFilters();
		IImportServiceRecordContainer container = getImportServiceRecords();
		addImportedServiceFilter(name, filterString, filters, container);
	}

	/**
	 * <i>Private Method:</i>
	 */
	private void addImportedServiceFilter(String name, String filterString, Map/*<String, Filter>*/ filters, IImportServiceRecordContainer container) {
		Assertion.checkArgumentIsNotNull(name, "name");  //$NON-NLS-1$
		Assertion.checkArgumentIsNotNull(filterString, "filterString");  //$NON-NLS-1$
		checkIsStarted();
		BundleContext bundleContext = getBundleContext();

		try {
			Filter filter = bundleContext.createFilter(filterString);

			synchronized (filters) {
				filters.put(name, filter);
			}

			IImportServiceRecord record = (IImportServiceRecord) container.get(name);
			if (record == null)
				return;  // Early return.
			record.setFilter(filter);
		} catch (InvalidSyntaxException exception) {
			String pattern = Messages.getString(BundleActivationManager.INVALID_LDAP_FILTER_KEY);
			String message = MessageFormatter.format(pattern, filterString);
			LogUtility.logError(this, message, exception);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#addImportServiceRecord(org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord)
	 */
	public void addImportServiceRecord(IImportServiceRecord record) {
		IImportServiceRecordContainer container = getImportServiceRecords();
		boolean exists = container.contains(record);
		if (exists == true)
			return;  // Early return.
		container.add(record);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#addOptionalImportedServiceFilter(java.lang.String, java.lang.String)
	 */
	public void addOptionalImportedServiceFilter(String name, String filterString) {
		Map/*<String, Filter>*/ filters = getOptionalImportedServiceFilters();
		IImportServiceRecordContainer container = getOptionalImportServiceRecords();
		addImportedServiceFilter(name, filterString, filters, container);
	}

	/**
	 * <i>Private Method:</i>
	 */
	private void checkExportedServiceRecord(IExportServiceRecord record) {
		Assertion.checkArgumentIsNotNull(record, "record");  //$NON-NLS-1$
		BundleContext bundleContext = getBundleContext();
		BundleContext recordBundleContext = record.getBundleContext();
		boolean match = recordBundleContext.equals(bundleContext);
		if (match == true)
			return;  // Early return.
		String message = Messages.getString(BundleActivationManager.UNKNOWN_BUNDLE_CONTEXT_KEY);
		throw new IllegalArgumentException(message);
	}

	/**
	 * <i>Private Method:</i>
	 */
	private void checkExportServiceRecords(IExportServiceRecord[] records) {
		Assertion.checkArgumentIsNotNull(records, "records");  //$NON-NLS-1$

		for (int i = 0; i < records.length; i++) {
			IExportServiceRecord record = records [ i ];
			checkExportedServiceRecord(record);
		}
	}

	/**
	 * Check that the named imported service is not <code>null</code>.  Since
	 * the method <code>getImportedService(String)</code> should never return
	 * <code>null</code>, this method provides some sanity checking for
	 * developers.
	 *
	 * @param name     The name of the service.
	 * @param service  The service object.
	 */
	private void checkImportedServiceIsNotNull(String name, Object service) {
		if (service != null)
			return;  // Early return.
		WarningMessageUtility utility = WarningMessageUtility.getInstance();
		String component = Messages.getString(BundleActivationManager.SAT_CORE_KEY);
		Object source = getBundleSymbolicName();
		String label = Messages.getString(BundleActivationManager.SERVICE_KEY);
		String warning = Messages.getString(BundleActivationManager.FAILED_TO_GET_IMPORTED_SERVICE_KEY);
		utility.warn(component, source, warning, label, name);
	}

	private void checkIsStarted() {
		boolean started = isStarted();
		if (started == true)
			return;  // Early return.
		String message = Messages.getString(BundleActivationManager.BUNDLE_ACTIVATION_MANAGER_IS_NOT_STARTED_KEY);
		throw new RuntimeException(message);
	}

	/**
	 * <i>Private Method:</i> Check that the bundle has either the method
	 * <code>isUninstallable()</code> overridden to return <code>true</code>, or
	 * the method <code>isTransient()</code> overridden to return
	 * <code>true</code>, but not both.  If both method are overridden, issue
	 * a warning.
	 */
	private void checkUninstallPolicy() {
		WarningMessageUtility utility = WarningMessageUtility.getInstance();
		boolean warn = utility.isOn();
		if (warn == false)
			return;  // Early return.

		boolean uninstallable = isUninstallable();
		boolean transientFlag = isTransient();
		if (uninstallable == false || transientFlag == false)
			return;  // Early return.

		String component = Messages.getString(BundleActivationManager.SAT_CORE_KEY);
		Bundle bundle = getBundle();
		Object source = bundle.getSymbolicName();
		Class clazz = getClass();
		String className = clazz.getName();
		String message = Messages.getString(BundleActivationManager.BUNDLES_SHOULD_BE_TRANSIENT_OR_UNINSTALLABLE_NOT_BOTH_KEY);
		String label = Messages.getString(BundleActivationManager.CLASS_KEY);
		utility.warn(component, source, message, label, className);
	}

	/**
	 * <i>Private Method:</i>
	 */
	private Object[] collectServices(IServiceRecord[] records) {
		int length = records.length;
		Object[] services = new Object [ length ];

		for (int i = 0; i < length; i ++) {
			IServiceRecord record = records [ i ];
			Object service = record.getService();
			services [ i ] = service;
		}

		return services;
	}

	/**
	 * <i>Private Method:</i>
	 */
	private IExportProxyServiceRecord createExportProxyServiceRecord(Class interfaceType, IProxyServiceHandler handler, Dictionary properties) {
		FactoryUtility factory = FactoryUtility.getInstance();
		BundleContext bundleContext = getBundleContext();
		IExportProxyServiceRecord record = factory.createExportProxyServiceRecord(bundleContext, interfaceType, handler, properties);
		return record;
	}

	/**
	 * <i>Private Method:</i>
	 */
	private IExportServiceRecord createExportServiceRecord(String name, Object service, Dictionary properties) {
		FactoryUtility factory = FactoryUtility.getInstance();
		BundleContext bundleContext = getBundleContext();
		IExportServiceRecord record = factory.createExportServiceRecord(bundleContext, name, service, properties);
		return record;
	}

	/**
	 * <i>Private Method:</i> Create the receiver's exported service record
	 * container.
	 *
	 * @return A new IExportServiceRecordContainer.
	 */
	private IExportServiceRecordContainer createExportServiceRecordContainer() {
		FactoryUtility factory = FactoryUtility.getInstance();
		IExportServiceRecordContainer container = factory.createExportServiceRecordContainer();
		return container;
	}

	/**
	 * <i>Private Method:</i> Create the receiver's import service record
	 * container.
	 *
	 * @return A new IImportServiceRecordContainer.
	 */
	private IImportServiceRecordContainer createImportServiceRecordContainer() {
		FactoryUtility factory = FactoryUtility.getInstance();
		IImportServiceRecordContainer container = factory.createImportServiceRecordContainer();
		return container;
	}

	/**
	 * <i>Private Method:</i> Create an import service record owner.
	 *
	 * @return An IImportServiceRecordOwner.
	 */
	private IImportServiceRecordContainerOwner createImportServiceRecordContainerOwner() {
		return new IImportServiceRecordContainerOwner() {
			public void acquired(IImportServiceRecordContainer container) {
				BundleActivationManager.this.performActivation();
			}

			public void released(IImportServiceRecordContainer container) {
				BundleActivationManager.this.performDeactivation();
			}
		};
	}

	/**
	 * <i>Private Method:</i> Create the import service records.
	 */
	private void createImportServiceRecords() {
		String[] names = getImportedServiceNames();
		if (names == null || names.length == 0)
			return;  // Early return.

		FactoryUtility factory = FactoryUtility.getInstance();
		BundleContext bundleContext = getBundleContext();
		IImportServiceRecord record;
		IImportServiceRecordContainer container = getImportServiceRecords();

		for (int i = 0; i < names.length; i++) {
			String name = names [ i ];
			Filter filter = getImportedServiceFilter(name);
			record = factory.createImportServiceRecord(bundleContext, name, filter);
			container.add(record);
		}
	}

	/**
	 * <i>Private Method:</i>
	 */
	private IImportServiceRecordContainerOwner createOptionalImportServiceRecordContainerOwner() {
		return new IImportServiceRecordContainerLenientOwner() {
			public void acquired(IImportServiceRecordContainer container) {
				//...
			}

			public void released(IImportServiceRecordContainer container) {
				//...
			}

			public void serviceAcquired(IImportServiceRecordContainer container, IImportServiceRecord record) {
				BundleActivationManager.this.handleAcquiredOptionalImportedService(record);
			}

			public void serviceReleased(IImportServiceRecordContainer container, IImportServiceRecord record) {
				BundleActivationManager.this.handleReleasedOptionalImportedService(record);
			}
		};
	}

	/**
	 * <i>Private Method:</i> Create the optional import service records.
	 */
	private void createOptionalImportServiceRecords() {
		String[] names = getOptionalImportedServiceNames();
		if (names == null || names.length == 0)
			return;  // Early return.

		FactoryUtility factory = FactoryUtility.getInstance();
		BundleContext bundleContext = getBundleContext();
		IImportServiceRecord record;
		IImportServiceRecordContainer container = getOptionalImportServiceRecords();

		for (int i = 0; i < names.length; i++) {
			String name = names [ i ];
			Filter filter = getOptionalImportedServiceFilter(name);
			record = factory.createImportServiceRecord(bundleContext, name, filter);
			container.add(record);
		}
	}

	/**
	 * <i>Private Method:</i> Create the Runnable used to start the bundle
	 * asynchronously.
	 *
	 * @return The
	 */
	private Runnable createStartAsyncRunnable() {
		return new Runnable() {
			public void run() {
				try {
					BundleActivationManager.this.startSync();
				} catch (Exception exception) {
					exception.printStackTrace();
				} finally {
					setAsyncStartThread(null);
				}
			}
		};
	}

	/**
	 * <i>Hook Method:</i> You have been deactivated.  Concrete subclasses
	 * sometimes implement this method to execute domain specific deactivation.
	 * For example:
	 * <pre>
	 * protected void deactivate() {
	 *     // Get the exported service that needs cleaning up...
	 *     MyDomainObject object = (MyDomainObject) getExportedService(MyService.SERVICE_NAME);
	 *     object.shutdown();
	 * }
	 * </pre>
	 */
	private void deactivate() {
		IBundleActivationManagerOwner owner = getOwner();
		owner.deactivate();
	}

	/**
	 * <i>Private Method:</i> Destroy all export service record objects.
	 */
	private void destroyExportServiceRecords() {
		IServiceRecordContainer records = getExportServiceRecords();
		records.empty();
	}

	/**
	 * <i>Private Method:</i> Destroy the imported service filters.
	 */
	private void destroyImportedServiceFilters() {
		Map/*<String, Filter>*/ map = getImportedServiceFilters();

		synchronized (map) {
			map.clear();
		}
	}

	/**
	 * <i>Private Method:</i> Destroy all import service record objects.
	 */
	private void destroyImportedServiceRecords() {
		IImportServiceRecordContainer records = getImportServiceRecords();
		records.empty();
	}

	/**
	 * <i>Private Method:</i> Destroy the optional imported service filters.
	 */
	private void destroyOptionalImportedServiceFilters() {
		Map/*<String, Filter>*/ map = getOptionalImportedServiceFilters();

		synchronized (map) {
			map.clear();
		}
	}

	/**
	 * <i>Private Method:</i>
	 */
	private void destroyOptionalImportedServiceRecords() {
		IImportServiceRecordContainer records = getOptionalImportServiceRecords();
		records.empty();
	}

	private int estimateHashedCollectionSize(int capacity) {
		CollectionUtility utility = CollectionUtility.getInstance();
		int size = utility.estimateHashedCollectionSize(capacity);
		return size;
	}

	/**
	 * Private activationLock getter.
	 *
	 * @return The activation lock.
	 */
	private Object getActivationLock() {
		return activationLock;
	}

	/**
	 * <i>Configuration Parameter Method:</i> Get the async start thread
	 * priority.  This method is overridden by bundles that have overridden the
	 * method <code>isStartAsync()</code> to return <code>true</code> and wish
	 * to specify a thread priority other than <code>Thread.NORM_PRIORITY</code>.
	 * For example:
	 * <pre>
	 * protected int getAsyncStartPriority() {
	 *     return Thread.NORM_PRIORITY + 1;
	 * }
	 * </pre>
	 *
	 * @return The asynchronous start thread priority.
	 * @see #isStartAsync()
	 */
	private int getAsyncStartPriority() {
		IBundleActivationManagerOwner owner = getOwner();
		int priority = owner.getAsyncStartPriority();
		return priority;
	}

	/**
	 * <i>Private Method:</i> Private <code>asyncStartThread</code> getter.
	 *
	 * @return The async start thread.
	 */
	private Thread getAsyncStartThread() {
		return asyncStartThread;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getBundle()
	 */
	public Bundle getBundle() {
		checkIsStarted();
		BundleContext bundleContext = getBundleContext();
		Bundle bundle = null;
		try {
			bundle = bundleContext.getBundle();
		} catch (IllegalStateException exception) {
			// The BundleContext is disposed.
		}
		return bundle;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getBundleContext()
	 */
	public BundleContext getBundleContext() {
		return bundleContext;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getBundleSymbolicName()
	 */
	public String getBundleSymbolicName() {
		Bundle bundle = getBundle();
		String symbolicName = bundle.getSymbolicName();
		return symbolicName;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getDataDirectory()
	 */
	public File getDataDirectory() {
		String name = new String();
		File file = getDataFile(name);
		return file;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getDataFile(java.lang.String)
	 */
	public File getDataFile(String filename) {
		Assertion.checkArgumentIsNotNull(filename, "filename");  //$NON-NLS-1$
		checkIsStarted();
		BundleContext bundleContext = getBundleContext();
		File file = bundleContext.getDataFile(filename);
		return file;
	}

	/**
	 * <i>Private Method:</i> Get the default name of the bundle's properties
	 * file, which is the symbolic name of the bundle, followed by
	 * ".properties".
	 *
	 * @return The default name of the bundle's properties file.
	 */
	private String getDefaultPropertiesFilename() {
		String symbolicName = getBundleSymbolicName();
		int length = symbolicName.length() + 11;
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(length);
		buffer.append(symbolicName);
		buffer.append(".properties");  //$NON-NLS-1$
		String filename = buffer.toString();
		return filename;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getExportedService(java.lang.String)
	 */
	public Object getExportedService(String name) {
		IServiceRecordContainer records = getExportServiceRecords();
		IExportServiceRecord record = (IExportServiceRecord) records.get(name);
		if (record == null)
			return null;  // Early return.
		Object service = record.getService();
		return service;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getExportedServiceNamesFromManifest()
	 */
	public String[] getExportedServiceNamesFromManifest() {
		Bundle bundle = getBundle();  // OSGi Query Method.
		BundleManifestUtility utility = BundleManifestUtility.getInstance();
		String[] names = utility.getExportServices(bundle);
		return names;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getExportedServiceProperties(java.lang.String)
	 */
	public Dictionary getExportedServiceProperties(String name) {
		IExportServiceRecordContainer records = getExportServiceRecords();
		IExportServiceRecord record = (IExportServiceRecord) records.get(name);
		if (record == null)
			return null;  // Early return.
		Dictionary properties = record.getProperties();
		return properties;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getExportedServiceProperties(java.lang.String, java.lang.Object)
	 */
	public Dictionary getExportedServiceProperties(String name, Object service) {
		IExportServiceRecordContainer records = getExportServiceRecords();
		IExportServiceRecord record = (IExportServiceRecord) records.get(name, service);
		if (record == null)
			return null;  // Early return.
		Dictionary properties = record.getProperties();
		return properties;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getExportedServices()
	 */
	public Map/*<String, List<Object>>*/ getExportedServices() {
		IServiceRecordContainer container = getExportServiceRecords();
		IServiceRecordAction action = BundleActivationManager.getCollectExportedServicesAction();
		int size = container.size();
		int capacity = estimateHashedCollectionSize(size);
		Map/*<String, List<Object>>*/ map = new HashMap/*<String, List<Object>>*/(capacity);
		container.doForEach(action, map);
		return map;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getExportedServices(java.lang.String)
	 */
	public Object[] getExportedServices(String name) {
		IServiceRecordContainer records = getExportServiceRecords();
		IServiceRecord[] matches = records.getAll(name);
		Object[] services = collectServices(matches);
		return services;
	}

	/**
	 * <i>Private Method:</i> Private <code>exportedServiceRecords</code> getter.
	 *
	 * @return The IExportServiceRecordContainer.
	 */
	private IExportServiceRecordContainer getExportServiceRecords() {
		synchronized (this) {
			if (exportServiceRecords == null) {
				exportServiceRecords = createExportServiceRecordContainer();
				setExportServiceRecords(exportServiceRecords);
			}

			return exportServiceRecords;
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getFilePropertiesInputStream()
	 */
	public InputStream getFilePropertiesInputStream() throws IOException {
		String filename = getDefaultPropertiesFilename();
		InputStream stream = getFilePropertiesInputStream(filename);
		return stream;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getFilePropertiesInputStream(java.lang.String)
	 */
	public InputStream getFilePropertiesInputStream(String filename) throws IOException {
		Assertion.checkArgumentIsNotNull(filename, "filename");  //$NON-NLS-1$
		File file = new File(filename);
		boolean exists = file.exists();
		InputStream stream = null;

		if (exists == true) {
			stream = new FileInputStream(file);
			stream = new BufferedInputStream(stream);
		} else {
			handleFailedToFindProperties(filename);
		}

		return stream;
	}

	/**
	 * <i>Private Method:</i>
	 */
	private String getFrameworkVendor() {
		BundleContext context = getBundleContext();
		String vendor = context.getProperty(Constants.FRAMEWORK_VENDOR);
		return vendor;
	}

	String getId() {
		if (BundleActivationManager.NO_ID.equals(id))
			return null;  // Early return.
		if (id != null)
			return id;  // Early return.
		boolean started = isStarted();
		String value = started == true ? getBundleSymbolicName() : null;
		return value;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getImportedService(java.lang.String)
	 */
	public Object getImportedService(String name) {
		Object service = null;
		IServiceRecordContainer records = getImportServiceRecords();
		IServiceRecord record = records.get(name);
		if (record != null) {
			service = record.getService();
			if (service != null)
				return service;  // Early return.
			service = acquireImportedService(name);
		}
		checkImportedServiceIsNotNull(name, service);
		return service;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getImportedServiceFilter(java.lang.String)
	 */
	public Filter getImportedServiceFilter(String name) {
		Map/*<String, Filter>*/ map = getImportedServiceFilters();
		Filter filter = (Filter) map.get(name);
		return filter;
	}

	/**
	 * <i>Private Method:</i> Private <code>importedServiceFilters</code> getter.
	 *
	 * @return A map containing imported service filters.
	 */
	private Map/*<String, Filter>*/ getImportedServiceFilters() {
		synchronized (this) {
			if (importedServiceFilters == null) {
				Map/*<String, Filter>*/ map = new HashMap/*<String, Filter>*/(17);
				setImportedServiceFilters(map);
			}

			return importedServiceFilters;
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getImportedServiceNames()
	 */
	public String[] getImportedServiceNames() {
		IBundleActivationManagerOwner owner = getOwner();
		String[] names = owner.getImportedServiceNames();
		return names;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getImportedServiceNamesFromManifest()
	 */
	public String[] getImportedServiceNamesFromManifest() {
		Bundle bundle = getBundle();  // OSGi Query Method.
		BundleManifestUtility utility = BundleManifestUtility.getInstance();
		String[] names = utility.getImportServices(bundle);
		return names;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getImportedServiceProperty(java.lang.String, java.lang.String)
	 */
	public Object getImportedServiceProperty(String name, String key) {
		IServiceRecordContainer records = getImportServiceRecords();
		IServiceRecord record = records.get(name);
		Object value = record.getProperty(key);
		return value;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getImportedServicePropertyKeys(java.lang.String)
	 */
	public String[] getImportedServicePropertyKeys(String name) {
		IServiceRecordContainer records = getImportServiceRecords();
		IServiceRecord record = records.get(name);
		String[] keys = record.getPropertyKeys();
		return keys;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getImportedServices()
	 */
	public Map/*<String, Object>*/ getImportedServices() {
		IServiceRecordContainer container = getImportServiceRecords();
		IServiceRecordAction action = BundleActivationManager.getCollectImportedServicesAction();
		int size = container.size();
		int capacity = estimateHashedCollectionSize(size);
		Map/*<String, Object>*/ map = new HashMap/*<String, Object>*/(capacity);
		container.doForEach(action, map);
		return map;
	}

	private IImportServiceRecord getImportServiceRecord(String name) {
		IImportServiceRecordContainer container = getImportServiceRecords();
		IImportServiceRecord record = (IImportServiceRecord) container.get(name);
		return record;
	}

	/**
	 * <i>Private Method:</i> Private <code>importServiceRecords</code> getter.
	 *
	 * @return The import service record container.
	 */
	private IImportServiceRecordContainer getImportServiceRecords() {
		synchronized (this) {
			if (importServiceRecords == null) {
				IImportServiceRecordContainer container = createImportServiceRecordContainer();
				setImportServiceRecords(container);
			}

			return importServiceRecords;
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getOptionalImportedService(java.lang.String)
	 */
	public Object getOptionalImportedService(String name) {
		IServiceRecordContainer records = getOptionalImportServiceRecords();
		IServiceRecord record = records.get(name);
		if (record == null)
			return null;  // Early return.
		Object service = record.getService();
		if (service != null)
			return service;  // Early return.
		service = acquireOptionalImportedService(name);
		return service;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getOptionalImportedServiceFilter(java.lang.String)
	 */
	public Filter getOptionalImportedServiceFilter(String name) {
		Map/*<String, Filter>*/ map = getOptionalImportedServiceFilters();
		Filter filter = (Filter) map.get(name);
		return filter;
	}

	/**
	 * <i>Private Method:</i> Private <code>optionalImportedServiceFilters</code>
	 * getter.
	 *
	 * @return A map containing imported service filters.
	 */
	private Map/*<String, Filter>*/ getOptionalImportedServiceFilters() {
		synchronized (this) {
			if (optionalImportedServiceFilters == null) {
				Map/*<String, Filter>*/ map = new HashMap/*<String, Filter>*/(7);
				setOptionalImportedServiceFilters(map);
			}

			return optionalImportedServiceFilters;
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getOptionalImportedServiceNames()
	 */
	public String[] getOptionalImportedServiceNames() {
		IBundleActivationManagerOwner owner = getOwner();
		String[] names = owner.getOptionalImportedServiceNames();
		return names;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getOptionalImportedServiceProperty(java.lang.String, java.lang.String)
	 */
	public Object getOptionalImportedServiceProperty(String name, String key) {
		IServiceRecordContainer records = getOptionalImportServiceRecords();
		IServiceRecord record = records.get(name);
		Object value = record.getProperty(key);
		return value;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getOptionalImportedServicePropertyKeys(java.lang.String)
	 */
	public String[] getOptionalImportedServicePropertyKeys(String name) {
		IServiceRecordContainer records = getOptionalImportServiceRecords();
		IServiceRecord record = records.get(name);
		String[] keys = record.getPropertyKeys();
		return keys;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getOptionalImportedServices()
	 */
	public Map/*<String, Object>*/ getOptionalImportedServices() {
		IServiceRecordContainer container = getOptionalImportServiceRecords();
		IServiceRecordAction action = BundleActivationManager.getCollectImportedServicesAction();
		int size = container.size();
		int capacity = estimateHashedCollectionSize(size);
		Map/*<String, Object>*/ map = new HashMap/*<String, Object>*/(capacity);
		container.doForEach(action, map);
		return map;
	}

	private IImportServiceRecord getOptionalImportServiceRecord(String name) {
		IImportServiceRecordContainer container = getOptionalImportServiceRecords();
		IImportServiceRecord record = (IImportServiceRecord) container.get(name);
		return record;
	}

	/**
	 * <i>Private Method:</i> Private <code>optionalImportServiceRecords</code>
	 * getter.
	 *
	 * @return The optional import service record container.
	 */
	private IImportServiceRecordContainer getOptionalImportServiceRecords() {
		synchronized (this) {
			if (optionalImportServiceRecords == null) {
				IImportServiceRecordContainer container = createImportServiceRecordContainer();
				setOptionalImportServiceRecords(container);
			}

			return optionalImportServiceRecords;
		}
	}

	/**
	 * Private owner getter.
	 *
	 * @return The owner of the IBundleActivationManager.
	 */
	private IBundleActivationManagerOwner getOwner() {
		return owner;
	}

	/**
	 * <i>Query API:</i> Create a <code>Properties</code> object out of the
	 * bundle's properties.  This method does not cache the <code>Properties</code>
	 * object.  The properties are obtained using the query method
	 * <code>getPropertiesInputStream()</code>, which is typically overridden by
	 * subclasses that define properties.
	 *
	 * @return The bundle's properties.
	 */
	public Properties getProperties() {
		synchronized (this) {
			if (properties == null) {
				Properties properties = loadProperties();
				setProperties(properties);
			}

			return properties;
		}
	}

	/**
	 * <i>Hook Method:</i> Get an input stream to the bundle's properties.  This
	 * method is overridden by subclasses that possess properties.  For example,
	 * if the properties file is stored as a resource in the same package as the
	 * <code>BundleActivator</code>:
	 * <pre>
	 * protected InputStream getPropertiesInputStream() throws IOException {
	 *     return getResourcePropertiesInputStream();
	 * }
	 * </pre>
	 * And if the properties are stored as a file in the local file system:
	 * <pre>
	 * protected InputStream getPropertiesInputStream() throws IOException {
	 *     return getFilePropertiesInputStream();
	 * }
	 * </pre>
	 *
	 * @throws java.io.IOException
	 * @return An input stream to the properties or <code>null</code> if the
	 *         bundle does not have any properties.
	 *
	 * @see #getFilePropertiesInputStream()
	 * @see #getFilePropertiesInputStream(String)
	 * @see #getResourcePropertiesInputStream()
	 * @see #getResourcePropertiesInputStream(String)
	 */
	private InputStream getPropertiesInputStream() throws IOException {
		IBundleActivationManagerOwner owner = getOwner();
		InputStream stream = owner.getPropertiesInputStream();
		return stream;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getProperty(java.lang.String, java.lang.String)
	 */
	public String getProperty(String key, String defaultValue) {
		Assertion.checkArgumentIsNotNull(key, "key");  //$NON-NLS-1$
		String value = System.getProperty(key);

		if (value == null) {
			Properties properties = getProperties();
			value = properties.getProperty(key);
		}

		if (value == null) {
			value = defaultValue;
		}

		return value;
	}

	/**
	 * <i>Private Method:</i> Get the name of the thread used to start the
	 * bundle asynchronously.
	 *
	 * @return The name of the asynchronous start thread.
	 */
	private String getStartAsynchThreadName() {
		String pattern = Messages.getString(BundleActivationManager.ASYNC_START_UP_KEY);
		String symbolicName = getBundleSymbolicName();
		String name = MessageFormatter.format(pattern, symbolicName);
		return name;
	}

	/**
	 * Private startLock getter.
	 *
	 * @return The start lock.
	 */
	private Object getStartLock() {
		return startLock;
	}

	/**
	 * <i>Private Method:</i> Get the System Bundle.
	 *
	 * @return  The System Bundle.
	 */
	private Bundle getSystemBundle() {
		BundleContext bundleContext = getBundleContext();
		Bundle bundle = bundleContext.getBundle(0);  // System Bundle has id 0.
		return bundle;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getUnacquiredImportedServiceNames()
	 */
	public String[] getUnacquiredImportedServiceNames() {
		IImportServiceRecordContainer container = getImportServiceRecords();
		String[] names = container.getUnacquiredServiceNames();
		return names;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#getUnacquiredOptionalImportedServiceNames()
	 */
	public String[] getUnacquiredOptionalImportedServiceNames() {
		IImportServiceRecordContainer container = getOptionalImportServiceRecords();
		String[] names = container.getUnacquiredServiceNames();
		return names;
	}

	/**
	 * <i>Private Method:</i>
	 */
	private void handleAcquiredOptionalImportedService(IImportServiceRecord record) {
		String name = record.getName();
		Object service = record.getService();
		IBundleActivationManagerOwner owner = getOwner();
		owner.handleAcquiredOptionalImportedService(name, service);
	}

	/**
	 * <i>Hook Handler Method:</i> Handles a thrown exception.  This method can
	 * be overridden by subclasses that wish to handle thrown exceptions
	 * themselves.
	 *
	 * @param exception  The unhandled exception.
	 * @return True if the exception was fully handled, otherwise false.
	 */
	private boolean handleException(Exception exception) {
		boolean result = true;
		IBundleActivationManagerOwner owner = getOwner();

		if (owner == null) {
			String message = exception.getMessage();
			LogUtility.logError(this, message, exception);
		} else {
			result = owner.handleException(exception);
		}

		return result;
	}

	/**
	 * <i>Hook Handler Method:</i> Handle the fact that the specified properties
	 * file could not be found.
	 *
	 * @param filename  The name of the properties file.
	 */
	private void handleFailedToFindProperties(String filename) {
		IBundleActivationManagerOwner owner = getOwner();
		owner.handleFailedToFindProperties(filename);
	}

	/**
	 * <i>Private Method:</i>
	 */
	private void handleReleasedOptionalImportedService(IImportServiceRecord record) {
		String name = record.getName();
		Object service = record.getService();
		IBundleActivationManagerOwner owner = getOwner();
		owner.handleReleasedOptionalImportedService(name, service);
	}

	/**
	 * <i>Private Method:</i> If the bundle was started synchronously, interrupt
	 * and join with the async start thread.
	 */
	private void interruptAndJoinWithAsyncThread() {
		boolean async = isStartAsync();
		if (async == false)
			return;  // Early return.

		Thread thread = getAsyncStartThread();
		if (thread == null)
			return;  // Early return.

		String name = thread.getName();
		String pattern;
		pattern = Messages.getString(BundleActivationManager.WAITING_FOR_ASYNC_START_UP_THREAD_TO_STOP_KEY);
		String waitingForThreadToStop = MessageFormatter.format(pattern, name);
		pattern = Messages.getString(BundleActivationManager.ASYNC_START_UP_THREAD_HAS_STOPPED_KEY);
		String threadHasStopped = MessageFormatter.format(pattern, name);

		LogUtility.logInfo(this, waitingForThreadToStop);
		thread.interrupt();

		try {
			thread.join();
			LogUtility.logInfo(this, threadHasStopped);
		} catch (InterruptedException exception) {
			// OK
		}
	}

	/**
	 * <i>Private Method:</i> Queries whether the bundle has been activated.
	 *
	 * @return boolean
	 */
	private boolean isActivated() {
		return activated;
	}

	/**
	 * <i>Configuration Parameter Method:</i> Specifies whether the bundle
	 * should start asynchronously.  This method should be overridden by
	 * bundles that wish to start asynchronously.  For example:
	 * <pre>
	 * protected boolean isStartAsync() {
	 *     return true;
	 * }
	 * </pre>
	 *
	 * @return True if the bundle should start asynchronously, otherwise false.
	 */
	private boolean isStartAsync() {
		IBundleActivationManagerOwner owner = getOwner();
		boolean startAsynchronously = owner.isStartAsync();
		return startAsynchronously;
	}

	/**
	 * <i>Query Method:</i> Answers whether the bundle activation manager has
	 * been started.
	 *
	 * @return  True if the bundle activation manager has been started,
	 *          otherwise false.
	 */
	private boolean isStarted() {
		BundleContext bundleContext = getBundleContext();
		boolean started = bundleContext != null;
		return started;
	}

	/**
	 * <i>Configuration Parameter Method:</i> Specify whether the bundle should
	 * be treated as transient.  Transient bundles are automatically uninstalled
	 * once they have started and entered the <code>Bundle.ACTIVE</code> state.
	 * This method should be overridden by bundles that are to be considered
	 * transient.  For example:
	 * <pre>
	 * protected boolean isTransient() {
	 *     return true;
	 * }
	 * </pre>
	 * <i>Note:</i>
	 * <ul>
	 *   <li>
	 *     A transient bundle typically does not export any services.
	 *   </li>
	 *   <li>
	 *     It makes no sense for a transient bundle to also override the
	 *     method <code>isUninstallable()</code>.
	 *   </li>
	 * </ul>
	 * @return True if the bundle should be treated as transient, otherwise
	 * false.
	 */
	private boolean isTransient() {
		IBundleActivationManagerOwner owner = getOwner();
		boolean result = owner.isTransient();
		return result;
	}

	/**
	 * <i>Configuration Parameter Method:</i> Specify whether the bundle should
	 * be treated as uninstalled.  Uninstalled bundles are automatically
	 * uninstalled when their last dependent bundle is uninstalled.  This method
	 * should be overridden by bundles that are uninstallable prerequisites.
	 * <p>
	 * <i>Note:</i>
	 * <ul>
	 *   <li>
	 *     An uninstallable bundle is always a prerequisite of another bundle.
	 *   </li>
	 *   <li>
	 *     It makes no sense for an uninstallable bundle to also override the
	 *     method <code>isTransient()</code>.
	 *   </li>
	 * </ul>
	 * @return True if the bundle should be treated as uninstallable, otherwise
	 * false.
	 */
	private boolean isUninstallable() {
		IBundleActivationManagerOwner owner = getOwner();
		boolean result = owner.isUninstallable();
		return result;
	}

	/**
	 * <i>Private Method</i>: Load the properties for the bundle.
	 *
	 * @return  The bundle's properties.
	 */
	private Properties loadProperties() {
		Properties properties = new Properties();

		try {
			InputStream stream = getPropertiesInputStream();

			if (stream != null) {
				try {
					properties.load(stream);
				} finally {
					stream.close();
				}
			}
		} catch (IOException exception) {
			String message = Messages.getString(BundleActivationManager.FAILED_TO_GET_PROPERTIES_KEY);
			LogUtility.logWarning(message, exception);
		}

		return properties;
	}

	/**
	 * <i>Private Method:</i>
	 */
	private void logTraceOfUnacquiredImportedServices() {
		boolean tracing = LogUtility.isTracing();
		if (tracing == false)
			return;  // Early return.

		String[] names = getUnacquiredImportedServiceNames();
		int size = names.length;
		if (size == 0)
			return;  // Early return.

		String bundleSymbolicName = getBundleSymbolicName();
		String pattern = Messages.getString(BundleActivationManager.FAILED_TO_ACQUIRE_THE_FOLLOWING_SERVICES_KEY);
		String message = MessageFormatter.format(pattern, bundleSymbolicName);

		char newLine = '\n';
		char tab = '\t';

		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(500);
		buffer.append(message);
		buffer.append(newLine);

		for (int i = 0; i < size; i++) {
			String name = names [ i ];
			buffer.append(tab);
			buffer.append(name);
			buffer.append(newLine);
		}

		String value = buffer.toString();
		String component = Messages.getString(BundleActivationManager.SAT_CORE_KEY);
		LogUtility.logTrace(component, value);
	}

	/**
	 * <i>Private Method:</i> Try to activate the bundle.
	 */
	private void performActivation() {
		Object startLock = getStartLock();

		synchronized (startLock) {
			boolean started = isStarted();
			if (started == false)
				return;  // Early return.

			Object activationLock = getActivationLock();

			synchronized (activationLock) {
				boolean activated = isActivated();
				if (activated == true)
					return;  // Early return.
				setActivated(true);
				activate();
				activated = isActivated();
				if (activated == false)
					return;  // Early return.
				registerExportedServices();
				registerWithBundleUninstallManager();
			}
		}
	}

	/**
	 * <i>Private Method:</i> Try to deactivate the bundle.
	 */
	private void performDeactivation() {
		Object startLock = getStartLock();

		synchronized (startLock) {
			boolean started = isStarted();
			if (started == false)
				return;  // Early return.

			Object activationLock = getActivationLock();

			synchronized (activationLock) {
				boolean activated = isActivated();
				if (activated == false)
					return;  // Early return.
				setActivated(false);
				unregisterExportServices();
				deactivate();
				destroyExportServiceRecords();
			}
		}
	}

	private void registerAsUninstallable() {
		boolean uninstallable = isUninstallable();
		if (uninstallable == false)
			return;  // Early return.
		BundleDependencyManager manager = BundleDependencyManager.getInstance();
		Bundle bundle = getBundle();
		manager.addUninstallableBundle(bundle);
	}

	/**
	 * <i>Private Method:</i> Register the exported services.
	 */
	private void registerExportedServices() {
		IExportServiceRecordContainer records = getExportServiceRecords();
		records.register();
	}

	/**
	 * <i>Private Method:</i>
	 */
	private void registerExportServiceRecords(IExportServiceRecord[] records) {
		for (int i = 0; i < records.length; i++) {
			IExportServiceRecord record = records [ i ];
			record.register();
		}
	}

	/**
	 * <i>Private Method:</i> Registers the bundle for uninstalling with the
	 * bundle dependency manager.
	 *
	 * @see org.eclipse.soda.sat.core.internal.framework.bundle.BundleDependencyManager
	 */
	private void registerWithBundleDependencyManager() {
		BundleDependencyManager manager = BundleDependencyManager.getInstance();
		manager.addBundleActivationManager(this);
		registerAsUninstallable();
	}

	/**
	 * <i>Private Method:</i> If the bundle is transient, register it with the
	 * BundleUninstallManager.
	 *
	 * @see org.eclipse.soda.sat.core.internal.framework.bundle.BundleUninstallManager
	 */
	private void registerWithBundleUninstallManager() {
		boolean transientFlag = isTransient();
		if (transientFlag == false)
			return;  // Early return.
		BundleUninstallService uninstaller = BundleUninstallManager.getInstance();
		Bundle bundle = getBundle();
		uninstaller.uninstall(bundle);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#releaseImportedService(java.lang.String)
	 */
	public void releaseImportedService(String name) {
		IImportServiceRecord record = getImportServiceRecord(name);
		if (record == null)
			return;  // Early return.
		record.release();
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#releaseImportedServices()
	 */
	public void releaseImportedServices() {
		IImportServiceRecordContainer records = getImportServiceRecords();
		records.release();
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#releaseOptionalImportedService(java.lang.String)
	 */
	public void releaseOptionalImportedService(String name) {
		IImportServiceRecord record = getOptionalImportServiceRecord(name);
		if (record == null)
			return;  // Early return.
		record.release();
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#releaseOptionalImportedServices()
	 */
	public void releaseOptionalImportedServices() {
		IImportServiceRecordContainer records = getOptionalImportServiceRecords();
		records.release();
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#removeExportedService(java.lang.String)
	 */
	public void removeExportedService(String name) {
		IExportServiceRecordContainer records = getExportServiceRecords();
		IExportServiceRecord record = (IExportServiceRecord) records.get(name);
		if (record == null)
			return;  // Early return.
		removeExportServiceRecord(record);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#removeExportedService(java.lang.String, java.lang.Object)
	 */
	public void removeExportedService(String name, Object service) {
		IExportServiceRecordContainer records = getExportServiceRecords();
		IExportServiceRecord record = (IExportServiceRecord) records.get(name, service);
		if (record == null)
			return;  // Early return.
		removeExportServiceRecord(record);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#removeExportedServices(java.lang.String)
	 */
	public void removeExportedServices(String name) {
		IExportServiceRecordContainer records = getExportServiceRecords();
		IServiceRecord[] matches = records.getAll(name);
		if (matches == null)
			return;  // Early return.

		int count = matches.length;
		IExportServiceRecord record;

		for (int i = 0; i < count; i++) {
			record = (IExportServiceRecord) matches [ i ];
			records.remove(record);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#removeExportServiceRecord(org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord)
	 */
	public void removeExportServiceRecord(IExportServiceRecord record) {
		checkExportedServiceRecord(record);
		IExportServiceRecordContainer records = getExportServiceRecords();
		boolean removed = records.remove(record);
		if (removed == false)
			return;  // Early return.
		boolean unregister = isActivated();
		if (unregister == false)
			return;  // Early return.
		record.unregister();
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#removeImportedServiceFilter(java.lang.String)
	 */
	public void removeImportedServiceFilter(String name) {
		Map/*<String, Filter>*/ filters = getImportedServiceFilters();
		IImportServiceRecordContainer container = getImportServiceRecords();
		removeImportedServiceFilter(name, filters, container);
	}

	/**
	 * <i>Private Method:</i>
	 */
	private void removeImportedServiceFilter(String name, Map/*<String, Filter>*/ filters, IImportServiceRecordContainer container) {
		Object value = null;

		synchronized (filters) {
			value = filters.remove(name);
		}

		if (value == null)
			return;  // Early return.

		IImportServiceRecord record = (IImportServiceRecord) container.get(name);
		if (record == null)
			return;  // Early return.
		record.setFilter(null);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#removeOptionalImportedServiceFilter(java.lang.String)
	 */
	public void removeOptionalImportedServiceFilter(String name) {
		Map/*<String, Filter>*/ filters = getOptionalImportedServiceFilters();
		IImportServiceRecordContainer container = getOptionalImportServiceRecords();
		removeImportedServiceFilter(name, filters, container);
	}

	/**
	 * See Eclipse bug <a href="https://bugs.eclipse.org/bugs/show_bug.cgi?id=128531">128531</a>
	 * for more details.
	 *
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#restartFramework()
	 */
	public void restartFramework() throws BundleException {
		checkIsStarted();
		String pattern = Messages.getString(BundleActivationManager.FRAMEWORK_RESTARTED_BY_KEY);
		String symbolicName = getBundleSymbolicName();
		String message = MessageFormatter.format(pattern, symbolicName);
		LogUtility.logInfo(message);

		// TODO The Bundle update() method does not work in Equinox 3.3. Hope it will be fixed in 3.4.
		// See https://bugs.eclipse.org/bugs/show_bug.cgi?id=128531
		String frameworkVendor = getFrameworkVendor();
		boolean broken = "Eclipse".equals(frameworkVendor);  //$NON-NLS-1$

		if (broken == true) {
			FactoryUtility utility = FactoryUtility.getInstance();
			BundleContext context = getBundleContext();
			String name = StartLevel.class.getName();
			IImportServiceRecord record = utility.createImportServiceRecord(context, name, null);
			record.acquire();
			StartLevel startLevel = (StartLevel) record.getService();
			int current = startLevel != null ? startLevel.getStartLevel() : 6;
			record.release();
			Object value = String.valueOf(current);
			Properties properties = System.getProperties();
			properties.put("osgi.framework.beginningstartlevel", value);  //$NON-NLS-1$
		}

		// See OSGi R4: "4.5 The System Bundle"
		Bundle bundle = getSystemBundle();
		bundle.update();
	}

	/**
	 * <i>Private Method:</i> Private <code>activated</code> setter.
	 *
	 * @param activated  Boolean value to indicate whether the bundle has been
	 *                   activated.
	 */
	private void setActivated(boolean activated) {
		this.activated = activated;
	}

	/**
	 * <i>Private Method:</i> Private <code>asyncStartThread</code> setter.
	 *
	 * @param asyncStartThread  The async start thread.
	 */
	private void setAsyncStartThread(Thread asyncStartThread) {
		this.asyncStartThread = asyncStartThread;
	}

	/**
	 * <i>Private Method:</i> Private <code>bundleContext</code> setter.
	 *
	 * @param bundleContext  The BundleContext handle back to the framework.
	 */
	private void setBundleContext(BundleContext bundleContext) {
		this.bundleContext = bundleContext;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#setExportedServiceProperties(java.lang.String, java.util.Dictionary)
	 */
	public void setExportedServiceProperties(String name, Dictionary properties) {
		IExportServiceRecordContainer records = getExportServiceRecords();
		IExportServiceRecord record = (IExportServiceRecord) records.get(name);
		if (record == null)
			return;  // Early return.
		record.setProperties(properties);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#setExportedServiceProperties(java.lang.String, java.lang.Object, java.util.Dictionary)
	 */
	public void setExportedServiceProperties(String name, Object service, Dictionary properties) {
		IExportServiceRecordContainer records = getExportServiceRecords();
		IExportServiceRecord record = (IExportServiceRecord) records.get(name, service);
		if (record == null)
			return;  // Early return.
		record.setProperties(properties);
	}

	/**
	 * <i>Private Method:</i> Private <code>exportedServiceRecords</code> setter.
	 *
	 * @param exportServiceRecords  A container for the bundle's exported
	 *                              service objects.
	 */
	private void setExportServiceRecords(IExportServiceRecordContainer exportServiceRecords) {
		this.exportServiceRecords = exportServiceRecords;
	}

	void setId(String id) {
		this.id = id == null ? BundleActivationManager.NO_ID : id;
	}

	/**
	 * <i>Private Method:</i> Private <code>importedServiceFilters</code> setter.
	 *
	 * @param importedServiceFilters  A Map containing the LDAP filters for
	 *                                imported services.
	 */
	private void setImportedServiceFilters(Map/*<String, Filter>*/ importedServiceFilters) {
		this.importedServiceFilters = importedServiceFilters;
	}

	/**
	 * <i>Private Method:</i> Private <code>importServiceRecords</code> setter.
	 *
	 * @param importServiceRecords  An IImportServiceRecordContainer.
	 */
	private void setImportServiceRecords(IImportServiceRecordContainer importServiceRecords) {
		this.importServiceRecords = importServiceRecords;
	}

	/**
	 * <i>Private Method:</i> Private <code>optionalImportedServiceFilters</code>
	 * setter.
	 *
	 * @param optionalImportedServiceFilters  A Map containing the LDAP filters
	 *                                        for imported services.
	 */
	private void setOptionalImportedServiceFilters(Map/*<String, Filter>*/ optionalImportedServiceFilters) {
		this.optionalImportedServiceFilters = optionalImportedServiceFilters;
	}

	/**
	 * <i>Private Method:</i> Private <code>optionalImportServiceRecords</code>
	 * setter.
	 *
	 * @param optionalImportServiceRecords  An IImportServiceRecordContainer.
	 */
	private void setOptionalImportServiceRecords(IImportServiceRecordContainer optionalImportServiceRecords) {
		this.optionalImportServiceRecords = optionalImportServiceRecords;
	}

	/**
	 * Private owner setter.
	 *
	 * @param owner  The owner of the IBundleActivationManager.
	 */
	private void setOwner(IBundleActivationManagerOwner owner) {
		this.owner = owner;
	}

	/**
	 * Private properties setter.
	 *
	 * @param properties  The bundles's properties.
	 */
	private void setProperties(Properties properties) {
		this.properties = properties;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#shutdownFramework()
	 */
	public void shutdownFramework() throws BundleException {
		checkIsStarted();
		String pattern = Messages.getString(BundleActivationManager.FRAMEWORK_SHUTDOWN_BY_KEY);
		String symbolicName = getBundleSymbolicName();
		String message = MessageFormatter.format(pattern, symbolicName);
		LogUtility.logInfo(message);

		// See OSGi R3: "4.2.1 System Bundle"
		Bundle bundle = getSystemBundle();
		bundle.stop();
	}

	/**
	 * <i>Hook Method:</i> This method is called by <code>start(BundleContext)</code>.
	 * This method is typically implemented by subclasses that wish to perform
	 * behavior that is to be performance exactly once when the bundle starts.
	 * For example:
	 * <pre>
	 * protected void start() {
	 *     PrinterApplicationWindow window = getWindow();
	 *     WindowListener listener = getWindowListener();
	 *     window.addWindowListener(listener);
	 *     window.open();
	 * }
	 * </pre>
	 *
	 * @throws java.lang.Exception
	 */
	private void start() throws Exception {
		IBundleActivationManagerOwner owner = getOwner();
		owner.start();
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#start(org.osgi.framework.BundleContext, org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner)
	 */
	public void start(BundleContext bundleContext, IBundleActivationManagerOwner owner) throws Exception {
		Assertion.checkArgumentIsNotNull(bundleContext, "bundleContext");  //$NON-NLS-1$
		Assertion.checkArgumentIsNotNull(owner, "owner");  //$NON-NLS-1$

		Object lock = getStartLock();

		synchronized (lock) {
			boolean started = isStarted();
			if (started == true)
				return;  // Early return;
			setBundleContext(bundleContext);
			setOwner(owner);
			checkUninstallPolicy();
			registerWithBundleDependencyManager();
			boolean async = isStartAsync();

			if (async == true) {
				startAsync();
			} else {
				startSync();
			}
		}
	}

	/**
	 * <i>Private Method:</i> Create a thread on which to start up the bundle.
	 * This method is only called when the <i>Configuration Parameter Method<i>
	 * <code>isStartAsync()</code> has been overridden to return true.
	 */
	private void startAsync() {
		Runnable runnable = createStartAsyncRunnable();
		String name = getStartAsynchThreadName();
		Thread thread = new Thread(runnable, name);
		setAsyncStartThread(thread);
		int priority = getAsyncStartPriority();
		thread.setPriority(priority);
		thread.start();
	}

	/**
	 * <i>Private Method:</i> Start the bundle.
	 *
	 * @throws java.lang.Exception
	 */
	private void startSync() throws Exception {
		try {
			start();
			createOptionalImportServiceRecords();
			createImportServiceRecords();
			acquireOptionalImportServiceRecords();
			acquireImportServiceRecords();
		} catch (Exception exception) {
			boolean handled = handleException(exception);
			if (handled == true)
				return;  // Early return.
			throw exception;
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager#stop()
	 */
	public void stop() throws Exception {
		Object lock = getStartLock();

		try {
			synchronized (lock) {
				boolean started = isStarted();
				if (started == false)
					return;  // Early return

				try {
					interruptAndJoinWithAsyncThread();

					// Imported Services
					releaseImportedServices();
					destroyImportedServiceFilters();
					destroyImportedServiceRecords();

					// Optional Imported Services
					releaseOptionalImportedServices();
					destroyOptionalImportedServiceFilters();
					destroyOptionalImportedServiceRecords();

					unregisterWithBundleDependencyManager();
					IBundleActivationManagerOwner owner = getOwner();
					owner.stop();
				} finally {
					setOwner(null);
					setBundleContext(null);
				}
			}
		} catch (Exception exception) {
			boolean handled = handleException(exception);
			if (handled == true)
				return;  // Early return.
			throw exception;
		}
	}

	private void unregisterAsUninstallable() {
		boolean uninstallable = isUninstallable();
		if (uninstallable == false)
			return;  // Early return.
		BundleDependencyManager manager = BundleDependencyManager.getInstance();
		Bundle bundle = getBundle();
		manager.removeUninstallableBundle(bundle);
	}

	/**
	 * <i>Private Method:</i> Unregister the exported services.
	 */
	private void unregisterExportServices() {
		IExportServiceRecordContainer records = getExportServiceRecords();
		records.unregister();
	}

	/**
	 * <i>Private Method:</i> Unregisters the bundle for uninstalling with the
	 * bundle dependency manager.
	 *
	 * @see org.eclipse.soda.sat.core.internal.framework.bundle.BundleDependencyManager
	 */
	private void unregisterWithBundleDependencyManager() {
		unregisterAsUninstallable();
		BundleDependencyManager manager = BundleDependencyManager.getInstance();
		manager.removeBundleActivationManager(this);
	}
}
