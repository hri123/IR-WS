/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework.interfaces;

import org.osgi.framework.Bundle;

/**
 * The <code>BundleDependencyListener</code> interface is implemented by
 * classes that wish to receive call-back notifications that a bundle
 * relationship has either been <i>registered</i> or <i>unregistered</i> with
 * the <code>BundleDependencyService</code>.  Once this interface has been
 * implemented by a class, it can be added and removed as a listener of the
 * <code>BundleDependencyService</code>.
 */
public interface BundleDependencyListener {
	/**
	 * A <code>Bundle</code> dependency relationship has been <i>registered</i>.
	 *
	 * @param importer  The <code>Bundle</code> that imports a service.
	 * @param exporter  The <code>Bundle</code> that exports a service.
	 */
	public void registered(Bundle importer, Bundle exporter);

	/**
	 * A <code>Bundle</code> dependency relationship has been unregistered.
	 *
	 * @param importer  The <code>Bundle</code> that imports a service.
	 * @param exporter  The <code>Bundle</code> that exports a service.
	 */
	public void unregistered(Bundle importer, Bundle exporter);
}
