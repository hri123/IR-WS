/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.record.interfaces;

/**
 * The <code>IExportProxyServiceRecord</code> interface extends the
 * <code>IExportServiceRecord</code> to define how to export a proxy service.
 * <p>
 * <i>Note:</i> Since this abstraction is used internally by the SAT bundle
 * this interface is typically not used directly by bundle developers.  For
 * cases where subclassing the <code>BaseBundleActivator</code> is not
 * appropriate, instances of this interface can be created using the
 * <code>FactoryUtility</code> class.
 */
public interface IExportProxyServiceRecord extends IExportServiceRecord {
	/**
	 * Get the real service, rather than the proxy.
	 *
	 * @return The real service.
	 */
	public Object getRealService();

	/**
	 * Query method for testing whether the proxy service has been created.
	 * Being able to test whether the proxy service has been created is
	 * important since <code>getRealService()</code> causes the proxy
	 * service to be created if it does not exist.
	 *
	 * @return True if the proxy service has been created, otherwise false.
	 */
	public boolean isServiceCreated();
}