/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.record;

import org.eclipse.soda.sat.core.internal.framework.bundle.BundleDependencyManager;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecordOwner;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.eclipse.soda.sat.core.util.ServiceReferenceUtility;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Filter;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceReference;

/**
 * The <code>ImportServiceRecord</code> class models a service that is imported
 * by a bundle and acquired from the OSGi framework.  The class is an
 * implementation of the <code>IImportServiceRecord</code> interface.
 */
public final class ImportServiceRecord extends ServiceRecord implements IImportServiceRecord {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String ACQUIRED_SERVICE_KEY = "ImportServiceRecord.AcquiredService";  //$NON-NLS-1$
	private static final String ACQUIRED_SERVICE_MATCHING_FILTER_KEY = "ImportServiceRecord.AcquiredServiceMatchingFilter";  //$NON-NLS-1$
	private static final String FAILED_TO_ACQUIRE_SERVICE_KEY = "ImportServiceRecord.FailedToAcquireService";  //$NON-NLS-1$
	private static final String FAILED_TO_ACQUIRE_SERVICE_MATCHING_FILTER_KEY = "ImportServiceRecord.FailedToAcquireServiceMatchingFilter";  //$NON-NLS-1$
	private static final String LOCK_MUST_NOT_BE_NULL_KEY = "ImportServiceRecord.LockMustNotBeNull";  //$NON-NLS-1$

	// Misc
	private static final ServiceReference[] NO_SERVICE_REFERENCES = new ServiceReference [ 0 ];

	private static final String SAT_CORE_KEY = "Common.SatCore";  //$NON-NLS-1$

	//
	// Instance Fields
	//

	private volatile Filter filter;
	private String name;
	private volatile IImportServiceRecordOwner owner;
	private volatile ServiceReference serviceReference;



	//
	// Constructors
	//

	/**
	 * Constructor.
	 *
	 * @param bundleContext  The <code>BundleContext</code> handle back to the
	 *                       framework.
	 * @param name           The fully qualified type name of the imported
	 *                       service.
	 * @param filter         The LDAP filter used to acquire the imported
	 *                       service.
	 */
	public ImportServiceRecord(BundleContext bundleContext, String name, Filter filter) {
		super(bundleContext);
		setName(name);
		basicSetFilter(filter);
	}

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord#acquire()
	 */
	public void acquire() {
		Object lock = getLock();

		synchronized (lock) {
			boolean acquired = isAcquired();
			if (acquired == true)
				return;  // Early return.

			registerAsServiceListener();

			ServiceReference reference;
			BundleContext bundleContext = getBundleContext();
			boolean filtered = hasFilter();

			if (filtered == true) {
				reference = acquireFilteredServiceFromFramework();
			} else {
				String name = getName();
				reference = bundleContext.getServiceReference(name);
			}

			if (reference != null) {
				setServiceReference(reference);
				Object service = bundleContext.getService(reference);
				setService(service);
				logTraceAcquiredService();
				IImportServiceRecordOwner owner = getOwner();
				if (owner == null)
					return;  // Early return.
				owner.serviceAcquired(this);
			} else {
				logTraceFailedToAcquireService();
			}
		}
	}

	/**
	 * Using the service filter, query the framework for a matching registered
	 * service.
	 *
	 * @return ServiceReference
	 */
	private ServiceReference acquireFilteredServiceFromFramework() {
		ServiceReference reference = null;
		ServiceReference[] references = getFilteredServiceReferences();
		int length = references.length;
		if (length == 0)
			return null;  // Early return.

		if (length == 1) {
			reference = references [ 0 ];
		} else {
			ServiceReferenceUtility utility = ServiceReferenceUtility.getInstance();
			reference = utility.select(references);
		}

		return reference;
	}

	/**
	 * Apply the receivers filter.
	 */
	private void applyFilter() {
		boolean acquired = isAcquired();

		if (acquired == true) {
			Filter filter = getFilter();
			if (filter == null)
				return;  // Early return.

			ServiceReference reference = getServiceReference();
			boolean match = filter.match(reference);
			if (match == true)
				return;  // Early return.
			release(false);
			acquire();
			return;  // Early return.
		}

		boolean listening = isRegisteredForServiceEvents();
		if (listening == false)
			return;  // Early return.
		acquire();
	}

	/**
	 * Private filter setter.
	 *
	 * @param filter  An LDAP filter.
	 */
	private void basicSetFilter(Filter filter) {
		this.filter = filter;
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.record.ServiceRecord#createServiceFilter()
	 */
	protected String createServiceFilter() {
		String name = getName();
		int length = name.length();
		int size = 14 + length;
		StringBuffer buffer = new StringBuffer(size);
		createServiceFilterOn(buffer, name);
		String result = buffer.toString();
		return result;
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.record.ServiceRecord#estimateToStringBufferSize()
	 */
	protected int estimateToStringBufferSize() {
		return super.estimateToStringBufferSize() + 100;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord#getFilter()
	 */
	public Filter getFilter() {
		return filter;
	}

	/**
	 * Using the service filter, query the framework for a matching registered
	 * service.
	 *
	 * @return An array of <code>ServiceReference</code> objects that match the
	 *         filter.
	 */
	private ServiceReference[] getFilteredServiceReferences() {
		BundleContext bundleContext = getBundleContext();
		String name = getName();
		Object filter = getFilter();
		String filterString = filter.toString();
		ServiceReference[] references = null;

		try {
			references = bundleContext.getServiceReferences(name, filterString);
		} catch (InvalidSyntaxException exception) {
			handleInvalidSyntaxException(exception);
		}

		if (references == null) {
			references = ImportServiceRecord.NO_SERVICE_REFERENCES;
		}

		return references;
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.record.ServiceRecord#getLock()
	 */
	protected Object getLock() {
		IImportServiceRecordOwner owner = getOwner();
		Object lock;

		if (owner != null) {
			lock = owner.getLock();
			Assertion.checkIsNotNull(lock, ImportServiceRecord.LOCK_MUST_NOT_BE_NULL_KEY, this);
		} else {
			lock = super.getLock();
		}

		return lock;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord#getName()
	 */
	public String getName() {
		return name;
	}

	/**
	 * Private owner getter.
	 *
	 * @return IImportServiceRecordOwner
	 */
	private IImportServiceRecordOwner getOwner() {
		return owner;
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.record.ServiceRecord#getServiceReference()
	 */
	protected ServiceReference getServiceReference() {
		return serviceReference;
	}

	/**
	 * Handle the case where the OSGi service represented by the
	 * <code>ServiceReference</code> has been modified.  This is sent by the
	 * <code>ServiceRecord</code> method <code>serviceChanged(ServiceEvent)</code>
	 * as a result of being notified by the OSGi framework.
	 *
	 * @param serviceReference  The <code>ServiceReference</code> for the
	 * modified service.
	 */
	protected void handleModifiedService(ServiceReference serviceReference) {
		Object lock = getLock();

		synchronized (lock) {
			boolean filtered = hasFilter();
			if (filtered == false)
				return;  // Early return.
			applyFilter();
		}
	}

	/**
	 * Handle the case where the OSGi service represented by the
	 * <code>ServiceReference</code> has been registered.  This is sent by the
	 * <code>ServiceRecord</code> method <code>serviceChanged(ServiceEvent)</code>
	 * as a result of being notified by the OSGi framework.
	 *
	 * @param serviceReference  The <code>ServiceReference</code> for the
	 * registered service.
	 */
	protected void handleRegisteredService(ServiceReference serviceReference) {
		acquire();
	}	/**
	 * Handle the case where the OSGi service represented by the
	 * <code>ServiceReference</code> is being unregistering.  This is sent by
	 * the <code>ServiceRecord</code> method <code>serviceChanged(ServiceEvent)</code>
	 * as a result of being notified by the OSGi framework.
	 *
	 * @param serviceReference  The <code>ServiceReference</code>to the
	 *                          unregistering service.
	 */
	protected void handleUnregisteringService(ServiceReference serviceReference) {
		Object lock = getLock();

		synchronized (lock) {
			ServiceReference reference = getServiceReference();
			boolean equal = serviceReference.equals(reference);
			if (equal == false)
				return;  // Early return.
			release(false);
			acquire();
		}
	}

	/**
	 * Answers true if a user defined filter exists, otherwise false.
	 *
	 * @return boolean
	 */
	private boolean hasFilter() {
		Object filter = getFilter();
		boolean result = filter != null;
		return result;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord#isAcquired()
	 */
	public boolean isAcquired() {
		ServiceReference reference = getServiceReference();
		boolean acquired = reference != null;
		return acquired;
	}

	private void logTraceAcquiredService() {
		boolean tracing = LogUtility.isTracing();
		if (tracing == false)
			return;  // Early return.

		Bundle bundle = getBundle();
		if (bundle == null)
			return;  // Early return.

		Object source = bundle.getSymbolicName();
		Object name = getName();
		Object filter = getFilter();

		Object[] values = new Object[] {
			source, name, filter
		};

		String key = filter == null ? ImportServiceRecord.ACQUIRED_SERVICE_KEY : ImportServiceRecord.ACQUIRED_SERVICE_MATCHING_FILTER_KEY;
		String pattern = Messages.getString(key);
		String message = MessageFormatter.format(pattern, values);
		String component = Messages.getString(ImportServiceRecord.SAT_CORE_KEY);
		LogUtility.logTrace(component, message);
	}

	/**
	 * Log that a service matching the filter could not be acquired.
	 */
	private void logTraceFailedToAcquireService() {
		boolean tracing = LogUtility.isTracing();
		if (tracing == false)
			return;  // Early return.

		Bundle bundle = getBundle();
		if (bundle == null)
			return;  // Early return.

		Object source = bundle.getSymbolicName();
		Object name = getName();
		Object filter = getFilter();

		Object[] values = new Object[] {
			source, name, filter
		};

		String key = filter == null ? ImportServiceRecord.FAILED_TO_ACQUIRE_SERVICE_KEY : ImportServiceRecord.FAILED_TO_ACQUIRE_SERVICE_MATCHING_FILTER_KEY;
		String pattern = Messages.getString(key);
		String message = MessageFormatter.format(pattern, values);
		String component = Messages.getString(ImportServiceRecord.SAT_CORE_KEY);
		LogUtility.logTrace(component, message);
	}

	/**
	 * Print the filter on the specified buffer.
	 *
	 * @param buffer  The buffer on which to write.
	 */
	private void printFilterOn(StringBuffer buffer) {
		Object filter = getFilter();
		buffer.append(", filter=");  //$NON-NLS-1$
		buffer.append(filter);
	}

	/**
	 * Print the name on the specified buffer.
	 *
	 * @param buffer  The buffer on which to write.
	 */
	private void printNameOn(StringBuffer buffer) {
		Object name = getName();
		buffer.append(", name=");  //$NON-NLS-1$
		buffer.append(name);
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.record.ServiceRecord#printOn(StringBuffer)
	 */
	protected void printOn(StringBuffer buffer) {
		super.printOn(buffer);
		printNameOn(buffer);
		printFilterOn(buffer);
	}

	/**
	 * Registers the importer bundle and the exporter bundle relationship.
	 */
	private void registerBundleRelationship() {
		Bundle importer = getBundle();
		if (importer == null)
			return;  // Early return.

		ServiceReference reference = getServiceReference();
		Bundle exporter = reference.getBundle();
		if (exporter == null)
			return;  // Early return.

		BundleDependencyManager manager = BundleDependencyManager.getInstance();
		manager.register(importer, exporter);
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord#release()
	 */
	public void release() {
		Object lock = getLock();

		synchronized (lock) {
			release(true);
		}
	}

	/**
	 * Release the imported service.
	 *
	 * @param unregister  True if unregistering as a service listener is
	 *                    required, otherwise false.
	 */
	private void release(boolean unregister) {
		boolean acquired = isAcquired();
		if (acquired == true) {
			ServiceReference reference = getServiceReference();
			setServiceReference(null);

			IImportServiceRecordOwner owner = getOwner();
			if (owner != null) {
				owner.serviceReleased(this);
			}

			boolean reacquired = isAcquired();
			if (reacquired == false) {
				setService(null);
			}

			BundleContext bundleContext = getBundleContext();

			try {
				bundleContext.ungetService(reference);
			} catch (IllegalStateException exception) {
				// BundleContext is disposed.
			}
		}

		if (unregister == true) {
			unregisterAsServiceListener();
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord#setFilter(org.osgi.framework.Filter)
	 */
	public void setFilter(Filter filter) {
		Object lock = getLock();

		synchronized (lock) {
			if (this.filter != null && this.filter.equals(filter))
				return;  // Early return.
			basicSetFilter(filter);
			applyFilter();
		}
	}

	/**
	 * Private name setter.
	 *
	 * @param name  The fully qualified type name of the service.
	 */
	private void setName(String name) {
		Assertion.checkArgumentIsNotNull(name, "name");  //$NON-NLS-1$
		this.name = name;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord#setOwner(org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecordOwner)
	 */
	public void setOwner(IImportServiceRecordOwner owner) {
		this.owner = owner;
	}

	/**
	 * Private serviceReference setter.
	 *
	 * @param serviceReference  The <code>ServiceReference</code> for the
	 *                          imported service.
	 */
	private void setServiceReference(ServiceReference serviceReference) {
		Object lock = getLock();

		synchronized (lock) {
			if (this.serviceReference != null) {
				unregisterBundleRelationship();
			}

			this.serviceReference = serviceReference;

			if (this.serviceReference != null) {
				registerBundleRelationship();
			}
		}
	}

	/**
	 * Unregisters the importer bundle and the exporter bundle relationship.
	 */
	private void unregisterBundleRelationship() {
		ServiceReference reference = getServiceReference();
		Bundle exporter = reference.getBundle();
		if (exporter == null)
			return;  // Early return.

		BundleDependencyManager bdm = BundleDependencyManager.getInstance();
		boolean uninstallable = bdm.isRegisteredAsUninstallable(exporter);

		if (uninstallable == false) {
			Bundle importer = getBundle();
			if (importer == null)
				return;  // Early return.
			bdm.unregister(importer, exporter);
		}
	}
}