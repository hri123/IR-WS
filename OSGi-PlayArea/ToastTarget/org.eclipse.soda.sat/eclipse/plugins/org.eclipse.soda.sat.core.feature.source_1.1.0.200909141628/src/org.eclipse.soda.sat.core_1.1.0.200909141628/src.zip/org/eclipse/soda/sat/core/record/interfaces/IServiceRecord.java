/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.record.interfaces;

import org.osgi.framework.BundleContext;

/**
 * The <code>IServiceRecord</code> interface declares the API for all OSGi
 * services that are managed by SAT.  The following responsibilities are
 * declared:
 * <ul>
 *   <li>
 *     Knowing the service object.
 *   </li>
 *   <li>
 *     Knowing whether the service object exists.
 *   </li>
 *   <li>
 *     Knowing the service object's properties.
 *   </li>
 *   <li>
 *     Knowing the service object's property keys.
 *   </li>
 * </ul>
 * <p>
 * <i>Note:</i> Since this abstraction is used internally by the SAT bundle
 * this interface is typically not used directly by bundle developers.  For
 * cases where subclassing the <code>BaseBundleActivator</code> is not
 * appropriate, instances of this interface can be created using the
 * <code>FactoryUtility</code> class.
 */
public interface IServiceRecord {
	/**
	 * Answers the result of calling the <code>Object</code> implementation of
	 * <code>toString()</code>.
	 *
	 * @return A String representation of the receiver.
	 */
	public String basicToString();

	/**
	 * Answers the <code>BundleContext</code>.
	 *
	 * @return The <code>BundleContext</code> handle back to the framework.
	 */
	public BundleContext getBundleContext();

	/**
	 * Answers the property value with the key.
	 *
	 * @param key  A service property key.
	 * @return The service property with the key.
	 */
	public Object getProperty(String key);

	/**
	 * Answers all the property keys.
	 *
	 * @return The service's property key names.
	 */
	public String[] getPropertyKeys();

	/**
	 * Answers the service domain object.
	 *
	 * @return The service domain object.
	 */
	public Object getService();
}