/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle;

import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleEvent;
import org.osgi.framework.BundleListener;

/**
 * The <code>BundleManager</code> is a class that provide support for
 * subclasses that wish to register with the OSGi framework as a
 * <code>org.osgi.framework.BundleListener</code>. The class implements the
 * following responsibilities:
 * <ul>
 *   <li>
 *     Registering as an OSGi <code>BundleListener</code> when started.
 *   </li>
 *   <li>
 *     Unregistering as an OSGi <code>BundleListener</code> when stopped.
 *   </li>
 *   <li>
 *     Handling each <code>BundleEvent</code> when fired by the OSGi framework.
 *     The event is <i>cracked</i> and dispatched to a handler method.
 *   </li>
 * </ul>
 *
 */
class BundleManager extends Object {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String UNKNOWN_BUNDLE_CONTEXT_KEY = "Common.UnknownBundleContext";  //$NON-NLS-1$
	private static final String UNKNOWN_BUNDLE_EVENT_KEY = "BundleManager.UnknownBundleEvent";  //$NON-NLS-1$

	//
	// Instance Fields
	//

	private BundleContext bundleContext;
	private BundleListener bundleListener;
	private boolean started;
	private final Object lock = new Object();

	//
	// Constructors
	//

	/**
	 * Construct a new <code>BundleManager</code>.
	 */
	protected BundleManager() {
		super();
		setBundleListener(createBundleListener());
		setStarted(false);
	}

	//
	// Instance Methods
	//

	/**
	 * A Bundle has changed state.
	 *
	 * @param event  A <code>BundleEvent</code> describing the bundle that has
	 * changed.
	 */
	private void bundleChanged(BundleEvent event) {
		int type = event.getType();
		Bundle bundle = event.getBundle();

		switch (type) {
			case BundleEvent.INSTALLED:
				handleBundleInstalled(bundle);
				break;
			case BundleEvent.STARTED:
				handleBundleStarted(bundle);
				break;
			case BundleEvent.STOPPED:
				handleBundleStopped(bundle);
				break;
			case BundleEvent.UPDATED:
				handleBundleUpdated(bundle);
				break;
			case BundleEvent.UNINSTALLED:
				handleBundleUninstalled(bundle);
				break;
			case BundleEvent.RESOLVED:
				handleBundleResolved(bundle);
				break;
			case BundleEvent.UNRESOLVED:
				handleBundleUnresolved(bundle);
				break;
			case BundleEvent.STARTING:
				handleBundleStarting(bundle);
				break;
			case BundleEvent.STOPPING:
				handleBundleStopping(bundle);
				break;
			default:
				handleUnknownBundleEvent(event);
				break;
		}
	}

	private void checkShutdownIsAllowed(BundleContext bundleContext) {
		BundleContext bc = getBundleContext();
		if (bundleContext.equals(bc) == true)
			return;  // Early return.
		String message = Messages.getString(BundleManager.UNKNOWN_BUNDLE_CONTEXT_KEY);
		throw new IllegalArgumentException(message);
	}

	/**
	 * Create a new <code>BundleListener</code>.
	 *
	 * @return BundleListener
	 */
	private BundleListener createBundleListener() {
		return new BundleListener() {
			public void bundleChanged(BundleEvent event) {
				BundleManager.this.bundleChanged(event);
			}
		};
	}

	protected final Bundle getBundle() {
		BundleContext bundleContext = getBundleContext();
		Bundle bundle = null;
		try {
			bundle = bundleContext.getBundle();
		} catch (IllegalStateException exception) {
			// The BundleContext is disposed.
		}
		return bundle;
	}

	/**
	 * Private <code>bundleContext</code> getter.
	 *
	 * @return BundleContext
	 */
	protected final BundleContext getBundleContext() {
		return bundleContext;
	}

	/**
	 * Private <code>bundleListener</code> getter.
	 *
	 * @return BundleListener
	 */
	private BundleListener getBundleListener() {
		return bundleListener;
	}

	/**
	 * Private <code>lock</code> getter.
	 *
	 * @return The lock Object.
	 */
	private Object getLock() {
		return lock;
	}

	/**
	 * Handles the case where a <code>Bundle</code> has been installed.
	 *
	 * @param bundle  The <code>Bundle</code> that has been installed.
	 */
	protected void handleBundleInstalled(Bundle bundle) {
		// No-op
	}

	/**
	 * Handles the case where a <code>Bundle</code> has been resolved.
	 *
	 * @param bundle  The <code>Bundle</code> that has been resolved.
	 */
	protected void handleBundleResolved(Bundle bundle) {
		// No-op
	}

	/**
	 * Handles the case where a <code>Bundle</code> has been started.
	 *
	 * @param bundle  The <code>Bundle</code> that has been started.
	 */
	protected void handleBundleStarted(Bundle bundle) {
		// No-op
	}

	/**
	 * Handles the case where a <code>Bundle</code> is starting.
	 *
	 * @param bundle  The <code>Bundle</code> that is starting.
	 */
	protected void handleBundleStarting(Bundle bundle) {
		// No-op
	}

	/**
	 * Handles the case where a <code>Bundle</code> has been stopped.
	 *
	 * @param bundle  The <code>Bundle</code> that has been stopped.
	 */
	protected void handleBundleStopped(Bundle bundle) {
		// No-op
	}

	/**
	 * Handles the case where a <code>Bundle</code> is stopping.
	 *
	 * @param bundle  The <code>Bundle</code> that is stopping.
	 */
	protected void handleBundleStopping(Bundle bundle) {
		// No-op
	}

	/**
	 * Handles the case where a <code>Bundle</code> has been uninstalled.
	 *
	 * @param bundle  The <code>Bundle</code> that has been uninstalled.
	 */
	protected void handleBundleUninstalled(Bundle bundle) {
		// No-op
	}

	/**
	 * Handles the case where a <code>Bundle</code> has been unresolved.
	 *
	 * @param bundle  The <code>Bundle</code> that has been unresolved.
	 */
	protected void handleBundleUnresolved(Bundle bundle) {
		// No-op
	}

	/**
	 * Handles the case where a <code>Bundle</code> has been updated.
	 *
	 * @param bundle  The <code>Bundle</code> that has been updated.
	 */
	protected void handleBundleUpdated(Bundle bundle) {
		// No-op
	}

	/**
	 * The manager has been shutdown.
	 */
	protected void handleManagerShutdown() {
		// No-op
	}

	/**
	 * The manager has been started.
	 */
	protected void handleManagerStarted() {
		// No-op
	}

	/**
	 * Handles the case where an unknown <code>BundleEvent</code> is received.
	 *
	 * @param event  The unknown <code>BundleEvent</code>.
	 */
	protected void handleUnknownBundleEvent(BundleEvent event) {
		logUnknownBundleEvent(event);
	}

	/**
	 * Hooks up the <code>BundleListener</code>.
	 */
	private void hookupBundleListener() {
		BundleContext bundleContext = getBundleContext();
		BundleListener listener = getBundleListener();
		bundleContext.addBundleListener(listener);
	}

	/**
	 * Answers true if the <code>BundleDependencyManager</code> is started,
	 * otherwise false.
	 *
	 * @return boolean
	 */
	public final boolean isStarted() {
		return started;
	}

	/**
	 * Log the unknown bundle event as an error.
	 *
	 * @param event  The bundle event.
	 */
	protected final void logUnknownBundleEvent(BundleEvent event) {
		String pattern = Messages.getString(BundleManager.UNKNOWN_BUNDLE_EVENT_KEY);
		Object[] values = new Object [ 2 ];
		Class clazz = getClass();
		String name = clazz.getName();
		values [ 0 ] = name;
		values [ 1 ] = event;
		String message = MessageFormatter.format(pattern, values);
		LogUtility.logDebug(message);
	}

	/**
	 * Private <code>bundleContext</code> setter.
	 *
	 * @param bundleContext  The receiver's <code>BundleContext</code>.
	 */
	private void setBundleContext(BundleContext bundleContext) {
		if (this.bundleContext != null) {
			unhookBundleListener();
		}

		this.bundleContext = bundleContext;

		if (this.bundleContext != null) {
			hookupBundleListener();
		}
	}

	/**
	 * Private <code>bundleListener</code> setter.
	 *
	 * @param bundleListener  The manager's <code>BundleListener</code>.
	 */
	private void setBundleListener(BundleListener bundleListener) {
		this.bundleListener = bundleListener;
	}

	private void setStarted(boolean started) {
		this.started = started;
	}

	/**
	 * Shutdown the manager.
	 *
	 * @param bundleContext  The manager's <code>BundleContext</code>.
	 */
	public final void shutdown(BundleContext bundleContext) {
		Assertion.checkArgumentIsNotNull(bundleContext, "bundleContext");  //$NON-NLS-1$
		Object lock = getLock();

		synchronized (lock) {
			boolean started = isStarted();
			if (started == false)
				return;  // Early return.
			checkShutdownIsAllowed(bundleContext);
			setStarted(false);
			handleManagerShutdown();
			setBundleContext(null);
		}
	}

	/**
	 * Starts up the manager.
	 *
	 * @param bundleContext  The manager's <code>BundleContext</code>.
	 */
	public final void startup(BundleContext bundleContext) {
		Assertion.checkArgumentIsNotNull(bundleContext, "bundleContext");  //$NON-NLS-1$
		Object lock = getLock();

		synchronized (lock) {
			boolean started = isStarted();
			if (started == true)
				return;  // Early return.
			setStarted(true);
			setBundleContext(bundleContext);
			handleManagerStarted();
		}
	}

	/**
	 * Unhook the <code>BundleListener</code>.
	 */
	private void unhookBundleListener() {
		BundleContext bundleContext = getBundleContext();
		BundleListener listener = getBundleListener();
		bundleContext.removeBundleListener(listener);
	}
}