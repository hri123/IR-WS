/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.eclipse.soda.sat.core.framework.LazyBundleActivator;
import org.eclipse.soda.sat.core.framework.interfaces.ITokenizer;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.BundleManifestUtility;
import org.eclipse.soda.sat.core.util.CollectionUtility;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;

public class LazyBundeActivatorProperties extends Object {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String DUPLICATE_PROPERTY_PARAMETER_KEY = "LazyBundleActivatorProperties.DuplicatePropertyParameter";  //$NON-NLS-1$
	private static final String FAILED_TO_FIND_PROPERTIES_FILE_KEY = "LazyBundleActivatorProperties.FailedToFindPropertiesFile";  //$NON-NLS-1$
	private static final String FAILED_TO_FIND_PROPERTY_KEY = "LazyBundleActivatorProperties.FailedToFindProperty";  //$NON-NLS-1$

	// Keys
	private static final String BUNDLE_ACTIVATOR_PROPERTIES_KEY = "Bundle-Activator";  //$NON-NLS-1$
	private static final String IMPORTED_SERVICES_PROPERTIES_KEY = "Imported-Services";  //$NON-NLS-1$

	// Characters
	private static final char ASSIGNMENT_OPERATOR = '=';
	private static final char PARAMETER_SEPARATOR = ';';

	// Misc
	private static final String FILTER = "filter";  //$NON-NLS-1$
	private static final String PROPERTIES_EXTENSION = ".properties";  //$NON-NLS-1$
	private static final String PROPERTIES_HEADER_PREFIX = "SAT";  //$NON-NLS-1$

	//
	// Instance Fields
	//

	private BundleContext bundleContext;
	private String bundleActivator;
	private List/*<String>*/ importedServiceNames;
	private Map/*<String, String>*/ importedServiceFilters;

	//
	// Constructors
	//

	/**
	 * Constructor
	 *
	 * @param bundleContext  The bundle's <code>BundleContext</code>.
	 */
	public LazyBundeActivatorProperties(BundleContext bundleContext) {
		super();
		setBundleContext(bundleContext);
		initialize();
	}

	//
	// Instance Methods
	//

	private String createDuplicatePropertyParameterMessage(String property, String key) {
		String pattern = Messages.getString(LazyBundeActivatorProperties.DUPLICATE_PROPERTY_PARAMETER_KEY);
		String path = getPropertiesPath();
		String symbolicName = getBundleSymbolicName();

		Object[] values = new Object[] {
			property,
			path,
			symbolicName,
			key
		};

		String message = MessageFormatter.format(pattern, values);
		return message;
	}

	private String createFailedToFindPropertiesFileMessage() {
		String pattern = Messages.getString(LazyBundeActivatorProperties.FAILED_TO_FIND_PROPERTIES_FILE_KEY);
		String path = getPropertiesPath();
		String symbolicName = getBundleSymbolicName();

		Object[] values = new Object[] {
			path,
			symbolicName
		};

		String message = MessageFormatter.format(pattern, values);
		return message;
	}

	private String createFailedToFindPropertyMessage(String key) {
		String pattern = Messages.getString(LazyBundeActivatorProperties.FAILED_TO_FIND_PROPERTY_KEY);
		String path = getPropertiesPath();
		String symbolicName = getBundleSymbolicName();

		Object[] values = new Object[] {
			key,
			path,
			symbolicName
		};

		String message = MessageFormatter.format(pattern, values);
		return message;
	}

	private ITokenizer createTokenizer(String value) {
		FactoryUtility utility = getFactoryUtility();
		ITokenizer tokenizer = utility.createTokenizer(value);
		return tokenizer;
	}

	private ITokenizer createTokenizer(String value, char delimiter) {
		FactoryUtility utility = getFactoryUtility();
		ITokenizer tokenizer = utility.createTokenizer(value, delimiter);
		return tokenizer;
	}

	private int estimateHashedCollectionSize(int capacity) {
		CollectionUtility utility = CollectionUtility.getInstance();
		int size = utility.estimateHashedCollectionSize(capacity);
		return size;
	}

	private Bundle getBundle() {
		BundleContext bundleContext = getBundleContext();
		Bundle bundle = null;
		try {
			bundle = bundleContext.getBundle();
		} catch (IllegalStateException exception) {
			// The BundleContext is disposed.
		}
		return bundle;
	}

	/**
	 * Get the bundle activator name.
	 *
	 * @return String
	 */
	public String getBundleActivator() {
		return bundleActivator;
	}

	private BundleContext getBundleContext() {
		return bundleContext;
	}

	private URL getBundleEntry(String path) {
		URL url = null;
		Bundle bundle = getBundle();
		if (bundle != null) {
			url = bundle.getEntry(path);
		}
		return url;
	}

	private String getBundleSymbolicName() {
		String symbolicName = null;
		Bundle bundle = getBundle();
		if (bundle != null) {
			symbolicName = bundle.getSymbolicName();
		}
		return symbolicName;
	}

	private String getClassName() {
		String value = LazyBundleActivator.class.getName();
		int index = value.lastIndexOf('.') + 1;
		value = value.substring(index);
		return value;
	}

	private String getDefaultPropertiesPath() {
		String className = getClassName();
		String path = className + LazyBundeActivatorProperties.PROPERTIES_EXTENSION;
		return path;
	}

	private FactoryUtility getFactoryUtility() {
		return FactoryUtility.getInstance();
	}

	/**
	 * Get the imported service filter for the specified service.
	 * @param name  The name of an imported service.
	 * @return String
	 */
	public String getImportedServiceFilter(String name) {
		Assertion.checkArgumentIsNotNull(name, "name");  //$NON-NLS-1$
		Map/*<String, String>*/ filters = getImportedServiceFilters();
		String filter = (String) filters.get(name);
		return filter;
	}

	private Map/*<String, String>*/ getImportedServiceFilters() {
		return importedServiceFilters;
	}

	private List/*<String>*/ getImportedServiceLines(String value) {
		ITokenizer tokenizer = createTokenizer(value);
		ArrayList/*<String>*/ lines = new ArrayList/*<String>*/(10);

		while (tokenizer.hasMoreTokens() == true) {
			String line = tokenizer.nextToken();
			lines.add(line);
		}

		lines.trimToSize();
		return lines;
	}

	/**
	 * Get the imported service names.
	 *
	 * @return List
	 */
	public List/*<String>*/ getImportedServiceNames() {
		return importedServiceNames;
	}

	private String getParameterKey(String parameter) {
		int index = parameter.indexOf(LazyBundeActivatorProperties.ASSIGNMENT_OPERATOR);
		String key = index == -1 ? parameter : parameter.substring(0, index);
		key = key.trim();
		return key;
	}

	private Map/*<String, String>*/ getParameters(String property, String value) {
		int size = estimateHashedCollectionSize(3);
		Map/*<String, String>*/ map = new HashMap/*<String, String>*/(size);
		ITokenizer tokenizer = createTokenizer(value, LazyBundeActivatorProperties.PARAMETER_SEPARATOR);

		while (tokenizer.hasMoreTokens() == true) {
			String parameter = tokenizer.nextToken();
			String parameterKey = getParameterKey(parameter);
			String parameterValue = getParameterValue(parameter);

			boolean exists = map.containsKey(parameterKey);

			if (exists == true) {
				String message = createDuplicatePropertyParameterMessage(property, parameterKey);
				throw new RuntimeException(message);
			}

			map.put(parameterKey, parameterValue);
		}

		return map;
	}

	private String getParameterValue(String parameter) {
		int index = parameter.indexOf(LazyBundeActivatorProperties.ASSIGNMENT_OPERATOR);
		String value = index == -1 ? parameter : parameter.substring(index + 1);
		value = value.trim();
		return value;
	}

	private String getPropertiesHeader() {
		String className = getClassName();
		String header = LazyBundeActivatorProperties.PROPERTIES_HEADER_PREFIX + '-' + className;
		return header;
	}

	private InputStream getPropertiesInputStream() throws IOException {
		String path = getPropertiesPath();
		URL url = getBundleEntry(path);

		if (url == null) {
			String message = createFailedToFindPropertiesFileMessage();
			throw new RuntimeException(message);
		}

		InputStream stream = url.openStream();
		return stream;
	}

	private String getPropertiesPath() {
		BundleManifestUtility utility = BundleManifestUtility.getInstance();
		Bundle bundle = getBundle();
		String header = getPropertiesHeader();
		String path = utility.getHeader(bundle, header);

		if (path == null) {
			path = getDefaultPropertiesPath();
		}

		return path;
	}

	private String getProperty(String key, Properties properties) {
		String lowerCaseKey = key.toLowerCase();
		String value = properties.getProperty(lowerCaseKey);

		if (value != null) {
			value = value.trim();
		}

		if (value == null || value.length() == 0) {
			String message = createFailedToFindPropertyMessage(key);
			throw new RuntimeException(message);
		}

		return value;
	}

	private void initialize() {
		Properties properties = loadProperties();
		processProperties(properties);
	}

	private Properties loadProperties() {
		Properties properties = null;

		try {
			InputStream stream = getPropertiesInputStream();
			try {
				Properties loadedProperties = new Properties();
				loadedProperties.load(stream);
				properties = toLowerCaseKeys(loadedProperties);
			} finally {
				stream.close();
			}
		} catch (IOException exception) {
			String message = exception.getMessage();
			LogUtility.logError(this, message, exception);
		}

		return properties;
	}

	private void processBundleActivatorProperty(Properties properties) {
		String bundleActivator = getProperty(LazyBundeActivatorProperties.BUNDLE_ACTIVATOR_PROPERTIES_KEY, properties);
		setBundleActivator(bundleActivator);
	}

	private void processImportedService(String line) {
		String name;
		String filterString = null;

		int index = line.indexOf(LazyBundeActivatorProperties.PARAMETER_SEPARATOR);

		if (index == -1) {
			name = line;
		} else {
			name = line.substring(0, index);
			String parameters = line.substring(index + 1);
			Map/*<String, String>*/ map = getParameters(LazyBundeActivatorProperties.IMPORTED_SERVICES_PROPERTIES_KEY, parameters);
			filterString = (String) map.get(LazyBundeActivatorProperties.FILTER);
		}

		List/*<String>*/ names = getImportedServiceNames();
		names.add(name);


		if (filterString != null) {
			Map/*<String, String>*/ filters = getImportedServiceFilters();
			filters.put(name, filterString);
		}
	}

	private void processImportedServicesProperty(Properties properties) {
		String value = getProperty(LazyBundeActivatorProperties.IMPORTED_SERVICES_PROPERTIES_KEY, properties);
		List/*<String>*/ lines = getImportedServiceLines(value);
		int numberOfImportedServices = lines.size();

		List/*<String>*/ names = new ArrayList/*<String>*/(numberOfImportedServices);
		setImportedServiceNames(names);

		int size = estimateHashedCollectionSize(numberOfImportedServices);
		Map/*<String, String>*/ filters = new HashMap/*<String, String>*/(size);
		setImportedServiceFilters(filters);

		Iterator/*<String>*/ iterator = lines.iterator();

		while (iterator.hasNext() == true) {
			String line = (String) iterator.next();
			processImportedService(line);
		}
	}

	private void processProperties(Properties properties) {
		processBundleActivatorProperty(properties);
		processImportedServicesProperty(properties);
	}

	private void setBundleActivator(String bundleActivator) {
		this.bundleActivator = bundleActivator;
	}

	private void setBundleContext(BundleContext bundleContext) {
		Assertion.checkArgumentIsNotNull(bundleContext, "bundleContext");  //$NON-NLS-1$
		this.bundleContext = bundleContext;
	}

	private void setImportedServiceFilters(Map/*<String, String>*/ importedServiceFilters) {
		this.importedServiceFilters = importedServiceFilters;
	}

	private void setImportedServiceNames(List/*<String>*/ importedServiceNames) {
		this.importedServiceNames = importedServiceNames;
	}

	private Properties toLowerCaseKeys(Properties properties) {
		Set/*<Map.Entry>*/ entries = properties.entrySet();
		Iterator/*<Map.Entry>*/ iterator = entries.iterator();
		Properties lowerCasePropertyKeys = new Properties();

		while (iterator.hasNext() == true) {
			Map.Entry entry = (Map.Entry) iterator.next();
			String key = (String) entry.getKey();
			key = key.toLowerCase();
			String value = (String) entry.getValue();
			lowerCasePropertyKeys.put(key, value);
		}

		return lowerCasePropertyKeys;
	}
}
