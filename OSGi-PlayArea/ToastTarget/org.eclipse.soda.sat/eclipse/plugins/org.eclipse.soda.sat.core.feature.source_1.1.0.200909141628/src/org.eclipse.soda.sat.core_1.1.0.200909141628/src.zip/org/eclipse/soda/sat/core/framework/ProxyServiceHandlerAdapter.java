/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework;

import java.lang.reflect.Method;

import org.eclipse.soda.sat.core.framework.interfaces.IProxyServiceHandler;
import org.eclipse.soda.sat.core.util.LogUtility;

/**
 * <code>ProxyServiceHandlerAdapter</code> is a concrete <i>no-op</i>
 * implementation of the <code>IProxyServiceHandler</code> interface.  It is
 * intended that this class be subclassed and one or two methods overridden.  It
 * is common for a subclass to only implement the <code>createService()</code>
 * method, for example.
 */
public class ProxyServiceHandlerAdapter extends Object implements IProxyServiceHandler {
	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IProxyServiceHandler#createService()
	 */
	public Object createService() {
		// No-op
		return null;
	}

	/**
	 * This implementation logs <code>throwable</code> parameter as an error if
	 * it is not <code>null</code>.
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IProxyServiceHandler#postInvoke(java.lang.Object, java.lang.reflect.Method, java.lang.Object[], java.lang.Throwable, java.lang.Object)
	 */
	public void postInvoke(Object service, Method method, Object[] args, Throwable throwable, Object data) {
		if (throwable == null)
			return;  // Early return.
		String message = throwable.getMessage();
		LogUtility.logError(this, message, throwable);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IProxyServiceHandler#preInvoke(java.lang.Object, java.lang.reflect.Method, java.lang.Object[])
	 */
	public Object preInvoke(Object service, Method method, Object[] args) {
		// No-op
		return null;
	}
}
