/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework;

import java.io.IOException;
import java.io.InputStream;

import org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner;
import org.eclipse.soda.sat.core.util.LogUtility;

/**
 * <code>BundleActivationManagerOwnerAdapter</code> is a no-op implementation of
 * the <code>IBundleActivationManagerOwner</code> interface. This class is
 * useful for creating an owner of an <code>IBundleActivationManager</code> that
 * only requires to handle a subset of the possible call-backs, which is common.
 */
public class BundleActivationManagerOwnerAdapter extends Object implements IBundleActivationManagerOwner {
	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#activate()
	 */
	public void activate() {
		// No-op
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#deactivate()
	 */
	public void deactivate() {
		// No-op
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#getAsyncStartPriority()
	 */
	public int getAsyncStartPriority() {
		return Thread.NORM_PRIORITY;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#getImportedServiceNames()
	 */
	public String[] getImportedServiceNames() {
		return IBundleActivationManagerOwner.NO_SERVICES;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#getOptionalImportedServiceNames()
	 */
	public String[] getOptionalImportedServiceNames() {
		return IBundleActivationManagerOwner.NO_SERVICES;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#getPropertiesInputStream()
	 */
	public InputStream getPropertiesInputStream() throws IOException {
		return null;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#handleAcquiredOptionalImportedService(java.lang.String, java.lang.Object)
	 */
	public void handleAcquiredOptionalImportedService(String serviceName, Object service) {
		// No-op
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#handleException(java.lang.Exception)
	 */
	public boolean handleException(Exception exception) {
		String message = exception.getMessage();
		LogUtility.logError(this, message, exception);
		return false;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#handleFailedToFindProperties(java.lang.String)
	 */
	public void handleFailedToFindProperties(String filename) {
		// No-op
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#handleReleasedOptionalImportedService(java.lang.String, java.lang.Object)
	 */
	public void handleReleasedOptionalImportedService(String serviceName, Object service) {
		// No-op
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#isStartAsync()
	 */
	public boolean isStartAsync() {
		return false;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#isTransient()
	 */
	public boolean isTransient() {
		return false;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#isUninstallable()
	 */
	public boolean isUninstallable() {
		return false;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#start()
	 */
	public void start() throws Exception {
		// No-op
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner#stop()
	 */
	public void stop() throws Exception {
		// No-op
	}
}
