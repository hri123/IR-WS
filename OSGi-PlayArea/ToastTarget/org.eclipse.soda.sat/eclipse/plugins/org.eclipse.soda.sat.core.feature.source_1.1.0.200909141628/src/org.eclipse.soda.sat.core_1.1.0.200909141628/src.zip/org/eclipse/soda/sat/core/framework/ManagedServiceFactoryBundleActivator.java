/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework;

import java.net.URL;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Set;

import org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryActivationManager;
import org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryAdvisor;
import org.eclipse.soda.sat.core.framework.interfaces.IProxyServiceHandler;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.internal.util.WarningMessageUtility;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.MiscUtility;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.service.cm.ConfigurationAdmin;
import org.osgi.service.cm.ConfigurationException;
import org.osgi.service.cm.ManagedServiceFactory;

/**
 * <code>ManagedServiceFactoryBundleActivator</code> is an abstract class from
 * which all SAT managed service factory bundles typically derive their
 * <code>BundleActivator</code>.
 */
public abstract class ManagedServiceFactoryBundleActivator extends BaseBundleActivator implements ManagedServiceFactory  {
	//
	// Static Fields
	//

	// Property Keys
	private static final String CHECK_METADATA_EXISTS_PROPERTY = "org.eclipse.soda.sat.core.framework.check.metadata.exists";  //$NON-NLS-1$
	private static final String CREATE_MANAGED_SERVICE_FACTORY_PROXY_PROPERTY = "org.eclipse.soda.sat.core.framework.create.msf.proxy";  //$NON-NLS-1$

	// Default Property Values
	private static final boolean DEFAULT_CHECK_METADATA_EXISTS = false;
	private static final boolean DEFAULT_CREATE_MANAGED_SERVICE_FACTORY_PROXY = false;

	// Properties
	private static final boolean CHECK_METADATA_EXISTS = ManagedServiceFactoryBundleActivator.getBooleanProperty(ManagedServiceFactoryBundleActivator.CHECK_METADATA_EXISTS_PROPERTY, ManagedServiceFactoryBundleActivator.DEFAULT_CHECK_METADATA_EXISTS);
	private static final boolean CREATE_MANAGED_SERVICE_FACTORY_PROXY = ManagedServiceFactoryBundleActivator.getBooleanProperty(ManagedServiceFactoryBundleActivator.CREATE_MANAGED_SERVICE_FACTORY_PROXY_PROPERTY, ManagedServiceFactoryBundleActivator.DEFAULT_CREATE_MANAGED_SERVICE_FACTORY_PROXY);

	// Externalized String Keys
	private static final String FAILED_TO_FIND_METADATA_RESOURCE_KEY = "ManagedServiceFactoryBundleActivator.FailedToFindMetaDataResource";  //$NON-NLS-1$
	private static final String SAT_CORE_KEY = "Common.SatCore";  //$NON-NLS-1$

	// Misc
	protected static final String CONFIGURATION_ADMIN_SERVICE_NAME = ConfigurationAdmin.class.getName();
	protected static final String MANAGED_SERVICE_FACTORY_SERVICE_NAME = ManagedServiceFactory.class.getName();
	protected static final int NUMBER_OF_CONFIGURATIONS_HINT = 5;

	//
	// Static Methods
	//

	private static boolean getBooleanProperty(String key, boolean defaultValue) {
		MiscUtility utility = MiscUtility.getInstance();
		boolean value = utility.getBooleanProperty(key, defaultValue);
		return value;
	}

	//
	// Instance Fields
	//

	private IManagedServiceFactoryActivationManager managedServiceFactoryActivationManager;
	private String pid;

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#activate()
	 */
	protected void activate() {
		registerManagedServiceFactory();
	}

	private void addExportedManagedServiceFactoryProxyService() {
		Class interfaceType = ManagedServiceFactory.class;

		IProxyServiceHandler handler = new ProxyServiceHandlerAdapter(){
			public Object createService() {
				return ManagedServiceFactoryBundleActivator.this.createManagedServiceFactory();
			}
		};

		Dictionary properties = createManagedServiceFactoryProperties();
		addExportedProxyService(interfaceType, handler, properties);
	}

	/**
	 * Check that that META-INF/METADATA.XML file exists.  Since this resource
	 * should reside in the bundle it is worth checking that it exists and
	 * display a warning message if it does not.
	 */
	private void checkMetaDataResourceExists() {
		if (ManagedServiceFactoryBundleActivator.CHECK_METADATA_EXISTS == false)
			return;  // Early return.
		Bundle bundle = getBundle();  // OSGi Query Method.
		URL url = bundle.getResource("META-INF/METADATA.XML");  //$NON-NLS-1$
		if (url != null)
			return;  // Early return.

		WarningMessageUtility utility = WarningMessageUtility.getInstance();
		String component = Messages.getString(ManagedServiceFactoryBundleActivator.SAT_CORE_KEY);
		Object source = bundle.getSymbolicName();
		String warning = Messages.getString(ManagedServiceFactoryBundleActivator.FAILED_TO_FIND_METADATA_RESOURCE_KEY);
		utility.warn(component, source, warning, null, null);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#collectImportedServiceNames(java.util.Set)
	 */
	protected void collectImportedServiceNames(Set/*<String>*/ serviceNames) {
		super.collectImportedServiceNames(serviceNames);
		serviceNames.add(ManagedServiceFactoryBundleActivator.CONFIGURATION_ADMIN_SERVICE_NAME);
	}

	/**
	 * Create the <code>IManagedServiceFactoryAdvisor</code> that knows how
	 * to create and destroy the exported service that is managed by the
	 * service factory.
	 *
	 * @return An IManagedServiceFactoryAdvisor.
	 */
	protected abstract IManagedServiceFactoryAdvisor createAdvisor();

	/**
	 * Create the default PID for the <code>ManagedServiceFactory</code>.
	 *
	 * @return The default PID of the <code>ManagedServiceFactory</code>.
	 */
	protected final String createDefaultPid() {
		Class clazz = getClass();
		String name = clazz.getName();
		return name;
	}

	private ManagedServiceFactory createManagedServiceFactory() {
		checkMetaDataResourceExists();
		startManagedServiceFactoryActivationManager();
		ManagedServiceFactory service = getManagedServiceFactory();
		return service;
	}

	/**
	 * Create the <code>IManagedServiceFactoryActivationManager</code>.
	 *
	 * @return An IManagedServiceFactoryActivationManager
	 */
	private IManagedServiceFactoryActivationManager createManagedServiceFactoryActivationManager() {
		String name = getName();
		IManagedServiceFactoryAdvisor advisor = createAdvisor();
		FactoryUtility utility = FactoryUtility.getInstance();
		int hint = ManagedServiceFactoryBundleActivator.NUMBER_OF_CONFIGURATIONS_HINT;
		IManagedServiceFactoryActivationManager manager = utility.createManagedServiceFactoryActivationManager(name, advisor, hint);
		return manager;
	}

	/**
	 * Create the properties for the <code>ManagedServiceFactory</code> that is
	 * is exported and registered with the OSGi framework.
	 *
	 * @return A Dictionary.
	 */
	private Dictionary createManagedServiceFactoryProperties() {
		Dictionary properties = new Hashtable(11);
		String pid = getPid();
		properties.put(Constants.SERVICE_PID, pid);
		return properties;
	}

	/**
	 * Create the PID for the <code>ManagedServiceFactory</code>.
	 *
	 * @return The PID of the <code>ManagedServiceFactory</code>.
	 */
	protected String createPid() {
		String pid = createDefaultPid();
		return pid;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#deactivate()
	 */
	protected void deactivate() {
		unregisterManagedServiceFactory();
		stopManagedServiceFactoryActivationManager();
	}

	/**
	 * @see org.osgi.service.cm.ManagedServiceFactory#deleted(java.lang.String)
	 */
	public final void deleted(String pid) {
		IManagedServiceFactoryActivationManager manager = getManagedServiceFactoryActivationManager();
		manager.deleted(pid);
	}

	/**
	 * Get the <code>ManagedServiceFactory</code>, which is always
	 * <code>this</code> object.
	 *
	 * @return The <code>ManagedServiceFactory</code>.
	 */
	private ManagedServiceFactory getManagedServiceFactory() {
		return this;
	}

	/**
	 * Private <code>managedServiceFactoryActivationManager</code> getter.
	 *
	 * @return IManagedServiceFactoryActivationManager
	 */
	private IManagedServiceFactoryActivationManager getManagedServiceFactoryActivationManager() {
		synchronized (this) {
			if (managedServiceFactoryActivationManager == null) {
				IManagedServiceFactoryActivationManager manager = createManagedServiceFactoryActivationManager();
				setManagedServiceFactoryActivationManager(manager);
			}

			return managedServiceFactoryActivationManager;
		}
	}

	/*
	 * @see org.osgi.service.cm.ManagedServiceFactory#getName()
	 */
	/**
	 * @see org.osgi.service.cm.ManagedServiceFactory#getName()
	 */
	public String getName() {
		String name = getPid();
		return name;
	}

	/**
	 * Get a hint to the number of configurations that will be created for this
	 * <code>ManagedServiceFactory</code>.
	 *
	 * @return A hint to the number of configurations that will be created.
	 */
	protected int getNumberOfConfigurationsHint() {
		return ManagedServiceFactoryBundleActivator.NUMBER_OF_CONFIGURATIONS_HINT;
	}

	/**
	 * Get the persistent ID for the <code>ManagedServiceFactory</code>.
	 *
	 * @return The pid.
	 */
	protected final String getPid() {
		synchronized (this) {
			if (pid == null) {
				String pid = createPid();
				setPid(pid);
			}

			return pid;
		}
	}

	/**
	 * Query whether the managed service factory is created as a proxy service.
	 *
	 * @return True if the managed service factory is created as a proxy service
	 * otherwise false.
	 */
	protected boolean isProxyService() {
		return ManagedServiceFactoryBundleActivator.CREATE_MANAGED_SERVICE_FACTORY_PROXY;
	}

	/**
	 * Register the <code>ManagedServiceFactory</code>.
	 */
	private void registerManagedServiceFactory() {
		boolean proxy = isProxyService();

		if (proxy == true) {
			addExportedManagedServiceFactoryProxyService();
		} else {
			ManagedServiceFactory service = createManagedServiceFactory();
			Dictionary properties = createManagedServiceFactoryProperties();
			addExportedService(ManagedServiceFactoryBundleActivator.MANAGED_SERVICE_FACTORY_SERVICE_NAME, service, properties);
		}
	}

	/**
	 * Private managedServiceFactoryActivationManager setter.
	 *
	 * @param managedServiceFactoryActivationManager  An IManagedServiceFactoryActivationManager.
	 */
	private void setManagedServiceFactoryActivationManager(IManagedServiceFactoryActivationManager managedServiceFactoryActivationManager) {
		this.managedServiceFactoryActivationManager = managedServiceFactoryActivationManager;
	}

	/**
	 * Private pid setter.
	 *
	 * @param pid  The persistent ID.
	 */
	private void setPid(String pid) {
		this.pid = pid;
	}

	/**
	 * Start the <code>IManagedServiceFactoryActivationManager</code>.  This
	 * is done just before creating the exported <code>ManagedServiceFactory</code>.
	 */
	private void startManagedServiceFactoryActivationManager() {
		BundleContext context = getBundleContext();
		IManagedServiceFactoryActivationManager manager = getManagedServiceFactoryActivationManager();
		manager.start(context);
	}

	/**
	 * Stop the <code>IManagedServiceFactoryActivationManager</code>.  This
	 * is done just before destroying the exported <code>ManagedServiceFactory</code>.
	 */
	private void stopManagedServiceFactoryActivationManager() {
		IManagedServiceFactoryActivationManager manager = getManagedServiceFactoryActivationManager();
		manager.stop();
		setManagedServiceFactoryActivationManager(null);
	}

	private void unregisterManagedServiceFactory() {
		removeExportedService(ManagedServiceFactoryBundleActivator.MANAGED_SERVICE_FACTORY_SERVICE_NAME);
	}

	/**
	 * @see org.osgi.service.cm.ManagedServiceFactory#updated(java.lang.String, java.util.Dictionary)
	 */
	public final void updated(String pid, Dictionary properties) throws ConfigurationException {
		IManagedServiceFactoryActivationManager manager = getManagedServiceFactoryActivationManager();
		manager.updated(pid, properties);
	}
}