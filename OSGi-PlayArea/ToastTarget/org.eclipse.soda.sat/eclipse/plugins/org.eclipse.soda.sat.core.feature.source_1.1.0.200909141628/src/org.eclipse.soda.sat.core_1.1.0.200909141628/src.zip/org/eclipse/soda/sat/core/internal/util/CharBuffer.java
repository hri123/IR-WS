/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util;

import java.util.Arrays;

import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.MessageFormatter;

/**
 * The <code>CharBuffer</code> class is an unsynchronized character buffer. This
 * class has been designed as a high performance replacement for the most common
 * <code>StringBuffer</code> uses. This class is not internally thread-safe so
 * you must ensure that an instance is only ever being used by a single thread.
 * The method toSynchronizedCharBuffer() should be used to make an instance of
 * this class thread-safe.
 */
public class CharBuffer extends Object implements ICharBuffer {
	//
	// Static Fields
	//

	// Externalized String
	private static final String UNKNOWN_GROW_STYLE = "CharBuffer.UnknownGrowStyle";  //$NON-NLS-1$

	// Misc
	private static final int DEFAULT_INITIAL_CAPACITY = 25;

	//
	// Instance Fields
	//

	private char[] contents;
	private int initialCapacity;
	private int growPercentage;
	private short growStyle;
	private int index;

	//
	// Constructors
	//

	/**
	 * Constructor.
	 *
	 * @param initialCapacity  The initial capacity of the buffer.
	 */
	public CharBuffer(int initialCapacity) {
		super();
		int capacity = validateInitialCapacity(initialCapacity);
		setInitialCapacity(capacity);
		setContents(createContents(capacity + 1));
		setGrowPercentage(100);
		setGrowStyle(ICharBuffer.GROW_LINEARLY);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(boolean)
	 */
	public ICharBuffer append(boolean booleanValue) {
		Boolean wrapper = booleanValue == true ? Boolean.TRUE : Boolean.FALSE;
		String value = wrapper.toString();
		return append(value);
	}

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(char)
	 */
	public ICharBuffer append(char charValue) {
		ensureCapacity(1);
		char[] contents = getContents();
		int index = getIndex();
		contents [ index ] = charValue;
		setIndex(index + 1);
		return this;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(char[])
	 */
	public ICharBuffer append(char[] array) {
		return append(array, 0, array.length);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(char[], int, int)
	 */
	public ICharBuffer append(char[] array, int start, int length) {
		ensureCapacity(length);
		char[] contents = getContents();
		int index = getIndex();
		int stop = start + length;
		for (int i = start; i < stop; i++) {
			contents [ index ] = array [ i ];
			index++;
		}
		setIndex(index);
		return this;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(double)
	 */
	public ICharBuffer append(double doubleValue) {
		String value = Double.toString(doubleValue);
		return append(value);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(float)
	 */
	public ICharBuffer append(float floatValue) {
		String value = Float.toString(floatValue);
		return append(value);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(int)
	 */
	public ICharBuffer append(int intValue) {
		String value = Integer.toString(intValue);
		return append(value);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(long)
	 */
	public ICharBuffer append(long longValue) {
		String value = Long.toString(longValue);
		return append(value);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(java.lang.Object)
	 */
	public ICharBuffer append(Object object) {
		String value = String.valueOf(object);
		ICharBuffer buffer = append(value);
		return buffer;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(java.lang.String)
	 */
	public ICharBuffer append(String value) {
		if (value == null) {
			String nullValue = String.valueOf(value);
			ICharBuffer buffer = append(nullValue);
			return buffer;
		}
		int length = value.length();
		ensureCapacity(length);
		char[] contents = getContents();
		int index = getIndex();
		value.getChars(0, length, contents, index);
		setIndex(index + length);
		return this;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#capacity()
	 */
	public int capacity() {
		char[] contents = getContents();
		int capacity = contents.length - 1;
		return capacity;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#charAt(int)
	 */
	public char charAt(int i) {
		char[] contents = getContents();
		char ch = contents [ i ];
		return ch;
	}

	private char[] copy(char[] source, char[] target, int length) {
		System.arraycopy(source, 0, target, 0, length);
		return target;
	}

	private char[] createContents(int size) {
		return new char [ size ];
	}

	private void ensureCapacity(int length) {
		char[] contents = getContents();
		int index = getIndex();
		int minimumSize = index + length;
		if (minimumSize < contents.length)
			return; // Early return.
		int size = contents.length;
		size += minimumSize - contents.length + 1;
		int growBy = getGrowBy();
		size += growBy;
		contents = growContents(size);
		setContents(contents);
	}

	private char[] getContents() {
		return contents;
	}

	private int getGrowBy() {
		int capacity = getGrowByCapacity();
		int percentage = getGrowPercentage();
		int size = capacity * percentage / 100;
		return size;
	}

	private int getGrowByCapacity() {
		short style = getGrowStyle();
		int value;
		if (style == ICharBuffer.GROW_LINEARLY) {
			value = getInitialCapacity();
		} else if (style == ICharBuffer.GROW_EXPONENTIALLY) {
			char[] contents = getContents();
			value = contents.length;
		} else {
			String styleValue = String.valueOf(style);
			String message = MessageFormatter.format(CharBuffer.UNKNOWN_GROW_STYLE, styleValue);
			throw new RuntimeException(message);
		}
		return value;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#getGrowPercentage()
	 */
	public int getGrowPercentage() {
		return growPercentage;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#getGrowStyle()
	 */
	public short getGrowStyle() {
		return growStyle;
	}

	private int getIndex() {
		return index;
	}

	private int getInitialCapacity() {
		return initialCapacity;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#getValue()
	 */
	public String getValue() {
		char[] contents = getContents();
		int length = getIndex();
		String value = new String(contents, 0, length);
		return value;
	}

	private char[] growContents(int size) {
		char[] source = getContents();
		char[] target = createContents(size);
		int index = getIndex();
		int length = index < source.length ? index : source.length;
		copy(source, target, length);
		setIndex(length);
		return target;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#length()
	 */
	public int length() {
		int length = getIndex();
		return length;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#setChar(int, char)
	 */
	public void setChar(int i, char ch) {
		char[] contents = getContents();
		contents [ i ] = ch;
	}

	private void setContents(char[] contents) {
		this.contents = contents;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#setGrowPercentage(int)
	 */
	public void setGrowPercentage(int growPercentage) {
		Assertion.checkRange(growPercentage, "growPercentage", 1, Integer.MAX_VALUE); //$NON-NLS-1$
		this.growPercentage = growPercentage;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#setGrowStyle(short)
	 */
	public void setGrowStyle(short growStyle) {
		this.growStyle = growStyle;
	}

	private void setIndex(int index) {
		this.index = index;
	}

	private void setInitialCapacity(int initialCapacity) {
		this.initialCapacity = initialCapacity;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#setLength(int)
	 */
	public void setLength(int length) {
		int index = getIndex();
		if (length == index) {
			return;  // Early return.
		} else if (length < index) {
			char[] contents = getContents();
			char ch = 0;
			Arrays.fill(contents, length, index, ch);
		} else {
			ensureCapacity(length);
		}
		setIndex(length);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#toArray()
	 */
	public char[] toArray() {
		char[] source = getContents();
		int length = getIndex();
		char[] target = new char [ length ];
		copy(source, target, length);
		return target;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#toArray(char[])
	 */
	public char[] toArray(char[] target) {
		char[] result;
		char[] source = getContents();
		int length = getIndex();
		if (target == null || target.length < length) {
			result = toArray();
		} else {
			result = copy(source, target, length);
		}
		return result;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return getValue();
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#toSynchronizedCharBuffer()
	 */
	public ICharBuffer toSynchronizedCharBuffer() {
		return new SynchronizedCharBuffer(this);
	}

	private int validateInitialCapacity(int initialCapacity) {
		return initialCapacity > 0 ? initialCapacity : CharBuffer.DEFAULT_INITIAL_CAPACITY;
	}
}
