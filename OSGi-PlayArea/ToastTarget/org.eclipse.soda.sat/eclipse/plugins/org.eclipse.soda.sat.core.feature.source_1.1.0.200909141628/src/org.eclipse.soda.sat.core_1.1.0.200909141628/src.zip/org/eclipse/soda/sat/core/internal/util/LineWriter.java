/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

import org.eclipse.soda.sat.core.framework.interfaces.ILineWriter;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.LogUtility;

/**
 * The <code>LineWriter</code> class is a utility that greatly simplifies
 * writing lines of text to an <code>OutputStream</code>.
 */
public class LineWriter extends Object implements ILineWriter {
	//
	// Static Fields
	//

	private static final int EIGHT_K_BYTES = 8192;
	private static final String UTF8_CHARACTER_ENCODING = "UTF-8"; //$NON-NLS-1$
	private static final String DEFAULT_CHARACTER_ENCODING = System.getProperty("file.encoding", LineWriter.UTF8_CHARACTER_ENCODING); //$NON-NLS-1$

	//
	// Instance Fields
	//

	private BufferedWriter bufferedWriter;

	/**
	 * Constructor
	 *
	 * @param outputStream  The output stream to write to.
	 */
	public LineWriter(OutputStream outputStream) {
		this(outputStream, 8192);  // 8K
	}

	/**
	 * Constructor
	 *
	 * @param outputStream  The output stream to write to.
	 * @param size          The size of the write buffer.
	 */
	public LineWriter(OutputStream outputStream, int size) {
		this(outputStream, LineWriter.DEFAULT_CHARACTER_ENCODING, size);
	}

	//
	// Constructors
	//

	/**
	 * Constructor
	 *
	 * @param outputStream       The output stream to write to.
	 * @param characterEncoding  The character encoding to use.
	 */
	public LineWriter(OutputStream outputStream, String characterEncoding) {
		this(outputStream, characterEncoding, LineWriter.EIGHT_K_BYTES);
	}

	/**
	 * Constructor
	 *
	 * @param outputStream       The output stream to write to.
	 * @param characterEncoding  The character encoding to use.
	 * @param size               The size of the write buffer.
	 */
	public LineWriter(OutputStream outputStream, String characterEncoding, int size) {
		super();
		setBufferWriter(createBufferedWriter(outputStream, characterEncoding, size));
	}

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ILineWriter#close()
	 */
	public void close() throws IOException {
		BufferedWriter bufferedWriter = getBufferedWriter();
		bufferedWriter.close();  // No need to flush. // $codepro.audit.disable closeInFinally
	}

	private BufferedWriter createBufferedWriter(OutputStream outputStream, String encoding, int size) {
		Assertion.checkArgumentIsNotNull(outputStream, "outputStream");  //$NON-NLS-1$
		OutputStreamWriter outputStreamWriter;
		try {
			outputStreamWriter = new OutputStreamWriter(outputStream, encoding);
		} catch (UnsupportedEncodingException exception) {
			String message = exception.getMessage();
			LogUtility.logError(this, message, exception);
			outputStreamWriter = new OutputStreamWriter(outputStream);
		}
		BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter, size);
		return bufferedWriter;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ILineWriter#flush()
	 */
	public void flush() throws IOException {
		BufferedWriter bufferedWriter = getBufferedWriter();
		bufferedWriter.flush();
	}

	/**
	 * Private bufferedWriter getter.
	 *
	 * @return BufferedWriter
	 */
	private BufferedWriter getBufferedWriter() {
		return bufferedWriter;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ILineWriter#newLine()
	 */
	public void newLine() throws IOException {
		BufferedWriter bufferedWriter = getBufferedWriter();
		bufferedWriter.newLine();
	}

	/**
	 * Private bufferedWriter setter.
	 *
	 * @param bufferedWriter  The BufferedWriter.
	 */
	private void setBufferWriter(BufferedWriter bufferedWriter) {
		this.bufferedWriter = bufferedWriter;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ILineWriter#write(java.lang.String)
	 */
	public void write(String line) throws IOException {
		Assertion.checkArgumentIsNotNull(line, "line");  //$NON-NLS-1$
		BufferedWriter bufferedWriter = getBufferedWriter();
		int length = line.length();
		bufferedWriter.write(line, 0, length);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ILineWriter#writeLine(java.lang.String)
	 */
	public void writeLine(String line) throws IOException {
		write(line);
		newLine();
	}
}
