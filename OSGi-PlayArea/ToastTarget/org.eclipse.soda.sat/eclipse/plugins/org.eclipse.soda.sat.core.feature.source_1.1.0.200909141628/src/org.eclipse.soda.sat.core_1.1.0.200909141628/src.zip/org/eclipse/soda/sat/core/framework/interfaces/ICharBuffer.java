/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework.interfaces;

/**
 * The <code>ICharBuffer</code> interface defines the API of an unsynchronized
 * character buffer.
 */
public interface ICharBuffer {
	/**
	 * This grow style causes the buffer to grow linearly in multiples of the
	 * buffer's initial capacity.
	 */
	public static final short GROW_LINEARLY = 0;

	/**
	 * This grow style cause the buffer to grow exponentially in multiples of
	 * the buffer's current capacity.
	 */
	public static final short GROW_EXPONENTIALLY = 1;

	/**
	 * Append a <code>boolean</code> to the buffer.  The value is converted to a
	 * <code>String</code> which is appended to the buffer.
	 *
	 * @param booleanValue  The <code>boolean</code> to append to the buffer.
	 * @return The buffer, never <code>null</code>.
	 */
	public ICharBuffer append(boolean booleanValue);

	/**
	 * Append a single character to the buffer.
	 *
	 * @param charValue  The character to append.
	 * @return The buffer, never <code>null</code>.
	 */
	public ICharBuffer append(char charValue);

	/**
	 * Append characters from an array to the buffer.
	 *
	 * @param array  The source.
	 * @return The buffer, never <code>null</code>.
	 */
	public ICharBuffer append(char[] array);

	/**
	 * Append characters from an array to the buffer.
	 *
	 * @param array  The source.
	 * @param start  The index of the first character.
	 * @param length The number of characters to append.
	 * @return The buffer, never <code>null</code>.
	 */
	public ICharBuffer append(char[] array, int start, int length);

	/**
	 * Append a <code>double</code> to the buffer.  The value is converted to a
	 * <code>String</code> which is appended to the buffer.
	 *
	 * @param doubleValue  The <code>double</code> to append to the buffer.
	 * @return The buffer, never <code>null</code>.
	 */
	public ICharBuffer append(double doubleValue);

	/**
	 * Append a <code>float</code> to the buffer.  The value is converted to a
	 * <code>String</code> which is appended to the buffer.
	 *
	 * @param floatValue  The <code>float</code> to append to the buffer.
	 * @return The buffer, never <code>null</code>.
	 */
	public ICharBuffer append(float floatValue);

	/**
	 * Append an <code>int</code> to the buffer.  The value is converted to a
	 * <code>String</code> which is appended to the buffer.
	 *
	 * @param intValue  The <code>int</code> to append to the buffer.
	 * @return The buffer, never <code>null</code>.
	 */
	public ICharBuffer append(int intValue);

	/**
	 * Append a <code>long</code> to the buffer.  The value is converted to a
	 * <code>String</code> which is appended to the buffer.
	 *
	 * @param longValue  The <code>double</code> to append to the buffer.
	 * @return The buffer, never <code>null</code>.
	 */
	public ICharBuffer append(long longValue);

	/**
	 * Append an <code>Object</code> to the buffer.  The object is converted
	 * to a <code>String</code> by calling <code>toString()</code>, the result
	 * of which is appended to the buffer.
	 *
	 * @param object  The <code>Object</code> to append to the buffer.
	 * @return The buffer, never <code>null</code>.
	 */
	public ICharBuffer append(Object object);

	/**
	 * Append a <code>String</code> to the buffer.
	 *
	 * @param value  The <code>String</code> to append to the buffer.
	 * @return The buffer, never <code>null</code>.
	 */
	public ICharBuffer append(String value);

	/**
	 * Answers the number of characters that can be appended to the buffer
	 * without it growing.
	 *
	 * @return The capacity of the buffer.
	 */
	public int capacity();

	/**
	 * Answers the character in the buffer at the specified index
	 *
	 * @param i  The index.
	 * @return The character at the specified index.
	 */
	public char charAt(int i);

	/**
	 * Get the grow percentage used to calculate how much the buffer will grow
	 * when its capacity is exhausted.
	 *
	 * @return A positive integer.
	 */
	public int getGrowPercentage();

	/**
	 * Get the grow style used to calculate how much the buffer will grow when
	 * its capacity is exhausted. Valid values:
	 * <ul>
	 *   <li>
	 *     <code>ICharBuffer.GROW_LINEARLY</code>
	 *   </li>
	 *   <li>
	 *     <code>ICharBuffer.GROW_EXPONENTIALLY</code>
	 *   </li>
	 * </ul>
	 *
	 * @return The buffer's grow style.
	 */
	public short getGrowStyle();

	/**
	 * Get a <code>String</code> composed of the contents of the buffer.
	 *
	 * @return The contents of the buffer.
	 */
	public String getValue();

	/**
	 * The number of characters in the buffer.
	 *
	 * @return The length of the buffer.
	 */
	public int length();

	/**
	 * Set the character at the specified index.
	 *
	 * @param i   The index.
	 * @param ch  The character.
	 */
	public void setChar(int i, char ch);

	/**
	 * Set the grow percentage used to calculate how much the buffer will grow
	 * when its capacity is exhausted.
	 *
	 * @param growthFactor  A positive integer.
	 */
	public void setGrowPercentage(int growthFactor);

	/**
	 * Set the grow style used to calculate how much the buffer will grow when
	 * its capacity is exhausted. Valid values:
	 * <ul>
	 *   <li>
	 *     <code>ICharBuffer.GROW_LINEARLY</code>
	 *   </li>
	 *   <li>
	 *     <code>ICharBuffer.GROW_EXPONENTIALLY</code>
	 *   </li>
	 * </ul>
	 *
	 * @param growStyle  A grow style.
	 */
	public void setGrowStyle(short growStyle);

	/**
	 * Set the length of the buffer. If the buffer's length is greater than the
	 * specified length, the characters beyond the specified length are deleted.
	 * If the buffer's length is less than the specified length, additional
	 * character are set to <code>(char) 0</code>.
	 *
	 * @param length  The new length of the buffer.
	 */
	public void setLength(int length);

	/**
     * Answers a new <code>char</code> array containing the contents of the
     * buffer.
     *
     * @return A <code>char</code> array containing the contents of the buffer.
     */
	public char[] toArray();

	/**
     * Copies the contents of the buffer into the specified <code>char</code>
     * array. If the array is not big enough and new array is created.
     *
     * @param target  The target array into which the contents of the buffer is
     *                copied.
     * @return A <code>char</code> array containing the contents of the buffer.
     */
	public char[] toArray(char[] target);

	/**
	 * Answers a thread-safe version of the buffer.
	 *
	 * @return A buffer.
	 */
	public ICharBuffer toSynchronizedCharBuffer();
}