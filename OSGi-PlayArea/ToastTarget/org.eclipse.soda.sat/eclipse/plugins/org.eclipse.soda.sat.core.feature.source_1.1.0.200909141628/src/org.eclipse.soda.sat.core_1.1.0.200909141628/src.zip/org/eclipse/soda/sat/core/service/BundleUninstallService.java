/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.service;

import org.osgi.framework.Bundle;

/**
 * The <code>BundleUninstallService</code> interface defines the API for
 * requesting that a <code>Bundle</code> be uninstalled after it has become
 * <code>Bundle.ACTIVE</code>.
 */
public interface BundleUninstallService {
	/**
	 * The OSGi service name for <code>BundleUninstallService</code>.
	 */
	public static final String SERVICE_NAME = BundleUninstallService.class.getName();

	/**
	 * Uninstall the specified bundle once it has transition to the
	 * <code>Bundle.ACTIVE</code> state.
	 *
	 * @param bundle  The bundle to be uninstalled.
	 */
	public void uninstall(Bundle bundle);
}
