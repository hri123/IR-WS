/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.util;

import org.eclipse.soda.sat.core.internal.nls.Messages;

/**
 * The <code>Assertion</code> class provides static method for common assertions.
 */
public final class Assertion extends Object {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String ARGUMENT_MUST_NOT_BE_NULL_KEY = "Assertion.ArgumentMustNotBeNull";  //$NON-NLS-1$
	private static final String ARGUMENT_MUST_BE_IN_RANGE_KEY = "Assertion.ArgumentMustBeInRange";  //$NON-NLS-1$
	private static final String ARGUMENT_1_MUST_BE_LESS_THAN_OR_EQUAL_TO_ARGUMENT_2_KEY = "Assertion.Argument1MustBeLessThanOrEqualToArgument2";  //$NON-NLS-1$
	private static final String ARRAY_MUST_NOT_BE_EMPTY = "Assertion.ArrayMustNotBeEmpty";  //$NON-NLS-1$

	//
	// Static Methods
	//

	/**
	 * Check whether the specified value argument is not <code>null</code>.
	 *
	 * @param value  An <code>Object</code> that must not be <code>null</code>.
	 * @param name   The name of the argument.
	 * @throws IllegalArgumentException when the argument is <code>null</code>.
	 */
	public static void checkArgumentIsNotNull(Object value, String name) throws IllegalArgumentException {
		Assertion.checkIsNotNull(value, Assertion.ARGUMENT_MUST_NOT_BE_NULL_KEY, name);
	}

	/**
	 * Check whether the specified array is not empty.
	 *
	 * @param value  An <code>Object[]</code> that must not be empty.
	 * @param name   The name of the argument.
	 * @throws IllegalArgumentException when the array is empty.
	 */
	public static void checkArrayIsNotEmpty(Object value, String name) throws IllegalArgumentException {
		Object[] array = (Object[]) value;
		if (array.length != 0)
			return;  // Early return.
		String pattern = Assertion.ARRAY_MUST_NOT_BE_EMPTY;
		String message = MessageFormatter.format(pattern, name);
		throw new IllegalArgumentException(message);
	}

	private static void checkIsLessThanOrEqualTo(long value1, String name1, long value2, String name2) throws IllegalArgumentException {
		if (value1 <= value2)
			return;  // Early return
		String pattern = Assertion.ARGUMENT_1_MUST_BE_LESS_THAN_OR_EQUAL_TO_ARGUMENT_2_KEY;
		Object[] values = new Object[] {
			name1,
			new Long(value1),
			name2,
			new Long(value2)
		};
		String message = MessageFormatter.format(pattern, values);
		throw new IllegalArgumentException(message);
	}

	/**
	 * Check whether the specified value is not <code>null</code>.  If the value
	 * is <code>null</code>, display the message associated with the specified
	 * message key.
	 *
	 * @param value       An <code>Object</code> that must not be
	 *                    <code>null</code>.
	 * @param messageKey  The key of a message to display if the value is
	 *                    <code>null</code>.
	 * @throws IllegalArgumentException when the value is <code>null</code>.
	 */
	public static void checkIsNotNull(Object value, String messageKey) throws IllegalArgumentException {
		Assertion.checkIsNotNull(value, messageKey, null);
	}

	/**
	 * Check whether the specified value is not <code>null</code>.  If the value
	 * is <code>null</code>, display the message associated with the specified
	 * message key and message parameter.
	 *
	 * @param value            An <code>Object</code> that must not be
	 *                         <code>null</code>.
	 * @param messageKey       The key of a message to display if the value is
	 *                         <code>null</code>.
	 * @param messageParameter The value to replace <code>{0}</code> place
	 *                         holder in the message.
	 * @throws IllegalArgumentException when the value is <code>null</code>.
	 */
	public static void checkIsNotNull(Object value, String messageKey, Object messageParameter) throws IllegalArgumentException {
		if (value != null)
			return;  // Early return.
		String message = Messages.getString(messageKey);

		if (messageParameter != null) {
			message = MessageFormatter.format(message, messageParameter);
		}

		throw new IllegalArgumentException(message);
	}

	/**
	 * Check whether the specified value is with the specified begin and end
	 * range.
	 *
	 * @param value       An number.
	 * @param name        The name for the number.
	 * @param beginRange  The begin range.
	 * @param endRange    The end range.
	 * @throws IllegalArgumentException when the value is not within the begin
	 * and end range.
	 */
	public static void checkRange(long value, String name, long beginRange, long endRange) throws IllegalArgumentException {
		Assertion.checkIsLessThanOrEqualTo(beginRange, "beginRange", endRange, "endRange");  //$NON-NLS-1$  //$NON-NLS-2$

		if (value >= beginRange && value <= endRange)
			return;  // Early return.

		Object[] values = new Object[] {
			name,
			new Long(value),
			new Long(beginRange),
			new Long(endRange)
		};

		String pattern = Messages.getString(Assertion.ARGUMENT_MUST_BE_IN_RANGE_KEY);
		String message = MessageFormatter.format(pattern, values);
		throw new IllegalArgumentException(message);
	}

	private Assertion() {
		super();
	}
}
