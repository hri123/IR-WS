/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.util;

import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.osgi.framework.Bundle;
import org.osgi.framework.ServiceReference;

/**
 * The <code>BundleUtility</code> class is a utility that simplifies working
 * with <code>Bundle</code> objects.
 * <p>
 * <i>Note:</i> This is a singleton class, accessible only via the static method
 * <code>getInstance()</code>.  For example:
 * <pre>
 * BundleUtility utility = BundleUtility.getInstance();
 * boolean result = utility.isBundleState(bundle, Bundle.INSTALLED);
 * </pre>
 */
public final class BundleUtility extends Object {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String ACTIVE_STATE_KEY = "BundleUtility.ActiveState";  //$NON-NLS-1$
	private static final String INSTALLED_STATE_KEY = "BundleUtility.InstalledState";  //$NON-NLS-1$
	private static final String RESOLVED_STATE_KEY = "BundleUtility.ResolvedState";  //$NON-NLS-1$
	private static final String STARTING_STATE_KEY = "BundleUtility.StartingState";  //$NON-NLS-1$
	private static final String STOPPING_STATE_KEY = "BundleUtility.StoppingState";  //$NON-NLS-1$
	private static final String UNINSTALLED_STATE_KEY = "BundleUtility.UninstalledState";  //$NON-NLS-1$
	private static final String UNKNOWN_STATE_KEY = "Common.Unknown";  //$NON-NLS-1$

	// Singleton
	private static final BundleUtility INSTANCE = new BundleUtility();

	//
	// Static Methods
	//

	/**
	 * Public getter for the <code>BundleUtility</code> singleton instance.
	 *
	 * @return <code>BundleUtility</code>
	 */
	public static BundleUtility getInstance() {
		return BundleUtility.INSTANCE;
	}

	/**
	 * Constructor.
	 */
	private BundleUtility() {
		super();
	}

	//
	// Instance Methods
	//

	/**
	 * Query a <code>Bundle</code> for a <code>ServiceReference</code> to a
	 * named service.  Answers the <code>ServiceReference</code> or
	 * <code>null</code> if no match was found.
	 *
	 * @param bundle  The bundle to be queried.
	 * @param name    The fully qualified type name of the service.
	 * @return <code>ServiceReference</code> or <code>null</code>.
	 */
	public ServiceReference getServiceInstanceOf(Bundle bundle, String name) {
		Assertion.checkArgumentIsNotNull(bundle, "bundle");  //$NON-NLS-1$
		ServiceReference[] services = bundle.getRegisteredServices();
		if (services == null)
			return null;  // Early return.

		int size = services.length;
		boolean match = false;
		int index = 0;
		ServiceReference service = null;
		ServiceReferenceUtility utility = ServiceReferenceUtility.getInstance();

		while (match == false && index < size) {
			service = services [ index ];
			match = utility.isServiceInstanceOf(service, name);
			index++;
		}

		return match == true ? service : null;
	}

	/**
	 * Searches an array of <code>ServiceReference</code> objects for a specific
	 * instance.
	 *
	 * @param serviceReference  The <code>ServiceReference</code> to be searched
	 *                          for.
	 * @param services          An array of <code>ServiceRefence</code> objects
	 *                          to be searched.
	 * @return If the <code>ServiceReference</code> is included in the array
	 * return true, otherwise <code>false</code>.
	 */
	private boolean includesServiceReference(ServiceReference[] services, ServiceReference serviceReference) {
		boolean match = false;
		if (services == null)
			return match;  // Early return.

		int size = services.length;
		int index = 0;

		while (match == false && index < size) {
			Object service = services [ index ];
			match = service.equals(serviceReference);
			index++;
		}

		return match;
	}

	/**
	 * Tests whether a <code>Bundle</code> is in a specific state.  Valid bundle
	 * states are defined by the <code>Bundle</code> class:
	 * <code>
	 *   <ul>
	 *     <li>Bundle.UNINSTALLED</li>
	 *     <li>Bundle.INSTALLED</li>
	 *     <li>Bundle.RESOLVED</li>
	 *     <li>Bundle.STARTING</li>
	 *     <li>Bundle.STOPPING</li>
	 *     <li>Bundle.ACTIVE</li>
	 *   </ul>
	 * </code>
	 * <p>
	 * For example:
	 * <pre>
	 * boolean active = BundleUntility.isBundle(bundle, Bundle.ACTIVE);
	 * </pre>
	 *
	 * @param bundle  The bundle who's state is being tested.
	 * @param state   The state being tested for.
	 * @return <code>boolean</code>
	 */
	public boolean isBundleState(Bundle bundle, int state) {
		int currentState = bundle.getState();
		boolean result = (currentState & state) != 0;
		return result;
	}

	/**
	 * Answers <code>true</code> if the <code>Bundle</code> has registered the
	 * <code>ServiceReference</code>, otherwise <code>false</code>.
	 *
	 * @param bundle            The <code>Bundle</code> being queried.
	 * @param serviceReference  The <code>ServiceReference</code> being searched
	 *                          for.
	 * @return <code>boolean</code>
	 */
	public boolean isRegisteredService(Bundle bundle, ServiceReference serviceReference) {
		ServiceReference[] services = bundle.getRegisteredServices();
		boolean match = includesServiceReference(services, serviceReference);
		return match;
	}

	/**
	 * Answers <code>true</code> if the <code>Bundle</code> has registered a
	 * service with the given name, otherwise <code>false</code>.
	 *
	 * @param bundle  The <code>Bundle</code> being queried.
	 * @param name    The fully qualified type name of the service.
	 * @return <code>boolean</code>
	 */
	public boolean isRegisteredService(Bundle bundle, String name) {
		ServiceReference service = getServiceInstanceOf(bundle, name);
		boolean result = service != null;
		return result;
	}

	/**
	 * Answers true if the <code>Bundle</code> is using the
	 * <code>ServiceReference</code>, otherwise <code>false</code>.
	 *
	 * @param bundle            The <code>Bundle</code> being queried.
	 * @param serviceReference  The <code>ServiceReference</code> being searched
	 *                          for.
	 * @return <code>boolean</code>
	 */
	public boolean isServiceInUse(Bundle bundle, ServiceReference serviceReference) {
		ServiceReference[] services = bundle.getServicesInUse();
		boolean match = includesServiceReference(services, serviceReference);
		return match;
	}

	/**
	 * Get a human-readable string that describes the state of a given bundle.
	 *
	 * @param bundle  A <code>Bundle</code>.
	 * @return The <code>String</code> describing the state of the
	 *         <code>Bundle</code>.
	 */
	public String toBundleStateString(Bundle bundle) {
		int state = bundle.getState();
		String key;

		switch (state) {
			case Bundle.UNINSTALLED:
				key = BundleUtility.UNINSTALLED_STATE_KEY;
				break;
			case Bundle.INSTALLED:
				key = BundleUtility.INSTALLED_STATE_KEY;
				break;
			case Bundle.RESOLVED:
				key = BundleUtility.RESOLVED_STATE_KEY;
				break;
			case Bundle.STARTING:
				key = BundleUtility.STARTING_STATE_KEY;
				break;
			case Bundle.STOPPING:
				key = BundleUtility.STOPPING_STATE_KEY;
				break;
			case Bundle.ACTIVE:
				key = BundleUtility.ACTIVE_STATE_KEY;
				break;
			default:
				key = BundleUtility.UNKNOWN_STATE_KEY;
				break;
		}

		String value = Messages.getString(key);
		return value;
	}
}