/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle.cm;

import java.util.Collection;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.eclipse.soda.sat.core.framework.BundleActivationManagerOwnerAdapter;
import org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager;
import org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner;
import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryActivationManager;
import org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryAdvisor;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.CollectionUtility;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.service.cm.ConfigurationException;

/**
 * ManagedServiceFactoryActivationManager.java
 */
public class ManagedServiceFactoryActivationManager extends Object implements IManagedServiceFactoryActivationManager {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String FAILED_TO_CREATE_IMPORTED_SERVICE_FILTER_FOR_PID_KEY = "ManagedServiceFactoryActivationManager.FailedToCreateImportedServiceFilterForPid";  //$NON-NLS-1$
	private static final String FAILED_TO_CREATE_OBJECT_FOR_PID_KEY = "ManagedServiceFactoryActivationManager.FailedToCreateObjectForPid";  //$NON-NLS-1$
	private static final String FAILED_TO_DELETE_CONFIGURATION_FOR_PID_KEY = "ManagedServiceFactoryActivationManager.FailedToDeleteConfigurationForPid";  //$NON-NLS-1$
	private static final String FAILED_TO_DESTROY_OBJECT_FOR_PID_KEY = "ManagedServiceFactoryActivationManager.FailedToDestroyObjectForPid";  //$NON-NLS-1$
	private static final String FAILED_TO_HANDLE_ACQUIRED_OPTIONAL_IMPORTED_SERVICE_FOR_PID_KEY = "ManagedServiceFactoryActivationManager.FailedToHandleAcquiredOptionalImportedServiceServiceForPid";  //$NON-NLS-1$
	private static final String FAILED_TO_HANDLE_RELEASED_OPTIONAL_IMPORTED_SERVICE_FOR_PID_KEY = "ManagedServiceFactoryActivationManager.FailedToHandleReleasedOptionalImportedServiceServiceForPid";  //$NON-NLS-1$
	private static final String FAILED_TO_START_BUNDLE_ACTIVATION_MANAGER_KEY = "ManagedServiceFactoryActivationManager.FailedToStartBundleActivationManager";  //$NON-NLS-1$
	private static final String FAILED_TO_STOP_BUNDLE_ACTIVATION_MANAGER_KEY = "ManagedServiceFactoryActivationManager.ManagedServiceFactoryActivationManager.FailedToStopBundleActivationManager";  //$NON-NLS-1$
	private static final String FAILED_TO_UPDATE_OBJECT_FOR_PID_KEY = "ManagedServiceFactoryActivationManager.FailedToUpdateObjectForPid";  //$NON-NLS-1$

	// Misc
	private static final String LINE_SEPARATOR = System.getProperty("line.separator");  //$NON-NLS-1$

	//
	// Instance Fields
	//

	private IManagedServiceFactoryAdvisor advisor;
	private BundleContext bundleContext;
	private Map/*<String, ConfigurationData>*/ configurationDataMap;
	private String name;

	// Locks
	private final Object lock = new Object();

	//
	// Constructors
	//

	/**
	 * Public constructor.
	 *
	 * @param name  The name of the <code>ManagedServiceFactory</code>.
	 * @param advisor  The advisor for the <code>ManagedServiceFactory</code>.
	 */
	public ManagedServiceFactoryActivationManager(String name, IManagedServiceFactoryAdvisor advisor) {
		this(name, advisor, 5);
	}

	/**
	 * Public constructor.
	 *
	 * @param name                       The name of the
	 *                                   <code>ManagedServiceFactory</code>.
	 * @param advisor                    The advisor for the
	 *                                   <code>ManagedServiceFactory</code>.
	 * @param numberOfConfigurationHint  A hint to the number of configurations
	 *                                   that will be created for the
	 *                                   <code>ManagedServiceFactory</code>.
	 */
	public ManagedServiceFactoryActivationManager(String name, IManagedServiceFactoryAdvisor advisor, int numberOfConfigurationHint) {
		super();
		setName(name);
		setAdvisor(advisor);
		setConfigurationDataMap(createConfigurationDataMap(numberOfConfigurationHint));
	}

	//
	// Instance Methods
	//

	private ConfigurationData addConfigurationData(String pid, Dictionary properties) {
		Map/*<String, ConfigurationData>*/ map = getConfigurationDataMap();
		ConfigurationData data;

		synchronized (map) {
			data = new ConfigurationData(properties);
			map.put(pid, data);
		}

		return data;
	}

	/**
	 * Create the object for the specified PID.
	 *
	 * @param pid  The persistent ID for the configuration.
	 */
	private void create(String pid) {
		IManagedServiceFactoryAdvisor advisor = getAdvisor();
		ConfigurationData data = getConfigurationData(pid);
		Dictionary properties = data.getProperties();
		IBundleActivationManager manager = data.getBundleActivationManager();

		try {
			Object object = advisor.create(pid, properties, manager);
			data.setObject(object);
		} catch (Throwable throwable) {
			logError(pid, throwable, ManagedServiceFactoryActivationManager.FAILED_TO_CREATE_OBJECT_FOR_PID_KEY);
		}
	}

	/**
	 * Create an <code>IBundleActivationManagerOwner</code> for the specified
	 * PID.
	 *
	 * @param pid  A persistent ID for a configuration.
	 * @return The owner of an <code>IBundleActivationManager</code>.
	 */
	private IBundleActivationManagerOwner createBundleActivationManagerOwner(final String pid) {
		return new BundleActivationManagerOwnerAdapter() {
			public void activate() {
				ManagedServiceFactoryActivationManager.this.create(pid);
			}

			public void deactivate() {
				ManagedServiceFactoryActivationManager.this.destroy(pid);
			}

			public String[] getImportedServiceNames() {
				return ManagedServiceFactoryActivationManager.this.getImportedServiceNames(pid);
			}

			public String[] getOptionalImportedServiceNames() {
				return ManagedServiceFactoryActivationManager.this.getOptionalImportedServiceNames(pid);
			}

			public void handleAcquiredOptionalImportedService(String serviceName, Object service) {
				ManagedServiceFactoryActivationManager.this.handleAcquiredOptionalImportedService(pid, serviceName, service);
			}

			public void handleReleasedOptionalImportedService(String serviceName, Object service) {
				ManagedServiceFactoryActivationManager.this.handleReleasedOptionalImportedService(pid, serviceName, service);
			}

			public void start() {
				ManagedServiceFactoryActivationManager.this.createImportedServiceFilters(pid);
			}
		};
	}

	private Map/*<String, ConfigurationData>*/ createConfigurationDataMap(int numberOfConfigurationHint) {
		int initialCapacity = estimateHashedCollectionSize(numberOfConfigurationHint);
		Map/*<String, ConfigurationData>*/ map = new HashMap/*<String, ConfigurationData>*/(initialCapacity);
		return map;
	}

	/**
	 * Create the imported service filters for the specified PID.
	 *
	 * @param pid  The persistent ID for a configuration.
	 */
	private Object createImportedServiceFilters(String pid) {
		Object object = null;
		IManagedServiceFactoryAdvisor advisor = getAdvisor();
		ConfigurationData data = getConfigurationData(pid);
		Dictionary oldProperties = data.getOldProperties();
		Dictionary properties = data.getProperties();
		IBundleActivationManager manager = data.getBundleActivationManager();

		try {
			advisor.createImportedServiceFilters(pid, oldProperties, properties, manager);
			object = data.getObject();
		} catch (Throwable throwable) {
			logError(pid, throwable, ManagedServiceFactoryActivationManager.FAILED_TO_CREATE_IMPORTED_SERVICE_FILTER_FOR_PID_KEY);
		}

		return object;
	}

	/**
	 * @see org.osgi.service.cm.ManagedServiceFactory#deleted(java.lang.String)
	 */
	public void deleted(String pid) {
		try {
			Object lock = getLock();

			synchronized (lock) {
				stopBundleActivationManager(pid);
				removeFactoryConfigurationData(pid);
			}
		} catch (Throwable throwable) {
			logError(pid, throwable, ManagedServiceFactoryActivationManager.FAILED_TO_DELETE_CONFIGURATION_FOR_PID_KEY);
		}
	}

	/**
	 * Destroy the object for the specified PID.
	 *
	 * @param pid  The persistent ID for a configuration.
	 */
	private void destroy(String pid) {
		IManagedServiceFactoryAdvisor advisor = getAdvisor();
		ConfigurationData data = getConfigurationData(pid);
		Object object = data.getObject();
		Dictionary properties = data.getProperties();
		IBundleActivationManager manager = data.getBundleActivationManager();

		try {
			advisor.destroy(pid, object, properties, manager);
		} catch (Throwable throwable) {
			logError(pid, throwable, ManagedServiceFactoryActivationManager.FAILED_TO_DESTROY_OBJECT_FOR_PID_KEY);
		} finally {
			data.setObject(null);
		}
	}

	/**
	 * Compare the value of two Dictionary objects.
	 *
	 * @param dictionary1  A Dictionary.
	 * @param dictionary2  A Dictionary.
	 * @return True if the two Dictionary objects are equal, otherwise false.
	 */
	private boolean equal(Dictionary dictionary1, Dictionary dictionary2) {
		// Identical objects are always equal.
		if (dictionary1 == dictionary2) // $codepro.audit.disable useEquals
			return true;  // Early return.

		// If one of the parameters is null then they cannot be equal.
		if (dictionary1 == null || dictionary2 == null)
			return false;  // Early return.

		// If one Dictionary is larger than the other then they cannot be equal.
		int size1 = dictionary1.size();
		int size2 = dictionary2.size();
		boolean equal = size1 == size2;
		if (equal == false)
			return false;  // Early return.

		// Compare the key/value pairs...
		Enumeration keys = dictionary1.keys();

		while (equal == true && keys.hasMoreElements() == true) {
			Object key = keys.nextElement();
			Object value1 = dictionary1.get(key);
			Object value2 = dictionary2.get(key);
			equal = value1.equals(value2);
		}

		return equal;
	}

	private int estimateHashedCollectionSize(int capacity) {
		CollectionUtility utility = CollectionUtility.getInstance();
		int size = utility.estimateHashedCollectionSize(capacity);
		return size;
	}

	/**
	 * Private advisor getter.
	 *
	 * @return The advisor for the <code>ManagedServiceFactoryActivationManager</code>.
	 */
	private IManagedServiceFactoryAdvisor getAdvisor() {
		return advisor;
	}

	private Map/*<String, Object>*/ getAllObjects() {
		Map/*<String, ConfigurationData>*/ map = getConfigurationDataMap();
		int size = map.size();
		int capacity = estimateHashedCollectionSize(size);
		Map/*<String, Object>*/ result = new HashMap/*<String, Object>*/(capacity);

		synchronized (map) {
			Iterator/*<String>*/ iterator = getAllPids();

			while (iterator.hasNext() == true) {
				String pid = (String) iterator.next();
				ConfigurationData data = (ConfigurationData) map.get(pid);
				Object object = data.getObject();
				if (object == null)
					continue;  // Skip to next iteration.
				result.put(pid, object);
			}
		}

		return result;
	}

	private Iterator/*<String>*/ getAllPids() {
		Map/*<String, ConfigurationData>*/ map = getConfigurationDataMap();
		Set/*<String>*/ keys = map.keySet();
		Iterator/*<String>*/ iterator = keys.iterator();
		return iterator;
	}

	private Map/*<String, Dictionary<String, String>>*/ getAllProperties() {
		Map/*<String, ConfigurationData>*/ map = getConfigurationDataMap();
		int size = map.size();
		int capacity = estimateHashedCollectionSize(size);
		Map/*<String, Dictionary<String, String>>*/ result = new HashMap/*<String, Dictionary<String, String>>*/(capacity);

		synchronized (map) {
			Iterator/*<String>*/ iterator = getAllPids();

			while (iterator.hasNext() == true) {
				String pid = (String) iterator.next();
				ConfigurationData data = (ConfigurationData) map.get(pid);
				Dictionary properties = data.getProperties();
				result.put(pid, properties);
			}
		}

		return result;
	}

	private Bundle getBundle() {
		BundleContext bundleContext = getBundleContext();
		Bundle bundle = null;
		try {
			bundle = bundleContext.getBundle();
		} catch (IllegalStateException exception) {
			// The BundleContext is disposed.
		}
		return bundle;
	}

	/**
	 * The <code>BundleContext</code> for the owning <code>Bundle</code>.
	 *
	 * @return A <code>BundleContext</code>.
	 */
	private BundleContext getBundleContext() {
		return bundleContext;
	}

	/**
	 * Get the <code>Bundle-SymbolicName</code> of the owning
	 * <code>Bundle</code>.
	 *
	 * @return The <code>Bundle-SymbolicName</code>.
	 */
	private String getBundleSymbolicName() {
		String symbolicName = null;
		Bundle bundle = getBundle();
		if (bundle != null) {
			symbolicName = bundle.getSymbolicName();
		}
		return symbolicName;
	}

	/**
	 * Get the <code>ConfigurationData</code> for the specified
	 * persistent ID.  This method will lazily create the
	 * <code>ConfigurationData</code> if it does not exist for a
	 * persistent identifier.
	 *
	 * @param pid  The persistent identifier.
	 * @return A <code>ConfigurationData</code>.
	 */
	private ConfigurationData getConfigurationData(String pid) {
		Map/*<String, ConfigurationData>*/ map = getConfigurationDataMap();
		ConfigurationData data;

		synchronized (map) {
			data = (ConfigurationData) map.get(pid);
		}

		return data;
	}

	/**
	 * Private configurationDataMap getter.
	 *
	 * @return A <code>Map</code>.
	 */
	private Map/*<String, ConfigurationData>*/ getConfigurationDataMap() {
		return configurationDataMap;
	}

	/**
	 * Get the names of the imported services.
	 *
	 * @return An array of the imported service names.
	 */
	private String[] getImportedServiceNames(String pid) {
		IManagedServiceFactoryAdvisor advisor = getAdvisor();
		ConfigurationData data = getConfigurationData(pid);
		Dictionary oldProperties = data.getOldProperties();
		Dictionary properties = data.getProperties();
		IBundleActivationManager manager = data.getBundleActivationManager();
		String[] names = advisor.getImportedServiceNames(pid, oldProperties, properties, manager);
		return names;
	}

	/**
	 * Private lock getter.
	 *
	 * @return The lock used during start, stop and configuration event handling.
	 */
	private Object getLock() {
		return lock;
	}

	/**
	 * @see org.osgi.service.cm.ManagedServiceFactory#getName()
	 */
	public String getName() {
		return name;
	}

	/**
	 * Get the names of the optional imported services.
	 *
	 * @return An array of the optional imported service names.
	 */
	private String[] getOptionalImportedServiceNames(String pid) {
		IManagedServiceFactoryAdvisor advisor = getAdvisor();
		ConfigurationData data = getConfigurationData(pid);
		Dictionary oldProperties = data.getOldProperties();
		Dictionary properties = data.getProperties();
		IBundleActivationManager manager = data.getBundleActivationManager();
		String[] names = advisor.getOptionalImportedServiceNames(pid, oldProperties, properties, manager);
		return names;
	}

	private void handleAcquiredOptionalImportedService(String pid, String importedServiceName, Object importedService) {
		ConfigurationData data = getConfigurationData(pid);
		Object object = data.getObject();
		if (object == null)
			return;  // Early return.

		IManagedServiceFactoryAdvisor advisor = getAdvisor();
		IBundleActivationManager manager = data.getBundleActivationManager();

		try {
			advisor.handleAcquiredOptionalImportedService(pid, object, importedServiceName, importedService, manager);
		} catch (Throwable throwable) {
			String pattern = Messages.getString(ManagedServiceFactoryActivationManager.FAILED_TO_HANDLE_ACQUIRED_OPTIONAL_IMPORTED_SERVICE_FOR_PID_KEY);
			Object[] values = new Object[] {
				importedService, pid
			};
			String message = MessageFormatter.format(pattern, values);
			logError(message, throwable);
		}
	}

	private void handleReleasedOptionalImportedService(String pid, String importedServiceName, Object importedService) {
		ConfigurationData data = getConfigurationData(pid);
		Object object = data.getObject();
		if (object == null)
			return;  // Early return.

		IManagedServiceFactoryAdvisor advisor = getAdvisor();
		IBundleActivationManager manager = data.getBundleActivationManager();

		try {
			advisor.handleReleasedOptionalImportedService(pid, object, importedServiceName, importedService, manager);
		} catch (Throwable throwable) {
			String pattern = Messages.getString(ManagedServiceFactoryActivationManager.FAILED_TO_HANDLE_RELEASED_OPTIONAL_IMPORTED_SERVICE_FOR_PID_KEY);
			Object[] values = new Object[] {
				importedService, pid
			};
			String message = MessageFormatter.format(pattern, values);
			logError(message, throwable);
		}
	}

	/**
	 * Answers whether the <code>ManagedServiceFactoryActivationManager</code>
	 * is started or not.
	 *
	 * @return True when started, otherwise false.
	 */
	private boolean isStarted() {
		BundleContext bundleContext = getBundleContext();
		boolean started = bundleContext != null;
		return started;
	}

	private void logError(String message, Throwable throwable) {
		LogUtility.logError(this, message, throwable);
	}

	private void logError(String pid, Throwable throwable, String key) {
		String pattern = Messages.getString(key);
		String message = MessageFormatter.format(pattern, pid);
		logError(message, throwable);
	}

	private void printConfigurationOn(ICharBuffer buffer, String pid, Object object, Dictionary properties) {
		final char tab = '\t';
		Enumeration enumeration = properties.keys();

		buffer.append(tab);
		buffer.append("Persistent ID: ");  //$NON-NLS-1$
		buffer.append(pid);
		buffer.append(ManagedServiceFactoryActivationManager.LINE_SEPARATOR);

		buffer.append(tab);
		buffer.append(tab);
		buffer.append("Object: ");  //$NON-NLS-1$
		buffer.append(object);
		buffer.append(ManagedServiceFactoryActivationManager.LINE_SEPARATOR);

		buffer.append(tab);
		buffer.append(tab);
		buffer.append("Properties:");  //$NON-NLS-1$
		buffer.append(ManagedServiceFactoryActivationManager.LINE_SEPARATOR);

		while (enumeration.hasMoreElements() == true) {
			Object key = enumeration.nextElement();
			Object value = properties.get(key);
			buffer.append(tab);
			buffer.append(tab);
			buffer.append(tab);
			buffer.append("Key=");  //$NON-NLS-1$
			buffer.append(key);
			buffer.append(", Value=");  //$NON-NLS-1$
			buffer.append(value);
			buffer.append(ManagedServiceFactoryActivationManager.LINE_SEPARATOR);
		}

		buffer.append(ManagedServiceFactoryActivationManager.LINE_SEPARATOR);
	}

	/**
	 * Print a description of the configurations on the specified buffer. This
	 * API is provided for debug purposes.
	 *
	 * @param buffer  The buffer on which to print the factory configurations.
	 */
	private void printConfigurationsOn(ICharBuffer buffer) {
		Map/*<String, ConfigurationData>*/ map = getConfigurationDataMap();

		synchronized (map) {
			Iterator/*<String>*/ pids = getAllPids();
			Map/*<String, Object>*/ objects = getAllObjects();
			Map/*<String, Dictionary<String, String>>*/ props = getAllProperties();

			while (pids.hasNext() == true) {
				String pid = (String) pids.next();
				Object object = objects.get(pid);
				Dictionary properties = (Dictionary) props.get(pid);
				printConfigurationOn(buffer, pid, object, properties);
			}
		}
	}

	private void printOn(ICharBuffer buffer) {
		String value = super.toString();
		buffer.append(value);

		String bundleSymbolicName = getBundleSymbolicName();
		buffer.append(", bundleSymbolicName=");  //$NON-NLS-1$
		buffer.append(bundleSymbolicName);

		String name = getName();
		buffer.append(", name=");  //$NON-NLS-1$
		buffer.append(name);

		IManagedServiceFactoryAdvisor advisor = getAdvisor();
		buffer.append(", advisor=");  //$NON-NLS-1$
		buffer.append(advisor);

		buffer.append(ManagedServiceFactoryActivationManager.LINE_SEPARATOR);
		printConfigurationsOn(buffer);
	}

	private void removeFactoryConfigurationData(String pid) {
		Map/*<String, ConfigurationData>*/ map = getConfigurationDataMap();

		synchronized (map) {
			map.remove(pid);
		}
	}

	/**
	 * Private advisor setter.
	 *
	 * @param advisor  An <code>IManagedServiceFactoryAdvisor</code>
	 */
	private void setAdvisor(IManagedServiceFactoryAdvisor advisor) {
		Assertion.checkArgumentIsNotNull(advisor, "advisor");  //$NON-NLS-1$
		this.advisor = advisor;
	}

	/**
	 * Private bundleContext setter.
	 *
	 * @param bundleContext  The <code>BundleContext</code> for the
	 *                 <code>ManagedServiceFactory</code>.
	 */
	private void setBundleContext(BundleContext bundleContext) {
		this.bundleContext = bundleContext;
	}

	/**
	 * Private configurationDataMap setter.
	 *
	 * @param configurationDataMap  A <code>Map</code>
	 */
	private void setConfigurationDataMap(Map/*<String, ConfigurationData>*/ configurationDataMap) {
		this.configurationDataMap = configurationDataMap;
	}

	/**
	 * Private name setter.
	 *
	 * @param name The name of the ManagedServiceFactory.
	 */
	private void setName(String name) {
		Assertion.checkArgumentIsNotNull(name, "name");  //$NON-NLS-1$
		this.name = name;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryActivationManager#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext bundleContext) {
		Assertion.checkArgumentIsNotNull(bundleContext, "bundleContext");  //$NON-NLS-1$
		Object lock = getLock();

		synchronized (lock) {
			boolean started = isStarted();
			if (started == true)
				return;  // Early return.
			setBundleContext(bundleContext);
		}
	}

	/**
	 * Start the <code>IBundleActivationManager</code> for the specified
	 * persistent identifier.
	 *
	 * @param pid  A persistent identifier.
	 */
	private void startBundleActivationManager(String pid) {
		ConfigurationData data = getConfigurationData(pid);
		IBundleActivationManager manager = data.getBundleActivationManager();
		BundleContext bundleContext = getBundleContext();
		IBundleActivationManagerOwner owner = createBundleActivationManagerOwner(pid);

		try {
			manager.start(bundleContext, owner);
		} catch (Exception exception) {
			logError(pid, exception, ManagedServiceFactoryActivationManager.FAILED_TO_START_BUNDLE_ACTIVATION_MANAGER_KEY);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryActivationManager#stop()
	 */
	public void stop() {
		Object lock = getLock();

		synchronized (lock) {
			boolean started = isStarted();
			if (started == false)
				return;  // Early return.
			stopBundleActivationManagers();
			setBundleContext(null);
		}
	}

	/**
	 * Stop the <code>IBundleActivationManager</code> for the specified
	 * persistent identifier.
	 *
	 * @param pid  A persistent identifier.
	 */
	private void stopBundleActivationManager(String pid) {
		ConfigurationData data = getConfigurationData(pid);
		if (data == null)
			return;  // Early return.

		IBundleActivationManager manager = data.getBundleActivationManager();

		try {
			manager.stop();
		} catch (Exception exception) {
			logError(pid, exception, ManagedServiceFactoryActivationManager.FAILED_TO_STOP_BUNDLE_ACTIVATION_MANAGER_KEY);
		}
	}

	/**
	 * Stop all the <code>IBundleActivationManager</code> objects.
	 */
	private void stopBundleActivationManagers() {
		HashMap/*<String, ConfigurationData>*/ map = (HashMap/*<String, ConfigurationData>*/) getConfigurationDataMap();
		Map/*<String, ConfigurationData>*/ clone = (Map/*<String, ConfigurationData>*/) map.clone();
		Collection/*<String>*/ keys = clone.keySet();
		Iterator/*<String>*/ iterator = keys.iterator();

		while (iterator.hasNext() == true) {
			String pid = (String) iterator.next();
			stopBundleActivationManager(pid);
			removeFactoryConfigurationData(pid);
		}
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public final String toString() {
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(350);
		printOn(buffer);
		String result = buffer.toString();
		return result;
	}

	/**
	 * Update the object described by the specified data.
	 */
	private void update(String pid, ConfigurationData data) {
		IManagedServiceFactoryAdvisor advisor = getAdvisor();
		Object object = data.getObject();
		Dictionary oldProperties = data.getOldProperties();
		Dictionary properties = data.getProperties();
		IBundleActivationManager manager = data.getBundleActivationManager();
		Object updatedObject = advisor.update(pid, object, oldProperties, properties, manager);
		data.setObject(updatedObject);
	}

	private void update(String pid, Dictionary properties, ConfigurationData data) {
		// Compare current and the new properties.  Ignore update if
		// the properties have not changed.
		Dictionary currentProperties = data.getProperties();
		boolean match = equal(currentProperties, properties);
		if (match == true)
			return;  // Early return.

		// Store the changed properties.
		data.setProperties(properties);

		// Cache the current object.
		Object object = data.getObject();

		// Recreate and apply the imported service filters.  New imported
		// service filters might cause the object to be destroyed and recreated.
		Object newObject = createImportedServiceFilters(pid);

		// Update the object only if it was not recreated as a result of
		// creating new imported service filters.
		boolean update = object != null && object == newObject; // $codepro.audit.disable useEquals
		if (update == false)
			return;  // Early return.

		update(pid, data);
	}

	/**
	 * @see org.osgi.service.cm.ManagedServiceFactory#updated(java.lang.String, java.util.Dictionary)
	 */
	public void updated(String pid, Dictionary properties) throws ConfigurationException {
		try {
			Object lock = getLock();

			synchronized (lock) {
				boolean started = isStarted();
				if (started == false)
					return;  // Early return.

				validateConfiguration(pid, properties);
				ConfigurationData data = getConfigurationData(pid);

				if (data == null) {
					addConfigurationData(pid, properties);
					startBundleActivationManager(pid);
				} else {
					update(pid, properties, data);
				}
			}
		} catch (Throwable throwable) {
			logError(pid, throwable, ManagedServiceFactoryActivationManager.FAILED_TO_UPDATE_OBJECT_FOR_PID_KEY);
		}
	}

	/**
	 * Validate the configuration's properties.  If the properties are found to
	 * be invalid a <code>ConfigurationException</code> is thrown.
	 *
	 * @param pid         A persistent identifier.
	 * @param properties  The configuration properties.
	 * @throws ConfigurationException
	 */
	private void validateConfiguration(String pid, Dictionary properties) throws ConfigurationException {
		IManagedServiceFactoryAdvisor advisor = getAdvisor();
		advisor.validateConfiguration(pid, properties);
	}
}
