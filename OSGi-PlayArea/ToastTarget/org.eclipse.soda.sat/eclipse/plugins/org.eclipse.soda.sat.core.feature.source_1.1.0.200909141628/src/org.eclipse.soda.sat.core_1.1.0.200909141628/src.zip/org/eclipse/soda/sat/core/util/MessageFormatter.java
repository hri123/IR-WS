/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.util;

import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.internal.nls.Messages;

/**
 * The <code>MessageFormatter</code> class provides a ways for building
 * an internationalized <code>String</code> based on a message pattern.  The
 * message pattern contains variable such as <code>{0}</code>, <code>{1}</code>,
 * <code>{2}</code>, etc, that are populated at runtime.
 * <p>
 * For example, a message pattern such as <code>"The rain in {0} falls mainly on
 * the {1}."</code> could be formatted as follows:
 * <code>
 * <pre>
 * String pattern = "The rain in {0} falls mainly on the {1}.";
 * Object[] values = Object[] {
 *     "Spain", "plain"
 * };
 * String message = MessageFormatter.format(pattern, values);
 * System.out.println(message);
 * </pre>
 * </code>
 * The <code>message</code> will be initialized to <code>"The rain in Spain
 * falls mainly on the plain."</code>.
 */
public class MessageFormatter extends Object {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String PLACEHOLDER_CANNOT_BE_FOUND_KEY = "MessageFormatter.PlaceholderCannotBeFound";  //$NON-NLS-1$

	//
	// Static Methods
	//

	/**
	 * Create a formatted string using the specified pattern and object.  The
	 * pattern typically contains the place-holder <code>{0}</code> that will be
	 * replaced with a <code>String</code> representation of the specified
	 * object.  The place-holder may appear in the pattern any number of times.
	 * The object is converted to a <code>String</code> using its
	 * <code>toString()</code> method.  This is a convenience  method
	 * that simply calls <code>format(String,Object[])</code>.
	 *
	 * @param pattern  A pattern containing the place-holder <code>{0}</code>.
	 * @param value    The value to be inserted at the place-holder.
	 * @return The formatted <code>String</code>.
	 */
	public static String format(String pattern, Object value) {
		Object[] values = new Object[] {
			value
		};
		String message = MessageFormatter.format(pattern, values);
		return message;
	}
	/**
	 * Create a formatted string using the specified pattern and an array of
	 * objects.  The pattern typically contains the place-holders such as
	 * <code>{0}</code>, <code>{1}</code>, <code>{2}</code>, etc, that will be
	 * replaced with a <code>String</code> representation of the objects at the
	 * corresponding index in the specified object array. The place-holders may
	 * appear in the pattern any number of times.  The objects are converted to
	 * a <code>String</code> using its <code>toString()</code> method.
	 *
	 * @param pattern  A pattern containing place-holders.
	 * @param values   The objects to be inserted at the place-holders.
	 * @return The formatted <code>String</code>.
	 */
	public static String format(String pattern, Object[] values) {
		if (pattern == null)
			throw new IllegalArgumentException(); // $codepro.audit.disable exceptionUsage.exceptionCreation
		if (values == null)
			throw new IllegalArgumentException(); // $codepro.audit.disable exceptionUsage.exceptionCreation

		int length = pattern.length() * 2;
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(length);
		int index = 0;
		int copyIndex = 0;

		while (true) { // $codepro.audit.disable constantConditionalExpression
			int first = pattern.indexOf('{', index);

			if (first == -1) {
				break;
			}

			int last = pattern.indexOf('}', first);

			if (last == -1) {
				break;
			}

			index = first + 1;

			if (last <= first + 3) {
				MessageFormatter.format(pattern, values, buffer, copyIndex, first, last);
				copyIndex = last + 1;
			}
		}

		buffer.append(pattern.substring(copyIndex));
		String message = buffer.toString();
		return message;
	}

	private static void format(String pattern, Object[] values, ICharBuffer buffer, int patternIndex, int placeholderBegin, int placeholderEnd) {
		Object chunk;
		chunk = pattern.substring(patternIndex, placeholderBegin);
		buffer.append(chunk);
		String number = pattern.substring(placeholderBegin + 1, placeholderEnd);
		try {
			int valueIndex = Integer.parseInt(number);

			if (valueIndex >= 0 && valueIndex < values.length) {
				chunk = values [ valueIndex ];
			} else {
				MessageFormatter.logPlaceholderCannotBeFoundError(pattern, valueIndex);
				chunk = pattern.substring(placeholderBegin, placeholderEnd + 1);
			}
		} catch (NumberFormatException exception) {
			chunk = pattern.substring(placeholderBegin, placeholderEnd + 1);
		}

		buffer.append(chunk);
	}

	private static void logPlaceholderCannotBeFoundError(String pattern, int index) {
		String errorPattern = Messages.getString(MessageFormatter.PLACEHOLDER_CANNOT_BE_FOUND_KEY);
		String valueString = Integer.toString(index);
		Object[] values = new Object[] {
			valueString,
			pattern
		};
		String message = MessageFormatter.format(errorPattern, values);
		LogUtility.logError(MessageFormatter.class, message);
	}

	//
	// Constructors
	//

	/**
	 * Private constructor.
	 */
	private MessageFormatter() {
		super();
	}
}
