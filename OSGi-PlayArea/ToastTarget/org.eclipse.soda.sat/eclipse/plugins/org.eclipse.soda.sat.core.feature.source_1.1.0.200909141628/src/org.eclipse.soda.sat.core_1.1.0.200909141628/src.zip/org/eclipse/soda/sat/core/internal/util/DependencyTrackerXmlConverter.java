/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util;

import java.util.Iterator;
import java.util.List;

import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.FactoryUtility;

/**
 * DependencyTrackerXmlConverter.java
 */
class DependencyTrackerXmlConverter extends Object {
	//
	// Static Types
	//

	/**
	 * DependencyTrackerConverter.DefaultXmlProvider
	 */
	private static class DefaultXmlProvider extends Object implements IDependencyTracker.IXmlProvider {
		/**
		 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker.IXmlProvider#convertDependentToXml(java.lang.Object, int)
		 */
		public String convertDependentToXml(Object dependent, int indent) {
			return convertToXml(dependent);
		}

		/**
		 * @see org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker.IXmlProvider#convertPrerequisiteToXml(java.lang.Object, int)
		 */
		public String convertPrerequisiteToXml(Object prerequisite, int indent) {
			return convertToXml(prerequisite);
		}

		/**
		 * Convert the specified <code>Object</code> to XML.
		 *
		 * @param object  The object to convert to XML.
		 *
		 * @return The XML String
		 */
		private String convertToXml(Object object) {
			String value = String.valueOf(object);
			int size = value.length() + 12;
			FactoryUtility utility = FactoryUtility.getInstance();
			ICharBuffer buffer = utility.createCharBuffer(size);
			printXmlOn(value, buffer);
			String xml = buffer.toString();
			return xml;
		}

		/**
		 * Print the specified <code>Object</code> on the specified buffer as
		 * XML.
		 *
		 * @param object  The object to print on the buffer as XML.
		 * @param buffer  The buffer on which to print.
		 */
		private void printXmlOn(Object object, ICharBuffer buffer) {
			buffer.append("<![CDATA[");  //$NON-NLS-1$
			buffer.append(object);
			buffer.append("]]>");  //$NON-NLS-1$
		}
	}

	//
	// Static Fields
	//

	public static final String INDENT = "  ";  //$NON-NLS-1$
	public static final String NEWLINE = System.getProperty("line.separator");  //$NON-NLS-1$

	//
	// Instance Fields
	//

	private IDependencyTracker model;
	private String name;
	private IDependencyTracker.IXmlProvider xmlProvider;

	//
	// Constructors
	//

	/**
	 * @param dependencyTracker  The source dependency tracker.
	 * @param name               The name of the dependency tracker.
	 */
	DependencyTrackerXmlConverter(IDependencyTracker dependencyTracker, String name) {
		this(dependencyTracker, name, new DefaultXmlProvider());
	}

	/**
	 * @param dependencyTracker  The source dependency tracker.
	 * @param name               The name of the dependency tracker.
	 * @param xmlProvider  The converter provider.
	 */
	DependencyTrackerXmlConverter(IDependencyTracker dependencyTracker, String name, IDependencyTracker.IXmlProvider xmlProvider) {
		super();
		setModel(dependencyTracker);
		setName(name);
		setXmlProvider(xmlProvider);
	}

	//
	// Instance Methods
	//

	/**
	 * Private model getter.
	 *
	 * @return IDependencyTracker
	 */
	private IDependencyTracker getModel() {
		return model;
	}

	/**
	 * Private name getter.
	 *
	 * @return String
	 */
	private String getName() {
		return name;
	}

	/**
	 * Private xmlProvider getter.
	 *
	 * @return IDependencyTracker.IXmlProvider
	 */
	private IDependencyTracker.IXmlProvider getXmlProvider() {
		return xmlProvider;
	}

	/**
	 * Print indentation on the buffer.
	 *
	 * @param buffer  The buffer on which to print.
	 * @param level   The indentation level.
	 */
	private void printIndentOn(ICharBuffer buffer, int level) {
		printNewLineOn(buffer);

		for (int i = 0; i < level; i++) {
			buffer.append(DependencyTrackerXmlConverter.INDENT);
		}
	}

	/**
	 * Print a new line on the buffer.
	 *
	 * @param buffer  The buffer on which to print.
	 */
	private void printNewLineOn(ICharBuffer buffer) {
		buffer.append(DependencyTrackerXmlConverter.NEWLINE);
	}

	/**
	 * Print the XML body of the conversion to the specified buffer.
	 *
	 * @param buffer  The buffer on which to print the body.
	 * @param indent  The indentation level.
	 */
	private void printXmlBodyOn(ICharBuffer buffer, int indent) {
		IDependencyTracker dependencyTracker = getModel();
		List/*<P>*/ prerequisites = dependencyTracker.getPrerequisites();
		Iterator/*<P>*/ iterator = prerequisites.iterator();

		while (iterator.hasNext() == true) {
			Object prerequisite = iterator.next();
			List/*<D>*/ dependents = dependencyTracker.getDependents(prerequisite);
			printXmlOn(buffer, indent, prerequisite, dependents);
		}
	}

	/**
	 * Print the XML footer of the conversion to the specified buffer.
	 *
	 * @param buffer  The buffer on which to print the footer.
	 * @param indent  The indentation level.
	 */
	private void printXmlFooterOn(ICharBuffer buffer, int indent) {
		printIndentOn(buffer, indent);
		buffer.append("</dependencyTracker>");  //$NON-NLS-1$
	}

	/**
	 * Print the XML header of the conversion to the specified buffer.
	 *
	 * @param buffer  The buffer on which to print the the header.
	 * @param indent  The indentation level.
	 */
	private void printXmlHeaderOn(ICharBuffer buffer, int indent) {
		String name = getName();
		printIndentOn(buffer, indent);
		buffer.append('<');
		buffer.append("dependencyTracker");  //$NON-NLS-1$

		if (name != null) {
			buffer.append(' ');
			buffer.append("name");  //$NON-NLS-1$
			buffer.append('=');
			buffer.append('"');
			buffer.append(name);
			buffer.append('"');
		}

		buffer.append('>');
	}

	/**
	 * Print the XML conversion on the buffer.
	 *
	 * @param buffer  The buffer on which to print.
	 */
	private void printXmlOn(ICharBuffer buffer, int indent) {
		printXmlHeaderOn(buffer, indent);
		printXmlBodyOn(buffer, indent);
		printXmlFooterOn(buffer, indent);
	}

	/**
	 * Print the XML conversion of a prerequisite object and its dependents on
	 * the buffer.
	 *
	 * @param buffer        The buffer on which to print.
	 * @param indent        The indentation level.
	 * @param prerequisite  The prerequisite.
	 * @param dependents    The dependents.
	 */
	private void printXmlOn(ICharBuffer buffer, int indent, Object prerequisite, List/*<D>*/ dependents) {
		IDependencyTracker.IXmlProvider xmlProvider = getXmlProvider();

		printIndentOn(buffer, indent + 1);
		buffer.append("<prerequisite>");  //$NON-NLS-1$
		printIndentOn(buffer, indent + 2);
		Object convertedPrerequisite = xmlProvider.convertPrerequisiteToXml(prerequisite, indent + 2);
		buffer.append(convertedPrerequisite);

		Iterator/*<D>*/ iterator = dependents.iterator();

		while (iterator.hasNext() == true) {
			Object dependent = iterator.next();
			printIndentOn(buffer, indent + 2);
			buffer.append("<dependent>");  //$NON-NLS-1$
			printIndentOn(buffer, indent + 3);
			Object convertedDependents = xmlProvider.convertDependentToXml(dependent, indent + 3);
			buffer.append(convertedDependents);
			printIndentOn(buffer, indent + 2);
			buffer.append("</dependent>");  //$NON-NLS-1$
		}

		printIndentOn(buffer, indent + 1);
		buffer.append("</prerequisite>");  //$NON-NLS-1$
	}

	/**
	 * Private model setter.
	 *
	 * @param model  A dependency tracker.
	 */
	private void setModel(IDependencyTracker model) {
		Assertion.checkArgumentIsNotNull(model, "model");  //$NON-NLS-1$
		this.model = model;
	}

	/**
	 * Private name setter.
	 *
	 * @param name  The name of the dependency tracker.
	 */
	private void setName(String name) {
		this.name = name;
	}

	/**
	 * Private xmlProvider setter.
	 *
	 * @param xmlProvider  The converter provider.
	 */
	private void setXmlProvider(IDependencyTracker.IXmlProvider xmlProvider) {
		Assertion.checkArgumentIsNotNull(xmlProvider, "xmlProvider");  //$NON-NLS-1$
		this.xmlProvider = xmlProvider;
	}

	/**
	 * Create an XML document formatted at the specified indentation level.
	 *
	 * @param indent  The indentation level.
	 * @return The XML document.
	 */
	String toXml(int indent) {
		IDependencyTracker dependencyTracker = getModel();

		synchronized (dependencyTracker) {
			int size = dependencyTracker.size() * 500;
			FactoryUtility utility = FactoryUtility.getInstance();
			ICharBuffer buffer = utility.createCharBuffer(size);
			printXmlOn(buffer, indent);
			String result = buffer.toString();
			return result;
		}
	}
}