/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Map;
import java.util.Properties;

import org.eclipse.soda.sat.core.framework.BaseBundleActivator;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.service.BundleDependencyService;
import org.eclipse.soda.sat.core.service.BundleUninstallService;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.eclipse.soda.sat.core.util.MiscUtility;
import org.osgi.framework.BundleContext;
import org.osgi.service.log.LogService;
import org.osgi.service.packageadmin.PackageAdmin;

/**
 * This is the <code>BundleActivator</code> for the SAT core bundle.
 */
public class Activator extends BaseBundleActivator {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String BUNDLE_ADDED_PROPERTY = "Activator.BundleAddedProperty";  //$NON-NLS-1$
	private static final String BUNDLE_REMOVED_PROPERTY = "Activator.BundleRemovedProperty";  //$NON-NLS-1$

	// Service Names
	private static final String LOG_SERVICE_NAME = LogService.class.getName();
	private static final String PACKAGE_ADMIN_SERVICE_NAME = PackageAdmin.class.getName();

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#activate()
	 */
	protected void activate() {
		addExportedBundleDependencyService();
		addExportedBundleUninstallService();
	}

	/**
	 * Start and export the <code>BundleDependencyService</code>.
	 */
	private void addExportedBundleDependencyService() {
		startupBundleDependencyManager();
		BundleDependencyManager manager = BundleDependencyManager.getInstance();
		boolean started = manager.isStarted();
		if (started == false)
			return;  // Early return.
		addExportedService(BundleDependencyService.SERVICE_NAME, manager, null);
	}

	/**
	 * Export the <code>BundleUninstallService</code>.
	 */
	private void addExportedBundleUninstallService() {
		Object manager = BundleUninstallManager.getInstance();
		addExportedService(BundleUninstallService.SERVICE_NAME, manager, null);
	}

	/**
	 * Adds the contents of the properties file to the <code>System</code>
	 * properties.
	 */
	private void addSystemProperties() {
		Properties properties = getProperties();
		boolean empty = properties.isEmpty();
		if (empty == true)
			return;  // Early return.

		Enumeration keys = properties.propertyNames();

		while (keys.hasMoreElements() == true) {
			String key = (String) keys.nextElement();
			Object value = properties.getProperty(key);
			addSystemProperty(key, value);
		}
	}

	/**
	 * Adds the specified key/value pair  to the <code>System</code>
	 * properties.
	 *
	 * @param key    Property key.
	 * @param value  Property value.
	 */
	private void addSystemProperty(Object key, Object value) {
		Map sysProps = System.getProperties();
		boolean exists = sysProps.containsKey(key);
		if (exists == true)
			return;  // Early return.
		sysProps.put(key, value);

		String pattern = Messages.getString(Activator.BUNDLE_ADDED_PROPERTY);
		String symbolicName = getBundleSymbolicName();

		Object[] values = new Object[] {
			symbolicName,
			key,
			value
		};

		String message = MessageFormatter.format(pattern, values);
		LogUtility.logInfo(message);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#deactivate()
	 */
	protected void deactivate() {
		shutdownBundleDependencyManager();
	}

	private boolean getBooleanProperty(String key, boolean defaultValue) {
		MiscUtility utility = MiscUtility.getInstance();
		boolean value = utility.getBooleanProperty(key, defaultValue);
		return value;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#getImportedServiceNames()
	 */
	protected String[] getImportedServiceNames() {
		return new String[] {
			Activator.PACKAGE_ADMIN_SERVICE_NAME
		};
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#getOptionalImportedServiceNames()
	 */
	protected String[] getOptionalImportedServiceNames() {
		return new String[] {
			Activator.LOG_SERVICE_NAME
		};
	}

	private PackageAdmin getPackageAdmin() {
		return (PackageAdmin) getImportedService(Activator.PACKAGE_ADMIN_SERVICE_NAME);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#getPropertiesInputStream()
	 */
	protected InputStream getPropertiesInputStream() throws IOException {
		return getFilePropertiesInputStream();
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#handleAcquiredOptionalImportedService(java.lang.String, java.lang.Object)
	 */
	protected void handleAcquiredOptionalImportedService(String serviceName, Object service) {
		if (serviceName.equals(Activator.LOG_SERVICE_NAME)) {
			LogService logService = (LogService) service;
			LogUtility utility = LogUtility.getInstance();
			utility.setLog(logService);
		} else {
			super.handleAcquiredOptionalImportedService(serviceName, service);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#handleFailedToFindProperties(java.lang.String)
	 */
	protected void handleFailedToFindProperties(String filename) {
		// No-op: It is OK for properties to not exist.
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#handleReleasedOptionalImportedService(java.lang.String, java.lang.Object)
	 */
	protected void handleReleasedOptionalImportedService(String serviceName, Object service) {
		if (serviceName.equals(Activator.LOG_SERVICE_NAME)) {
			LogUtility utility = LogUtility.getInstance();
			utility.setLog(null);
		} else {
			super.handleReleasedOptionalImportedService(serviceName, service);
		}
	}

	private boolean isBundleDependencyServiceEnabled() {
		boolean status = getBooleanProperty(BundleDependencyService.BDS_STATUS_PROPERTY, true);
		return status;
	}

	/**
	 * Remove the properties from the <code>System</code> properties
	 * @throws java.io.IOException
	 */
	private void removeSystemProperties() {
		Properties properties = getProperties();
		boolean empty = properties.isEmpty();
		if (empty == true)
			return;  // Early return.

		Enumeration keys = properties.propertyNames();

		while (keys.hasMoreElements() == true) {
			String key = (String) keys.nextElement();
			removeSystemProperty(key);
		}
	}

	/**
	 * Removes the specified key from the <code>System</code> properties.
	 *
	 * @param key  Property key.
	 */
	private void removeSystemProperty(String key) {
		Map sysProps = System.getProperties();
		Object value = sysProps.remove(key);
		if (value == null)
			return;  // Early return.

		String pattern = Messages.getString(Activator.BUNDLE_REMOVED_PROPERTY);
		String symbolicName = getBundleSymbolicName();

		Object[] values = new Object[] {
			symbolicName,
			key
		};

		String message = MessageFormatter.format(pattern, values);
		LogUtility.logInfo(message);
	}

	/**
	 * Shutdown the <code>BundleDependencyManager</code>.
	 */
	private void shutdownBundleDependencyManager() {
		BundleDependencyManager manager = BundleDependencyManager.getInstance();
		BundleContext bundleContext = getBundleContext();
		manager.shutdown(bundleContext);
		manager.setPackageAdmin(null);
	}

	/**
	 * Shutdown the <code>BundleUninstallManager</code>.
	 */
	private void shutdownBundleUninstallManager() {
		BundleManager manager = BundleUninstallManager.getInstance();
		BundleContext bundleContext = getBundleContext();
		manager.shutdown(bundleContext);
	}

	/**
	 * Shutdown the <code>FrameworkManager</code>.
	 */
	private void shutdownFrameworkManager() {
		FrameworkManager manager = FrameworkManager.getInstance();
		BundleContext bundleContext = getBundleContext();
		manager.shutdown(bundleContext);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#start()
	 */
	protected void start() throws Exception {
		addSystemProperties();
		startupBundleUninstallManager();
		startupFrameworkManager();
	}

	/**
	 * Startup the <code>BundleDependencyManager</code>.
	 */
	private void startupBundleDependencyManager() {
		boolean status = isBundleDependencyServiceEnabled();
		if (status == false)
			return;  // Early return.
		BundleDependencyManager manager = BundleDependencyManager.getInstance();
		PackageAdmin admin = getPackageAdmin();
		manager.setPackageAdmin(admin);
		BundleContext bundleContext = getBundleContext();
		manager.startup(bundleContext);
	}

	/**
	 * Startup the <code>BundleUninstallManager</code>.
	 */
	private void startupBundleUninstallManager() {
		BundleManager manager = BundleUninstallManager.getInstance();
		BundleContext bundleContext = getBundleContext();
		manager.startup(bundleContext);
	}

	/**
	 * Startup the <code>FrameworkManager</code>.
	 */
	private void startupFrameworkManager() {
		FrameworkManager manager = FrameworkManager.getInstance();
		BundleContext bundleContext = getBundleContext();
		manager.startup(bundleContext);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#stop()
	 */
	protected void stop() throws Exception {
		shutdownFrameworkManager();
		shutdownBundleUninstallManager();
		removeSystemProperties();
	}
}