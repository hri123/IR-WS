/*******************************************************************************
 * Copyright (c) 2001, 2009 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework.interfaces;

import java.util.Enumeration;

/**
 * The <code>ITokenizer</code> interface defines the API for an optimized
 * <code>String</code> tokenizer class.  An instance of <code>ITokenizer</code>
 * can be created using the <code>FactoryUtility</code> singleton.
 *
 * <pre>
 * String value = ...
 * FactoryUtility utility = FactoryUtility.getInstance();
 * ITokenizer tokenizer = utility.createTokenizer(value);
 * </pre>
 *
 * This API is designed such that it should be easy to use, especially if you
 * are familiar with the <code>Enumeration</code> interface or the
 * <code>StringTokenizer</code> class.
 *
 * <pre>
 * while (tokenizer.hasMoreTokens() == true) {
 *   String token = tokenizer.nextToken();
 *   ...
 * }
 * </pre>
 *
 * The need for this abstraction was identified after measuring the performance
 * of an OSGi application built using SAT and identifying that using the
 * standard Java class <code>StringTokenizer</code> was taking an excessive
 * amount of time.
 *
 * @see org.eclipse.soda.sat.core.util.FactoryUtility
 */
public interface ITokenizer extends Enumeration {
	/**
	 * Query whether there are more tokens.
	 *
	 * @return <code>boolean</code>
	 */
	public boolean hasMoreTokens();

	/**
	 * Get the next token.
	 *
	 * @return <code>String</code>
	 */
	public String nextToken();

	/**
	 * Set whether an empty token is considered valid. When set to true a pair
	 * of adjacent delimiters will return an empty String. When set to false
	 * a pair of adjacent delimiters will be ignored.
	 *
	 * @param emptyTokenIsValid  Whether an empty token is valid.
	 */
	public void setEmptyTokenIsValid(boolean emptyTokenIsValid);

	/**
	 * Set whether to trim the whitespace from around each token before it is
	 * returned.
	 *
	 * @param trimToken True to enable token trimming, otherwise false.
	 */
	public void setTrimToken(boolean trimToken);

	/**
	 * Answers a thread-safe version of the tokenizer.
	 *
	 * @return A tokenizer.
	 */
	public ITokenizer toSynchronizedTokenizer();
}