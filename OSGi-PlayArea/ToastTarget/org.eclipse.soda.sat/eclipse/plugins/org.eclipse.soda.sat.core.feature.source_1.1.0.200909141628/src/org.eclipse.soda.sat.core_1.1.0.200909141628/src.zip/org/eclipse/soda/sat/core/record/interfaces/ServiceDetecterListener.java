/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.record.interfaces;

import org.osgi.framework.ServiceReference;

/**
 * The <code>ServiceDetecterListener</code> interface is implemented by classes
 * that wishes to observer when a service is <i>added</i> and <i>removed</i>
 * from a <code>ServiceDetecter</code>.
 */
public interface ServiceDetecterListener {
	/**
	 * A service has been added to the specified <code>ServiceDetecter</code>.
	 *
	 * @param detecter          The <code>ServiceDetecter</code> to which the
	 *                          service was added.
	 * @param serviceReference  The <code>ServiceReference</code> of the service
	 *                          that was added.
	 * @param service           The service <code>Object</code> that was added.
	 */
	public void serviceAdded(IServiceDetecter detecter, ServiceReference serviceReference, Object service);

	/**
	 * A service has been removed from the specified <code>ServiceDetecter</code>.
	 *
	 * @param detecter          The <code>ServiceDetecter</code> to which the
	 *                          service was removed.
	 * @param serviceReference  The <code>ServiceReference</code> of the service
	 *                          that was removed.
	 * @param service           The service <code>Object</code> that was removed.
	 */
	public void serviceRemoved(IServiceDetecter detecter, ServiceReference serviceReference, Object service);
}
