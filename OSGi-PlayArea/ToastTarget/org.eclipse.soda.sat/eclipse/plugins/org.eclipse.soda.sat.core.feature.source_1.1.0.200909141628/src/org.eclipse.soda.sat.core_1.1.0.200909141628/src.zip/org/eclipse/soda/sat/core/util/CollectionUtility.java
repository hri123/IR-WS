/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

package org.eclipse.soda.sat.core.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

public class CollectionUtility extends Object {
	//
	// Nested Types
	//

	public interface Accessor {
		/**
		 * Get the object associated with the specified item.
		 *
		 * @param item  An <code>Object</code>.
		 * @return An <code>Object</code>, or <code>null</code>.
		 */
		public Object get(Object item);
	}

	public interface InjectionAccessor {
		/**
		 * Get the object associated with the specified item.
		 *
		 * @param value  An <code>Object</code>.
		 * @param item   An <code>Object</code>.
		 * @return An <code>Object</code>, or <code>null</code>.
		 */
		public Object get(Object value, Object item);
	}

	// Singleton
	private static final CollectionUtility INSTANCE = new CollectionUtility();

	//
	// Static Methods
	//

	/**
	 * Public getter for the <code>CollectionUtility</code> singleton instance.
	 *
	 * @return <code>CollectionUtility</code>
	 */
	public static CollectionUtility getInstance() {
		return CollectionUtility.INSTANCE;
	}

	//
	// Constructors
	//

	/**
	 * Constructor.
	 */
	private CollectionUtility() {
		super();
	}

	//
	// Instance Methods
	//

	private void checkArgumentsAreNotNull(Object/*<Object>*/ collection, Object/*<Object>*/ accessor) {
		Assertion.checkArgumentIsNotNull(collection, "collection");  //$NON-NLS-1$
		Assertion.checkArgumentIsNotNull(accessor, "accessor");  //$NON-NLS-1$
	}

	/**
	 * For each of the objects in the specified <code>Collection</code>
	 * collect objects using the specified <code>Accessor</code> object.
	 *
	 * @param collection  A <code>Collection</code>.
	 * @param accessor    The object <code>Acccessor</code>.
	 * @return A list of objects.
	 */
	public List/*<Object>*/ collect(Collection/*<Object>*/ collection, Accessor/*<Object>*/ accessor) {
		checkArgumentsAreNotNull(collection, accessor);
		int size = collection.size();
		List/*<Object>*/ list = new ArrayList/*<Object>*/(size);
		Iterator/*<Object>*/ iterator = collection.iterator();

		while (iterator.hasNext() == true) {
			Object item = iterator.next();
			Object value = accessor.get(item);
			list.add(value);
		}

		return list;
	}

	/**
	 * Detect the first object in the specified <code>Collection</code> for
	 * which the specified <code>Accessor</code> does not return
	 * <code>null</code>.
	 *
	 * @param collection  A <code>Collection</code>.
	 * @param accessor    An <code>Accessor</code>.
	 * @return The detected object.
	 */
	public Object detect(Collection/*<Object>*/ collection, Accessor/*<Object>*/ accessor) {
		checkArgumentsAreNotNull(collection, accessor);
		Object result = null;
		Iterator/*<Object>*/ iterator = collection.iterator();

		while (result == null && iterator.hasNext() == true) {
			Object item = iterator.next();
			Object value = accessor.get(item);
			if (value == null)
				continue;  // Skip to next iteration.
			result = item;
		}

		return result;
	}

	/**
	 * Estimate the size of a hashed collection based on the specified capacity
	 * and the load factor of 75%. Unlike other collections, hashed collections
	 * need to be created bigger than the number of elements they intend to
	 * hold.  This method estimates how big a hashed collections must be to
	 * efficiently hold the specified number of elements without needing to
	 * grow.
	 *
	 * @param capacity  The number of elements the hash collections must hold.
	 * @return The estimate size of the hashed collection.
	 */
	public int estimateHashedCollectionSize(int capacity) {
		return estimateHashedCollectionSize(capacity, 0.75f);
	}

	/**
	 * Estimate the size of a hashed collection based on the specified capacity
	 * and load factor. Unlike other collections, hashed collections need to be
	 * created bigger than the number of elements they intend to hold.  This
	 * method estimates how big a hashed collections must be to efficiently hold
	 * the specified number of elements without needing to grow.
	 *
	 * @param capacity  The number of elements the hash collections must hold.
	 * @param loadFactor The load factor of the hashed collection.
	 * @return The estimate size of the hashed collection.
	 */
	public int estimateHashedCollectionSize(int capacity, float loadFactor) {
		if (capacity <= 0)
			return 0;
		if (loadFactor <= 0)
			throw new IllegalArgumentException();
		int size = (int) (capacity / loadFactor) + 1;
		return size;
	}

	/**
	 * Inject each item in the specified collection into the specified
	 * <code>Object</code> using the specified accessor.
	 *
	 * @param collection  A <code>Collection</code> of objects to be injected.
	 * @param value       The target for the injection.
	 * @param accessor    The accessor defining the injection behavior.
	 * @return The injection result.
	 */
	public Object inject(Collection/*<Object>*/ collection, Object value, InjectionAccessor/*<Object>*/ accessor) {
		checkArgumentsAreNotNull(collection, accessor);
		Assertion.checkArgumentIsNotNull(value, "value");  //$NON-NLS-1$
		Iterator/*<Object>*/ iterator = collection.iterator();
		Object result = value;

		while (iterator.hasNext() == true) {
			Object item = iterator.next();
			result = accessor.get(result, item);
		}

		return result;
	}

	private List/*<Object>*/ iterate(Collection/*<Object>*/ collection, Accessor/*<Object>*/ accessor, boolean select) {
		checkArgumentsAreNotNull(collection, accessor);
		int size = collection.size();
		ArrayList/*<Object>*/ list = new ArrayList/*<Object>*/(size);
		Iterator/*<Object>*/ iterator = collection.iterator();

		while (iterator.hasNext() == true) {
			Object item = iterator.next();
			Object value = accessor.get(item);
			if (select == true && value == null)
				continue; // Skip to next iteration.
			if (select == false && value != null)
				continue; // Skip to next iteration.
			list.add(value);
		}

		list.trimToSize();
		return list;
	}

	/**
	 * Reject those items in the specified <code>Collection</code> as defined by
	 * the specified <code>Accessor</code>.
	 *
	 * @param collection  The items from which to reject.
	 * @param accessor    The rejection accessor.
	 * @return A <code>List</code> of items that were not rejected, never
	 * <code>null</code>.
	 */
	public List/*<Object>*/ reject(Collection/*<Object>*/ collection, Accessor/*<Object>*/ accessor) {
		return iterate(collection, accessor, false);
	}

	/**
	 * Select those items in the specified <code>Collection</code> as defined by
	 * the specified <code>Accessor</code>.
	 *
	 * @param collection  The items from which to select.
	 * @param accessor    The selection accessor.
	 * @return A <code>List</code> of selected items, never <code>null</code>
	 */
	public List/*<Object>*/ select(Collection/*<Object>*/ collection, Accessor/*<Object>*/ accessor) {
		return iterate(collection, accessor, true);
	}

	/**
	 * Convert the specified <code>Enumeration</code> into a <code>List</code>.
	 *
	 * @param enumeration  The source <code>Enumeration</code>.
	 * @return The target <code>List</code> containing the items in the source
	 * <code>Enumeration</code>
	 */
	public List/*<Object>*/ toList(Enumeration/*<Object>*/ enumeration) {
		ArrayList/*<Object>*/ list = new ArrayList/*<Object>*/(25);
		list = (ArrayList) toList(enumeration, list);
		list.trimToSize();
		return list;
	}

	/**
	 * Add the specified <code>Enumeration</code> to the specified
	 * <code>List</code>.
	 *
	 * @param enumeration  The source <code>Enumeration</code>.
	 * @param list         The target <code>List</code>.
	 * @return The target <code>List</code>.
	 */
	public List/*<Object>*/ toList(Enumeration/*<Object>*/ enumeration, List/*<Object>*/ list) {
		Assertion.checkArgumentIsNotNull(enumeration, "enumeration");  //$NON-NLS-1$
		Assertion.checkArgumentIsNotNull(list, "list");  //$NON-NLS-1$

		while (enumeration.hasMoreElements() == true) {
			Object element = enumeration.nextElement();
			list.add(element);
		}

		return list;
	}
}
