/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.record.container.interfaces;

import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord;
import org.osgi.framework.Filter;

/**
 * The <code>IImportServiceRecordContainer</code> interface declares the API for
 * import service record containers.  The following responsibilities are
 * declared:
 * <ul>
 *   <li>
 *     Acquiring the contained import service records.
 *   </li>
 *   <li>
 *     Releasing the contained import service records.
 *   </li>
 *   <li>
 *     Adding an import service record.
 *   </li>
 *   <li>
 *     Removing an import service record.
 *   </li>
 *   <li>
 *     If the container is <b>strict</b> notifying the container's owner when:
 *     <ul>
 *        <li>
 *          All the contained import service records have been acquired.
 *        </li>
 *        <li>
 *          All the contained import service records have previously been
 *          acquired, and then one of the contained import service records has
 *          been released.
 *        </li>
 *     </ul>
 *   </li>
 *   <li>
 *     If the container is <b>non-strict</b> notifying the container's owner
 *     when:
 *     <ul>
 *        <li>
 *          Asked to acquire all of the contained import service records.
 *        </li>
 *        <li>
 *          Each of the contained import service records is acquired.
 *        </li>
 *        <li>
 *          Each of the contained import service records is released.
 *        </li>
 *        <li>
 *          Asked to release all of the contained import service records.
 *        </li>
 *     </ul>
 *   </li>
 *   <li>
 *     Querying whether all the contained import service records are acquired.
 *   </li>
 * </ul>
 * <p>
 * <i>Note:</i> Since this abstraction is used internally by the SAT bundle
 * this interface is typically not used directly by bundle developers.  For
 * cases where subclassing the <code>BaseBundleActivator</code> is not
 * appropriate, instances of this interface can be created using the
 * <code>FactoryUtility</code> class.
 */
public interface IImportServiceRecordContainer extends IServiceRecordContainer {
	/**
	 * Acquire all the contained import service records.
	 */
	public void acquire();

	/**
	 * Add an import service record to the container.
	 *
	 * @param record  The import service record to add.
	 * @return True if the record was added, otherwise false.
	 */
	public boolean add(IImportServiceRecord record);

	/**
	 * Get the names of the services that have not been acquired.
	 *
	 * @return The names of the services that have not been acquired.
	 */
	public String[] getUnacquiredServiceNames();

	/**
	 * Get the record from the container with the matching service name and
	 * filter.
	 *
	 * @param name    The name of a service.
	 * @param filter  An LDP filter.
	 * @return The record matching the specified service name and filter, or
	 * null if no match is found.
	 */
	public IImportServiceRecord getWithFilter(String name, Filter filter);

	/**
	 * Releases the container's import service records.
	 */
	public void release();

	/**
	 * Remove an import service record from the container.  Once removed, an
	 * acquired record is released.
	 *
	 * @param record  The import service record to remove.
	 * @return True if the record was removed, otherwise false.
	 */
	public boolean remove(IImportServiceRecord record);

	/**
	 * Set the container's owner.
	 *
	 * @param owner  The container's owner.
	 */
	public void setOwner(IImportServiceRecordContainerOwner owner);
}