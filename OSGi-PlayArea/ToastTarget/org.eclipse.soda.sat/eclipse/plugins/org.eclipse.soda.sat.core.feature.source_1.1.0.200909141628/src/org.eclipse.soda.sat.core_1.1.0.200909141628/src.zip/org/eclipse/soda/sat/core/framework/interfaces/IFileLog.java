/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework.interfaces;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * The <code>IFileLog</code> interface defines the API for a file-based log.
 * An instance of <code>IFileLog</code> can be created using the
 * <code>FactoryUtility</code> singleton.
 *
 * <pre>
 * File file = ...
 * FactoryUtility utility = FactoryUtility.getInstance();
 * IFileLog fileLog = utility.createFileLog(file);
 * </pre>
 *
 * An <code>IFileLog</code> must be opened before it can be written to, and
 * closed after use.  For example:
 *
 * <pre>
 * try {
 *   try {
 *     fileLog.open();
 *     fileLog.log(this, "Hello World");
 *   } finally {
 *     fileLog.close();
 *   }
 * } catch (IOException exception) {
 *   ...
 * }
 * </pre>
 *
 * For convenience, the <code>LogUtility</code> singleton has a built-in
 * <code>IFileLog</code> that may be written to using its
 * <code>logToFile(Object, String)</code> and <code>traceToFile(Object, String)
 * methods.
 *
 * @see org.eclipse.soda.sat.core.util.FactoryUtility
 * @see org.eclipse.soda.sat.core.util.LogUtility
 */
public interface IFileLog {
	/**
	 * Close the file.
	 *
	 * @throws IOException
	 */
	public void close() throws IOException;

	/**
	 * Delete the file.
	 *
	 * @return True if the file was deleted, otherwise false.
	 * @throws IOException
	 */
	public boolean delete() throws IOException;

	/**
	 * Get the absolute path of the file.
	 *
	 * @return The absolute path of the file.
	 */
	public String getAbsolutePath();

	/**
	 * Get the name of the file.
	 *
	 * @return String
	 */
	public String getFilename();

	/**
	 * Write the specified message to the file.  This method is provided for
	 * debugging purposes only.  Since this method makes use of local file I/O,
	 * this should typically not be called in production code.
	 *
	 * @param id        An object that identifies who is logging the message.
	 * @param message   The message to log.
	 * @throws IOException
	 */
	public void log(Object id, String message) throws IOException;

	/**
	 * Open the file.
	 *
	 * @throws FileNotFoundException
	 */
	public void open() throws FileNotFoundException;
}
