/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.record;

import org.eclipse.soda.sat.core.record.interfaces.IServiceRecord;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;

/**
 * The abstract <code>ServiceRecordDelegate</code> class is the superclass to
 * all classes that wish to delegate to a contained service record.  The class
 * is an implementation of the <code>IServiceRecord</code> interface where each
 * method simply delegates to the contained service record.  This abstraction
 * is useful for creating a service record class that is intended to be
 * composed of another service record class.
 */
abstract class ServiceRecordDelegate extends Object implements IServiceRecord {
	//
	// Instance Fields
	//

	private IServiceRecord serviceRecord;

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceRecord#basicToString()
	 */
	public final String basicToString() {
		String value = super.toString();
		return value;
	}

	/**
	 * Get the size of the StringBuffer used by toString().
	 *
	 * @return The size of the StringBuffer.
	 */
	protected int createToStringBufferSize() {
		return 100;
	}

	protected final Bundle getBundle() {
		BundleContext bundleContext = getBundleContext();
		Bundle bundle = null;
		try {
			bundle = bundleContext.getBundle();
		} catch (IllegalStateException exception) {
			// The BundleContext is disposed.
		}
		return bundle;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceRecord#getBundleContext()
	 */
	public BundleContext getBundleContext() {
		IServiceRecord record = getServiceRecord();
		BundleContext bundleContext = record.getBundleContext();
		return bundleContext;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceRecord#getProperty(java.lang.String)
	 */
	public Object getProperty(String key) {
		IServiceRecord record = getServiceRecord();
		Object property = record.getProperty(key);
		return property;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceRecord#getPropertyKeys()
	 */
	public String[] getPropertyKeys() {
		IServiceRecord record = getServiceRecord();
		String[] keys = record.getPropertyKeys();
		return keys;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceRecord#getService()
	 */
	public Object getService() {
		IServiceRecord record = getServiceRecord();
		Object service = record != null ? record.getService() : null;
		return service;
	}

	/**
	 * Protected serviceRecord getter.
	 *
	 * @return The service record to which to delegate.
	 */
	protected final IServiceRecord getServiceRecord() {
		return serviceRecord;
	}

	/**
	 * Prints a description of the service record on the StringBuffer.
	 *
	 * @param buffer  A buffer on which to print a description of the receiver.
	 */
	protected void printOn(StringBuffer buffer) {
		printServiceRecordOn(buffer);
	}

	/**
	 * Prints an Object on a StringBuffer.  This method simply provides a way
	 * to print an Object.toString() description of Object on a StringBuffer
	 * regardless of whether its toString() method has been overridden.
	 *
	 * @param buffer  A buffer on which to print the Object.
	 * @param object  The object to print on the buffer.
	 */
	protected final void printOn(StringBuffer buffer, Object object) {
		if (object == null) {
			buffer.append(object);
		} else {
			Class clazz = object.getClass();
			String name = clazz.getName();
			int hashCode = object.hashCode();
			String hexHashCode = Integer.toHexString(hashCode);

			buffer.append(name);
			buffer.append('@');
			buffer.append(hexHashCode);
		}
	}

	private void printServiceRecordOn(StringBuffer buffer) {
		buffer.append(", serviceRecord=");  //$NON-NLS-1$
		IServiceRecord record = getServiceRecord();
		Object value = record != null ? record.basicToString() : null;
		buffer.append(value);
	}

	/**
	 * Protected serviceRecord setter.
	 *
	 * @param serviceRecord  A service record to which to delegate.
	 */
	protected final void setServiceRecord(IServiceRecord serviceRecord) {
		this.serviceRecord = serviceRecord;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public final String toString() {
		int size = createToStringBufferSize();
		StringBuffer buffer = new StringBuffer(size);
		Object value = super.toString();
		buffer.append(value);
		printOn(buffer);
		String description = buffer.toString();
		return description;
	}
}
