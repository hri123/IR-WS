/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util;

import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.util.Assertion;

public class SynchronizedCharBuffer extends Object implements ICharBuffer {
	private ICharBuffer buffer;

	/**
	 * Constructor.
	 *
	 * @param buffer  The <code>ICharBuffer</code> to wrap, never
	 *                <code>null</code>.
	 */
	public SynchronizedCharBuffer(ICharBuffer buffer) {
		super();
		setBuffer(buffer);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(boolean)
	 */
	public ICharBuffer append(boolean value) {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.append(value);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(char)
	 */
	public ICharBuffer append(char charValue) {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.append(charValue);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(char[])
	 */
	public ICharBuffer append(char[] array) {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.append(array);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(char[], int, int)
	 */
	public ICharBuffer append(char[] array, int start, int length) {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.append(array, start, length);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(double)
	 */
	public ICharBuffer append(double doubleValue) {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.append(doubleValue);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(float)
	 */
	public ICharBuffer append(float floatValue) {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.append(floatValue);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(int)
	 */
	public ICharBuffer append(int intValue) {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.append(intValue);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(long)
	 */
	public ICharBuffer append(long longValue) {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.append(longValue);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(java.lang.Object)
	 */
	public ICharBuffer append(Object object) {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.append(object);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#append(java.lang.String)
	 */
	public ICharBuffer append(String value) {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.append(value);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#capacity()
	 */
	public int capacity() {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.capacity();
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#charAt(int)
	 */
	public char charAt(int i) {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.charAt(i);
		}
	}

	private ICharBuffer getBuffer() {
		return buffer;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#getGrowPercentage()
	 */
	public int getGrowPercentage() {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.getGrowPercentage();
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#getGrowStyle()
	 */
	public short getGrowStyle() {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.getGrowStyle();
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#getValue()
	 */
	public String getValue() {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.getValue();
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#length()
	 */
	public int length() {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.length();
		}
	}

	private void setBuffer(ICharBuffer buffer) {
		Assertion.checkArgumentIsNotNull(buffer, "buffer"); //$NON-NLS-1$
		this.buffer = buffer;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#setChar(int, char)
	 */
	public void setChar(int i, char ch) {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			buffer.setChar(i, ch);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#setGrowPercentage(int)
	 */
	public void setGrowPercentage(int growPercentage) {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			buffer.setGrowPercentage(growPercentage);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#setGrowStyle(short)
	 */
	public void setGrowStyle(short growStyle) {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			buffer.setGrowStyle(growStyle);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#setLength(int)
	 */
	public void setLength(int length) {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			buffer.setLength(length);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#toArray()
	 */
	public char[] toArray() {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.toArray();
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#toArray(char[])
	 */
	public char[] toArray(char[] target) {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.toArray(target);
		}
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		ICharBuffer buffer = getBuffer();
		synchronized (buffer) {
			return buffer.toString();
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer#toSynchronizedCharBuffer()
	 */
	public ICharBuffer toSynchronizedCharBuffer() {
		return this;
	}
}
