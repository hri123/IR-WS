/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util;

import java.util.Calendar;
import java.util.Date;

import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.osgi.framework.ServiceReference;
import org.osgi.service.log.LogService;

/**
 * The <code>LogProxy</code> class wraps an implementation of the OSGi defined
 * interface <code>LogService</code>.  The class also implements the interface
 * <code>LogService</code> and delegates all requests to a contained
 * <code>LogService</code>.  The <code>LogUtility</code> class uses an instance
 * of the class <code>LogProxy</code> to provide a <code>LogService</code> that
 * is guaranteed not to change identity.
 * <p>
 * The object references from the <code>LogUtility</code> singleton are as
 * follows:
 * <ul>
 *   <li>
 *     When a registered implementation of <code>LogService</code> does not
 *     exist:
 *     <ul>
 *       <li>
 *         <code>LogUtility &gt; LogProxy &gt; ConsoleLog</code>
 *       </li>
 *     </ul>
 *   </li>
 *   <li>
 *     When a registered implementation of <code>LogService</code> does exist:
 *     <ul>
 *       <li>
 *         <code>LogUtility &gt; LogProxy &gt; LogService</code>
 *       </li>
 *     </ul>
 *   </li>
 * </ul>
 * <p>
 */
public class LogProxy extends Object implements LogService {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String LOG_LEVEL_UNKNOWN_KEY = "LogProxy.LogLevelIsUnknown";  //$NON-NLS-1$

	// Misc
	private static final char DATE_DELIMETER = '-';
	private static final int DEFAULT_BUFFER_SIZE = 5 * 1024;  // 5K
	private static final char TIME_DELIMETER = ':';
	private static final char WHITESPACE = ' ';
	private static final char ZERO_PADDING = '0';
	private static final Calendar CALENDAR = Calendar.getInstance();

	//
	// Instance Fields
	//

	private static Calendar getCalendar() {
		Date now = new Date();
		LogProxy.CALENDAR.setTime(now);
		return LogProxy.CALENDAR;
	}
	private volatile LogService log;
	private LogService consoleLog;
	private volatile int logLevel;


	//
	// Static Methods
	//

	private ICharBuffer buffer;

	//
	// Constructors
	//

	/**
	 * Constructor that builds a <code>LogProxy</code> that does not have a
	 * contained <code>LogService</code>.  Requests will be delegated to an
	 * instance of <code>ConsoleLog</code>, which is created via lazy
	 * initialization.
	 */
	public LogProxy() {
		super();
	}

	/**
	 * Constructor that builds a <code>LogProxy</code> with a contained
	 * <code>LogService</code> to which requests will be delegated.
	 *
	 * @param log  A log service.
	 */
	public LogProxy(LogService log) {
		super();
		setLog(log);
	}


	/**
	 * Append the current date to the buffer.  This code must be executed while
	 * synchronized on the buffer.  The date will be written out in the
	 * following format: yyyy-mm-dd.
	 *
	 * @param calendar  A Calendar.
	 */
	private void appendDate(Calendar calendar) {
		ICharBuffer buffer = getBuffer();

		// Year
		int year = calendar.get(Calendar.YEAR);
		buffer.append(year);

		// Month
		buffer.append(LogProxy.DATE_DELIMETER);
		int month = calendar.get(Calendar.MONTH) + 1;

		if (month < 10) {
			buffer.append(LogProxy.ZERO_PADDING);
		}

		buffer.append(month);

		// Day
		buffer.append(LogProxy.DATE_DELIMETER);
		int day = calendar.get(Calendar.DAY_OF_MONTH);

		if (day < 10) {
			buffer.append(LogProxy.ZERO_PADDING);
		}

		buffer.append(day);
	}

	/**
	 * Append the current time to the buffer.  This code must be executed while
	 * synchronized on the buffer.  The date will be written out in the
	 * following format: "hh:mm:ss.xxx".  Note that "xxx" signifies
	 * milliseconds.
	 *
	 * @param calendar  A Calendar.
	 */
	private void appendTime(Calendar calendar) {
		ICharBuffer buffer = getBuffer();

		// Hours
		int hour = calendar.get(Calendar.HOUR_OF_DAY);

		if (hour < 10) {
			buffer.append(LogProxy.ZERO_PADDING);
		}

		buffer.append(hour);

		// Minutes
		buffer.append(LogProxy.TIME_DELIMETER);
		int minute = calendar.get(Calendar.MINUTE);

		if (minute < 10) {
			buffer.append(LogProxy.ZERO_PADDING);
		}

		buffer.append(minute);

		// Seconds
		buffer.append(LogProxy.TIME_DELIMETER);
		int second = calendar.get(Calendar.SECOND);

		if (second < 10) {
			buffer.append(LogProxy.ZERO_PADDING);
		}

		buffer.append(second);

		// Milliseconds
		buffer.append('.');
		int millisecond = calendar.get(Calendar.MILLISECOND);

		if (millisecond < 100) {
			buffer.append(LogProxy.ZERO_PADDING);
		}

		if (millisecond < 10) {
			buffer.append(LogProxy.ZERO_PADDING);
		}

		buffer.append(millisecond);
	}

	/**
	 * Check that the specified level is within the legal range.
	 *
	 * @param level  The log level to check.
	 * @throws IllegalArguementException if the level is out of range.
	 */
	private void checkLevel(int level) {
		if (level == 0)
			return;  // Early return.
		if (level >= LogService.LOG_ERROR && level <= LogService.LOG_DEBUG)
			return;  // Early return.
		String pattern = Messages.getString(LogProxy.LOG_LEVEL_UNKNOWN_KEY);
		String message = MessageFormatter.format(pattern, new Integer(level));
		throw new IllegalArgumentException(message);
	}

	/**
	 * Format the specified message so that it can be written to the log.
	 *
	 * @param message  The message to log.
	 * @return A formatted message.
	 */
	private String formatMessage(String message) {
		String formattedMessage;
		ICharBuffer buffer = getBuffer();

		// It is very important to synchronize on the buffer to ensure that only
		// one thread uses the buffer at a time.  A buffer is used to improve
		// performance and reduce garbage generation.
		synchronized (buffer) {
			// Since the buffer is reused, it must be emptied before each use.
			buffer.setLength(0);

			Calendar calendar = LogProxy.getCalendar();
			appendDate(calendar);
			buffer.append(LogProxy.WHITESPACE);
			appendTime(calendar);
			buffer.append(LogProxy.WHITESPACE);
			buffer.append('-');
			buffer.append(LogProxy.WHITESPACE);
			buffer.append(message);
			formattedMessage = buffer.toString();
		}

		return formattedMessage;
	}

	//
	// Instance Methods
	//

	/**
	 * Private buffer getter.  This method lazy initializes the buffer.
	 *
	 * @return The LogUtility instance's buffer that is used to format logged
	 * messages.
	 */
	private ICharBuffer getBuffer() {
		synchronized (this) {
			if (buffer == null) {
				FactoryUtility utility = FactoryUtility.getInstance();
				ICharBuffer buffer = utility.createCharBuffer(LogProxy.DEFAULT_BUFFER_SIZE);
				setBuffer(buffer);
			}

			return buffer;
		}
	}

	/**
	 * Private consoleLog getter.
	 *
	 * @return  The console log.
	 */
	private LogService getConsoleLog() {
		synchronized (this) {
			if (consoleLog == null) {
				setConsoleLog(new ConsoleLog());
			}

			return consoleLog;
		}
	}

	/**
	 * Private log getter.
	 *
	 * @return <code>LogService</code>
	 */
	private LogService getLog() {
		return log;
	}

	/**
	 * Public logLevel getter.
	 *
	 * @return The log level.
	 * @see org.osgi.service.log.LogService
	 */
	public int getLogLevel() {
		return logLevel;
	}

	/**
	 * Query the current log level.
	 *
	 * @param level  The level to compare against.
	 * @return True if the log level is equal or greater than the specified
	 * level, otherwise false.
	 */
	public boolean isLogging(int level) {
		int threshold = getLogLevel();
		boolean logging = threshold >= level;
		return logging;
	}

	/**
	 * @see org.osgi.service.log.LogService#log(int, String)
	 */
	public void log(int level, String message) {
		log(null, level, message, null);
	}

	/**
	 * @see org.osgi.service.log.LogService#log(int, String, Throwable)
	 */
	public void log(int level, String message, Throwable throwable) {
		log(null, level, message, throwable);
	}

	/**
	 * @see org.osgi.service.log.LogService#log(ServiceReference, int, String)
	 */
	public void log(ServiceReference reference, int level, String message) {
		log(reference, level, message, null);
	}

	/**
	 * @see org.osgi.service.log.LogService#log(ServiceReference, int, String, Throwable)
	 */
	public void log(ServiceReference reference, int level, String message, Throwable throwable) {
		boolean logging = isLogging(level);
		if (logging == false)
			return;  // Early return.

		LogService log = getLog();

		if (log == null) {
			log = getConsoleLog();
		}

		String formattedMessage = formatMessage(message);
		log.log(reference, level, formattedMessage, throwable);
	}

	/**
	 * Private buffer setter.
	 *
	 * @param buffer  The buffer used for formatting logged messages.
	 */
	private void setBuffer(ICharBuffer buffer) {
		this.buffer = buffer;
	}

	/**
	 * Private consoleLog setter.
	 *
	 * @param consoleLog  The console log.
	 */
	private void setConsoleLog(LogService consoleLog) {
		this.consoleLog = consoleLog;
	}

	/**
	 * Sets the log service.
	 *
	 * @param log  A log service.
	 */
	public void setLog(LogService log) {
		if (equals(log) == true)
			return;  // Early return.
		if (this.log != null && log != null)
			return;  // Early return.
		this.log = log;
	}

	/**
	 * Public logLevel setter.
	 *
	 * @param logLevel  The current log level.
	 */
	public void setLogLevel(int logLevel) {
		checkLevel(logLevel);
		this.logLevel = logLevel;
	}
}