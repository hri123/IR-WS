/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework.interfaces;

import java.lang.reflect.Method;

/**
 * An <code>IProxyServiceHandler</code> is responsible for handling call backs
 * for a proxy service.  This is a simple interface that provides API for
 * creating the service for which the proxy exists, handling pre-invoke behavior
 * and handling post-invoke behavior.
 */
public interface IProxyServiceHandler {
	/**
	 * Create the real service <code>Object</code> for which a proxy was
	 * created.
	 *
	 * @return The created service <code>Object</code>.
	 */
	public Object createService();

	/**
	 * A hook method that is executed <i>after</i> the proxy has invoked the
	 * specified <code>Method</code> on the specified service
	 * <code>Object</code>.  The <code>data</code> parameter is particularly
	 * interesting in that it is
	 * the <code>Object</code> returned by the <code>preInvoke</code> method.
	 *
	 * @param service    The service <code>Object</code>.
	 * @param method     The <code>Method</code> that was invoked on the
	 *                   service.
	 * @param args       The arguments passed to the method.
	 * @param throwable  The exception thrown by the method, or
	 *                   <code>null</code>.
	 * @param data       Handler specific data.
	 */
	public void postInvoke(Object service, Method method, Object[] args, Throwable throwable, Object data);

	/**
	 * A hook method that is executed <i>before</i> the proxy has invoked the
	 * specified <code>Method</code> on the specified service
	 * <code>Object</code>.  The <code>Object</code> returned by this method is
	 * handler-specific and will be passed into the <code>postInvoke</code>
	 * method; for example, the current time in milliseconds could be returned
	 * as a <code>Long</code>, allowing the <code>postInvoke</code> method to
	 * calculate approximately how long the service method took to execute.
	 *
	 * @param service  The service <code>Object</code>.
	 * @param method   The <code>Method</code> that will be invoked on the
	 *                 service.
	 * @param args     The arguments that will be passed to the method.
	 * @return Handler specific data.
	 */
	public Object preInvoke(Object service, Method method, Object[] args);
}
