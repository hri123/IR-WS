/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.framework;

import java.net.URL;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Set;

import org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceActivationManager;
import org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceAdvisor;
import org.eclipse.soda.sat.core.framework.interfaces.IProxyServiceHandler;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.internal.util.WarningMessageUtility;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.MiscUtility;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.service.cm.ConfigurationAdmin;
import org.osgi.service.cm.ConfigurationException;
import org.osgi.service.cm.ManagedService;

public abstract class ManagedServiceBundleActivator extends BaseBundleActivator implements ManagedService {
	//
	// Static Fields
	//

	// Property Keys
	private static final String CHECK_METADATA_EXISTS_PROPERTY = "org.eclipse.soda.sat.core.framework.check.metadata.exists";  //$NON-NLS-1$
	private static final String CREATE_MANAGED_SERVICE_PROXY_PROPERTY = "org.eclipse.soda.sat.core.framework.create.ms.proxy";  //$NON-NLS-1$

	// Default Property Values
	private static final boolean DEFAULT_CHECK_METADATA_EXISTS = false;
	private static final boolean DEFAULT_CREATE_MANAGED_SERVICE_PROXY = false;

	// Properties
	private static final boolean CHECK_METADATA_EXISTS = ManagedServiceBundleActivator.getBooleanProperty(ManagedServiceBundleActivator.CHECK_METADATA_EXISTS_PROPERTY, ManagedServiceBundleActivator.DEFAULT_CHECK_METADATA_EXISTS);
	private static final boolean CREATE_MANAGED_SERVICE_PROXY = ManagedServiceBundleActivator.getBooleanProperty(ManagedServiceBundleActivator.CREATE_MANAGED_SERVICE_PROXY_PROPERTY, ManagedServiceBundleActivator.DEFAULT_CREATE_MANAGED_SERVICE_PROXY);

	// Externalized String Keys
	private static final String FAILED_TO_FIND_METADATA_RESOURCE_KEY = "ManagedServiceBundleActivator.FailedToFindMetaDataResource";  //$NON-NLS-1$
	private static final String SAT_CORE_KEY = "Common.SatCore";  //$NON-NLS-1$

	// Misc
	protected static final String CONFIGURATION_ADMIN_SERVICE_NAME = ConfigurationAdmin.class.getName();
	protected static final String MANAGED_SERVICE_SERVICE_NAME = ManagedService.class.getName();

	//
	// Static Methods
	//

	private static boolean getBooleanProperty(String key, boolean defaultValue) {
		MiscUtility utility = MiscUtility.getInstance();
		boolean value = utility.getBooleanProperty(key, defaultValue);
		return value;
	}

	//
	// Instance Fields
	//

	private IManagedServiceActivationManager managedServiceActivationManager;
	private String pid;

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#activate()
	 */
	protected void activate() {
		registerManagedService();
	}

	private void addExportedManagedServiceProxyService() {
		Class interfaceType = ManagedService.class;

		IProxyServiceHandler handler = new ProxyServiceHandlerAdapter(){
			public Object createService() {
				return ManagedServiceBundleActivator.this.createManagedService();
			}
		};

		Dictionary properties = createManagedServiceProperties();
		addExportedProxyService(interfaceType, handler, properties);
	}

	/**
	 * Check that that META-INF/METADATA.XML file exists.  Since this resource
	 * should reside in the bundle it is worth checking that it exists and
	 * display a warning message if it does not.
	 */
	private void checkMetaDataResourceExists() {
		if (ManagedServiceBundleActivator.CHECK_METADATA_EXISTS == false)
			return;  // Early return.
		Bundle bundle = getBundle();  // OSGi Query Method.
		URL url = bundle.getResource("META-INF/METADATA.XML");  //$NON-NLS-1$
		if (url != null)
			return;  // Early return.

		WarningMessageUtility utility = WarningMessageUtility.getInstance();
		String component = Messages.getString(ManagedServiceBundleActivator.SAT_CORE_KEY);
		Object source = bundle.getSymbolicName();
		String warning = Messages.getString(ManagedServiceBundleActivator.FAILED_TO_FIND_METADATA_RESOURCE_KEY);
		utility.warn(component, source, warning, null, null);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#collectImportedServiceNames(java.util.Set)
	 */
	protected void collectImportedServiceNames(Set/*<String>*/ serviceNames) {
		super.collectImportedServiceNames(serviceNames);
		serviceNames.add(ManagedServiceBundleActivator.CONFIGURATION_ADMIN_SERVICE_NAME);
	}

	/**
	 * Create the <code>IManagedServiceAdvisor</code> that knows how
	 * to create and destroy the exported service that is managed by the
	 * service.
	 *
	 * @return An IManagedServiceAdvisor.
	 */
	protected abstract IManagedServiceAdvisor createAdvisor();

	/**
	 * Create the default PID for the <code>ManagedService</code>.
	 *
	 * @return The default PID of the <code>ManagedService</code>.
	 */
	protected final String createDefaultPid() {
		Class clazz = getClass();
		String name = clazz.getName();
		return name;
	}

	private ManagedService createManagedService() {
		checkMetaDataResourceExists();
		startManagedServiceActivationManager();
		ManagedService service = getManagedService();
		return service;
	}

	/**
	 * Create the <code>IManagedServiceActivationManager</code>.
	 *
	 * @return An IManagedServiceActivationManager
	 */
	private IManagedServiceActivationManager createManagedServiceActivationManager() {
		IManagedServiceAdvisor advisor = createAdvisor();
		FactoryUtility utility = FactoryUtility.getInstance();
		IManagedServiceActivationManager manager = utility.createManagedServiceActivationManager(advisor);
		return manager;
	}

	/**
	 * Create the properties for the <code>ManagedService</code> that is
	 * is exported and registered with the OSGi framework.
	 *
	 * @return A Dictionary.
	 */
	private Dictionary createManagedServiceProperties() {
		Dictionary properties = new Hashtable(11);
		String pid = getPid();
		properties.put(Constants.SERVICE_PID, pid);
		return properties;
	}

	/**
	 * Create the PID for the <code>ManagedService</code>.
	 *
	 * @return The PID of the <code>ManagedService</code>.
	 */
	protected String createPid() {
		String pid = createDefaultPid();
		return pid;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#deactivate()
	 */
	protected void deactivate() {
		unregisterManagedService();
		stopManagedServiceActivationManager();
	}

	/**
	 * Get the <code>ManagedService</code>, which is always
	 * <code>this</code> object.
	 *
	 * @return The <code>ManagedService</code>.
	 */
	private ManagedService getManagedService() {
		return this;
	}

	/**
	 * Private <code>managedServiceActivationManager</code> getter.
	 *
	 * @return IManagedServiceActivationManager
	 */
	private IManagedServiceActivationManager getManagedServiceActivationManager() {
		synchronized (this) {
			if (managedServiceActivationManager == null) {
				IManagedServiceActivationManager manager = createManagedServiceActivationManager();
				setManagedServiceActivationManager(manager);
			}

			return managedServiceActivationManager;
		}
	}

	/**
	 * Get the persistent ID for the <code>ManagedService</code>.
	 *
	 * @return The pid.
	 */
	protected final String getPid() {
		synchronized (this) {
			if (pid == null) {
				String pid = createPid();
				setPid(pid);
			}

			return pid;
		}
	}

	/**
	 * Query whether the managed service is created as a proxy service.
	 *
	 * @return True if the managed service is created as a proxy service
	 * otherwise false.
	 */
	protected boolean isProxyService() {
		return ManagedServiceBundleActivator.CREATE_MANAGED_SERVICE_PROXY;
	}

	/**
	 * Register the <code>ManagedService</code>.
	 */
	private void registerManagedService() {
		boolean proxy = isProxyService();

		if (proxy == true) {
			addExportedManagedServiceProxyService();
		} else {
			ManagedService service = createManagedService();
			Dictionary properties = createManagedServiceProperties();
			addExportedService(ManagedServiceBundleActivator.MANAGED_SERVICE_SERVICE_NAME, service, properties);
		}
	}

	/**
	 * Private managedServiceActivationManager setter.
	 *
	 * @param managedServiceActivationManager  An IManagedServiceActivationManager.
	 */
	private void setManagedServiceActivationManager(IManagedServiceActivationManager managedServiceActivationManager) {
		this.managedServiceActivationManager = managedServiceActivationManager;
	}

	/**
	 * Private pid setter.
	 *
	 * @param pid  The persistent ID.
	 */
	private void setPid(String pid) {
		this.pid = pid;
	}

	/**
	 * Start the <code>IManagedServiceActivationManager</code>.  This
	 * is done just before creating the exported <code>ManagedService</code>.
	 */
	private void startManagedServiceActivationManager() {
		BundleContext context = getBundleContext();
		IManagedServiceActivationManager manager = getManagedServiceActivationManager();
		manager.start(context);
	}

	/**
	 * Stop the <code>IManagedServiceActivationManager</code>.  This
	 * is done just before destroying the exported <code>ManagedService</code>.
	 */
	private void stopManagedServiceActivationManager() {
		IManagedServiceActivationManager manager = getManagedServiceActivationManager();
		manager.stop();
		setManagedServiceActivationManager(null);
	}

	private void unregisterManagedService() {
		removeExportedService(ManagedServiceBundleActivator.MANAGED_SERVICE_SERVICE_NAME);
	}

	/**
	 * @see org.osgi.service.cm.ManagedService#updated(java.util.Dictionary)
	 */
	public void updated(Dictionary properties) throws ConfigurationException {
		IManagedServiceActivationManager manager = getManagedServiceActivationManager();
		manager.updated(properties);
	}
}
