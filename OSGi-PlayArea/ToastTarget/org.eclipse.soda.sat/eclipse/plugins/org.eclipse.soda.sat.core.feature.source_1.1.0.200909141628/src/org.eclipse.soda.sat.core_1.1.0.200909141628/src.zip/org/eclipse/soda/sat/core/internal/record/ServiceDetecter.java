/*******************************************************************************
 * Copyright (c) 2001, 2009 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.record;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.internal.framework.bundle.BundleDependencyManager;
import org.eclipse.soda.sat.core.record.interfaces.IServiceDetecter;
import org.eclipse.soda.sat.core.record.interfaces.ServiceDetecterListener;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.ServiceReferenceUtility;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.framework.Filter;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceEvent;
import org.osgi.framework.ServiceListener;
import org.osgi.framework.ServiceReference;

/**
 * The <code>ServiceDetecter</code> class is intended for use in the rare cases
 * where a bundle wishes to track <i>all</i> registered services of a particular
 * type, possibly query each service as it is registered.  In most cases
 * detecting services is unnecessary and is often a sign of a bad design.  The
 * class is an implementation of the <code>IServiceDetecter</code> interface.
 */
public class ServiceDetecter extends Object implements IServiceDetecter {
	//
	// Instance Fields
	//

	private volatile boolean acquired;
	private BundleContext bundleContext;
	private Filter filter;
	private List/*<ServiceDetecterListener>*/ listeners;
	private String name;
	private ServiceListener serviceListener;
	private Map/*<ServiceReference, Object>*/ servicesMap;
	private Comparator serviceRankingComparator;
	private final Object acquireLock = new Object();

	//
	// Constructors
	//

	/**
	 * Constructor
	 *
	 * @param bundleContext  The bundle's <code>BundleContext</code>.
	 * @param name           The fully qualified service name.
	 */
	public ServiceDetecter(BundleContext bundleContext, String name) {
		super();
		setAcquired(false);
		setBundleContext(bundleContext);
		setListeners(new ArrayList/*<ServiceDetecterListener>*/(3));
		setName(name);
		setServicesMap(new HashMap/*<ServiceReference, Object>*/(101));
	}

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceDetecter#acquire()
	 */
	public void acquire() {
		Object lock = getAcquireLock();

		synchronized (lock) {
			boolean acquired = isAcquired();
			if (acquired == true)
				return;  // Early return.
			setAcquired(true);
			registerServiceListener();
			loadServiceMap();
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceDetecter#addServiceDetecterListener(org.eclipse.soda.sat.core.record.interfaces.ServiceDetecterListener)
	 */
	public void addServiceDetecterListener(ServiceDetecterListener listener) {
		List/*<ServiceDetecterListener>*/ listeners = getListeners();

		synchronized (listeners) {
			boolean exists = listeners.contains(listener);
			if (exists == true)
				return;  // Early return.
			listeners.add(listener);
		}
	}

	/**
	 * Apply the service filter.  Applying the filter might cause existing
	 * service to be removed, and other services to be added, depending on
	 * whether they match the filter.  This method is called whenever the
	 * filter is changed.
	 */
	private void applyFilter() {
		boolean acquired = isAcquired();
		if (acquired == false)
			return;  // Early return.

		Object lock = getServicesMap();

		synchronized (lock) {
			Iterator/*<ServiceReference>*/ iterator = getServicesMapKeyIterator();

			while (iterator.hasNext() == true) {
				ServiceReference reference = (ServiceReference) iterator.next();
				handleServiceModified(reference);
			}
		}

		loadServiceMap();
	}

	/**
	 * Create a filter <code>String</code> for the service, in the format:
	 * <code>
	 *		(objectclass=<imported-service-name>)
	 * </code>
	 *
	 * for example:
	 * <code>
	 *		(objectclass=org.osgi.service.http.HttpService)
	 * </code>
	 *
	 * @return String
	 */
	private String createServiceFilter() {
		String result = null;
		String name = getName();

		if (name != null) {
			int size = 15;
			size += name.length();

			FactoryUtility utility = FactoryUtility.getInstance();
			ICharBuffer buffer = utility.createCharBuffer(size);
			buffer.append('(');
			buffer.append(Constants.OBJECTCLASS);
			buffer.append('=');
			buffer.append(name);
			buffer.append(')');

			result = buffer.toString();
		}

		return result;
	}

	/**
	 * Create a <code>ServiceListener</code> for tracking the registered,
	 * unregistered and modified services.
	 *
	 * @return ServiceListener
	 */
	private ServiceListener createServiceListener() {
		return new ServiceListener() {
			public void serviceChanged(ServiceEvent event) {
				int type = event.getType();
				ServiceReference reference = event.getServiceReference();
				ServiceDetecter.this.serviceChanged(type, reference);
			}
		};
	}

	/**
	 * Private <code>acquireLock</code> getter.
	 *
	 * @return Object
	 */
	private Object getAcquireLock() {
		return acquireLock;
	}

	/**
	 * Query the current bundle.
	 *
	 * @return Bundle
	 */
	private Bundle getBundle() {
		BundleContext bundleContext = getBundleContext();
		Bundle bundle = null;
		try {
			bundle = bundleContext.getBundle();
		} catch (IllegalStateException exception) {
			// The BundleContext is disposed.
		}
		return bundle;
	}

	/**
	 * Private <code>bundleContext</code> getter.
	 *
	 * @return BundleContext
	 */
	private BundleContext getBundleContext() {
		return bundleContext;
	}

	/**
	 * Private <code>filter</code> getter.
	 *
	 * @return Filter
	 */
	private Filter getFilter() {
		return filter;
	}
	/**
	 * Private <code>listeners</code> getter.
	 *
	 * @return The registered listeners.
	 */
	private List/*<ServiceDetecterListener>*/ getListeners() {
		return listeners;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceDetecter#getName()
	 */
	public String getName() {
		return name;
	}

	/**
	 * Private <code>serviceListener</code> getter.  This method has the side
	 * effect of lazily initializing the field.
	 *
	 * @return ServiceListener
	 */
	private ServiceListener getServiceListener() {
		synchronized (this) {
			if (serviceListener == null) {
				setServiceListener(createServiceListener());
			}

			return serviceListener;
		}
	}
	private Comparator getServiceRankingComparator() {
		synchronized (this) {
			if (serviceRankingComparator == null) {
				ServiceReferenceUtility utility = ServiceReferenceUtility.getInstance();
				Comparator comparator = utility.createServiceRankingComparator();
				setServiceRankingComparator(comparator);
			}

			return serviceRankingComparator;
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceDetecter#getServiceReferences()
	 */
	public List/*<ServiceReference>*/ getServiceReferences() {
		Map/*<ServiceReference, Object>*/ map = getServicesMap();
		List/*<ServiceReference>*/ list;

		synchronized (map) {
			Collection/*<ServiceReference>*/ references = map.keySet();
			int size = references.size();
			list = new ArrayList/*<ServiceReference>*/(size);
			list.addAll(references);
		}

		Comparator comparator = getServiceRankingComparator();
		Collections.sort(list, comparator);
		return list;
	}

	/**
	 * Get the list of <code>ServiceReference</code> objects that match the
	 * specified <code>Filter</code>.
	 *
	 * @param filter  The filter against which to compare the
	 *                <code>ServiceReference</code> objects.
	 * @return List
	 */
	private List/*<ServiceReference>*/ getServiceReferences(Filter filter) {
		Map/*<ServiceReference, Object>*/ map = getServicesMap();

		synchronized (map) {
			int size = map.size();
			ArrayList/*<ServiceReference>*/ list = new ArrayList/*<ServiceReference>*/(size);
			Iterator/*<ServiceReference>*/ iterator = getServicesMapKeyIterator();

			while (iterator.hasNext() == true) {
				ServiceReference reference = (ServiceReference) iterator.next();
				boolean match = filter.match(reference);
				if (match == false)
					continue; // Skip to next iteration.
				list.add(reference);
			}

			list.trimToSize();
			return list;
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceDetecter#getServiceReferences(java.lang.String)
	 */
	public List/*<ServiceReference>*/ getServiceReferences(String filter) throws InvalidSyntaxException {
		BundleContext bundleContext = getBundleContext();
		Filter serviceReferenceFilter = bundleContext.createFilter(filter);
		List/*<ServiceReference>*/ list = getServiceReferences(serviceReferenceFilter);
		return list;
	}
	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceDetecter#getServices()
	 */
	public List/*<Object>*/ getServices() {
		Map/*<ServiceReference, Object>*/ map = getServicesMap();
		List/*<Object>*/ services;

		synchronized (map) {
			List/*<ServiceReference*/ references = getServiceReferences();
			int size = references.size();
			services = new ArrayList/*<Object>*/(size);
			Iterator/*<ServiceReference>*/ iterator = references.iterator();

			while (iterator.hasNext() == true) {
				ServiceReference reference = (ServiceReference) iterator.next();
				Object service = map.get(reference);
				services.add(service);
			}
		}

		return services;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceDetecter#getServices(java.lang.String)
	 */
	public List/*<Object>*/ getServices(String filter) throws InvalidSyntaxException {
		Map/*<ServiceReference, Object>*/ map = getServicesMap();

		synchronized (map) {
			List/*<ServiceReference>*/ references = getServiceReferences(filter);
			int size = references.size();
			List/*<Object>*/ services = new ArrayList/*<Object>*/(size);
			Iterator/*<ServiceReference>*/ iterator = references.iterator();

			while (iterator.hasNext() == true) {
				Object key = iterator.next();
				Object service = map.get(key);
				services.add(service);
			}

			return services;
		}
	}

	/**
	 * Private serviceMap getter.  This method has the side effect of lazily
	 * initializing the field.
	 *
	 * @return Map
	 */
	private Map/*<ServiceReference, Object>*/ getServicesMap() {
		return servicesMap;
	}

	/**
	 * Get an <code>Iterator</code> on the <code>servicesMap</code>'s keys.  The
	 * iterator is on a clone of the <code>servicesMap</code>, so it is safe to
	 * remove items from the servicesMap while iterating.  <i>Note:</i> Callers
	 * of this method should synchronize on the services map.
	 *
	 * @return Iterator
	 */
	private Iterator/*<ServiceReference>*/ getServicesMapKeyIterator() {
		HashMap/*<ServiceReference, Object>*/ map = (HashMap/*<ServiceReference, Object>*/) getServicesMap();
		Map/*<ServiceReference, Object>*/ clone = (Map/*<ServiceReference, Object>*/) map.clone();
		Set/*<ServiceReference>*/ set = clone.keySet();
		Iterator/*<ServiceReference>*/ iterator = set.iterator();
		return iterator;
	}

	/**
	 * Handle a service modification.  The service for the specified
	 * <code>ServiceReference</code> has modified it registered service
	 * properties.  When this happens, the ServiceReference is compared to the
	 * current filter, and if they do not match the service is treated as
	 * unregistering.
	 *
	 * @param reference  The <code>ServiceReference</code> of the modified
	 *                   service.
	 */
	private void handleServiceModified(ServiceReference reference) {
		Map/*<ServiceReference, Object>*/ map = getServicesMap();
		Object service;

		synchronized (map) {
			service = map.get(reference);
		}

		if (service == null) {
			handleServiceRegistered(reference);
		} else {
			boolean match = isMatchingService(reference);
			if (match == true)
				return;  // Early return.
			handleServiceUnregistering(reference);
		}
	}

	/**
	 * Handle a service registration.  The service for the specified
	 * <code>ServiceReference</code> has been registered with the framework.
	 * When this happens, the <code>ServiceReference</code> is compared to the
	 * current filter and if they match the service is added.
	 *
	 * @param reference  The <code>ServiceReference</code> of the registered
	 *                   service.
	 */
	private void handleServiceRegistered(ServiceReference reference) {
		Map/*<ServiceReference, Object>*/ map = getServicesMap();

		synchronized (map) {
			boolean exists = map.containsKey(reference);
			if (exists == true)
				return;  // Early return.
			boolean match = isMatchingService(reference);
			if (match == false)
				return;  // Early return.
			BundleContext bundleContext = getBundleContext();
			Object service = bundleContext.getService(reference);
			map.put(reference, service);
			registerBundleRelationship(reference);
			notifyListenersOfServiceAdded(reference, service);
		}
	}

	/**
	 * Handle a service unregistering.  The service for the specified
	 * <code>ServiceReference</code> is in the process of unregistering with the
	 * framework.  When this happens, the <code>ServiceReference</code> is
	 * removed.
	 *
	 * @param reference  The <code>ServiceReference</code> of the unregistering
	 *                   service.
	 */
	private void handleServiceUnregistering(ServiceReference reference) {
		Map/*<ServiceReference, Object>*/ map = getServicesMap();

		synchronized (map) {
			boolean exists = map.containsKey(reference);
			if (exists == false)
				return;  // Early return.
			Object service = map.remove(reference);
			unregisterBundleRelationship(reference);
			notifyListenersOfServiceRemoved(reference, service);
			BundleContext bundleContext = getBundleContext();
			try {
				bundleContext.ungetService(reference);
			} catch (IllegalStateException exception) {
				// BundleContext is disposed.
			}
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceDetecter#isAcquired()
	 */
	public boolean isAcquired() {
		Object lock = getAcquireLock();

		synchronized (lock) {
			return acquired;
		}
	}

	/**
	 * Query whether the specified <code>ServiceReference</code> matches the
	 * filter.  If the filter is <code>null</code>, a non-null
	 * <code>ServiceReference</code> always matches.  A <code>null</code>
	 * <code>ServiceReference</code> never matches.
	 *
	 * @param reference  A ServiceReference
	 * @return boolean
	 */
	private boolean isMatchingService(ServiceReference reference) {
		boolean match = reference != null;
		Filter filter = getFilter();

		if (filter != null) {
			match = filter.match(reference);
		}

		return match;
	}

	/**
	 * Get the <code>ServiceReference</code> objects for the registered services
	 * and attempt to add them to the <code>ServiceDetecter</code>.  A
	 * <code>ServiceReference</code> is only added if it matches the filter.
	 */
	private void loadServiceMap() {
		BundleContext bundleContext = getBundleContext();

		try {
			String name = getName();
			ServiceReference[] references = bundleContext.getServiceReferences(name, null);
			if (references == null)
				return;  // Early return.

			for (int i = 0; i < references.length; i++) {
				ServiceReference reference = references [ i ];
				serviceChanged(ServiceEvent.REGISTERED, reference);
			}
		} catch (InvalidSyntaxException exception) {
			String message = exception.getMessage();
			LogUtility.logError(this, message, exception);
		}
	}

	/**
	 * Notify registered listeners that a service was added.
	 *
	 * @param reference  The <code>ServiceReference</code> of the added service.
	 * @param service    The service that was added.
	 */
	private void notifyListenersOfServiceAdded(ServiceReference reference, Object service) {
		List/*<ServiceDetecterListener>*/ listeners = getListeners();

		synchronized (listeners) {
			Iterator/*<ServiceDetecterListener>*/ iterator = listeners.iterator();

			while (iterator.hasNext() == true) {
				ServiceDetecterListener listener = (ServiceDetecterListener) iterator.next();
				listener.serviceAdded(this, reference, service);
			}
		}
	}

	/**
	 * Notify registered listeners that a service was removed.
	 *
	 * @param reference  The <code>ServiceReference</code> of the removed
	 *                   service.
	 * @param service    The service that was removed.
	 */
	private void notifyListenersOfServiceRemoved(ServiceReference reference, Object service) {
		List/*<ServiceDetecterListener>*/ listeners = getListeners();

		synchronized (listeners) {
			Iterator/*<ServiceDetecterListener>*/ iterator = listeners.iterator();

			while (iterator.hasNext() == true) {
				ServiceDetecterListener listener = (ServiceDetecterListener) iterator.next();
				listener.serviceRemoved(this, reference, service);
			}
		}
	}

	/**
	 * Registers the importer bundle and the exporter bundle relationship.
	 *
	 * @param reference  A <code>ServiceReference</code>.
	 */
	private void registerBundleRelationship(ServiceReference reference) {
		Bundle importer = getBundle();
		if (importer == null)
			return;
		Bundle exporter = reference.getBundle();
		if (exporter == null)
			return;
		BundleDependencyManager manager = BundleDependencyManager.getInstance();
		manager.register(importer, exporter);
	}

	/**
	 * Register the <code>ServiceListener</code> with the framework for tracking
	 * the services that are registered, unregistering and modified.
	 */
	private void registerServiceListener() {
		BundleContext bundleContext = getBundleContext();
		ServiceListener listener = getServiceListener();
		String serviceFilter = createServiceFilter();

		try {
			bundleContext.addServiceListener(listener, serviceFilter);
		} catch (InvalidSyntaxException exception) {
			String message = exception.getMessage();
			LogUtility.logError(this, message, exception);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceDetecter#release()
	 */
	public void release() {
		Object lock = getAcquireLock();

		synchronized (lock) {
			boolean acquired = isAcquired();
			if (acquired == false)
				return;  // Early return.
			unloadServiceMap();
			unregisterServiceListener();
			setAcquired(false);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceDetecter#removeServiceDetecterListener(org.eclipse.soda.sat.core.record.interfaces.ServiceDetecterListener)
	 */
	public void removeServiceDetecterListener(ServiceDetecterListener listener) {
		List/*<ServiceDetecterListener>*/ listeners = getListeners();

		synchronized (listeners) {
			listeners.remove(listener);
		}
	}

	/**
	 * A service of the appropriate type has changed and needs to be handled.
	 *
	 * @param type       The type of service change.  A service can be
	 *                   registered, unregistering or modified.
	 * @param reference  A <code>ServiceReference</code>.
	 *
	 * @see ServiceEvent
	 */
	private void serviceChanged(int type, ServiceReference reference) {
		boolean acquired = isAcquired();
		if (acquired == false)
			return;  // Early return.

		switch (type) {
			case ServiceEvent.REGISTERED:
				handleServiceRegistered(reference);
				break;
			case ServiceEvent.UNREGISTERING:
				handleServiceUnregistering(reference);
				break;
			case ServiceEvent.MODIFIED:
				handleServiceModified(reference);
				break;
			default:
				break;
		}
	}

	/**
	 * Private <code>acquired</code> setter.
	 *
	 * @param acquired  True if the detecter is acquired, otherwise false.
	 */
	private void setAcquired(boolean acquired) {
		this.acquired = acquired;
	}

	/**
	 * Private <code>bundleContext</code> setter.
	 *
	 * @param bundleContext  The bundle's <code>BundleContext</code>.
	 */
	private void setBundleContext(BundleContext bundleContext) {
		Assertion.checkArgumentIsNotNull(bundleContext, "bundleContext");  //$NON-NLS-1$
		this.bundleContext = bundleContext;
	}

	/**
	 * Private filter setter.  If the ServiceDetecter already has an
	 * owner, this method has the side effect of applying the new filter to
	 * the existing services.  Passing null to this method removes a previously
	 * specified filter.
	 *
	 * @param filter  A <code>Filter</code> or <code>null</code>.
	 */
	private void setFilter(Filter filter) {
		synchronized (this) {
			if (this.filter != null && this.filter.equals(filter))
				return;  // Early return.
			this.filter = filter;
			applyFilter();
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceDetecter#setFilter(String)
	 */
	public void setFilter(String filter) throws InvalidSyntaxException {
		BundleContext bundleContext = getBundleContext();
		Filter importFilter = null;

		if (filter != null) {
			importFilter = bundleContext.createFilter(filter);
		}

		setFilter(importFilter);
	}

	/**
	 * Private <code>listeners</code> setter.
	 *
	 * @param listeners  The listeners.
	 */
	private void setListeners(List/*<ServiceDetecterListener>*/ listeners) {
		this.listeners = listeners;
	}

	/**
	 * Private <code>name</code> setter.
	 *
	 * @param name  The service name.
	 */
	private void setName(String name) {
		this.name = name;
	}

	/**
	 * Private <code>serviceListener</code> setter.
	 *
	 * @param serviceListener  A ServiceListener.
	 */
	private void setServiceListener(ServiceListener serviceListener) {
		this.serviceListener = serviceListener;
	}

	private void setServiceRankingComparator(Comparator serviceComparator) {
		serviceRankingComparator = serviceComparator;
	}

	/**
	 * Private <code>servicesMap</code> setter.
	 *
	 * @param servicesMap  A <code>Map</code>.
	 */
	private void setServicesMap(Map/*<ServiceReference, Object>*/ servicesMap) {
		this.servicesMap = servicesMap;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public final String toString() {
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(100);
		buffer.append(super.toString());

		String name = getName();
		buffer.append(", name=");  //$NON-NLS-1$
		buffer.append(name);

		Filter filter = getFilter();
		buffer.append(", filter=");  //$NON-NLS-1$
		buffer.append(filter);

		String description = buffer.toString();
		return description;
	}

	/**
	 * Unload the loaded services.
	 */
	private void unloadServiceMap() {
		Object lock = getServicesMap();

		synchronized (lock) {
			Iterator/*<ServiceReference>*/ iterator = getServicesMapKeyIterator();

			while (iterator.hasNext() == true) {
				ServiceReference serviceReference = (ServiceReference) iterator.next();
				serviceChanged(ServiceEvent.UNREGISTERING, serviceReference);
			}
		}
	}

	/**
	 * Unregisters the importer bundle and the exporter bundle relationship.
	 *
	 * @param reference  A ServiceReference.
	 */
	private void unregisterBundleRelationship(ServiceReference reference) {
		Bundle importer = getBundle();
		if (importer == null)
			return;
		Bundle exporter = reference.getBundle();
		if (exporter == null)
			return;
		BundleDependencyManager manager = BundleDependencyManager.getInstance();
		manager.unregister(importer, exporter);
	}

	/**
	 * Unregisters the ServiceListener.
	 */
	private void unregisterServiceListener() {
		BundleContext bundleContext = getBundleContext();
		ServiceListener listener = getServiceListener();
		bundleContext.removeServiceListener(listener);
	}
}
