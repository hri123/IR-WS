/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.record;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Dictionary;

import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.framework.interfaces.IProxyServiceHandler;
import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.record.interfaces.IExportProxyServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IServiceRecord;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

/**
 * The <code>ExportProxyServiceRecord</code> class models a service that is
 * exported by a bundle and registered with the OSGi framework, but only created
 * when needed by an importing bundle.  Proxy exported services are should
 * probably be used only as high performance startup strategy.  The class
 * extends <code>ServiceRecordDelegate</code> and is an implementation of the
 * <code>IExportProxyServiceRecord</code> interface.
 */
public final class ExportProxyServiceRecord extends ServiceRecordDelegate implements IExportProxyServiceRecord {
	//
	// Nested Types
	//

	private class ExportedServiceInvocationHandler extends Object implements InvocationHandler {
		private Object getRealService() {
			Object service = ExportProxyServiceRecord.this.getRealService();
			return service;
		}

		/**
		 * @see java.lang.reflect.InvocationHandler#invoke(java.lang.Object, java.lang.reflect.Method, java.lang.Object[])
		 */
		public Object invoke(Object service, Method method, Object[] args) throws Throwable { // $codepro.audit.disable declaredExceptions
			Object result = ExportProxyServiceRecord.this.invoke(method, args);
			return result;
		}
	}

	//
	// Static Fields
	//

	// Externalized Strings
	private static final String FAILED_TO_CREATE_PROXY_KEY = "ExportProxyServiceRecord.FailedToCreateProxy";  //$NON-NLS-1$
	private static final String INTERFACE_CLASSES_KEY = "ExportProxyServiceRecord.InterfaceClasses";  //$NON-NLS-1$
	private static final String UNRECOGNIZED_INVOCATION_HANDLER_KEY = "ExportProxyServiceRecord.UnrecognizedInvocationHandler";  //$NON-NLS-1$

	// Misc
	private static final String EQUALS_METHOD = "equals";  //$NON-NLS-1$

	/**
	 * Unwrap the specified service proxy.
	 *
	 * @param serviceProxy  A service proxy.
	 * @return The unwrapped service.
	 * @throws IllegalArgumentException is thrown if the parameter is not a
	 * <code>Proxy</code>, or if the parameters is not a proxy for an exported
	 * service.
	 *
	 * @see org.eclipse.soda.sat.core.util.MiscUtility#unwrapExportedServiceProxy(Object)
	 */
	public static Object unwrapProxy(Object serviceProxy) throws IllegalArgumentException {
		Assertion.checkArgumentIsNotNull(serviceProxy, "serviceProxy");  //$NON-NLS-1$
		InvocationHandler handler = Proxy.getInvocationHandler(serviceProxy);
		boolean valid = handler instanceof ExportedServiceInvocationHandler; // $codepro.audit.disable disallowInstanceof

		if (valid == false) {
			String pattern = Messages.getString(ExportProxyServiceRecord.UNRECOGNIZED_INVOCATION_HANDLER_KEY);
			String message = MessageFormatter.format(pattern, handler);
			throw new IllegalArgumentException(message);
		}

		ExportedServiceInvocationHandler exportedServiceInvocationHandler = (ExportedServiceInvocationHandler) handler;
		Object realService = exportedServiceInvocationHandler.getRealService();
		return realService;
	}

	//
	// Instance Fields
	//

	private BundleContext bundleContext;
	private IProxyServiceHandler handler;
	private Object realService;

	//
	// Constructors
	//

	/**
	 * Public constructor.
	 *
	 * @param bundleContext   The BundleContext handle back to the framework.
	 * @param interfaceTypes  The interface types of the exported service.
	 * @param handler         The IProxyServiceHandler.
	 * @param properties      The properties of the exported service.
	 */
	public ExportProxyServiceRecord(BundleContext bundleContext, Class[] interfaceTypes, IProxyServiceHandler handler, Dictionary properties) {
		super();
		setBundleContext(bundleContext);
		setHandler(handler);
		IExportServiceRecord record = createExportServiceRecord(bundleContext, interfaceTypes, properties);
		setServiceRecord(record);
	}

	//
	// Instance Methods
	//

	/**
	 * Private basic realService getter.  This method is needed, since
	 * <code>getRealService()</code> causes the real service to be
	 * created if it does not exist.
	 *
	 * @return The real service, or <code>null</code>.
	 */
	private Object basicGetRealService() {
		synchronized (this) {
			return realService;
		}
	}

	/**
	 * Create the <code>ClassLoader</code> that will be used to create the
	 * proxy service.
	 *
	 * @return A bundle proxy class loader.
	 */
	private ClassLoader createClassLoader() {
		ClassLoader classLoader = null;
		Bundle bundle = getBundle();
		if (bundle != null) {
			classLoader = new BundleProxyClassLoader(bundle);
		}
		return classLoader;
	}

	/**
	 * Create the contained export service record for the proxy service.
	 *
	 * @param bundleContext  The BundleContext handle back to the framework.
	 * @param interfaceTypes The interface types of the exported service.
	 * @param properties     The properties of the exported service.
	 *
	 * @return  The export service record for the proxy service.
	 */
	private IExportServiceRecord createExportServiceRecord(BundleContext bundleContext, Class[] interfaceTypes, Dictionary properties) {
		String[] names = getServiceInterfaceNames(interfaceTypes);
		Object service = createProxyService(interfaceTypes);
		IExportServiceRecord record = createExportServiceRecord(bundleContext, names, service, properties);
		return record;
	}

	/**
	 * Create the contained export service record for the proxy service.
	 *
	 * @param bundleContext  The BundleContext handle back to the framework.
	 * @param names          The service names of the exported service.
	 * @param service        The exported service, a proxy.
	 * @param properties     The properties of the exported service.
	 *
	 * @return  The export service record for the proxy service.
	 */
	private IExportServiceRecord createExportServiceRecord(BundleContext bundleContext, String[] names, Object service, Dictionary properties) {
		FactoryUtility utility = FactoryUtility.getInstance();
		IExportServiceRecord record = utility.createExportServiceRecord(bundleContext, names, service, properties);
		return record;
	}

	/**
	 * Create the proxy service.
	 *
	 * @param interfaceTypes  The interface types of the exported service.
	 *
	 * @return The created proxy service.
	 */
	private Object createProxyService(Class[] interfaceTypes) {
		Assertion.checkArgumentIsNotNull(interfaceTypes, "interfaceTypes");  //$NON-NLS-1$
		ClassLoader loader = createClassLoader();
		InvocationHandler handler = new ExportedServiceInvocationHandler();
		try {
			Object service = Proxy.newProxyInstance(loader, interfaceTypes, handler);
			return service;
		} catch (NoClassDefFoundError exception) {
			logFailedToCreateProxyService(interfaceTypes, exception);
			throw exception; // $codepro.audit.disable thrownExceptions
		}
	}

	/**
	 * Create the real service.
	 *
	 * @return Object
	 */
	private Object createRealService() {
		IProxyServiceHandler handler = getHandler();
		Object service = handler.createService();
		return service;
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.record.ServiceRecordDelegate#createToStringBufferSize()
	 */
	protected int createToStringBufferSize() {
		return super.createToStringBufferSize() + 100;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IServiceRecord#getBundleContext()
	 */
	public BundleContext getBundleContext() {
		return bundleContext;
	}

	/**
	 * Get the export service record.  This method simply calls the inherited
	 * method <code>getServiceRecord()</code>, casting the result to
	 * <code>IExportServiceRecord</code>.
	 *
	 * @return The export service record.
	 */
	private IExportServiceRecord getExportServiceRecord() {
		IServiceRecord record = getServiceRecord();
		IExportServiceRecord exportServiceRecord = (IExportServiceRecord) record;
		return exportServiceRecord;
	}

	/**
	 * Private <code>handler</code> getter.
	 *
	 * @return The proxy service handler.
	 */
	private IProxyServiceHandler getHandler() {
		return handler;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord#getNames()
	 */
	public String[] getNames() {
		IExportServiceRecord record = getExportServiceRecord();
		String[] names = record.getNames();
		return names;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord#getProperties()
	 */
	public Dictionary getProperties() {
		IExportServiceRecord record = getExportServiceRecord();
		Dictionary properties = record.getProperties();
		return properties;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportProxyServiceRecord#getRealService()
	 */
	public Object getRealService() {
		synchronized (this) {
			Object service = basicGetRealService();
			if (service == null) {
				service = createRealService();
				setRealService(service);
			}

			return realService;
		}
	}

	/**
	 * Query the service interface names.
	 *
	 * @param interfaceTypes  The interface types of the exported service.
	 *
	 * @return An array containing the service interface names.
	 */
	private String[] getServiceInterfaceNames(Class[] interfaceTypes) {
		Assertion.checkArgumentIsNotNull(interfaceTypes, "interfaceTypes");  //$NON-NLS-1$
		Assertion.checkArrayIsNotEmpty(interfaceTypes, "interfaceTypes");  //$NON-NLS-1$

		int count = interfaceTypes.length;
		String[] names = new String [ count ];

		for (int i = 0; i < count; i++) {
			Class interfaceType = interfaceTypes [ i ];
			String name = interfaceType.getName();
			names [ i ] = name;
		}

		return names;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord#getServiceReference()
	 */
	public ServiceReference getServiceReference() {
		IExportServiceRecord record = getExportServiceRecord();
		ServiceReference reference = record.getServiceReference();
		return reference;
	}

	/**
	 * Handle an exception thrown by invoking the proxy service's method.
	 *
	 * @param exception  An exception.
	 * @return The target exception.
	 * @throws Throwable
	 */
	private Throwable handleException(Throwable exception) throws Throwable { // $codepro.audit.disable declaredExceptions
		boolean rethrow = exception instanceof InvocationTargetException == false; // $codepro.audit.disable disallowInstanceof

		if (rethrow == true) {
			String message = exception.getMessage();
			LogUtility.logError(message, exception);
			throw exception;  // $codepro.audit.disable thrownExceptions
		}

		InvocationTargetException invocationTargetException = (InvocationTargetException) exception;
		Throwable throwable = invocationTargetException.getTargetException();
		return throwable;
	}

	/**
	 * Handler for proxy services.  This method invokes the requested
	 * method against the proxy service, passing the arguments and returning
	 * the result.
	 *
	 * @param method   The <code>Method</code> to invoke against the proxy
	 *                 service.
	 * @param args     The method arguments.
	 * @throws Throwable
	 * @return The result of invoking the specified <code>Method</code> object.
	 */
	private Object invoke(Method method, Object[] args) throws Throwable { // $codepro.audit.disable declaredExceptions
		Object result = null;
		Throwable throwable = null;
		Object data = preInvoke(method, args);

		try {
			boolean isEqualsMethod = isEqualsMethod(method, args);
			if (isEqualsMethod == true) {
				Object parameter = args [ 0 ];
				result = invokeEquals(parameter);
			}

			if (result == null) {
				Object service = getRealService();
				result = method.invoke(service, args); // $codepro.audit.disable com.instantiations.assist.eclipse.analysis.audit.rule.preferInterfacesToReflection
			}
		} catch (Throwable exception) {
			throwable = handleException(exception);
		} finally {
			postInvoke(method, args, throwable, data);
		}

		if (throwable != null) {
			throw throwable;  // $codepro.audit.disable thrownExceptions
		}

		return result;
	}

	private Object invokeEquals(Object parameter) {
		if (parameter == null)
			return null;  // Early return.
		Object object;

		try {
			object = ExportProxyServiceRecord.unwrapProxy(parameter);
		} catch (IllegalArgumentException exception) {
			// Either the parameter is not a Proxy, or its InvocationHandler was
			// not recognized, meaning that the Proxy was not created by the
			// ExportedServiceRecord class.
			return null;  // Early return.
		}

		Object service = getRealService();
		boolean equal = service.equals(object);
		Object result = equal == true ? Boolean.TRUE : Boolean.FALSE;
		return result;
	}

	private boolean isEqualsMethod(Method method, Object[] args) {
		if (args == null || args.length != 1)
			return false;  // Early return.
		String name = method.getName();
		boolean match = name.equals(ExportProxyServiceRecord.EQUALS_METHOD);
		return match;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord#isProxy()
	 */
	public boolean isProxy() {
		return true;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord#isRegistered()
	 */
	public boolean isRegistered() {
		IExportServiceRecord record = getExportServiceRecord();
		boolean registered = record.isRegistered();
		return registered;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportProxyServiceRecord#isServiceCreated()
	 */
	public boolean isServiceCreated() {
		Object service = basicGetRealService();
		boolean created = service != null;
		return created;
	}

	private void logFailedToCreateProxyService(Class[] interfaceClasses, Throwable exception) {
		Object id = this;
		Bundle bundle = getBundle();
		if (bundle != null) {
			id = bundle.getSymbolicName();
		}

		char newLine = '\n';
		String indent = "  "; //$NON-NLS-1$

		String exceptionMessage = exception.getMessage();
		String pattern = Messages.getString(ExportProxyServiceRecord.FAILED_TO_CREATE_PROXY_KEY);
		String message = MessageFormatter.format(pattern, exceptionMessage);

		int spaceForInterfaceClasses = interfaceClasses.length * 25;
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(75 + spaceForInterfaceClasses);

		buffer.append(message);
		buffer.append(newLine);
		buffer.append(indent);

		String label = Messages.getString(ExportProxyServiceRecord.INTERFACE_CLASSES_KEY);
		buffer.append(label);

		for (int i = 0; i < interfaceClasses.length; i++) {
			buffer.append(newLine);
			buffer.append(indent);
			buffer.append(indent);
			Class interfaceClass = interfaceClasses [ i ];
			String name = interfaceClass.getName();
			buffer.append(name);
		}

		message = buffer.toString();
		LogUtility.logError(id, message);
	}

	/**
	 * This method is called after calling the service method on the proxy.
	 *
	 * @param method     The <code>Method</code> object representing the service
	 *                   method that was called.
	 * @param args       The arguments that were passed to the service method.
	 * @param throwable  The exception that was thrown by the service method, or
	 *                   <code>null</code>
	 * @param data       Handler specific data that was returned by the method
	 *                   <code>preInvoke</code>.
	 */
	private void postInvoke(Method method, Object[] args, Throwable throwable, Object data) {
		IProxyServiceHandler handler = getHandler();
		Object service = getRealService();

		try {
			handler.postInvoke(service, method, args, throwable, data);
		} catch (Throwable exception) {
			String message = exception.getMessage();
			LogUtility.logError(message, exception);
		}
	}

	/**
	 * This method is called <i>before</i> calling the service method on the
	 * proxy.
	 *
	 * @param method  The <code>Method</code> object representing the service
	 *                method that will be called.
	 * @param args    The arguments that will be passed to the service method.
	 * @return Handler specific data that will be passed into the method
	 *         <code>postInvoke</code>
	 */
	private Object preInvoke(Method method, Object[] args) {
		Object result = null;
		IProxyServiceHandler handler = getHandler();
		Object service = getRealService();

		try {
			result = handler.preInvoke(service, method, args);
		} catch (Throwable exception) {
			String message = exception.getMessage();
			LogUtility.logError(message, exception);
		}

		return result;
	}

	/**
	 * Print the handler on the specified <code>StringBuffer</code>.
	 *
	 * @param buffer  The buffer on which to write.
	 */
	private void printHandlerOn(StringBuffer buffer) {
		Object handler = getHandler();
		buffer.append(", handler=");  //$NON-NLS-1$
		buffer.append(handler);
	}

	/**
	 * @see org.eclipse.soda.sat.core.internal.record.ServiceRecordDelegate#printOn(java.lang.StringBuffer)
	 */
	protected void printOn(StringBuffer buffer) {
		super.printOn(buffer);
		printHandlerOn(buffer);
		printServiceOn(buffer);
		printRealServiceOn(buffer);
	}

	/**
	 * Print the real service, if created, otherwise <code>null</code>, on the
	 * specified buffer.
	 *
	 * @param buffer  The buffer on which to write.
	 */
	private void printRealServiceOn(StringBuffer buffer) {
		buffer.append(", realService=");  //$NON-NLS-1$
		boolean created = isServiceCreated();
		Object realService = created == true ? getRealService() : null;
		buffer.append(realService);
	}

	/**
	 * Print the service on the specified <code>StringBuffer</code>.
	 *
	 * @param buffer  The buffer on which to write.
	 */
	private void printServiceOn(StringBuffer buffer) {
		Object service = getService();
		buffer.append(", service=");  //$NON-NLS-1$
		printOn(buffer, service);
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord#register()
	 */
	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord#register()
	 */
	public void register() {
		IExportServiceRecord record = getExportServiceRecord();
		record.register();
	}

	/**
	 * Private <code>bundleContext</code> setter.
	 *
	 * @param bundleContext  The proxy service's <code>BundleContext</code>.
	 */
	private void setBundleContext(BundleContext bundleContext) {
		this.bundleContext = bundleContext;
	}

	/**
	 * Private <code>handler</code> setter.
	 *
	 * @param handler  A proxy service handler.
	 */
	private void setHandler(IProxyServiceHandler handler) {
		Assertion.checkArgumentIsNotNull(handler, "handler");  //$NON-NLS-1$
		this.handler = handler;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord#setProperties(java.util.Dictionary)
	 */
	public void setProperties(Dictionary properties) {
		IExportServiceRecord record = getExportServiceRecord();
		record.setProperties(properties);
	}

	/**
	 * Private <code>realService</code> setter.
	 *
	 * @param realService  The real service.
	 */
	private void setRealService(Object realService) {
		this.realService = realService;
	}

	/**
	 * @see org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord#unregister()
	 */
	public void unregister() {
		IExportServiceRecord record = getExportServiceRecord();
		record.unregister();
	}
}

