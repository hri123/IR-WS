/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.util;

import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.internal.record.ExportProxyServiceRecord;

/**
 * Miscellaneous utilities.
 */
public class MiscUtility extends Object {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String CANNOT_CONVERT_TO_PRIMITIVE_KEY = "MiscUtility.CannotConvertToPrimitive";  //$NON-NLS-1$

	// Singleton
	private static final MiscUtility INSTANCE = new MiscUtility();


	//
	// Static Methods
	//

	/**
	 * Public getter for the <code>MiscUtility</code> singleton instance.
	 *
	 * @return <code>MiscUtility</code>
	 */
	public static MiscUtility getInstance() {
		return MiscUtility.INSTANCE;
	}

	/**
	 * Constructor.
	 */
	private MiscUtility() {
		super();
	}

	//
	// Static Methods
	//

	/**
	 * Get the specified <code>boolean</code> property.
	 *
	 * @param key           A property key.
	 * @param defaultValue  The default property value.
	 * @return The property value.
	 */
	public boolean getBooleanProperty(String key, boolean defaultValue) {
		Assertion.checkArgumentIsNotNull(key, "key");  //$NON-NLS-1$
		boolean value = defaultValue;
		String propertyValue =  System.getProperty(key);

		if (propertyValue != null) {
			if (propertyValue.equalsIgnoreCase(Boolean.TRUE.toString())) {
				value = true;
			} else if (propertyValue.equalsIgnoreCase(Boolean.FALSE.toString())) {
				value = false;
			} else {
				String type = boolean.class.getName();
				logCannotConvertToPrimitiveError(key, propertyValue, type);
			}
		}

		return value;
	}

	/**
	 * Get the specified <code>int</code> property.
	 *
	 * @param key           A property key, never <code>null</code>.
	 * @param defaultValue  The default property value.
	 * @return The property value.
	 */
	public int getIntProperty(String key, int defaultValue) {
		Assertion.checkArgumentIsNotNull(key, "key");  //$NON-NLS-1$
		int value = defaultValue;
		String propertyValue =  System.getProperty(key);

		if (propertyValue != null) {
			try {
				value = Integer.valueOf(propertyValue, 10).intValue();
			} catch (NumberFormatException exception) {
				String type = int.class.getName();
				logCannotConvertToPrimitiveError(key, propertyValue, type);
			}
		}

		return value;
	}

	/**
	 * Get the specified <code>long</code> property.
	 *
	 * @param key           A property key, never <code>null</code>.
	 * @param defaultValue  The default property value.
	 * @return The property value.
	 */
	public long getLongProperty(String key, long defaultValue) {
		Assertion.checkArgumentIsNotNull(key, "key");  //$NON-NLS-1$
		long value = defaultValue;
		String propertyValue =  System.getProperty(key);

		if (propertyValue != null) {
			try {
				value = Long.valueOf(propertyValue, 10).longValue();
			} catch (NumberFormatException exception) {
				String type = long.class.getName();
				logCannotConvertToPrimitiveError(key, propertyValue, type);
			}
		}

		return value;
	}

	private void logCannotConvertToPrimitiveError(String key, String value, String type) {
		String pattern = Messages.getString(MiscUtility.CANNOT_CONVERT_TO_PRIMITIVE_KEY);
		Object[] values = new Object[] {
			key,
			value,
			type
		};
		String message = MessageFormatter.format(pattern, values);
		LogUtility.logError(this, message);
	}

	/**
	 * Unwrap the specified exported service proxy.
	 *
	 * @param serviceProxy  A service proxy.
	 * @return The unwrapped service.
	 * @throws IllegalArgumentException is thrown if the parameter is not a
	 * <code>Proxy</code>, or if the parameters is not a proxy for an exported
	 * service.
	 *
	 * @see org.eclipse.soda.sat.core.internal.record.ExportProxyServiceRecord#unwrapProxy(Object)
	 */
	public Object unwrapExportedServiceProxy(Object serviceProxy) throws IllegalArgumentException {
		Object object = ExportProxyServiceRecord.unwrapProxy(serviceProxy);
		return object;
	}
}
