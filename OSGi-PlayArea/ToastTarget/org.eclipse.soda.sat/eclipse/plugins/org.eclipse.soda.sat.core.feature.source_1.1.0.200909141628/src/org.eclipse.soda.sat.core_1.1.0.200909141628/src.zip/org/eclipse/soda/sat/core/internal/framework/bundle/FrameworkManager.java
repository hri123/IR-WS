/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle;

import org.eclipse.soda.sat.core.internal.nls.Messages;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.eclipse.soda.sat.core.util.MiscUtility;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkEvent;
import org.osgi.framework.FrameworkListener;

/**
 * FrameworkManager.java
 */
class FrameworkManager extends Object {
	//
	// Static Fields
	//

	// Property Keys
	private static final String LOG_EVENTS_PROPERTY = "org.eclipse.soda.sat.core.internal.framework.log.events";  //$NON-NLS-1$

	// Default Property Values
	private static final boolean DEFAULT_LOG_EVENTS = true;

	// Properties
	private static final boolean LOG_EVENTS = FrameworkManager.getBooleanProperty(FrameworkManager.LOG_EVENTS_PROPERTY, FrameworkManager.DEFAULT_LOG_EVENTS);

	// Externalized String Keys
	private static final String FRAMEWORK_ERROR_EVENT_HAS_OCCURRED_KEY = "FrameworkManager.ErrorEventOccurred";  //$NON-NLS-1$
	private static final String FRAMEWORK_INFO_EVENT_HAS_OCCURRED_KEY = "FrameworkManager.InfoEventOccurred";  //$NON-NLS-1$
	private static final String FRAMEWORK_WARNING_EVENT_HAS_OCCURRED_KEY = "FrameworkManager.WarningEventOccurred";  //$NON-NLS-1$
	private static final String UNKNOWN_BUNDLE_CONTEXT_KEY = "Common.UnknownBundleContext";  //$NON-NLS-1$
	private static final String UNKNOWN_FRAMEWORK_EVENT_KEY = "FrameworkManager.UnknownFrameworkEvent";  //$NON-NLS-1$

	// Singleton
	private static final FrameworkManager INSTANCE = new FrameworkManager();

	//
	// Static Methods
	//

	private static boolean getBooleanProperty(String key, boolean defaultValue) {
		MiscUtility utility = MiscUtility.getInstance();
		boolean value = utility.getBooleanProperty(key, defaultValue);
		return value;
	}

	/**
	 * Answers the <code>FrameworkManager</code> singleton instance.
	 *
	 * @return FrameworkManager
	 */
	static FrameworkManager getInstance() {
		return FrameworkManager.INSTANCE;
	}

	//
	// Instance Fields
	//

	private BundleContext bundleContext;
	private FrameworkListener frameworkListener;

	//
	// Constructors
	//

	/**
	 * Private constructor.
	 */
	private FrameworkManager() {
		super();
		setFrameworkListener(createFrameworkListener());
	}

	//
	// Instance Methods
	//

	private void checkBundleContextIsNotNull(BundleContext bundleContext) {
		Assertion.checkArgumentIsNotNull(bundleContext, "bundleContext");  //$NON-NLS-1$
	}

	private void checkShutdownIsAllowed(BundleContext bundleContext) {
		BundleContext bc = getBundleContext();
		if (bundleContext.equals(bc) == true)
			return;  // Early return.
		String message = Messages.getString(FrameworkManager.UNKNOWN_BUNDLE_CONTEXT_KEY);
		throw new IllegalArgumentException(message);
	}

	/**
	 * Create the manager's FrameworkListener.
	 *
	 * @return FrameworkListener.
	 */
	private FrameworkListener createFrameworkListener() {
		return new FrameworkListener() {
			public void frameworkEvent(FrameworkEvent event) {
				FrameworkManager.this.frameworkEvent(event);
			}
		};
	}

	/**
	 * Handle the specified framework event.
	 *
	 * @param event  A FrameworkEvent.
	 */
	private void frameworkEvent(FrameworkEvent event) {
		if (FrameworkManager.LOG_EVENTS == false)
			return;  // Early return.
		int type = event.getType();
		switch (type) {
		case FrameworkEvent.STARTED:
			break;
		case FrameworkEvent.ERROR:
			logFrameworkErrorEvent(event);
			break;
		case FrameworkEvent.PACKAGES_REFRESHED:
			break;
		case FrameworkEvent.STARTLEVEL_CHANGED:
			break;
		case FrameworkEvent.WARNING:
			logFrameworkWarningEvent(event);
			break;
		case FrameworkEvent.INFO:
			logFrameworkInfoEvent(event);
			break;
		default:
			logUnknownFrameworkEvent(event);
			break;
		}
	}

	/**
	 * Private <code>bundleContext</code> getter.
	 *
	 * @return BundleContext
	 */
	private BundleContext getBundleContext() {
		return bundleContext;
	}

	/**
	 * Private frameworkListener getter.
	 *
	 * @return The FrameworkListener.
	 */
	private FrameworkListener getFrameworkListener() {
		return frameworkListener;
	}

	/**
	 * Hooks up the <code>FrameworkListener</code>.
	 */
	private void hookupFrameworkListener() {
		BundleContext bundleContext = getBundleContext();
		FrameworkListener listener = getFrameworkListener();
		bundleContext.addFrameworkListener(listener);
	}

	/**
	 * Answers true if the <code>BundleDependencyManager</code> is started,
	 * otherwise false.
	 *
	 * @return boolean
	 */
	private boolean isStarted() {
		BundleContext bundleContext = getBundleContext();
		boolean started = bundleContext != null;
		return started;
	}

	/**
	 * Log the framework error.
	 *
	 * @param event  The framework event.
	 */
	private void logFrameworkErrorEvent(FrameworkEvent event) {
		String pattern = Messages.getString(FrameworkManager.FRAMEWORK_ERROR_EVENT_HAS_OCCURRED_KEY);
		Object bundle = event.getBundle();
		String message = MessageFormatter.format(pattern, bundle);
		Throwable throwable = event.getThrowable();
		LogUtility.logError(this, message, throwable);
	}

	/**
	 * Log the framework error.
	 *
	 * @param event  The framework event.
	 */
	private void logFrameworkInfoEvent(FrameworkEvent event) {
		String pattern = Messages.getString(FrameworkManager.FRAMEWORK_INFO_EVENT_HAS_OCCURRED_KEY);
		Object bundle = event.getBundle();
		String message = MessageFormatter.format(pattern, bundle);
		Throwable throwable = event.getThrowable();
		LogUtility.logInfo(this, message, throwable);
	}

	/**
	 * Log the framework warning.
	 *
	 * @param event  The framework event.
	 */
	private void logFrameworkWarningEvent(FrameworkEvent event) {
		String pattern = Messages.getString(FrameworkManager.FRAMEWORK_WARNING_EVENT_HAS_OCCURRED_KEY);
		Object bundle = event.getBundle();
		String message = MessageFormatter.format(pattern, bundle);
		Throwable throwable = event.getThrowable();
		LogUtility.logWarning(this, message, throwable);
	}

	/**
	 * Log the unknown framework event as an error.
	 *
	 * @param event  The framework event.
	 */
	private void logUnknownFrameworkEvent(FrameworkEvent event) {
		String pattern = Messages.getString(FrameworkManager.UNKNOWN_FRAMEWORK_EVENT_KEY);
		String message = MessageFormatter.format(pattern, event);
		LogUtility.logDebug(this, message);
	}

	/**
	 * Private <code>bundleContext</code> setter.
	 *
	 * @param bundleContext  The receiver's <code>BundleContext</code>.
	 */
	private void setBundleContext(BundleContext bundleContext) {
		if (this.bundleContext != null) {
			unhookFrameworkListener();
		}

		this.bundleContext = bundleContext;

		if (this.bundleContext != null) {
			hookupFrameworkListener();
		}
	}

	/**
	 * Private frameworkListener setter.
	 *
	 * @param frameworkListener  A FrameworkListener.
	 */
	private void setFrameworkListener(FrameworkListener frameworkListener) {
		this.frameworkListener = frameworkListener;
	}

	/**
	 * Shutdown the manager.
	 *
	 * @param bundleContext  The manager's <code>BundleContext</code>.
	 */
	void shutdown(BundleContext bundleContext) {
		checkBundleContextIsNotNull(bundleContext);
		synchronized (this) {
			boolean started = isStarted();
			if (started == false)
				return;  // Early return.
			checkShutdownIsAllowed(bundleContext);
			setBundleContext(null);
		}
	}

	/**
	 * Starts up the manager.
	 *
	 * @param bundleContext  The manager's <code>BundleContext</code>.
	 */
	void startup(BundleContext bundleContext) {
		checkBundleContextIsNotNull(bundleContext);
		synchronized (this) {
			boolean started = isStarted();
			if (started == true)
				return;  // Early return.
			setBundleContext(bundleContext);
		}
	}

	/**
	 * Unhook the <code>FrameworkListener</code>.
	 */
	private void unhookFrameworkListener() {
		BundleContext bundleContext = getBundleContext();
		FrameworkListener listener = getFrameworkListener();
		bundleContext.removeFrameworkListener(listener);
	}
}
