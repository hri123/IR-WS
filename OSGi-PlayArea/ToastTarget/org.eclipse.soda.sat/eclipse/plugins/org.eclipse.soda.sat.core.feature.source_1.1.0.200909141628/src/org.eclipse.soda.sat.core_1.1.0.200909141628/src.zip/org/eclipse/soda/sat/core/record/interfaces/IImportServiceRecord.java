/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.record.interfaces;

import org.osgi.framework.Filter;

/**
 * The <code>IImportServiceRecord</code> interface represents a service imported
 * by a bundle and acquired from the OSGi framework.  The following
 * responsibilities are declared:
 * <ul>
 *   <li>
 *     Acquiring an imported service from the OSGi framework.
 *   </li>
 *   <li>
 *     Releasing an imported service back to the OSGi framework.
 *   </li>
 *   <li>
 *     Managing the filter used to acquire an imported service from the OSGi
 *     framework.
 *   </li>
 *   <li>
 *     Knowing the service name used to register an imported service with the
 *     OSGi framework.
 *   </li>
 * </ul>
 * <p>
 * Every <code>IImportServiceRecord</code> must having an owner that is an
 * implementation of the interface <code>IImportServiceRecordOwner</code>.  The
 * owner is responsible for handling call-back notifications such as when a
 * service is acquired and released.
 * <p>
 * <i>Note:</i> Since this abstraction is used internally by the SAT bundle
 * this interface is typically not used directly by bundle developers.  For
 * cases where subclassing the <code>BaseBundleActivator</code> is not
 * appropriate, instances of this interface can be created using the
 * <code>FactoryUtility</code> class.
 */
public interface IImportServiceRecord extends IServiceRecord {
	/**
	 * Try and acquire the imported service from the OSGi framework.
	 */
	public void acquire();

	/**
	 * Query the LDAP filter for the imported service.
	 *
	 * @return The filter used to acquire the imported service.
	 */
	public Filter getFilter();

	/**
	 * Query the name of the imported service.
	 *
	 * @return The name of the imported service.
	 */
	public String getName();

	/**
	 * Query whether the imported service is acquired.
	 *
	 * @return True if the imported service is acquired, otherwise false.
	 */
	public boolean isAcquired();

	/**
	 * Release the imported service back to the OSGi framework.
	 */
	public void release();

	/**
	 * Sets the filter used to acquire the imported service.
	 *
	 * @param filter  The LDAP filter used to acquire the imported service.
	 */
	public void setFilter(Filter filter);

	/**
	 * Set the import service record's owner.
	 *
	 * @param owner  The owner of the import service record.
	 */
	public void setOwner(IImportServiceRecordOwner owner);
}