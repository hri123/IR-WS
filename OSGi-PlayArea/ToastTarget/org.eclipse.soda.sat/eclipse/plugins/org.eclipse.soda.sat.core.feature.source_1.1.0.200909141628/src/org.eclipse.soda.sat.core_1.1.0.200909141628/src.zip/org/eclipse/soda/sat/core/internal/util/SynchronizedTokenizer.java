/*******************************************************************************
 * Copyright (c) 2008, 2009 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util;

import org.eclipse.soda.sat.core.framework.interfaces.ITokenizer;

public class SynchronizedTokenizer implements ITokenizer {
	private ITokenizer tokenizer;

	/**
	 * Constructor.
	 *
	 * @param tokenizer  The <code>ITokenizer</code> to wrap, never
	 *                   <code>null</code>.
	 */
	public SynchronizedTokenizer(ITokenizer tokenizer) {
		super();
		setTokenizer(tokenizer);
	}

	private ITokenizer getTokenizer() {
		return tokenizer;
	}

	/**
	 * @see java.util.Enumeration#hasMoreElements()
	 */
	public boolean hasMoreElements() {
		ITokenizer tokenizer = getTokenizer();
		synchronized (tokenizer) {
			return tokenizer.hasMoreElements();
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ITokenizer#hasMoreTokens()
	 */
	public boolean hasMoreTokens() {
		ITokenizer tokenizer = getTokenizer();
		synchronized (tokenizer) {
			return tokenizer.hasMoreTokens();
		}
	}

	/**
	 * @see java.util.Enumeration#nextElement()
	 */
	public Object nextElement() {
		ITokenizer tokenizer = getTokenizer();
		synchronized (tokenizer) {
			return tokenizer.nextElement();
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ITokenizer#nextToken()
	 */
	public String nextToken() {
		ITokenizer tokenizer = getTokenizer();
		synchronized (tokenizer) {
			return tokenizer.nextToken();
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ITokenizer#setEmptyTokenIsValid(boolean)
	 */
	public void setEmptyTokenIsValid(boolean emptyTokenIsValid) {
		ITokenizer tokenizer = getTokenizer();
		synchronized (tokenizer) {
			tokenizer.setEmptyTokenIsValid(emptyTokenIsValid);
		}
	}

	private void setTokenizer(ITokenizer tokenizer) {
		this.tokenizer = tokenizer;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ITokenizer#setTrimToken(boolean)
	 */
	public void setTrimToken(boolean trimToken) {
		ITokenizer tokenizer = getTokenizer();
		synchronized (tokenizer) {
			tokenizer.setTrimToken(trimToken);
		}
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.interfaces.ITokenizer#toSynchronizedTokenizer()
	 */
	public ITokenizer toSynchronizedTokenizer() {
		return this;
	}
}
