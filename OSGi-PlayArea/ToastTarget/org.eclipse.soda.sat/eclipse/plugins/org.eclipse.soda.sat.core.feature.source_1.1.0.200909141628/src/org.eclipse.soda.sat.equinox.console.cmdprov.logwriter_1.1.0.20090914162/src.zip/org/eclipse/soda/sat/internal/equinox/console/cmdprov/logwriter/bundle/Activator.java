/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.equinox.console.cmdprov.logwriter.bundle;

import org.eclipse.osgi.framework.console.CommandProvider;
import org.eclipse.soda.sat.core.framework.BaseBundleActivator;
import org.eclipse.soda.sat.core.service.LogReaderAggregatorService;
import org.eclipse.soda.sat.internal.equinox.console.cmdprov.logwriter.LogWriter;
import org.eclipse.soda.sat.internal.equinox.console.cmdprov.logwriter.LogWriterCommandProvider;

public class Activator extends BaseBundleActivator {
	//
	// Static Fields
	//

	private static final String COMMAND_PROVIDER_SERVICE_NAME = CommandProvider.class.getName();

	//
	// Instance Fields
	//

	private LogWriter writer;

	//
	// Instance Methods
	//

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#activate()
	 */
	protected void activate() {
		Object service = createLogWriterCommandProvider();
		addExportedService(Activator.COMMAND_PROVIDER_SERVICE_NAME, service, null);
	}

	private LogWriter createLogWriter() {
		LogReaderAggregatorService aggregator = getLogReaderAggregatorService();
		LogWriter writer = new LogWriter(aggregator);
		return writer;
	}

	private Object createLogWriterCommandProvider() {
		LogWriter writer = createLogWriter();
		setWriter(writer);
		writer.start();
		Object service = new LogWriterCommandProvider(writer);
		return service;
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#deactivate()
	 */
	protected void deactivate() {
		stopLogWriter();
		setWriter(null);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#getImportedServiceNames()
	 */
	protected String[] getImportedServiceNames() {
		return new String[] {
			LogReaderAggregatorService.SERVICE_NAME
		};
	}

	private LogReaderAggregatorService getLogReaderAggregatorService() {
		return (LogReaderAggregatorService) getImportedService(LogReaderAggregatorService.SERVICE_NAME);
	}

	private LogWriter getWriter() {
		return writer;
	}

	private void setWriter(LogWriter writer) {
		this.writer = writer;
	}

	private void stopLogWriter() {
		LogWriter writer = getWriter();
		writer.stop();
	}
}