/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.equinox.console.cmdprov.logwriter;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.service.LogReaderAggregatorService;
import org.eclipse.soda.sat.core.util.Assertion;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.eclipse.soda.sat.internal.equinox.console.cmdprov.logwriter.nls.Messages;
import org.osgi.framework.Bundle;
import org.osgi.framework.Constants;
import org.osgi.framework.ServiceReference;
import org.osgi.service.log.LogEntry;
import org.osgi.service.log.LogListener;
import org.osgi.service.log.LogService;

public class LogWriter extends Object {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String INVALID_LOG_LEVEL_KEY = "LogWriter.InvalidLogLevel";  //$NON-NLS-1$
	private static final String STARTED_LOGGING_EVENTS_KEY = "LogWriter.StartedLoggingEvents";  //$NON-NLS-1$
	private static final String STOPPED_LOGGING_EVENTS_KEY = "LogWriter.StoppedLoggingEvents";  //$NON-NLS-1$

	// Externalized String Values
	private static final String INVALID_LOG_LEVEL = Messages.getString(LogWriter.INVALID_LOG_LEVEL_KEY);
	private static final String STARTED_LOGGING_EVENTS = Messages.getString(LogWriter.STARTED_LOGGING_EVENTS_KEY);
	private static final String STOPPED_LOGGING_EVENTS = Messages.getString(LogWriter.STOPPED_LOGGING_EVENTS_KEY);

	// Log Level Constants
	private static final String ERROR_LOG_LEVEL = "ERROR";  //$NON-NLS-1$
	private static final String WARNING_LOG_LEVEL = "WARNING";  //$NON-NLS-1$
	private static final String INFO_LOG_LEVEL = "INFO";  //$NON-NLS-1$
	private static final String DEBUG_LOG_LEVEL = "DEBUG";  //$NON-NLS-1$

	// Date/Time Constants
	private static final char DATE_DELIMETER = '-';
	private static final char TIME_DELIMETER = ':';
	private static final char ZERO_PADDING = '0';
	private static final Calendar CALENDAR = Calendar.getInstance();

	private static Calendar getCalendar(long time) {
		Date date = new Date(time);
		LogWriter.CALENDAR.setTime(date);
		return LogWriter.CALENDAR;
	}

	private LogReaderAggregatorService aggregator;
	private LogListener logListener;
	private volatile int levelValue;
	private boolean started;
	private ICharBuffer buffer;

	public LogWriter(LogReaderAggregatorService aggregator) {
		super();
		setAggregator(aggregator);
		setLevelValue(LogService.LOG_DEBUG);
		setStarted(false);
		setBuffer(createBuffer());
	}

	private ICharBuffer createBuffer() {
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(250);
		return buffer;
	}

	private LogListener createLogListener() {
		return new LogListener() {
			public void logged(LogEntry entry) {
				LogWriter.this.handleLogEntry(entry);
			}
		};
	}

	private String formatLogMessage(int level, long time, String message, ServiceReference reference) {
		String value;
		ICharBuffer buffer = getBuffer();

		synchronized (buffer) {
			// Since the buffer is reused, it must be emptied before each use.
			buffer.setLength(0);

			printLevelOn(buffer, level);
			buffer.append(' ');
			printDateAndTimeOn(buffer, time);
			buffer.append(' ');
			buffer.append(message);

			if (reference != null) {
				buffer.append(',');
				buffer.append(' ');
				printServiceReferenceOn(buffer, reference);
			}

			value = buffer.toString();
		}

		return value;
	}

	private LogReaderAggregatorService getAggregator() {
		return aggregator;
	}

	private ICharBuffer getBuffer() {
		return buffer;
	}

	public String getLevel() {
		int logLevel = getLevelValue();
		String value = getLevel(logLevel);
		return value;
	}

	private String getLevel(int level) {
		String text;

		switch (level) {
			case LogService.LOG_ERROR:
				text = LogWriter.ERROR_LOG_LEVEL;
				break;

			case LogService.LOG_WARNING:
				text = LogWriter.WARNING_LOG_LEVEL;
				break;

			case LogService.LOG_INFO:
				text = LogWriter.INFO_LOG_LEVEL;
				break;

			case LogService.LOG_DEBUG:
				text = LogWriter.DEBUG_LOG_LEVEL;
				break;

			default:
				text = "<unknown>"; //$NON-NLS-1$
				break;
		}

		return text;
	}

	private int getLevelValue() {
		return levelValue;
	}

	private LogListener getLogListener() {
		synchronized (this) {
			if (logListener == null) {
				LogListener listener = createLogListener();
				setLogListener(listener);
			}

			return logListener;
		}
	}

	private List getServiceNames(ServiceReference reference) {
		String[] names = (String[]) reference.getProperty(Constants.OBJECTCLASS);
		List list = new ArrayList(names.length);

		for (int i = 0; i < names.length; i++) {
			String name = names [ i ];
			list.add(name);
		}

		return list;
	}

	private void handleLogEntry(LogEntry entry) {
		int entryLevel = entry.getLevel();
		int level = getLevelValue();
		if (level <= entryLevel)
			return;  // We're not logging at that level.

		long time = entry.getTime();
		ServiceReference reference = entry.getServiceReference();
		String message = entry.getMessage();
		logMessage(level, time, message, reference);

		Throwable throwable = entry.getException();
		if (throwable == null)
			return;  // No exception.
		logException(throwable);
	}

	private boolean isStarted() {
		return started;
	}

	private void logException(Throwable throwable) {
		PrintStream printStream = new PrintStream(System.err);
		throwable.printStackTrace(printStream);
		printStream.flush();
	}

	private void logInvalidLogLevel(String argument) {
		String message = MessageFormatter.format(LogWriter.INVALID_LOG_LEVEL, argument);
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(75);
		buffer.append(message);
		buffer.append(argument);
		buffer.append('\n');
		buffer.append('\t');
		buffer.append(LogWriterCommandProvider.SET_LOG_LEVEL_USAGE);
		PrintStream stream = System.err;
		stream.println(buffer);
	}

	private void logMessage(int level, long time, String message, ServiceReference reference) {
		String value = formatLogMessage(level, time, message, reference);
		System.out.println(value);
	}

	private void printDateAndTimeOn(ICharBuffer buffer, long time) {
		Calendar calendar = LogWriter.getCalendar(time);
		printDateOn(buffer, calendar);
		buffer.append(' ');
		printTimeOn(buffer, calendar);
	}

	private void printDateOn(ICharBuffer buffer, Calendar calendar) {
		// Year
		int year = calendar.get(Calendar.YEAR);
		buffer.append(year);

		// Month
		buffer.append(LogWriter.DATE_DELIMETER);
		int month = calendar.get(Calendar.MONTH) + 1;

		if (month < 10) {
			buffer.append(LogWriter.ZERO_PADDING);
		}

		buffer.append(month);

		// Day
		buffer.append(LogWriter.DATE_DELIMETER);
		int day = calendar.get(Calendar.DAY_OF_MONTH);

		if (day < 10) {
			buffer.append(LogWriter.ZERO_PADDING);
		}

		buffer.append(day);
	}

	private void printLevelOn(ICharBuffer buffer, int level) {
		String value = getLevel(level);
		buffer.append('[');
		buffer.append(value);
		buffer.append(']');
	}

	private void printServiceReferenceOn(ICharBuffer buffer, ServiceReference reference) {
		Bundle bundle = reference.getBundle();

		if (bundle != null) {
			String symbolicName = bundle.getSymbolicName();
			long id = bundle.getBundleId();
			buffer.append("bundle"); //$NON-NLS-1$
			buffer.append('=');
			buffer.append(symbolicName);
			buffer.append(' ');
			buffer.append('[');
			buffer.append(id);
			buffer.append(']');
			buffer.append(',');
			buffer.append(' ');
		}

		List/*<String>*/ names = getServiceNames(reference);
		boolean empty = names.isEmpty();
		if (empty == true)
			return;

		buffer.append("services"); //$NON-NLS-1$
		buffer.append('=');
		buffer.append('[');

		Iterator iterator = names.iterator();
		while (iterator.hasNext() == true) {
			Object name = iterator.next();
			buffer.append(name);

			if (iterator.hasNext() == true) {
				buffer.append(',');
				buffer.append(' ');
			}
		}

		buffer.append(']');
	}

	private void printTimeOn(ICharBuffer buffer, Calendar calendar) {
		// Hours
		int hour = calendar.get(Calendar.HOUR_OF_DAY);

		if (hour < 10) {
			buffer.append(LogWriter.ZERO_PADDING);
		}

		buffer.append(hour);

		// Minutes
		buffer.append(LogWriter.TIME_DELIMETER);
		int minute = calendar.get(Calendar.MINUTE);

		if (minute < 10) {
			buffer.append(LogWriter.ZERO_PADDING);
		}

		buffer.append(minute);

		// Seconds
		buffer.append(LogWriter.TIME_DELIMETER);
		int second = calendar.get(Calendar.SECOND);

		if (second < 10) {
			buffer.append(LogWriter.ZERO_PADDING);
		}

		buffer.append(second);

		// Milliseconds
		buffer.append('.');
		int millisecond = calendar.get(Calendar.MILLISECOND);

		if (millisecond < 100) {
			buffer.append(LogWriter.ZERO_PADDING);
		}

		if (millisecond < 10) {
			buffer.append(LogWriter.ZERO_PADDING);
		}

		buffer.append(millisecond);
	}

	private void setAggregator(LogReaderAggregatorService aggregator) {
		Assertion.checkArgumentIsNotNull(aggregator, "aggregator"); //$NON-NLS-1$
		this.aggregator = aggregator;
	}

	private void setBuffer(ICharBuffer buffer) {
		this.buffer = buffer;
	}

	public boolean setLevel(String level) {
		Assertion.checkArgumentIsNotNull(level, "level"); //$NON-NLS-1$
		boolean set = false;

		try {
			int value = toLevelValue(level);
			setLevelValue(value);
			set = true;
		} catch (NumberFormatException exception) {
			logInvalidLogLevel(level);
		} catch (IllegalArgumentException exception) {
			logInvalidLogLevel(level);
		}

		return set;
	}

	private void setLevelValue(int levelValue) {
		this.levelValue = levelValue;
	}

	private void setLogListener(LogListener logListener) {
		this.logListener = logListener;
	}

	private void setStarted(boolean started) {
		this.started = started;
	}

	public void start() {
		synchronized (this) {
			boolean started = isStarted();
			if (started == true)
				return;  // Already started.
			setStarted(true);
			startListening();
		}
	}

	private void startListening() {
		LogReaderAggregatorService service = getAggregator();
		LogListener listener = getLogListener();
		service.addLogListener(listener);
		System.out.println(LogWriter.STARTED_LOGGING_EVENTS);
	}

	public void stop() {
		synchronized (this) {
			boolean started = isStarted();
			if (started == false)
				return;  // Already stopped.
			setStarted(false);
			stopListening();
		}
	}

	private void stopListening() {
		LogReaderAggregatorService service = getAggregator();
		LogListener listener = getLogListener();
		service.removeLogListener(listener);
		System.out.println(LogWriter.STOPPED_LOGGING_EVENTS);
	}

	private int toLevelValue(String value) throws IllegalArgumentException {
		if (LogWriter.ERROR_LOG_LEVEL.equalsIgnoreCase(value)) {
			return LogService.LOG_ERROR;
		} else if (LogWriter.WARNING_LOG_LEVEL.equalsIgnoreCase(value)) {
			return LogService.LOG_WARNING;
		} else if (LogWriter.INFO_LOG_LEVEL.equalsIgnoreCase(value)) {
			return LogService.LOG_INFO;
		} else if (LogWriter.DEBUG_LOG_LEVEL.equalsIgnoreCase(value)) {
			return LogService.LOG_DEBUG;
		} else {
			throw new IllegalArgumentException("invalid log level: " + value); //$NON-NLS-1$
		}
	}
}
