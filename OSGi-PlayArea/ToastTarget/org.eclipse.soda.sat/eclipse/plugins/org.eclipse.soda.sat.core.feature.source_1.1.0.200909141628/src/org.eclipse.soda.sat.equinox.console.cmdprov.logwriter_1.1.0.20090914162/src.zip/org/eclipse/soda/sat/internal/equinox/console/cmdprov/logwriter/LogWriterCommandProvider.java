/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.internal.equinox.console.cmdprov.logwriter;

import org.eclipse.osgi.framework.console.CommandInterpreter;
import org.eclipse.osgi.framework.console.CommandProvider;
import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.core.util.MessageFormatter;
import org.eclipse.soda.sat.internal.equinox.console.cmdprov.logwriter.nls.Messages;

public class LogWriterCommandProvider extends Object implements CommandProvider {
	//
	// Static Fields
	//

	// Externalized String Keys
	private static final String LOG_LEVEL_IS_KEY = "LogWriterCommandProvider.LogLevelIs";  //$NON-NLS-1$
	private static final String SET_LOG_LEVEL_DESCRIPTION_KEY = "LogWriterCommandProvider.SetLogLevelDescription";  //$NON-NLS-1$
	private static final String START_LOG_WRITER_DESCRIPTION_KEY = "LogWriterCommandProvider.StartLogWriterDescription";  //$NON-NLS-1$
	private static final String STOP_LOG_WRITER_DESCRIPTION_KEY = "LogWriterCommandProvider.StopLogWriterDescription";  //$NON-NLS-1$

	// Externalized String Values
	private static final String LOG_LEVEL_IS = Messages.getString(LogWriterCommandProvider.LOG_LEVEL_IS_KEY);
	private static final String SET_LOG_LEVEL_DESCRIPTION = Messages.getString(LogWriterCommandProvider.SET_LOG_LEVEL_DESCRIPTION_KEY);
	private static final String START_LOG_WRITER_DESCRIPTION = Messages.getString(LogWriterCommandProvider.START_LOG_WRITER_DESCRIPTION_KEY);
	private static final String STOP_LOG_WRITER_DESCRIPTION = Messages.getString(LogWriterCommandProvider.STOP_LOG_WRITER_DESCRIPTION_KEY);

	// Non-Externalized String Patterns
	public static final String SET_LOG_LEVEL_USAGE = "setll <error | warning | info | debug> - {0}";  //$NON-NLS-1$
	private static final String START_LOG_WRITER_USAGE = "startlw - {0}";  //$NON-NLS-1$
	private static final String STOP_LOG_WRITER_USAGE = "stoplw - {0}";  //$NON-NLS-1$

	//
	// Instance Fields
	//

	private LogWriter writer;

	//
	// Constructors
	//

	public LogWriterCommandProvider(LogWriter writer) {
		super();
		if (writer == null)
			throw new IllegalArgumentException("writer must not be null"); //$NON-NLS-1$
		setWriter(writer);
	}

	//
	// Instance Methods
	//

	public void _setll(CommandInterpreter interpreter) {
		String argument = interpreter.nextArgument();

		if (argument != null) {
			LogWriter writer = getWriter();
			boolean set = writer.setLevel(argument);
			if (set == false)
				return;  // Log level not set.
		}

		displayLogLevel(interpreter);
	}

	public void _startlw(CommandInterpreter interpreter) {
		LogWriter writer = getWriter();
		writer.start();
	}

	public void _stoplw(CommandInterpreter interpreter) {
		LogWriter writer = getWriter();
		writer.stop();
	}

	private void displayLogLevel(CommandInterpreter interpreter) {
		LogWriter writer = getWriter();
		String value = writer.getLevel();
		String message = MessageFormatter.format(LogWriterCommandProvider.LOG_LEVEL_IS, value);
		interpreter.println(message);
	}

	public String getHelp() {
		String setLogLevelHelp = MessageFormatter.format(LogWriterCommandProvider.SET_LOG_LEVEL_USAGE, LogWriterCommandProvider.SET_LOG_LEVEL_DESCRIPTION);
		String startLogWriterHelp = MessageFormatter.format(LogWriterCommandProvider.START_LOG_WRITER_USAGE, LogWriterCommandProvider.START_LOG_WRITER_DESCRIPTION);
		String stopLogWriterHelp = MessageFormatter.format(LogWriterCommandProvider.STOP_LOG_WRITER_USAGE, LogWriterCommandProvider.STOP_LOG_WRITER_DESCRIPTION);

		String decoration = "---";  //$NON-NLS-1$
		char tab = '\t';
		char newLine = '\n';
		FactoryUtility utility = FactoryUtility.getInstance();
		ICharBuffer buffer = utility.createCharBuffer(150);
		buffer.append(decoration);
		buffer.append("Log Writer"); //$NON-NLS-1$
		buffer.append(decoration);
		buffer.append(newLine);
		buffer.append(tab);
		buffer.append(setLogLevelHelp);
		buffer.append(newLine);
		buffer.append(tab);
		buffer.append(startLogWriterHelp);
		buffer.append(newLine);
		buffer.append(tab);
		buffer.append(stopLogWriterHelp);
		buffer.append(newLine);
		String help = buffer.toString();
		return help;
	}

	private LogWriter getWriter() {
		return writer;
	}

	private void setWriter(LogWriter writer) {
		this.writer = writer;
	}
}
