/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util.test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.framework.interfaces.ILineReader;
import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;

public class LineReaderTestCase extends AbstractSatTestCase {
	private static final String NO_LINES_AVAILABLE = "No lines available"; //$NON-NLS-1$
	private static final String INVALID_LINE_READ = "Invalid line read"; //$NON-NLS-1$

	public static Test suite() {
		return new TestSuite(LineReaderTestCase.class);
	}

	public LineReaderTestCase(String name) {
		super(name);
	}

	private byte[] createDataBytes() {
		char newline = Character.LINE_SEPARATOR;

		StringBuffer buffer = new StringBuffer(25);
		buffer.append("one"); //$NON-NLS-1$
		buffer.append(newline);
		buffer.append("two"); //$NON-NLS-1$
		buffer.append('\n'); // $codepro.audit.disable platformSpecificLineSeparator
		buffer.append("three"); //$NON-NLS-1$
		buffer.append('\r'); // $codepro.audit.disable platformSpecificLineSeparator
		buffer.append("four"); //$NON-NLS-1$
		buffer.append(newline);
		buffer.append(newline);
		buffer.append("five"); //$NON-NLS-1$
		buffer.append(newline);

		String text = buffer.toString();
		byte[] bytes = text.getBytes();
		return bytes;
	}

	private InputStream createInputStream() {
		byte[] bytes = createDataBytes();
		InputStream stream = createInputStream(bytes);
		return stream;
	}

	private InputStream createInputStream(byte[] bytes) {
		InputStream stream = new ByteArrayInputStream(bytes);
		return stream;
	}

	private ILineReader createLineReader() {
		InputStream stream = createInputStream();
		ILineReader reader = createLineReader(stream);
		return reader;
	}

	private ILineReader createLineReader(ILineReader.IAdvisor advisor) {
		InputStream stream = createInputStream();
		ILineReader reader = AbstractSatTestCase.FACTORY.createLineReader(stream, advisor);
		return reader;
	}

	private ILineReader createLineReader(InputStream stream) {
		ILineReader reader = AbstractSatTestCase.FACTORY.createLineReader(stream);
		return reader;
	}

	private ILineReader createLineReader(InputStream stream, String characterEncoding) {
		ILineReader reader = AbstractSatTestCase.FACTORY.createLineReader(stream, characterEncoding);
		return reader;
	}

	public void test_AdvisorTransformation() throws IOException {
		ILineReader.IAdvisor advisor = new ILineReader.IAdvisor() {
			public boolean isValid(String line) {
				return true;
			}

			public String transform(String line) {
				if (line.equals("one")) { //$NON-NLS-1$
					return "1"; //$NON-NLS-1$
				} else if (line.equals("two")) { //$NON-NLS-1$
					return "2"; //$NON-NLS-1$
				} else if (line.equals("three")) { //$NON-NLS-1$
					return "3"; //$NON-NLS-1$
				} else if (line.equals("four")) { //$NON-NLS-1$
					return "4"; //$NON-NLS-1$
				} else if (line.equals("five")) { //$NON-NLS-1$
					return "5"; //$NON-NLS-1$
				}

				return line;
			}
		};

		ILineReader reader = createLineReader(advisor);
		Object line;

		line = reader.readLine();
		Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "1", line); //$NON-NLS-1$

		line = reader.readLine();
		Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "2", line); //$NON-NLS-1$

		line = reader.readLine();
		Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "3", line); //$NON-NLS-1$

		line = reader.readLine();
		Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "4", line); //$NON-NLS-1$

		line = reader.readLine();
		Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, new String(), line);

		line = reader.readLine();
		Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "5", line); //$NON-NLS-1$
	}

	public void test_AdvisorValidation() throws IOException {
		ILineReader.IAdvisor advisor = new ILineReader.IAdvisor() {
			public boolean isValid(String line) {
				return line.charAt(0) != '#';
			}

			public String transform(String line) {
				return line;
			}
		};

		char newline = Character.LINE_SEPARATOR;

		StringBuffer buffer = new StringBuffer(25);
		buffer.append("#one"); //$NON-NLS-1$
		buffer.append(newline);
		buffer.append("two"); //$NON-NLS-1$
		buffer.append(newline);
		buffer.append("three"); //$NON-NLS-1$
		buffer.append(newline);
		buffer.append("#four"); //$NON-NLS-1$
		buffer.append(newline);
		buffer.append("five"); //$NON-NLS-1$

		String text = buffer.toString();
		byte[] bytes = text.getBytes();
		InputStream stream = createInputStream(bytes);

		ILineReader reader = AbstractSatTestCase.FACTORY.createLineReader(stream, advisor);
		Object line;

		line = reader.readLine();
		Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "two", line); //$NON-NLS-1$

		line = reader.readLine();
		Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "three", line); //$NON-NLS-1$

		line = reader.readLine();
		Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "five", line); //$NON-NLS-1$
	}

	public void test_lines() {
		ILineReader reader = createLineReader();
		Enumeration enumeration = reader.lines();
		Object line;

		Assert.assertTrue(LineReaderTestCase.NO_LINES_AVAILABLE, enumeration.hasMoreElements() == true);
		line = enumeration.nextElement();
		Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "one", line); //$NON-NLS-1$

		Assert.assertTrue(LineReaderTestCase.NO_LINES_AVAILABLE, enumeration.hasMoreElements() == true);
		line = enumeration.nextElement();
		Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "two", line); //$NON-NLS-1$

		Assert.assertTrue(LineReaderTestCase.NO_LINES_AVAILABLE, enumeration.hasMoreElements() == true);
		line = enumeration.nextElement();
		Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "three", line); //$NON-NLS-1$

		Assert.assertTrue(LineReaderTestCase.NO_LINES_AVAILABLE, enumeration.hasMoreElements() == true);
		line = enumeration.nextElement();
		Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "four", line); //$NON-NLS-1$

		Assert.assertTrue(LineReaderTestCase.NO_LINES_AVAILABLE, enumeration.hasMoreElements() == true);
		line = enumeration.nextElement();
		Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, new String(), line);

		Assert.assertTrue(LineReaderTestCase.NO_LINES_AVAILABLE, enumeration.hasMoreElements() == true);
		line = enumeration.nextElement();
		Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "five", line); //$NON-NLS-1$

		Assert.assertTrue("Lines available", enumeration.hasMoreElements() == false); //$NON-NLS-1$
		line = enumeration.nextElement();
		Assert.assertNull(LineReaderTestCase.INVALID_LINE_READ, line);
	}

	public void test_readLine() throws IOException {
		ILineReader reader = createLineReader();
		Object line;

		try {
			line = reader.readLine();
			Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "one", line); //$NON-NLS-1$

			line = reader.readLine();
			Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "two", line); //$NON-NLS-1$

			line = reader.readLine();
			Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "three", line); //$NON-NLS-1$

			line = reader.readLine();
			Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "four", line); //$NON-NLS-1$

			line = reader.readLine();
			Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, new String(), line);

			line = reader.readLine();
			Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, "five", line); //$NON-NLS-1$

			line = reader.readLine();
			Assert.assertNull(LineReaderTestCase.INVALID_LINE_READ, line);
		} finally {
			reader.close();
		}
	}

	public void test_readLine_japanese() throws IOException {
		String yamadaTaro = "山田太郎"; //$NON-NLS-1$
		byte[] bytes = yamadaTaro.getBytes();
		InputStream stream = createInputStream(bytes);
		ILineReader reader = createLineReader(stream, "UTF-8"); //$NON-NLS-1$
		Object line;

		try {
			line = reader.readLine();
			Assert.assertEquals(LineReaderTestCase.INVALID_LINE_READ, yamadaTaro, line);

			line = reader.readLine();
			Assert.assertNull(LineReaderTestCase.INVALID_LINE_READ, line);
		} finally {
			reader.close();
		}
	}
}
