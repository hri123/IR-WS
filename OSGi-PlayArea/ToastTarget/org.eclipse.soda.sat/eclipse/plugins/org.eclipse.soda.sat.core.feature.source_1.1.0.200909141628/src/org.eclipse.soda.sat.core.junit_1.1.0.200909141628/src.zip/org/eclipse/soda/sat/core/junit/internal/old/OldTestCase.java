/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.junit.internal.old;

import java.util.Dictionary;
import java.util.Hashtable;

import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;
import org.eclipse.soda.sat.core.junit.internal.AbstractServiceTestCase;
import org.eclipse.soda.sat.core.junit.internal.old.service.Dummy;
import org.eclipse.soda.sat.core.junit.internal.old.service.DummyService;
import org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainer;
import org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainerOwner;
import org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecordOwner;
import org.osgi.framework.BundleContext;

public abstract class OldTestCase extends AbstractServiceTestCase implements IImportServiceRecordOwner, IImportServiceRecordContainerOwner {
	private IExportServiceRecord dummyExportServiceRecord;

	protected OldTestCase(String name) {
		super(name);
	}

	public void acquired(IImportServiceRecordContainer container) {
//		System.out.println("acquired:\n\t" + container);
	}

	private IExportServiceRecord createExportRecord() {
		BundleContext bundleContext = getBundleContext();
		String[] names = { DummyService.SERVICE_NAME };
		Object service = createService();
		Dictionary properties = createServiceProperties();
		IExportServiceRecord record = AbstractSatTestCase.FACTORY.createExportServiceRecord(bundleContext, names, service, properties);
		return record;
	}

	private Object createService() {
		return new Dummy();
	}

	protected final Dictionary createServiceProperties() {
		return new Hashtable(17);
	}

	protected final IExportServiceRecord getDummyExportServiceRecord() {
		return dummyExportServiceRecord;
	}

	public Object getLock() {
		return this;
	}

	protected final void registerDummyService() {
		IExportServiceRecord record = createExportRecord();
		setDummyExportServiceRecord(record);
		record.register();
	}

	public void released(IImportServiceRecordContainer container) {
//		System.out.println("released:\n\t" + container);
	}

	public void serviceAcquired(IImportServiceRecord record) {
//		System.out.println("serviceAcquired:\n\t" + record);
	}

	public void serviceAcquired(IImportServiceRecordContainer container, IImportServiceRecord record) {
//		System.out.println("serviceAcquired:\n\t" + container + "\n\t" + container);
	}

	public void serviceReleased(IImportServiceRecord record) {
//		System.out.println("serviceReleased:\n\t" + record);
	}

	public void serviceReleased(IImportServiceRecordContainer container, IImportServiceRecord record) {
//		System.out.println("serviceReleased:\n\t" + container + "\n\t" + container);
	}

	private void setDummyExportServiceRecord(IExportServiceRecord dummyExportServiceRecord) {
		this.dummyExportServiceRecord = dummyExportServiceRecord;
	}

	protected final void unregisterDummyService() {
		dummyExportServiceRecord.unregister();
	}
}
