/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.util.test;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.junit.util.ValueHolder;
import org.osgi.framework.ServiceReference;
import org.osgi.service.log.LogService;

public class LogUtilityTestCase extends AbstractSatTestCase {
	public static Test suite() {
		return new TestSuite(LogUtilityTestCase.class);
	}

	public LogUtilityTestCase(String name) {
		super(name);
	}

	private LogService createLogService(final ValueHolder/*<Boolean>*/ holder) {
		return new LogService() {
			public void log(int level, String message) {
				logged();
			}

			public void log(int level, String message, Throwable exception) {
				logged();
			}

			public void log(ServiceReference sr, int level, String message) {
				logged();
			}

			public void log(ServiceReference sr, int level, String message, Throwable exception) {
				logged();
			}

			private void logged() {
				holder.setTrue();
			}
		};
	}

	public void test_getLog() {
		LogUtility utility = LogUtility.getInstance();
		LogService logService = utility.getLog();
		Assert.assertNotNull(logService);
	}

	public void test_setLog() {
		LogUtility utility = LogUtility.getInstance();
		LogService currentLogService = utility.getLog();

		utility.setLog(null);
		Object log = utility.getLog();
		Assert.assertNotNull(log);

		utility.setLog(currentLogService);
		Object expected = currentLogService;
		Object actual = utility.getLog();
		Assert.assertSame(expected, actual);
	}

	public void test_setLoggingLevel() {
		int currentLoggingLevel = LogUtility.getLoggingLevel();
		try {
			LogUtility utility = LogUtility.getInstance();
			ValueHolder/*<Boolean>*/ holder = ValueHolder.falseValue();
			LogService logService = createLogService(holder);
			utility.setLog(logService);
			Assert.assertTrue(holder.isFalse());

			int expectedLevel;
			int actualLevel;
			boolean isLogging;
			String message = "message"; //$NON-NLS-1$
			boolean state;

			// Illegal Log Level: -1
			try {
				LogUtility.setLoggingLevel(-1);
				Assert.fail();
			} catch (IllegalArgumentException exception) {
				Assert.assertTrue(true);
			}

			// Log Level: 0 (turn logging off)
			LogUtility.setLoggingLevel(0);
			expectedLevel = 0;
			actualLevel = LogUtility.getLoggingLevel();
			Assert.assertEquals(expectedLevel, actualLevel);

			LogUtility.logError(message); // Error (no)
			state = holder.isFalse();
			Assert.assertTrue(state);

			LogUtility.logWarning(message); // Warning (no)
			state = holder.isFalse();
			Assert.assertTrue(state);

			LogUtility.logInfo(message); // Info (no)
			state = holder.isFalse();
			Assert.assertTrue(state);

			LogUtility.logDebug(message); // Debug (no)
			state = holder.isFalse();
			Assert.assertTrue(state);

			// Log Level: LOG_ERROR

			LogUtility.setLoggingLevel(LogService.LOG_ERROR); // 1
			expectedLevel = LogService.LOG_ERROR;
			actualLevel = LogUtility.getLoggingLevel();
			Assert.assertEquals(expectedLevel, actualLevel);

			isLogging = LogUtility.isLoggingError();
			Assert.assertTrue(isLogging);

			holder.setFalse();

			LogUtility.logDebug(message); // Debug (no)
			state = holder.isFalse();
			Assert.assertTrue(state);

			LogUtility.logInfo(message); // Info (no)
			state = holder.isFalse();
			Assert.assertTrue(state);

			LogUtility.logWarning(message); // Warning (no)
			state = holder.isFalse();
			Assert.assertTrue(state);

			LogUtility.logError(message); // Error (yes)
			state = holder.isTrue();
			Assert.assertTrue(state);

			// Log Level: LOG_WARNING

			LogUtility.setLoggingLevel(LogService.LOG_WARNING); // 2
			expectedLevel = LogService.LOG_WARNING;
			actualLevel = LogUtility.getLoggingLevel();
			Assert.assertEquals(expectedLevel, actualLevel);

			isLogging = LogUtility.isLoggingWarning();
			Assert.assertTrue(isLogging);

			holder.setFalse();

			LogUtility.logDebug(message); // Debug (no)
			state = holder.isFalse();
			Assert.assertTrue(state);

			LogUtility.logInfo(message); // Info (no)
			state = holder.isFalse();
			Assert.assertTrue(state);

			LogUtility.logWarning(message); // Warning (yes)
			state = holder.isTrue();
			Assert.assertTrue(state);

			holder.setFalse();

			LogUtility.logError(message); // Error (yes)
			state = holder.isTrue();
			Assert.assertTrue(state);

			// Log Level: LOG_INFO

			LogUtility.setLoggingLevel(LogService.LOG_INFO); // 3
			expectedLevel = LogService.LOG_INFO;
			actualLevel = LogUtility.getLoggingLevel();
			Assert.assertEquals(expectedLevel, actualLevel);

			isLogging = LogUtility.isLoggingInfo();
			Assert.assertTrue(isLogging);

			holder.setFalse();

			LogUtility.logDebug(message); // Debug (no)
			state = holder.isFalse();
			Assert.assertTrue(state);

			LogUtility.logInfo(message); // Info (yes)
			state = holder.isTrue();
			Assert.assertTrue(state);

			holder.setFalse();

			LogUtility.logWarning(message); // Warning (yes)
			state = holder.isTrue();
			Assert.assertTrue(state);

			holder.setFalse();

			LogUtility.logError(message); // Error (yes)
			state = holder.isTrue();
			Assert.assertTrue(state);

			// Log Level: LOG_DEBUG

			LogUtility.setLoggingLevel(LogService.LOG_DEBUG); // 4
			expectedLevel = LogService.LOG_DEBUG;
			actualLevel = LogUtility.getLoggingLevel();
			Assert.assertEquals(expectedLevel, actualLevel);

			isLogging = LogUtility.isLoggingDebug();
			Assert.assertTrue(isLogging);

			holder.setFalse();

			LogUtility.logDebug(message); // Debug (yes)
			state = holder.isTrue();
			Assert.assertTrue(state);

			holder.setFalse();

			LogUtility.logInfo(message); // Info(yes)
			state = holder.isTrue();
			Assert.assertTrue(state);

			holder.setFalse();

			LogUtility.logWarning(message); // Warning (yes)
			state = holder.isTrue();
			Assert.assertTrue(state);

			holder.setFalse();

			LogUtility.logError(message); // Error (yes)
			state = holder.isTrue();
			Assert.assertTrue(state);

			// Illegal Log Level: 5
			try {
				LogUtility.setLoggingLevel(5);
				Assert.fail();
			} catch (IllegalArgumentException exception) {
				Assert.assertTrue(true);
			}
		} finally {
			LogUtility.setLoggingLevel(currentLoggingLevel);
		}
	}
}
