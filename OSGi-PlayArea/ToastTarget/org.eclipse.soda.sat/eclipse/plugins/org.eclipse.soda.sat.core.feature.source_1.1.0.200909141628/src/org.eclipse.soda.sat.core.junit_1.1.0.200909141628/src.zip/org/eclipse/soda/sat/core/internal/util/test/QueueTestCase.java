/*******************************************************************************
 * Copyright (c) 2009 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util.test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.framework.interfaces.IQueue;
import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;
import org.eclipse.soda.sat.junit.util.ValueHolder;

public class QueueTestCase extends AbstractSatTestCase {
	private class ProducerConsumerTest {
		private void assertSuccess(ValueHolder/*<Integer>*/ counter, List/*<Thread>*/ items) {
			int expectedSize = counter.getIntValue();
			int actualSize = items.size();
			Assert.assertEquals(expectedSize, actualSize);
		}

		private Runnable createConsumerRunnable(final ValueHolder/*<Boolean>*/ runHolder, final IQueue queue, final List/*<Integer>*/ items) {
			return new Runnable() {
				public void run() {
					try {
						while (ProducerConsumerTest.this.keepConsuming(runHolder, queue) == true) {
							ProducerConsumerTest.this.processConsumer(queue, items);
							Thread.yield();
						}
					} catch (InterruptedException exception) {
						// OK
					}
				}
			};
		}

		private void createConsumerThread(int id, ValueHolder/*<Boolean>*/ runHolder, List/*<Integer>*/ items, IQueue queue, List/*<Thread>*/ threads) {
			Runnable runnable = createConsumerRunnable(runHolder, queue, items);
			Thread thread = new Thread(runnable, "Consumer-" + id); //$NON-NLS-1$
			threads.add(thread);
		}

		private void createConsumerThreads(int count, ValueHolder/*<Boolean>*/ keepRunning, List/*<Integer>*/ items, IQueue queue, List/*<Thread>*/ threads) {
			for (int i = 0; i < count; i++) {
				createConsumerThread(i + 1, keepRunning, items, queue, threads);
			}
		}

		private Runnable createProducerRunnable(final ValueHolder/*<Boolean>*/ runHolder, final IQueue queue, final ValueHolder/*<Integer>*/ idHolder) {
			return new Runnable() {
				public void run() {
					while (ProducerConsumerTest.this.keepProducing(runHolder) == true) {
						ProducerConsumerTest.this.processProducer(queue, idHolder);
						Thread.yield();
					}
				}
			};
		}

		private void createProducerThread(int id, ValueHolder/*<Boolean>*/ keepRunning, ValueHolder/*<Integer>*/ counterHolder, IQueue queue, List/*<Thread>*/ threads) {
			Runnable runnable = createProducerRunnable(keepRunning, queue, counterHolder);
			Thread thread = new Thread(runnable, "Producer-" + id); //$NON-NLS-1$
			threads.add(thread);
		}

		private void createProducerThreads(int count, ValueHolder/*<Boolean>*/ keepRunning, ValueHolder/*<Integer>*/ counter, IQueue queue, List/*<Thread>*/ threads) {
			for (int i = 0; i < count; i++) {
				createProducerThread(i + 1, keepRunning, counter, queue, threads);
			}
		}

		private int getNextId(ValueHolder/*<Integer>*/ idHolder) {
			synchronized (idHolder) {
				int value = idHolder.getIntValue();
				value++;
				idHolder.setValue(value);
				return value;
			}
		}

		private boolean keepConsuming(ValueHolder runHolder, final IQueue queue) {
			return queue.isEmpty() == false || runHolder.isTrue() == true;
		}

		private boolean keepProducing(ValueHolder runHolder) {
			return runHolder.isTrue() == true;
		}

		private void processConsumer(IQueue queue, List/*<Integer>*/ items) throws InterruptedException {
			Object item = queue.remove();
			synchronized (items) {
				items.add(item);
			}
		}

		private void processProducer(IQueue queue, ValueHolder/*<Integer>*/ idHolder) {
			int value = getNextId(idHolder);
			Object item = new Integer(value);
			queue.add(item);
		}

		public void run() throws InterruptedException {
			List/*<Integer>*/ items = new ArrayList/*<Integer>*/(25000);
			IQueue queue = createQueue();
			ValueHolder/*<Boolean>*/ keepRunning = ValueHolder.trueValue();
			ValueHolder/*<Integer>*/ counter = ValueHolder.zeroValue();
			int producerCount = 3;
			int consumerCount = 3;
			int threadCount = producerCount + consumerCount;
			List/*<Thread>*/ threads = new ArrayList/*<Thread>*/(threadCount);
			createProducerThreads(producerCount, keepRunning, counter, queue, threads);
			createConsumerThreads(producerCount, keepRunning, items, queue, threads);
			startThreads(threads);
			delay(100);
			stopThreads(threads, keepRunning);
			assertSuccess(counter, items);
		}

		private void startThreads(List/*<Thread>*/ threads) {
			Iterator/*<Thread>*/ iterator = threads.iterator();
			while (iterator.hasNext() == true) {
				Thread thread = (Thread) iterator.next();
				thread.start();
			}
		}

		private void stopThreads(List/*<Thread>*/ threads, ValueHolder/*<Boolean>*/ keepRunning) throws InterruptedException {
			keepRunning.setFalse();
			Iterator/*<Thread>*/ iterator = threads.iterator();
			InterruptedException caughtException = null;
			while (iterator.hasNext() == true) {
				Thread thread = (Thread) iterator.next();
				thread.interrupt();
				try {
					thread.join();
				} catch (InterruptedException exception) {
					caughtException = exception;
				}
			}
			if (caughtException != null) {
				throw caughtException;
			}
		}
	}

	private static final String RED = "red"; //$NON-NLS-1$
	private static final String BLUE = "blue"; //$NON-NLS-1$;
	private static final String GREEN = "green"; //$NON-NLS-1$

	public static Test suite() {
		return new TestSuite(QueueTestCase.class);
	}

	public QueueTestCase(String name) {
		super(name);
	}

	private IQueue createQueue() {
		return createQueue(10);
	}

	private IQueue createQueue(int capacity) {
		return AbstractSatTestCase.FACTORY.createQueue(capacity);
	}

	public void test_add() {
		IQueue queue = createQueue(2);
		int expectedSize;
		int actualSize;

		expectedSize = 0;
		actualSize = queue.size();
		Assert.assertEquals(expectedSize, actualSize);

		queue.add(QueueTestCase.RED);
		expectedSize = 1;
		actualSize = queue.size();
		Assert.assertEquals(expectedSize, actualSize);

		queue.add(QueueTestCase.BLUE);
		expectedSize = 2;
		actualSize = queue.size();
		Assert.assertEquals(expectedSize, actualSize);

		queue.add(QueueTestCase.GREEN);
		expectedSize = 3;
		actualSize = queue.size();
		Assert.assertEquals(expectedSize, actualSize);
	}

	public void test_contains() throws InterruptedException {
		IQueue queue = createQueue();
		boolean state;

		state = queue.isEmpty();
		Assert.assertTrue(state);

		state = queue.contains(QueueTestCase.RED);
		Assert.assertFalse(state);

		queue.add(QueueTestCase.RED);
		state = queue.contains(QueueTestCase.RED);
		Assert.assertTrue(state);

		state = queue.contains(QueueTestCase.BLUE);
		Assert.assertFalse(state);

		queue.add(QueueTestCase.BLUE);
		state = queue.contains(QueueTestCase.BLUE);
		Assert.assertTrue(state);

		Object item;

		item = queue.remove();
		state = queue.contains(item);
		Assert.assertFalse(state);

		item = queue.remove();
		state = queue.contains(item);
		Assert.assertFalse(state);

		try {
			queue.contains(null);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}
	}

	public void test_isEmpty() throws InterruptedException {
		IQueue queue = createQueue();
		boolean state;

		state = queue.isEmpty();
		Assert.assertTrue(state);

		queue.add(QueueTestCase.RED);
		state = queue.isEmpty();
		Assert.assertFalse(state);

		queue.remove();
		state = queue.isEmpty();
		Assert.assertTrue(state);
	}

	public void test_producers_and_consumers() throws InterruptedException {
		ProducerConsumerTest test = new ProducerConsumerTest();
		test.run();
	}

	public void test_remove() throws InterruptedException {
		final IQueue queue = createQueue();
		Object item;

		queue.add(QueueTestCase.RED);
		queue.add(QueueTestCase.GREEN);
		queue.add(QueueTestCase.BLUE);

		item = queue.remove();
		Assert.assertEquals(item, QueueTestCase.RED);

		item = queue.remove();
		Assert.assertEquals(item, QueueTestCase.GREEN);

		item = queue.remove();
		Assert.assertEquals(item, QueueTestCase.BLUE);

		boolean empty = queue.isEmpty();
		Assert.assertTrue(empty);

		item = queue.remove(1);
		Assert.assertNull(item);

		final ValueHolder/*<Object>*/ holder = ValueHolder.nullValue();
		Assert.assertNull(holder.getValue());

		Runnable runnable = new Runnable() {
			public void run() {
				try {
					queue.remove();
					holder.setFalse(); // Failure.
				} catch (InterruptedException exception) {
					holder.setTrue(); // Success.
				}
			}
		};

		Thread thread = new Thread(runnable, "QueueTestCase.test_remove"); //$NON-NLS-1$
		thread.start();
		thread.interrupt(); // Interrupt remove()
		thread.join(); // Wait for thread to end.
		Assert.assertTrue(holder.isTrue());
	}

	public void test_size() throws InterruptedException {
		int expectedSize;
		int actualSize;

		IQueue queue = createQueue(2);

		expectedSize = 0;
		actualSize = queue.size();
		Assert.assertEquals(expectedSize, actualSize);

		queue.add(QueueTestCase.RED);
		expectedSize = 1;
		actualSize = queue.size();
		Assert.assertEquals(expectedSize, actualSize);

		queue.add(QueueTestCase.BLUE);
		expectedSize = 2;
		actualSize = queue.size();
		Assert.assertEquals(expectedSize, actualSize);

		queue.add(QueueTestCase.GREEN);
		expectedSize = 3;
		actualSize = queue.size();
		Assert.assertEquals(expectedSize, actualSize);

		queue.remove();
		expectedSize = 2;
		actualSize = queue.size();
		Assert.assertEquals(expectedSize, actualSize);

		queue.remove();
		expectedSize = 1;
		actualSize = queue.size();
		Assert.assertEquals(expectedSize, actualSize);

		queue.remove();
		expectedSize = 0;
		actualSize = queue.size();
		Assert.assertEquals(expectedSize, actualSize);
	}
}
