/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle.cm.test.customer;

import org.eclipse.soda.sat.core.internal.framework.bundle.cm.test.hotdog.VendorService;
import org.eclipse.soda.sat.core.util.LogUtility;

public class Customer extends Object {
	public static final String SPICINESS_PROPERTY_KEY = "spiciness"; //$NON-NLS-1$

	private String id;
	private int spiciness;
	private VendorService vendor;

	Customer(String id) {
		super();
		setId(id);
	}

	boolean eat() {
		String id = getId();
		VendorService vendor = getVendor();
		Object name = vendor.getName();
		Object product = vendor.sell();

		StringBuffer buffer = new StringBuffer(100);
		buffer.append("Customer "); //$NON-NLS-1$
		buffer.append(id);
		buffer.append(" bought "); //$NON-NLS-1$
		buffer.append(product);
		buffer.append(" from "); //$NON-NLS-1$
		buffer.append(name);

		String message = buffer.toString();
		log(message);

		boolean result = product != null;
		return result;
	}

	public String getId() {
		return id;
	}

	public int getSpiciness() {
		return spiciness;
	}

	public VendorService getVendor() {
		return vendor;
	}

	private void log(String message) {
		LogUtility.logInfo(message);
	}

	private void setId(String id) {
		this.id = id;
	}

	void setSpiciness(int spiciness) {
		this.spiciness = spiciness;
	}

	void setVendor(VendorService vendor) {
		this.vendor = vendor;
	}

	public String toString() {
		Object id = getId();
		int spiciness = getSpiciness();
		Object vendor = getVendor();

		StringBuffer buffer = new StringBuffer(100);
		buffer.append(super.toString());
		buffer.append(", id="); //$NON-NLS-1$
		buffer.append(id);
		buffer.append(", spiciness="); //$NON-NLS-1$
		buffer.append(spiciness);
		buffer.append(", vendor="); //$NON-NLS-1$
		buffer.append(vendor);
		String message = buffer.toString();
		return message;
	}
}
