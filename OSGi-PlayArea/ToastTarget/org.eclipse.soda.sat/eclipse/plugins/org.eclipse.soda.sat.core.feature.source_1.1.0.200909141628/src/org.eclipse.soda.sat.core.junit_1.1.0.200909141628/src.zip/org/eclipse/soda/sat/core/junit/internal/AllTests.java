/*******************************************************************************
 * Copyright (c) 2001, 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.junit.internal;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.internal.framework.bundle.cm.test.ManagedServiceFactoryActivationManagerTestCase;
import org.eclipse.soda.sat.core.internal.framework.bundle.log.test.LogReaderAggregatorTestCase;
import org.eclipse.soda.sat.core.internal.framework.bundle.test.BundleActivationManagerTestCase;
import org.eclipse.soda.sat.core.internal.framework.bundle.test.BundleDependencyManagerTestCase;
import org.eclipse.soda.sat.core.internal.record.container.test.ExportServiceRecordContainerTestCase;
import org.eclipse.soda.sat.core.internal.record.container.test.ImportServiceRecordContainerTestCase;
import org.eclipse.soda.sat.core.internal.record.test.ServiceDetecterTestCase;
import org.eclipse.soda.sat.core.internal.util.test.CharBufferTestCase;
import org.eclipse.soda.sat.core.internal.util.test.DependencyTrackerTestCase;
import org.eclipse.soda.sat.core.internal.util.test.FileLogTestCase;
import org.eclipse.soda.sat.core.internal.util.test.LineReaderTestCase;
import org.eclipse.soda.sat.core.internal.util.test.LineWriterTestCase;
import org.eclipse.soda.sat.core.internal.util.test.OutputStreamLogTestCase;
import org.eclipse.soda.sat.core.internal.util.test.QueueTestCase;
import org.eclipse.soda.sat.core.internal.util.test.TokenizerTestCase;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.test.BundleManifestUtilityTestCase;
import org.eclipse.soda.sat.core.util.test.BundleUtilityTestCase;
import org.eclipse.soda.sat.core.util.test.CollectionUtilityTestCase;
import org.eclipse.soda.sat.core.util.test.LogUtilityTestCase;
import org.eclipse.soda.sat.core.util.test.ServiceReferenceUtilityTestCase;
import org.osgi.service.log.LogService;

/**
 * AllTests.java
 */
public class AllTests extends Object {
	/*
	 * Initialize the logging level use for the SAT tests.
	 */
	private static void initializeLoggingLevel() {
		boolean tracing = LogUtility.isTracing();
		int loggingLevel = tracing == true ? LogService.LOG_DEBUG : LogService.LOG_ERROR;
		LogUtility.setLoggingLevel(loggingLevel);
	}

	/*
	 * Answers a JUnit TestSuite containing all the SAT tests.
	 */
	public static Test suite() {
		AllTests.initializeLoggingLevel();

		TestSuite suite = new TestSuite("All SAT Core JUnit Tests"); //$NON-NLS-1$

		// Bundle Configuration Test
		suite.addTest(BundleConfigurationTestCase.suite());

		// org.eclipse.soda.sat.core.internal.framework.bundle.cm.test
		suite.addTest(ManagedServiceFactoryActivationManagerTestCase.suite());

		// org.eclipse.soda.sat.core.internal.framework.bundle.test
		suite.addTest(BundleActivationManagerTestCase.suite());
		suite.addTest(BundleDependencyManagerTestCase.suite());

		// org.eclipse.soda.sat.core.internal.framework.bundle.log.test
		suite.addTest(LogReaderAggregatorTestCase.suite());

		// org.eclipse.soda.sat.core.internal.record.test
		suite.addTest(ServiceDetecterTestCase.suite());
		suite.addTest(org.eclipse.soda.sat.core.internal.record.test.ExportServiceRecordTestCase.suite());
		suite.addTest(org.eclipse.soda.sat.core.internal.record.test.ExportProxyServiceRecordTestCase.suite());
		suite.addTest(org.eclipse.soda.sat.core.internal.record.test.ImportServiceRecordTestCase.suite());

		// org.eclipse.soda.sat.core.internal.record.container.test
		suite.addTest(ExportServiceRecordContainerTestCase.suite());
		suite.addTest(ImportServiceRecordContainerTestCase.suite());

		// org.eclipse.soda.sat.core.internal.util.test
		suite.addTest(CharBufferTestCase.suite());
		suite.addTest(DependencyTrackerTestCase.suite());
		suite.addTest(FileLogTestCase.suite());
		suite.addTest(LineReaderTestCase.suite());
		suite.addTest(LineWriterTestCase.suite());
		suite.addTest(OutputStreamLogTestCase.suite());
		suite.addTest(QueueTestCase.suite());
		suite.addTest(TokenizerTestCase.suite());

		// org.eclipse.soda.sat.core.util.test
		suite.addTest(BundleManifestUtilityTestCase.suite());
		suite.addTest(BundleUtilityTestCase.suite());
		suite.addTest(CollectionUtilityTestCase.suite());
		suite.addTest(LogUtilityTestCase.suite());
		suite.addTest(ServiceReferenceUtilityTestCase.suite());

		// org.eclipse.soda.sat.core.junit.internal.old;
//		suite.addTest(BaseBundleActivatorTestCase.suite());
//		suite.addTest(DependencyTrackerTestCase.suite());
//		suite.addTest(BaseBundleActivatorPropertiesTestCase.suite());

		return suite;
	}
}