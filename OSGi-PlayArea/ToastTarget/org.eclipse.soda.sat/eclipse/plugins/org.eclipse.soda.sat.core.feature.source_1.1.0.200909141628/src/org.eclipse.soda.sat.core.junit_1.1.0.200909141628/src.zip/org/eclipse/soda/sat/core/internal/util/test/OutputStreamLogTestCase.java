/*******************************************************************************
 * Copyright (c) 2009 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util.test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;
import org.eclipse.soda.sat.core.junit.internal.bundle.Activator;
import org.eclipse.soda.sat.core.util.CollectionUtility;
import org.osgi.framework.Bundle;
import org.osgi.framework.ServiceReference;
import org.osgi.service.log.LogService;

public class OutputStreamLogTestCase extends AbstractSatTestCase {
	private class AsynchronousLoggingTest extends Object {
		private void assertSuccess(List[] loggedMessageLists, int threadCount, int iterations) {
			int expectedSize = threadCount * iterations;
			for (int i = 0; i < loggedMessageLists.length; i++) {
				List/*<String>*/ loggedMessageList = loggedMessageLists [ i ];
				for (int j = 0; j < OutputStreamLogTestCase.MESSAGES.length; j++) {
					List values = selectMessages(j, loggedMessageList);
					int actualSize = values.size();
					Assert.assertEquals(expectedSize, actualSize);
				}
			}
		}

		private CollectionUtility.Accessor createAccessor(final String value) {
			return new CollectionUtility.Accessor() {
				public Object get(Object item) {
					String message = (String) item;
					boolean match = message.indexOf(value) != -1;
					return match == true ? item : null;
				}
			};
		}

		private Runnable createRunnable(final LogService log, final int count) {
			return new Runnable() {
				public void run() {
					AsynchronousLoggingTest.this.process(log, count);
				}
			};
		}

		private Thread createThread(int id, LogService log, int count) {
			Runnable runnable = createRunnable(log, count);
			Thread thread = new Thread(runnable, "Logger-" + id); //$NON-NLS-1$
			return thread;
		}

		private void process(LogService log, int count) {
			for (int i = 0; i < count; i++) {
				for (int j = 0; j < OutputStreamLogTestCase.MESSAGES.length; j++) {
					String message = getMessage(j);
					log.log(LogService.LOG_ERROR, message);
					log.log(LogService.LOG_WARNING, message);
					log.log(LogService.LOG_INFO, message);
					log.log(LogService.LOG_DEBUG, message);
					Thread.yield();
				}
			}
		}

		public void run() throws InterruptedException {
			int threadCount = 15;
			int iterations = 75;
			int size = OutputStreamLogTestCase.MESSAGES.length * threadCount * iterations;
			List/*<String>*/[] loggedMessageLists = createLoggedMessageLists(size);
			LogService log = createLogService(loggedMessageLists);
			List/*<Thread>*/ threads = new ArrayList/*<Thread>*/(threadCount);
			startThreads(log, threadCount, iterations, threads);
			waitForThreadsToTerminate(threads);
			assertSuccess(loggedMessageLists, threadCount, iterations);
		}

		private List selectMessages(int index, List/*<String>*/ loggedMessageList) {
			String message = getMessage(index);
			CollectionUtility.Accessor accessor = createAccessor(message);
			CollectionUtility utility = CollectionUtility.getInstance();
			List/*<String>*/ values = utility.select(loggedMessageList, accessor);
			return values;
		}

		private void startThreads(LogService log, int threadCount, int iterations, List/*<Thread>*/ threads) {
			for (int i = 0; i < threadCount; i++) {
				Thread thread = createThread(i + 1, log, iterations);
				threads.add(thread);
				thread.start();
			}
		}

		private void waitForThreadsToTerminate(List threads) throws InterruptedException {
			for (int i = 0; i < threads.size(); i++) {
				Thread thread = (Thread) threads.get(i);
				thread.join();
			}
		}
	}

	private static final int[] LOG_LEVELS = new int[] {
		LogService.LOG_ERROR,
		LogService.LOG_WARNING,
		LogService.LOG_INFO,
		LogService.LOG_DEBUG
	};

	private static final String[] LOG_LEVEL_LABELS = new String[] {
		"[ERROR]", //$NON-NLS-1$
		"[WARNING]", //$NON-NLS-1$
		"[INFO]", //$NON-NLS-1$
		"[DEBUG]" //$NON-NLS-1$
	};

	private static final String[] MESSAGES = new String[] {
		"one", //$NON-NLS-1$
		"two", //$NON-NLS-1$
		"three", //$NON-NLS-1$
		"four", //$NON-NLS-1$
		"five" //$NON-NLS-1$
	};

	public static Test suite() {
		return new TestSuite(OutputStreamLogTestCase.class);
	}

	public OutputStreamLogTestCase(String name) {
		super(name);
	}

	private List/*<String>*/[] createLoggedMessageLists(int size) {
		return new ArrayList/*<String>*/[] {
			new ArrayList/*<String>*/(size),
			new ArrayList/*<String>*/(size),
			new ArrayList/*<String>*/(size),
			new ArrayList/*<String>*/(size)
		};
	}

	private LogService createLogService(List/*<String>*/[] loggedMessageLists) {
		OutputStream[] outputStreams = createOutputStreams(loggedMessageLists);
		LogService log = createLogService(outputStreams);
		return log;
	}

	private LogService createLogService(OutputStream[] outputStreams) {
		LogService log = AbstractSatTestCase.FACTORY.createOutputStreamLog(
			outputStreams [ LogService.LOG_ERROR - 1 ],
			outputStreams [ LogService.LOG_WARNING - 1 ],
			outputStreams [ LogService.LOG_INFO - 1 ],
			outputStreams [ LogService.LOG_DEBUG - 1 ]);
		return log;
	}

	private LogService createNullLogService() {
		return AbstractSatTestCase.FACTORY.createOutputStreamLog(null, null, null, null);
	}

	private OutputStream createOutputStream(final List messages) {
		return new ByteArrayOutputStream(100) {
			public void write(byte[] bytes) throws IOException {
				String message = new String(bytes);
				synchronized (messages) {
					messages.add(message);
				}
				super.write(bytes);
			}
		};
	}

	private OutputStream[] createOutputStreams(List/*<String>*/[] loggedMessageLists) {
		return new OutputStream[] {
			createOutputStream(loggedMessageLists [ LogService.LOG_ERROR - 1 ]),
			createOutputStream(loggedMessageLists [ LogService.LOG_WARNING - 1 ]),
			createOutputStream(loggedMessageLists [ LogService.LOG_INFO - 1 ]),
			createOutputStream(loggedMessageLists [ LogService.LOG_DEBUG - 1 ])
		};
	}

	private ServiceReference createServiceReference() {
		return new ServiceReference() {
			public int compareTo(Object reference) {
				return 0;
			}

			public Bundle getBundle() {
				return OutputStreamLogTestCase.this.getBundle();
			}

			public Object getProperty(String key) {
				return null;
			}

			public String[] getPropertyKeys() {
				return null;
			}

			public Bundle[] getUsingBundles() {
				return null;
			}

			public boolean isAssignableTo(Bundle bundle, String className) {
				return false;
			}
		};
	}

	private Bundle getBundle() {
		return Activator.BUNDLE_CONTEXT != null ? Activator.BUNDLE_CONTEXT.getBundle() : null;
	}

	private String getMessage(int index) {
		int i = index % OutputStreamLogTestCase.MESSAGES.length;
		String message = OutputStreamLogTestCase.MESSAGES [ i ];
		return message;
	}

	public void test_asynchronous_logging() throws InterruptedException {
		AsynchronousLoggingTest test = new AsynchronousLoggingTest();
		test.run();
	}

	public void test_log() {
		List/*<String>*/[] loggedMessageLists = createLoggedMessageLists(5);
		LogService log = createLogService(loggedMessageLists);

		for (int i = 0; i < OutputStreamLogTestCase.LOG_LEVELS.length; i++) {
			int level = OutputStreamLogTestCase.LOG_LEVELS [ i ];
			for (int j = 0; j < OutputStreamLogTestCase.MESSAGES.length; j++) {
				String message = getMessage(j) + level;
				log.log(level, message);
			}
		}

		for (int i = 0; i < OutputStreamLogTestCase.LOG_LEVELS.length; i++) {
			int level = OutputStreamLogTestCase.LOG_LEVELS [ i ];
			String levelLabel = OutputStreamLogTestCase.LOG_LEVEL_LABELS [ i ];
			List/*<String>*/ list = loggedMessageLists [ i ];
			for (int j = 0; j < OutputStreamLogTestCase.MESSAGES.length; j++) {
				String expected = levelLabel + ' ' + getMessage(j) + level + "\r\n"; //$NON-NLS-1$
				String actual = (String) list.get(j);
				Assert.assertEquals(expected, actual);
			}
		}

		ServiceReference reference = createServiceReference();
		log.log(reference, LogService.LOG_DEBUG, "hello");
//		List list = loggedMessageLists [ 3 ];
//		System.out.println(list);
	}

	public void test_null_log() {
		LogService log = createNullLogService();
		for (int i = 0; i < OutputStreamLogTestCase.LOG_LEVELS.length; i++) {
			int level = OutputStreamLogTestCase.LOG_LEVELS [ i ];
			log.log(level, null);
		}
		Assert.assertTrue(true);
	}
}
