/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.framework.interfaces.ICharBuffer;
import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;

public class CharBufferTestCase extends AbstractSatTestCase {
	private static final String VALUE1 = "ABCDEFGHIJ"; //$NON-NLS-1$
	private static final String VALUE2 = "KLMNOPQRST"; //$NON-NLS-1$

	public static Test suite() {
		return new TestSuite(CharBufferTestCase.class);
	}

	public CharBufferTestCase(String name) {
		super(name);
	}

	private void assertAppendBoolean(boolean expectedValue) {
		ICharBuffer buffer = createBuffer(5);
		buffer.append(expectedValue);
		String value = buffer.getValue();
		Boolean wrapper = Boolean.valueOf(value);
		boolean actualValue = wrapper.booleanValue();
		Assert.assertEquals(expectedValue, actualValue);
	}

	private void assertAppendDouble(double expectedValue) {
		ICharBuffer buffer = createBuffer(5);
		buffer.append(expectedValue);
		String value = buffer.getValue();
		double actualValue = Double.parseDouble(value);
		Assert.assertEquals(expectedValue, actualValue, 0.0);
	}

	private void assertAppendFloat(float expectedValue) {
		ICharBuffer buffer = createBuffer(5);
		buffer.append(expectedValue);
		String value = buffer.getValue();
		float actualValue = Float.parseFloat(value);
		Assert.assertEquals(expectedValue, actualValue, 0.0);
	}

	private void assertAppendInt(int expectedValue) {
		ICharBuffer buffer = createBuffer(5);
		buffer.append(expectedValue);
		String value = buffer.getValue();
		int actualValue = Integer.parseInt(value);
		Assert.assertEquals(expectedValue, actualValue);
	}

	private void assertAppendLong(long expectedValue) {
		ICharBuffer buffer = createBuffer(5);
		buffer.append(expectedValue);
		String value = buffer.getValue();
		long actualValue = Long.parseLong(value);
		Assert.assertEquals(expectedValue, actualValue);
	}

	private void assertGrow100Percent(ICharBuffer buffer) {
		// Check that the specified buffer's grow percentage is 100%.
		int expectedGrowPercentage = 100;
		int actualGrowPercentage = buffer.getGrowPercentage();
		Assert.assertEquals(expectedGrowPercentage, actualGrowPercentage);
	}

	private void assertGrowExponentially(ICharBuffer buffer) {
		// Check that the specified buffer's grow strategy is exponential.
		assertGrowStyle(buffer, ICharBuffer.GROW_EXPONENTIALLY);
	}

	private void assertGrowLinearly(ICharBuffer buffer) {
		// Check that the specified buffer's grow strategy is linear.
		assertGrowStyle(buffer, ICharBuffer.GROW_LINEARLY);
	}

	private void assertGrowStyle(ICharBuffer buffer, short expectedGrowStyle) {
		// Check that the specified buffer's grow strategy is linear.
		short actualGrowStyle = buffer.getGrowStyle();
		Assert.assertEquals(expectedGrowStyle, actualGrowStyle);
	}

	private ICharBuffer createBuffer() {
		// Create a buffer that will grown at 100% of its initial capacity.
		return createBuffer(10);
	}

	private ICharBuffer createBuffer(int capacity) {
		return AbstractSatTestCase.FACTORY.createCharBuffer(capacity);
	}

	private Runnable createCharAppenderRunnable(final int n, final ICharBuffer buffer, final int count) {
		return new Runnable() {
			public void run() {
				for (int i = 0; i < count; i++) {
					char ch = (char) (65 + n);
					buffer.append(ch);
					Thread.yield(); // $codepro.audit.disable
				}
			}
		};
	}

	private Runnable createCharAppenderWithSynchronizationRunnable(final int n, final ICharBuffer buffer, final int count) {
		return new Runnable() {
			public void run() {
				Runnable runnable = CharBufferTestCase.this.createCharAppenderRunnable(n, buffer, count);
				synchronized (buffer) {
					runnable.run();
				}
			}
		};
	}

	private Runnable createCharAtRunnable(final ICharBuffer buffer, final int count) {
		return new Runnable() {
			public void run() {
				int length = buffer.length();
				for (int i = 0; i < count; i++) {
					int index = (int) (Math.random() * length);
					buffer.charAt(index);
					Thread.yield(); // $codepro.audit.disable
				}
			}
		};
	}

	private Runnable createStringAppenderRunnable(final String value, final ICharBuffer buffer, final int count) {
		return new Runnable() {
			public void run() {
				for (int i = 0; i < count; i++) {
					buffer.append(value);
					Thread.yield(); // $codepro.audit.disable
				}
			}
		};
	}

	private String getShortTestCaseName() {
		String className = CharBufferTestCase.class.getName();
		int index = className.lastIndexOf('.');
		String name = className.substring(index + 1);
		return name;
	}

	private void join(List/*<Thread>*/ threads) {
		// Wait for the threads to finish.
		Iterator/*<Thread>*/ iterator = threads.iterator();
		try {
			while (iterator.hasNext() == true) {
				Thread thread = (Thread) iterator.next();
				thread.join();
			}
		} catch (InterruptedException exception) {
			exception.printStackTrace();
		}
	}

	public void test_append_boolean() {
		assertAppendBoolean(true);
		assertAppendBoolean(false);
	}

	public void test_append_char() {
		ICharBuffer buffer;
		char ch;
		int expectedLength;
		int actualLength;

		buffer = createBuffer(10);

		// Check that the length of a newly created buffer is zero.
		expectedLength = 0;
		actualLength = buffer.length();
		Assert.assertEquals(expectedLength, actualLength);

		// Check that the capacity of the buffer is 10.
		int expectedCapacity = 10;
		int actualCapacity = buffer.capacity();
		Assert.assertEquals(expectedCapacity, actualCapacity);

		// Append 1 character and check that the buffer's length is 1.
		ch = CharBufferTestCase.VALUE1.charAt(0);
		buffer.append(ch);
		expectedLength = 1;
		actualLength = buffer.length();
		Assert.assertEquals(expectedLength, actualLength);

		// Append 9 characters.
		for (int i = 1; i < 10; i++) {
			ch = CharBufferTestCase.VALUE1.charAt(i);
			buffer.append(ch);
		}

		// Check that the buffer's length is 10.
		expectedLength = 10;
		actualLength = buffer.length();
		Assert.assertEquals(expectedLength, actualLength);

		// Append one more character than the capacity of the buffer.
		ch = CharBufferTestCase.VALUE2.charAt(0);
		buffer.append(ch);

		// Check that the buffer's length is 11.
		expectedLength = 11;
		actualLength = buffer.length();

		// Check that the buffer's grow percentage is 100% and that it grows
		// linearly based on its initial capacity.
		assertGrow100Percent(buffer);
		assertGrowLinearly(buffer);

		// Check that the buffer's capacity is now 21, which is 11 + 100% of 10.
		expectedCapacity = 21;
		actualCapacity = buffer.capacity();
		Assert.assertEquals(expectedCapacity, actualCapacity);

		// Check that the local variable ch has a well known value.
		char expectedCh = CharBufferTestCase.VALUE2.charAt(0);
		Assert.assertEquals(ch, expectedCh);

		// Check the value of the buffer.
		String expectedValue = CharBufferTestCase.VALUE1 + ch;
		String actualValue = buffer.getValue();
		Assert.assertEquals(expectedValue, actualValue);

		// Create a new buffer and append a null Object.
		buffer = createBuffer();
		Object objectParameter = null;
		buffer.append(objectParameter);
		expectedValue = String.valueOf(objectParameter);
		actualValue = buffer.getValue();
		Assert.assertEquals(expectedValue, actualValue);

		// Create a new buffer and append a null String.
		buffer = createBuffer();
		String stringParameter = null;
		buffer.append(stringParameter);
		expectedValue = String.valueOf(stringParameter);
		actualValue = buffer.getValue();
	}

	public void test_append_char_array() {
		ICharBuffer buffer;
		char[] array;
		int expectedLength;
		int actualLength;
		String expectedValue;
		String actualValue;

		buffer = createBuffer();
		array = CharBufferTestCase.VALUE1.toCharArray();
		buffer.append(array);
		expectedLength = array.length;
		actualLength = buffer.length();
		Assert.assertEquals(expectedLength, actualLength);

		buffer = createBuffer();
		array = CharBufferTestCase.VALUE1.toCharArray();
		buffer.append(array, 0, 5);
		expectedLength = 5;
		actualLength = buffer.length();
		Assert.assertEquals(expectedLength, actualLength);

		expectedValue = new String(array, 0, 5);
		actualValue = buffer.getValue();
		Assert.assertEquals(expectedValue, actualValue);

		buffer.append(array, 5, 5);
		expectedLength = 10;
		actualLength = buffer.length();
		Assert.assertEquals(expectedLength, actualLength);

		expectedValue = CharBufferTestCase.VALUE1;
		actualValue = buffer.getValue();
		Assert.assertEquals(expectedValue, actualValue);

		buffer = createBuffer();
		array = CharBufferTestCase.VALUE1.toCharArray();
		buffer.append(array, 5, 5);
		expectedLength = 5;
		actualLength = buffer.length();
		Assert.assertEquals(expectedLength, actualLength);

		expectedValue = new String(array, 5, 5);
		actualValue = buffer.getValue();
		Assert.assertEquals(expectedValue, actualValue);

		buffer = createBuffer();

		try {
			buffer.append(null, 0, 1);
			Assert.fail();
		} catch (NullPointerException exception) {
			Assert.assertTrue(true);
		}

		array = CharBufferTestCase.VALUE1.toCharArray();

		try {
			buffer.append(array, -1, 1);
			Assert.fail();
		} catch (ArrayIndexOutOfBoundsException exception) {
			Assert.assertTrue(true);
		}

		try {
			buffer.append(array, 0, array.length + 1);
			Assert.fail();
		} catch (ArrayIndexOutOfBoundsException exception) {
			Assert.assertTrue(true);
		}
	}

	public void test_append_double() {
		assertAppendDouble(Double.MIN_VALUE);
		assertAppendDouble(Double.MAX_VALUE);
	}

	public void test_append_float() {
		assertAppendFloat(Float.MIN_VALUE);
		assertAppendFloat(Float.MAX_VALUE);
	}

	public void test_append_int() {
		assertAppendInt(Integer.MIN_VALUE);
		assertAppendInt(Integer.MAX_VALUE);
	}

	public void test_append_long() {
		assertAppendLong(Long.MIN_VALUE);
		assertAppendLong(Long.MAX_VALUE);
	}

	public void test_append_Object() {
		ICharBuffer buffer;
		String expectedValue;
		String actualValue;

		// Create a new buffer and append a null Object.
		buffer = createBuffer();
		Object objectParameter = null;
		buffer.append(objectParameter);
		expectedValue = String.valueOf(objectParameter);
		actualValue = buffer.getValue();
		Assert.assertEquals(expectedValue, actualValue);

		// Create a new buffer and append a null String.
		buffer = createBuffer();
		String stringObject = null;
		buffer.append(stringObject);
		expectedValue = String.valueOf(stringObject);
		actualValue = buffer.getValue();
		Assert.assertEquals(expectedValue, actualValue);

		class Person {
			private String name;

			Person(String name) {
				super();
				this.name = name;
			}

			public String toString() {
				return name;
			}
		}

		expectedValue = "John Smith"; //$NON-NLS-1$
		Object person = new Person(expectedValue);

		// Create a new buffer and append a Person
		buffer = createBuffer();
		buffer.append(person);
		actualValue = buffer.getValue();
		Assert.assertEquals(expectedValue, actualValue);
	}

	public void test_append_String() {
		ICharBuffer buffer;
		String expectedValue;
		String actualValue;

		// Create a new buffer and append a String.
		buffer = createBuffer(5);
		buffer.append(CharBufferTestCase.VALUE1);
		buffer.append(CharBufferTestCase.VALUE2);

		expectedValue = CharBufferTestCase.VALUE1 + CharBufferTestCase.VALUE2;
		actualValue = buffer.getValue();
		Assert.assertEquals(expectedValue, actualValue);

		// Create a new buffer and append a null Object.
		buffer = createBuffer();

		// Create a new buffer and append a null String.
		buffer = createBuffer();
		String stringParameter = null;
		buffer.append(stringParameter);
		expectedValue = String.valueOf(stringParameter);
		actualValue = buffer.getValue();
		Assert.assertEquals(expectedValue, actualValue);
	}

	public void test_asynchronousCharAppend() {
		// Create a thread safe buffer that grows quickly.
		ICharBuffer buffer = createBuffer(100);
		buffer = toFastGrowingSynchronizedBuffer(buffer);
		int threadCount = 26;
		int appendCount = 100;
		String prefix = getShortTestCaseName();
		List/*<Thread>*/ threads = new ArrayList/*<Thread>*/(threadCount);

		// Start some threads that will append chars to the buffer.
		for (int i = 0; i < threadCount; i++) {
			String name = prefix + "-CharAppender-" + i; //$NON-NLS-1$
			Runnable runnable = createCharAppenderRunnable(i, buffer, appendCount);
			Thread thread = new Thread(runnable, name);
			threads.add(thread);
			thread.start();
		}

		join(threads);

		int expectedLength;
		int actualLength;

		// Check that the buffer's reported length is correct.
		expectedLength = threadCount * appendCount;
		actualLength = buffer.length();
		Assert.assertEquals(expectedLength, actualLength);

		// Check that the length of the String returned by the buffer is
		// correct.
		String value = buffer.getValue();
		actualLength = value.length();
		Assert.assertEquals(expectedLength, actualLength);
	}

	public void test_asynchronousCharAt() {
		ICharBuffer buffer = createBuffer(10);
		buffer = buffer.toSynchronizedCharBuffer();
		buffer.append(CharBufferTestCase.VALUE1);
		int threadCount = 25;
		int readCount = 100;
		String prefix = getShortTestCaseName();
		List/*<Thread>*/ threads = new ArrayList/*<Thread>*/(threadCount);

		// Start some threads that will read the buffer.
		for (int i = 0; i < threadCount; i++) {
			String name = prefix + "-Reader-" + i; //$NON-NLS-1$
			Runnable runnable = createCharAtRunnable(buffer, readCount);
			Thread thread = new Thread(runnable, name);
			threads.add(thread);
			thread.start();
		}

		join(threads);
		Assert.assertTrue(true);
	}

	public void test_asynchronousStringAppend() {
		// Create a thread safe buffer that grows quickly.
		ICharBuffer buffer = createBuffer(100);
		buffer = toFastGrowingSynchronizedBuffer(buffer);
		int threadCount = 10;
		int appendCount = 100;
		String prefix = getShortTestCaseName();
		List/*<Thread>*/ threads = new ArrayList/*<Thread>*/(threadCount);

		// Start some threads that will append Strings to the buffer.
		for (int i = 0; i < threadCount; i++) {
			String name = prefix + "-StringAppender-" + i; //$NON-NLS-1$
			Runnable runnable = createStringAppenderRunnable(CharBufferTestCase.VALUE1, buffer, appendCount);
			Thread thread = new Thread(runnable, name);
			threads.add(thread);
			thread.start();
		}

		join(threads);

		int expectedLength;
		int actualLength;

		// Check that the buffer's reported length is correct.
		expectedLength = threadCount * appendCount * CharBufferTestCase.VALUE1.length();
		actualLength = buffer.length();
		Assert.assertEquals(expectedLength, actualLength);

		// Check that the length of the String returned by the buffer is
		// correct.
		String value = buffer.getValue();
		actualLength = value.length();
		Assert.assertEquals(expectedLength, actualLength);
	}

	public void test_capacity() {
		int expectedCapacity;
		int actualCapacity;

		// Create a buffer with a capacity of 10 and check that it's correct.
		ICharBuffer buffer = createBuffer(10);
		expectedCapacity = 10;
		actualCapacity = buffer.capacity();
		Assert.assertEquals(expectedCapacity, actualCapacity);

		// Fill the buffer to capacity.
		buffer.append(CharBufferTestCase.VALUE1);
		actualCapacity = buffer.capacity();
		Assert.assertEquals(expectedCapacity, actualCapacity);

		// Check that the buffer's grow percentage is 100% and that it grows
		// linearly based on its initial capacity.
		assertGrow100Percent(buffer);
		assertGrowLinearly(buffer);

		// Force the buffer to grow and check that its new capacity is correct.
		buffer.append(CharBufferTestCase.VALUE2);
		expectedCapacity = 30;
		actualCapacity = buffer.capacity();
		Assert.assertEquals(expectedCapacity, actualCapacity);
	}

	public void test_charAt() {
		// Create an populate a buffer.
		ICharBuffer buffer = createBuffer();
		buffer.append(CharBufferTestCase.VALUE1);

		// Check that the buffer is the correct length.
		int expectedLength = CharBufferTestCase.VALUE1.length();
		int actualLength = buffer.length();
		Assert.assertEquals(expectedLength, actualLength);

		// Use charAt to query each character and then check that it is the
		// expected character.
		for (int i = 0; i < actualLength; i++) {
			char expectedCh = CharBufferTestCase.VALUE1.charAt(i);
			char actualCh = buffer.charAt(i);
			Assert.assertEquals(expectedCh, actualCh);
		}

		// Check that you cannot call charAt with a negative index.
		try {
			buffer.charAt(-1);
			Assert.fail();
		} catch (ArrayIndexOutOfBoundsException exception) {
			Assert.assertTrue(true);
		}
	}

	public void test_constructor() {
		ICharBuffer buffer;

		// Check that passing a non-zero value as the initial capacity results
		// in a buffer with the correct capacity.
		int expectedCapacity = 10;
		buffer = createBuffer(expectedCapacity);
		int actualCapacity = buffer.capacity();
		Assert.assertEquals(expectedCapacity, actualCapacity);

		// Check that passing zero as the initial capacity does not result in a
		// buffer with a capacity of zero.
		buffer = createBuffer(0);
		int capacity = buffer.capacity();
		Assert.assertTrue(capacity != 0);
	}

	public void test_getGrowPercentage() {
		// Create a buffer and check that the default grow percentation is 100%.
		ICharBuffer buffer = createBuffer();
		assertGrow100Percent(buffer);

		int expectedGrowPercentage;
		int actualGrowPercentage;

		// Check that the buffer's grow percentage can be set to 50%.
		expectedGrowPercentage = 50;
		buffer.setGrowPercentage(expectedGrowPercentage);
		actualGrowPercentage = buffer.getGrowPercentage();
		Assert.assertEquals(expectedGrowPercentage, actualGrowPercentage);

		// Check that the buffer's grow percentage can be set to 200%.
		expectedGrowPercentage = 200;
		buffer.setGrowPercentage(expectedGrowPercentage);
		actualGrowPercentage = buffer.getGrowPercentage();
		Assert.assertEquals(expectedGrowPercentage, actualGrowPercentage);

		// Check that the buffer's grow percentage cannot be set less that 1%.
		try {
			buffer.setGrowPercentage(0);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}
	}

	public void test_getGrowStyle() {
		// Create a buffer and check that by default it grows linearly.
		ICharBuffer buffer = createBuffer();
		assertGrowLinearly(buffer);

		// Check that the growth style can be changed to exponentially.
		buffer.setGrowStyle(ICharBuffer.GROW_EXPONENTIALLY);
		assertGrowExponentially(buffer);

		// Check that the growth style can be changed to linearly.
		buffer.setGrowStyle(ICharBuffer.GROW_LINEARLY);
		assertGrowLinearly(buffer);
	}

	public void test_getValue() {
		String expectedValue;
		String actualValue;

		// Create an empty buffer and check that it's value is an empty String.
		ICharBuffer buffer = createBuffer();
		expectedValue = new String();
		actualValue = buffer.getValue();
		Assert.assertEquals(expectedValue, actualValue);

		// Appending the characters A - J.
		int start = 'A';
		int stop = 'J';

		for (int i = start; i <= stop; i++) {
			char ch = (char) i;
			buffer.append(ch);
		}

		// Append a String containing the letters K - Z.
		buffer.append(CharBufferTestCase.VALUE2);

		// Check that the buffer's value is correct.
		expectedValue = CharBufferTestCase.VALUE1 + CharBufferTestCase.VALUE2;
		actualValue = buffer.getValue();
		Assert.assertEquals(expectedValue, actualValue);
	}

	public void test_length() {
		// Create an empty buffer and check that its length is zero.
		ICharBuffer buffer = createBuffer(10);
		int expectedLength = 0;
		int actualLength = buffer.length();
		Assert.assertEquals(expectedLength, actualLength);

		// Append a String and check that the buffer's length is correct.
		buffer.append(CharBufferTestCase.VALUE1);
		expectedLength = CharBufferTestCase.VALUE1.length();
		actualLength = buffer.length();
		Assert.assertEquals(expectedLength, actualLength);

		// Append another String and check that the buffer's length is correct.
		buffer.append(CharBufferTestCase.VALUE2);
		expectedLength += CharBufferTestCase.VALUE2.length();
		actualLength = buffer.length();
		Assert.assertEquals(expectedLength, actualLength);
	}

	public void test_setChar() {
		int capacity = 10;
		ICharBuffer buffer = createBuffer(capacity);

		// Check that you cannot set a character before index zero.
		try {
			buffer.setChar(-1, 'X');
			Assert.fail();
		} catch (ArrayIndexOutOfBoundsException exception) {
			Assert.assertTrue(true);
		}

		// Check that you can set a character between zero and the buffer's
		// capacity - 1.
		buffer.append(CharBufferTestCase.VALUE1);
		for (int i = 0; i < capacity; i++) {
			String value = String.valueOf(i);
			char ch = value.charAt(0);
			buffer.setChar(i, ch);
		}

		String expectedValue = "0123456789"; //$NON-NLS-1$
		String actualValue = buffer.getValue();
		Assert.assertEquals(expectedValue, actualValue);
	}

	public void test_setGrowPercentage() {
		// Create a buffer and check that its grow percentage is 100%.
		ICharBuffer buffer = createBuffer();
		assertGrow100Percent(buffer);

		// Check that the buffer's grow percentage cannot be to less than 1.
		try {
			buffer.setGrowPercentage(0);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}
	}

	public void test_setGrowStyle() {
		ICharBuffer buffer = createBuffer(1);
		buffer.append('A');
		assertGrowLinearly(buffer);

		short style;

		style = 100;
		buffer.setGrowStyle(style);

		try {
			buffer.append('Z');
			Assert.fail();
		} catch (RuntimeException exception) {
			Assert.assertTrue(true);
		}
	}

	public void test_setLength() {
		String expectedValue;
		String actualValue;

		int expectedLength;
		int actualLength;

		// Create a populated buffer.
		ICharBuffer buffer = createBuffer();
		buffer.append(CharBufferTestCase.VALUE1);

		// Set the buffer's length to 3.
		buffer.setLength(3);

		// Check the buffer's length is 3.
		expectedLength = 3;
		actualLength = buffer.length();
		Assert.assertEquals(expectedLength, actualLength);

		// Check the buffer's value is correct.
		expectedValue = CharBufferTestCase.VALUE1.substring(0, 3);
		actualValue = buffer.getValue();
		Assert.assertEquals(expectedValue, actualValue);

		// Set the buffer's length to 4.
		buffer.setLength(4);

		// Check the buffer's length is 4.
		expectedLength = 4;
		actualLength = buffer.length();
		Assert.assertEquals(expectedLength, actualLength);

		// Check the buffer's value is correct.
		expectedValue += (char) 0;
		actualValue = buffer.getValue();
		Assert.assertEquals(expectedValue, actualValue);

		// Append a String of length 3.
		String value = CharBufferTestCase.VALUE1.substring(3, 6);
		buffer.append(value);

		// Check the buffer's value is correct.
		expectedValue += value;
		actualValue = buffer.getValue();
		Assert.assertEquals(expectedValue, actualValue);

		// Check the buffer's length is correct.
		expectedLength = 7;
		actualLength = buffer.length();
		Assert.assertEquals(expectedLength, actualLength);
	}

	public void test_synchronization() {
		ICharBuffer buffer = createBuffer();
		ICharBuffer synchronizedBuffer = buffer.toSynchronizedCharBuffer();
		int threadCount = 26;
		int appendCount = 100;
		String prefix = getShortTestCaseName();
		List/*<Thread>*/ threads = new ArrayList/*<Thread>*/(threadCount * 2);
		String name;
		Runnable runnable;
		Thread thread;

		// Start some threads that will append chars to the buffer.
		for (int i = 0; i < threadCount; i++) {
			// This thread uses a synchronized buffer.
			name = prefix + "-CharAppender-" + i; //$NON-NLS-1$
			runnable = createCharAppenderRunnable(i, synchronizedBuffer, appendCount);
			thread = new Thread(runnable, name);
			threads.add(thread);
			thread.start();

			// This thread uses an unsynchronized buffer, but the thread
			// synchronizes on the buffer for every append.
			name = prefix + "-createCharAppenderWithSynchronization-" + i; //$NON-NLS-1$
			runnable = createCharAppenderWithSynchronizationRunnable(i, buffer, appendCount);
			thread = new Thread(runnable, name);
			threads.add(thread);
			thread.start();
		}

		join(threads);
		Assert.assertTrue(true);
	}

	public void test_toArray() {
		char[] expectedCharArray;
		char[] actualCharArray;
		boolean equal;
		char[] array;

		// Check that a toArray() returns and appropriately populated char[].
		ICharBuffer buffer = createBuffer();
		buffer.append(CharBufferTestCase.VALUE1);
		expectedCharArray = CharBufferTestCase.VALUE1.toCharArray();
		actualCharArray = buffer.toArray();
		equal = Arrays.equals(expectedCharArray, actualCharArray);
		Assert.assertTrue(equal);

		// Check that an appropriately sized char[] is populated and returned.
		int length = buffer.length();
		array = new char [ length ];
		actualCharArray = buffer.toArray(array);
		Assert.assertSame(array, actualCharArray);

		// Check that an inappropriately sized char[] is not populated and
		// returned.
		array = new char [ 1 ];
		actualCharArray = buffer.toArray(array);
		Assert.assertNotSame(array, actualCharArray);

		// Check that the char[] is populated correctly.
		equal = Arrays.equals(expectedCharArray, actualCharArray);
		Assert.assertTrue(equal);

		// Check that null is a legal parameter.
		actualCharArray = buffer.toArray(null);
		equal = Arrays.equals(expectedCharArray, actualCharArray);
		Assert.assertTrue(equal);
	}

	public void test_toSynchronizedBuffer() {
		ICharBuffer buffer = createBuffer();

		// Check that a buffer and a synchronized buffer are distinct objects.
		ICharBuffer synchronizedBuffer = buffer.toSynchronizedCharBuffer();
		Assert.assertNotSame(buffer, synchronizedBuffer);

		// Check that asking a synchronized buffer for a synchronized buffer
		// returns the same instance.
		ICharBuffer alias = synchronizedBuffer.toSynchronizedCharBuffer();
		Assert.assertSame(synchronizedBuffer, alias);

		ICharBuffer synchronizedBuffer2 = buffer.toSynchronizedCharBuffer();
		Assert.assertNotSame(synchronizedBuffer, synchronizedBuffer2);

		// Check that name of the synchronized buffer's class is correct.
		String expectedName = "SynchronizedCharBuffer"; //$NON-NLS-1$
		Class clazz = synchronizedBuffer.getClass();
		String actualName = clazz.getName();
		boolean state = actualName.endsWith(expectedName);
		Assert.assertTrue(state);
	}

	private ICharBuffer toFastGrowingSynchronizedBuffer(ICharBuffer buffer) {
		buffer.setGrowPercentage(500);
		buffer.setGrowStyle(ICharBuffer.GROW_EXPONENTIALLY);
		buffer = buffer.toSynchronizedCharBuffer();
		return buffer;
	}
}
