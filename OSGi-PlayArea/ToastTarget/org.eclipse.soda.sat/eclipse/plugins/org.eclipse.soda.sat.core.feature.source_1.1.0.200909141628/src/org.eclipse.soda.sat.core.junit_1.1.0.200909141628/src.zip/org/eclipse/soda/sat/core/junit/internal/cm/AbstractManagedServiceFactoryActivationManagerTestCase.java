/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.junit.internal.cm;

import java.io.IOException;
import java.util.Dictionary;

import junit.framework.Assert;

import org.eclipse.soda.sat.core.junit.internal.AbstractServiceTestCase;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;

public abstract class AbstractManagedServiceFactoryActivationManagerTestCase extends AbstractServiceTestCase {
	private ConfigurationAdminConfigurator configurator;

	protected AbstractManagedServiceFactoryActivationManagerTestCase(String name) {
		super(name);
	}

	protected final Configuration createConfiguration(IManagedServiceFactoryActivationDelegate factory, Object id, Dictionary properties) throws IOException, InterruptedException {
		ConfigurationAdminConfigurator configurator = getConfigurator();
		Configuration configuration = configurator.create(factory, id, properties);
		Object service = factory.getObjectWithId(id);
		Assert.assertNotNull(service);
		return configuration;
	}

	private ConfigurationAdminConfigurator createConfigurationAdminConfigurator() {
		ConfigurationAdmin admin = getConfigurationAdmin();
		ConfigurationAdminConfigurator configurator = new ConfigurationAdminConfigurator(admin);
		return configurator;
	}

	protected final ConfigurationAdminConfigurator getConfigurator() {
		return configurator;
	}

	protected final String getLocation() {
		BundleContext context = getBundleContext();
		Bundle bundle = context.getBundle();
		String location = bundle.getLocation();
		return location;
	}

	private void setConfigurator(ConfigurationAdminConfigurator configurator) {
		this.configurator = configurator;
	}

	protected void setUp() throws Exception {
		super.setUp();
		ConfigurationAdminConfigurator configurator = createConfigurationAdminConfigurator();
		setConfigurator(configurator);
	}

	protected void tearDown() throws Exception {
		setConfigurator(null);
		super.tearDown();
	}

}
