/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.junit.internal.old;

import java.util.Dictionary;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.framework.BaseBundleActivator;
import org.eclipse.soda.sat.core.junit.internal.old.service.DummyService;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.junit.util.ValueHolder;
import org.osgi.framework.BundleContext;
import org.osgi.service.log.LogService;


/**
 * BaseBundleActivatorPropertiesTestCase.java
 */
public class BaseBundleActivatorPropertiesTestCase extends PropertiesTestCase {
	private static final String DEACTIVATED_BUNDLE_PREMATURELY = "Deactivated bundle prematurely";  //$NON-NLS-1$
	private static final String BUNDLE_ACTIVATION_FAILED = "Bundle activation failed"; //$NON-NLS-1$
	private static final String BUNDLE_DEACTIVATION_FAILED = "Bundle deactivation failed"; //$NON-NLS-1$
	private static final String FAILED_TO_ACQUIRE_SERVICE = "Failed to acquire DummyService"; //$NON-NLS-1$

	public static Test suite() {
		return new TestSuite(BaseBundleActivatorPropertiesTestCase.class);
	}

	private BaseBundleActivator baseBundleActivator;
	private final ValueHolder activatedHolder;
	private final ValueHolder acquiredHolder;
	private final ValueHolder deactivatedHolder;

	public BaseBundleActivatorPropertiesTestCase(String name) {
		super(name);
		activatedHolder = ValueHolder.nullValue();
		acquiredHolder = ValueHolder.nullValue();
		deactivatedHolder = ValueHolder.nullValue();
	}

	private void buildBaseBundleActivator() {
		baseBundleActivator = new BaseBundleActivator() {
			protected void activate() {
				activatedHolder.setTrue();
				DummyService dummy = (DummyService) getImportedService(DummyService.SERVICE_NAME);
				String description = dummy.getDescription();
				boolean equal = PropertiesTestCase.DESCRIPTION.equals(description);
				acquiredHolder.setValue(equal);
			}

			protected void deactivate() {
				deactivatedHolder.setTrue();
			}

			public String[] getImportedServiceNames() {
				String[] names = {
					DummyService.SERVICE_NAME
				};

				return names;
			}

			protected void start() {
				addImportedServiceFilter(DummyService.SERVICE_NAME, "(&(cn=simona)(o=OTI)(c=US))");  //$NON-NLS-1$
			}
		};
	}

	protected void setUp() throws Exception {
		super.setUp();

		activatedHolder.setFalse();
		acquiredHolder.setFalse();
		deactivatedHolder.setFalse();

		buildBaseBundleActivator();
		startBundleActivator();
	}

	private void startBundleActivator() {
		BundleContext bundleContext = getBundleContext();

		try {
			baseBundleActivator.start(bundleContext);
		} catch (Exception exception) {
			Assert.fail(exception.getMessage());
		}
	}

	private void stopBundleActivator() {
		BundleContext bundleContext = getBundleContext();

		try {
			baseBundleActivator.stop(bundleContext);
		} catch (Exception exception) {
			Assert.fail(exception.getMessage());
		}
	}

	protected void tearDown() throws Exception {
		stopBundleActivator();
		super.tearDown();
	}

	public void testAddProperty() {
		Dictionary properties = recordWithProperties.getProperties();
		properties.put("state", "NC");  //$NON-NLS-1$  //$NON-NLS-2$
		recordWithProperties.setProperties(properties);

		Assert.assertTrue(BaseBundleActivatorPropertiesTestCase.DEACTIVATED_BUNDLE_PREMATURELY, deactivatedHolder.isFalse());
	}

	public void testMatchingPropertyChange() {
		testUnmatchingPropertyChange();

		activatedHolder.setFalse();
		acquiredHolder.setFalse();
		deactivatedHolder.setFalse();

		Dictionary properties = recordWithProperties.getProperties();
		properties.put("c", "US");  //$NON-NLS-1$  //$NON-NLS-2$
		recordWithProperties.setProperties(properties);

		Assert.assertTrue(BaseBundleActivatorPropertiesTestCase.BUNDLE_ACTIVATION_FAILED, activatedHolder.isTrue());
		Assert.assertTrue(BaseBundleActivatorPropertiesTestCase.FAILED_TO_ACQUIRE_SERVICE, acquiredHolder.isTrue());
		Assert.assertTrue(BaseBundleActivatorPropertiesTestCase.DEACTIVATED_BUNDLE_PREMATURELY, deactivatedHolder.isFalse());
	}

	public void testRemoveProperty() {
		Dictionary properties = recordWithProperties.getProperties();
		properties.remove("o");  //$NON-NLS-1$

		int level = LogUtility.getLoggingLevel();

		try {
			LogUtility.setLoggingLevel(LogService.LOG_ERROR);
			recordWithProperties.setProperties(properties);
		} finally {
			LogUtility.setLoggingLevel(level);
		}

		Assert.assertTrue(BaseBundleActivatorPropertiesTestCase.BUNDLE_DEACTIVATION_FAILED, deactivatedHolder.isTrue());
	}

	public void testSimpleCase() {
		Assert.assertTrue(BaseBundleActivatorPropertiesTestCase.BUNDLE_ACTIVATION_FAILED, activatedHolder.isTrue());
		Assert.assertTrue(BaseBundleActivatorPropertiesTestCase.FAILED_TO_ACQUIRE_SERVICE, acquiredHolder.isTrue());
		Assert.assertTrue(BaseBundleActivatorPropertiesTestCase.DEACTIVATED_BUNDLE_PREMATURELY, deactivatedHolder.isFalse());
	}

	public void testUnmatchingPropertyChange() {
		testSimpleCase();

		Dictionary properties = recordWithProperties.getProperties();
		properties.put("c", "UK");  //$NON-NLS-1$ //$NON-NLS-2$

		int level = LogUtility.getLoggingLevel();

		try {
			LogUtility.setLoggingLevel(LogService.LOG_ERROR);
			recordWithProperties.setProperties(properties);
		} finally {
			LogUtility.setLoggingLevel(level);
		}

		Assert.assertTrue(BaseBundleActivatorPropertiesTestCase.BUNDLE_DEACTIVATION_FAILED, deactivatedHolder.isTrue());
	}
}