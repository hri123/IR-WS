/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle.cm.test.hotdog;

import java.util.Dictionary;
import java.util.Hashtable;

import org.eclipse.soda.sat.core.framework.BaseManagedServiceFactoryAdvisor;
import org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager;
import org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryAdvisor;
import org.eclipse.soda.sat.core.junit.internal.cm.AbstractManagedServiceFactoryActivationDelegate;

public class HotdogVendorManagedServiceFactory extends AbstractManagedServiceFactoryActivationDelegate {
	public HotdogVendorManagedServiceFactory(String factoryPid, String location) {
		super(factoryPid, location);
	}

	private Object create(String pid, Dictionary properties, IBundleActivationManager manager) {
		String id = getId(properties);
		int spiciness = getSpiciness(properties);
		Object service = new HotdogVendor(id, spiciness);
		Dictionary serviceProperties = new Hashtable(11);
		serviceProperties.put(VendorService.SPICINESS_PROPERTY_KEY, new Integer(spiciness));
		manager.addExportedService(VendorService.SERVICE_NAME, service, serviceProperties);
		addObjectWithId(id, service);
		return service;
	}

	protected IManagedServiceFactoryAdvisor createAdvisor() {
		return new BaseManagedServiceFactoryAdvisor(){
			public Object create(String pid, Dictionary properties, IBundleActivationManager manager) {
				return HotdogVendorManagedServiceFactory.this.create(pid, properties, manager);
			}

			public void destroy(String pid, Object object, Dictionary properties, IBundleActivationManager manager) {
				HotdogVendorManagedServiceFactory.this.destroy(pid, object, properties, manager);
			}

			public Object update(String pid, Object object, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager) {
				return HotdogVendorManagedServiceFactory.this.update(pid, object, oldProperties, properties, manager);
			}
		};
	}

	private void destroy(String pid, Object object, Dictionary properties, IBundleActivationManager manager) {
		VendorService service = (VendorService) object;
		String id = service.getId();
		removeObjectWithId(id);
	}

	private int getSpiciness(Dictionary properties) {
		Integer wrapper = (Integer) properties.get(VendorService.SPICINESS_PROPERTY_KEY);
		int spiciness = wrapper.intValue();
		return spiciness;
	}

	private Object update(String pid, Object object, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager) {
		VendorService service = (VendorService) object;
		int id = getSpiciness(properties);
		service.setSpiciness(id);
		updated(service);
		return service;
	}
}
