/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.junit.internal.old;

import java.util.Dictionary;

import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;
import org.eclipse.soda.sat.core.junit.internal.old.service.Dummy;
import org.eclipse.soda.sat.core.junit.internal.old.service.DummyService;
import org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord;
import org.osgi.framework.BundleContext;

/**
 * PropertiesTestCase.java
 */
public abstract class PropertiesTestCase extends OldTestCase {
	protected static final String DESCRIPTION = "Dummy with properties"; //$NON-NLS-1$

	protected IExportServiceRecord recordWithProperties; // $codepro.audit.disable instanceFieldVisibility

	protected  PropertiesTestCase(String name) {
		super(name);
	}

	private void registerDummyServiceWithProperties() {
		BundleContext bundleContext = getBundleContext();
		String[] names = { DummyService.SERVICE_NAME };

		DummyService service = new Dummy() {
			public String getDescription() {
				return PropertiesTestCase.DESCRIPTION;
			}
		};

		Dictionary properties = createServiceProperties();
		properties.put("cn", "simona"); //$NON-NLS-1$ //$NON-NLS-2$
		properties.put("o", "OTI"); //$NON-NLS-1$ //$NON-NLS-2$
		properties.put("c", "US"); //$NON-NLS-1$ //$NON-NLS-2$

		recordWithProperties = AbstractSatTestCase.FACTORY.createExportServiceRecord(bundleContext, names, service, properties);
		recordWithProperties.register();
	}

	protected void setUp() throws Exception {
		super.setUp();
		registerDummyService();
		registerDummyServiceWithProperties();
	}

	protected void tearDown() throws Exception {
		unregisterDummyServiceWithProperties();
		unregisterDummyService();
		super.tearDown();
	}

	private void unregisterDummyServiceWithProperties() {
		recordWithProperties.unregister();
	}
}