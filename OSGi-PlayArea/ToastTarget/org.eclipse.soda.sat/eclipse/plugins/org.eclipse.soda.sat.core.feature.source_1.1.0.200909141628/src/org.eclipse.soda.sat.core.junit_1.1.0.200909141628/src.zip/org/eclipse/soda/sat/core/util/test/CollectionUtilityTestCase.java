/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.util.test;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;
import org.eclipse.soda.sat.core.util.CollectionUtility;
import org.eclipse.soda.sat.core.util.CollectionUtility.Accessor;
import org.eclipse.soda.sat.core.util.CollectionUtility.InjectionAccessor;
import org.eclipse.soda.sat.junit.util.ValueHolder;

public class CollectionUtilityTestCase extends AbstractSatTestCase {
	private static final CollectionUtility UTILITY = CollectionUtility.getInstance();

	public static Test suite() {
		return new TestSuite(CollectionUtilityTestCase.class);
	}

	public CollectionUtilityTestCase(String name) {
		super(name);
	}

	private InjectionAccessor createAccumulateStringLengthInjectionAccessor() {
		return new CollectionUtility.InjectionAccessor() {
			public Object get(Object value, Object item) {
				ValueHolder holder = (ValueHolder) value;
				Integer wrapper = (Integer) holder.getValue();
				int total = wrapper.intValue();

				String color = (String) item;
				int length = color.length();
				total += length;

				wrapper = new Integer(total);
				holder.setValue(wrapper);
				return holder;
			}
		};
	}

	private Accessor createNullAccessor() {
		return new CollectionUtility.Accessor() {
			public Object get(Object item) {
				return null;
			}
		};
	}

	private CollectionUtility.InjectionAccessor createNullInjectionAccessor() {
		return new CollectionUtility.InjectionAccessor(){
			public Object get(Object value, Object item) {
				return null;
			}
		};
	}

	private Accessor createRejectAllAccessor() {
		return new CollectionUtility.Accessor() {
			public Object get(Object item) {
				return item;
			}
		};
	}

	private Accessor createStringLengthAccessor() {
		return new CollectionUtility.Accessor() {
			public Object get(Object item) {
				String value = (String) item;
				int length = value.length();
				Object wrapper = new Integer(length);
				return wrapper;
			}
		};
	}

	private Accessor createStringOfLengthAtLeastAccessor(final int length) {
		return new CollectionUtility.Accessor() {
			public Object get(Object item) {
				String color = (String) item;
				int colorLength = color.length();
				Object value = colorLength >= length ? color : null;
				return value;
			}
		};
	}

	private List/*<String>*/ getColors() {
		List/*<String>*/ colors = new ArrayList/*<String>*/(5);
		colors.add("red");  //$NON-NLS-1$
		colors.add("yellow");  //$NON-NLS-1$
		colors.add("blue");  //$NON-NLS-1$
		colors.add("green");  //$NON-NLS-1$
		colors.add("orange");  //$NON-NLS-1$
		return colors;
	}

	public void test_collect() {
		List/*<String>*/ colors = getColors();
		CollectionUtility.Accessor accessor;
		int expectedSize;
		int actualSize;

		// Collect String lengths test.
		accessor = createStringLengthAccessor();
		List/*<Integer>*/ lengths = CollectionUtilityTestCase.UTILITY.collect(colors, accessor);
		expectedSize = colors.size();
		actualSize = lengths.size();
		Assert.assertEquals(expectedSize, actualSize);

		for (int i = 0; i < actualSize; i++) {
			String color = (String) colors.get(i);
			int expectedLength = color.length();
			Integer wrapper = (Integer) lengths.get(i);
			int actualLength = wrapper.intValue();
			Assert.assertEquals(expectedLength, actualLength);
		}

		// Null collection test.
		accessor = createNullAccessor();
		List/*<Object>*/ list = CollectionUtilityTestCase.UTILITY.collect(colors, accessor);
		expectedSize = colors.size();
		actualSize = list.size();
		Assert.assertEquals(expectedSize, actualSize);
		Iterator/*<Object>*/ iterator = list.iterator();
		while (iterator.hasNext() == true) {
			Object object = iterator.next();
			Assert.assertNull(object);
		}

		// IAE tests...
		try {
			CollectionUtilityTestCase.UTILITY.collect(null, accessor);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}
		try {
			CollectionUtilityTestCase.UTILITY.collect(colors, null);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}
	}

	public void test_detect() {
		List/*<String>*/ colors = getColors();
		CollectionUtility.Accessor accessor;
		Object actual;

		// Detect color with length >= 5.
		accessor = createStringOfLengthAtLeastAccessor(5);
		Object expected = "yellow"; //$NON-NLS-1$
		actual = CollectionUtilityTestCase.UTILITY.detect(colors, accessor);
		Assert.assertEquals(expected, actual);

		// Failed to detect test.
		accessor = createStringOfLengthAtLeastAccessor(25);
		actual = CollectionUtilityTestCase.UTILITY.detect(colors, accessor);
		Assert.assertNull(actual);

		// Null detection test.
		accessor = createNullAccessor();
		actual = CollectionUtilityTestCase.UTILITY.detect(colors, accessor);
		Assert.assertNull(actual);

		// IAE tests...
		try {
			CollectionUtilityTestCase.UTILITY.detect(null, accessor);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}
		try {
			CollectionUtilityTestCase.UTILITY.detect(colors, null);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}
	}


	public void test_estimateHashedCollectionSize() {
		int expectedCapacity;
		int actualCapacity;
		int capacity = 25;
		float loadFactor = 0.75f;

		// Basic test.
		expectedCapacity = (int) (capacity / loadFactor) + 1;
		actualCapacity = CollectionUtilityTestCase.UTILITY.estimateHashedCollectionSize(capacity);
		Assert.assertEquals(expectedCapacity, actualCapacity);

		loadFactor = 0.95f;
		expectedCapacity = (int) (capacity / loadFactor) + 1;
		actualCapacity = CollectionUtilityTestCase.UTILITY.estimateHashedCollectionSize(capacity, loadFactor);
		Assert.assertEquals(expectedCapacity, actualCapacity);

		// Negative capacity test.
		expectedCapacity = 0;
		actualCapacity = CollectionUtilityTestCase.UTILITY.estimateHashedCollectionSize(-1);
		Assert.assertEquals(expectedCapacity, actualCapacity);
	}

	public void test_getInstance() {
		Assert.assertNotNull(CollectionUtilityTestCase.UTILITY);
	}

	public void test_inject() {
		List/*<String>*/ colors = getColors();
		ValueHolder holder = ValueHolder.zeroValue();
		CollectionUtility.InjectionAccessor accessor;

		Iterator iterator = colors.iterator();
		int expectedTotal = 0;

		while (iterator.hasNext() == true) {
			String color = (String) iterator.next();
			int length = color.length();
			expectedTotal += length;
		}

		// Accumulate String lengths test.
		accessor = createAccumulateStringLengthInjectionAccessor();
		CollectionUtilityTestCase.UTILITY.inject(colors, holder, accessor);
		Integer wrapper = (Integer) holder.getValue();
		int actualTotal = wrapper.intValue();
		Assert.assertEquals(expectedTotal, actualTotal);

		// Null accessor test.
		holder.setZero();
		accessor = createNullInjectionAccessor();
		CollectionUtilityTestCase.UTILITY.inject(colors, holder, accessor);
		Assert.assertTrue(holder.isZero() == true);

		// IAE tests...
		try {
			CollectionUtilityTestCase.UTILITY.inject(null, holder, accessor);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}
		try {
			CollectionUtilityTestCase.UTILITY.inject(colors, null, accessor);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}
		try {
			CollectionUtilityTestCase.UTILITY.inject(colors, holder, null);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}
	}
	public void test_reject() {
		List/*<String>*/ colors = getColors();
		CollectionUtility.Accessor accessor;
		List/*<String>*/ result;
		int expectedSize;
		int actualSize;

		// Basic test.
		accessor = createStringOfLengthAtLeastAccessor(5);
		result = CollectionUtilityTestCase.UTILITY.reject(colors, accessor);
		expectedSize = 2;
		actualSize = result.size();
		Assert.assertEquals(expectedSize, actualSize);

		// Reject all test.
		accessor = createRejectAllAccessor();
		result = CollectionUtilityTestCase.UTILITY.reject(colors, accessor);
		Assert.assertNotNull(result);
		expectedSize = 0;
		actualSize = result.size();
		Assert.assertEquals(expectedSize, actualSize);

		// IAE tests...
		try {
			CollectionUtilityTestCase.UTILITY.reject(null, accessor);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}
		try {
			CollectionUtilityTestCase.UTILITY.reject(colors, null);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}

	}

	public void test_select() {
		List/*<String>*/ colors = getColors();
		List/*<String>*/ result;
		CollectionUtility.Accessor accessor;
		int expectedSize;
		int actualSize;

		// Select colors of 5 characters or more.
		accessor = createStringOfLengthAtLeastAccessor(5);
		result = CollectionUtilityTestCase.UTILITY.select(colors, accessor);
		expectedSize = 3;
		actualSize = result.size();
		Assert.assertEquals(expectedSize, actualSize);

		// Select no colors.
		accessor = createNullAccessor();
		result = CollectionUtilityTestCase.UTILITY.select(colors, accessor);
		Assert.assertNotNull(result);
		expectedSize = 0;
		actualSize = result.size();
		Assert.assertEquals(expectedSize, actualSize);

		// IAE tests...
		try {
			CollectionUtilityTestCase.UTILITY.select(null, accessor);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}
		try {
			CollectionUtilityTestCase.UTILITY.select(colors, null);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}
	}

	public void test_toEnumeration() {
		List/*<String>*/ colors = getColors();
		Vector/*<String>*/ vector;
		List/*<String>*/ actualList;
		Enumeration/*<String>*/ elements;

		// Basic test.
		vector = new Vector/*<String>*/(colors);
		elements = vector.elements();
		actualList = CollectionUtilityTestCase.UTILITY.toList(elements);
		Assert.assertEquals(colors, actualList);

		// IAE test.
		try {
			CollectionUtilityTestCase.UTILITY.toList(null);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}
		elements = vector.elements();
		try {
			CollectionUtilityTestCase.UTILITY.toList(elements, null);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}

		int size;
		List/*<String>*/ list;

		// To an existing list of the right size.
		elements = vector.elements();
		size = vector.size();
		list = new ArrayList/*<String>*/(size);
		actualList = CollectionUtilityTestCase.UTILITY.toList(elements, list);
		Assert.assertEquals(colors, actualList);

		// To an existing list that is too big.
		elements = vector.elements();
		list = new ArrayList/*<String>*/(10);
		actualList = CollectionUtilityTestCase.UTILITY.toList(elements, list);
		Assert.assertEquals(colors, actualList);
		Assert.assertSame(list, actualList);

		// Empty Enumeration test.
		vector = new Vector/*<String>*/();
		elements = vector.elements();
		actualList = CollectionUtilityTestCase.UTILITY.toList(elements);
		int expectedSize = 0;
		int actualSize = actualList.size();
		Assert.assertEquals(expectedSize, actualSize);
	}
}
