/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.junit.internal.bundle;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Map;
import java.util.Properties;

import junit.framework.Test;

import org.eclipse.soda.sat.core.framework.BaseBundleActivator;
import org.eclipse.soda.sat.core.junit.internal.AllTests;
import org.eclipse.soda.sat.core.service.LogReaderAggregatorService;
import org.eclipse.soda.sat.junit.service.TestRunnerServerService;
import org.osgi.framework.BundleContext;
import org.osgi.service.cm.ConfigurationAdmin;

/**
 * Activator.java
 */
public class Activator extends BaseBundleActivator {
	public static BundleContext BUNDLE_CONTEXT; // $codepro.audit.disable initializeStaticFields
	public static ConfigurationAdmin CONFIGURATION_ADMIN; // $codepro.audit.disable initializeStaticFields
	public static LogReaderAggregatorService LOG_READER_AGGREGATOR_SERVICE;
	private static final String CONFIGURATION_ADMIN_SERVICE_NAME = ConfigurationAdmin.class.getName();

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#activate()
	 */
	protected void activate() {
		BundleContext bundleContext = getBundleContext();
		Activator.BUNDLE_CONTEXT = bundleContext;
		Activator.CONFIGURATION_ADMIN = getConfigurationAdmin();
		Activator.LOG_READER_AGGREGATOR_SERVICE = getLogReaderAggregatorService();

		TestRunnerServerService server = getTestRunnerServerService();
		Test test = AllTests.suite();
		server.run(test);
	}

	/**
	 * Adds the contents of the properties file to the <code>System</code>
	 * properties.
	 */
	private void addSystemProperties() {
		Properties properties = getProperties();
		boolean empty = properties.isEmpty();
		if (empty == true) return;  // Early return.

		Enumeration keys = properties.propertyNames();

		while (keys.hasMoreElements() == true) {
			String key = (String) keys.nextElement();
			Object value = properties.getProperty(key);
			addSystemProperty(key, value);
		}
	}

	/**
	 * Adds the specified key/value pair  to the <code>System</code>
	 * properties.
	 *
	 * @param key    Property key.
	 * @param value  Property value.
	 */
	private void addSystemProperty(Object key, Object value) {
		Map sysProps = System.getProperties();
		boolean exists = sysProps.containsKey(key);
		if (exists == true) return;  // Early return.
		sysProps.put(key, value);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#deactivate()
	 */
	protected void deactivate() {
		Activator.LOG_READER_AGGREGATOR_SERVICE = null;
		Activator.CONFIGURATION_ADMIN = null;
		Activator.BUNDLE_CONTEXT = null;
	}

	private ConfigurationAdmin getConfigurationAdmin() {
		return (ConfigurationAdmin) getImportedService(Activator.CONFIGURATION_ADMIN_SERVICE_NAME);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#getImportedServiceNames()
	 */
	protected String[] getImportedServiceNames() {
		return new String[] {
			TestRunnerServerService.SERVICE_NAME,
			Activator.CONFIGURATION_ADMIN_SERVICE_NAME,
			LogReaderAggregatorService.SERVICE_NAME
		};
	}

	private LogReaderAggregatorService getLogReaderAggregatorService() {
		return (LogReaderAggregatorService) getImportedService(LogReaderAggregatorService.SERVICE_NAME);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#getPropertiesInputStream()
	 */
	protected InputStream getPropertiesInputStream() throws IOException {
		InputStream stream = getFilePropertiesInputStream();  // First try the local file system.
		if (stream != null) return stream;  // Early return.
		stream = getResourcePropertiesInputStream(); // Then try the package resource.
		return stream;
	}

	private TestRunnerServerService getTestRunnerServerService() {
		return (TestRunnerServerService) getImportedService(TestRunnerServerService.SERVICE_NAME);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#handleFailedToFindProperties(java.lang.String)
	 */
	protected void handleFailedToFindProperties(String filename) {
		// No-op: It's OK for properties to not exist.
	}

	/**
	 * Remove the properties from the <code>System</code> properties
	 * @throws java.io.IOException
	 */
	private void removeSystemProperties() {
		Properties properties = getProperties();
		boolean empty = properties.isEmpty();
		if (empty == true) return;  // Early return.

		Enumeration keys = properties.propertyNames();

		while (keys.hasMoreElements() == true) {
			String key = (String) keys.nextElement();
			removeSystemProperty(key);
		}
	}

	/**
	 * Removes the specified key from the <code>System</code> properties.
	 *
	 * @param key  Property key.
	 */
	private void removeSystemProperty(String key) {
		Map sysProps = System.getProperties();
		sysProps.remove(key);
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#start()
	 */
	protected void start() {
		addSystemProperties();
	}

	/**
	 * @see org.eclipse.soda.sat.core.framework.BaseBundleActivator#stop()
	 */
	protected void stop() {
		removeSystemProperties();
	}
}