/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.record.test;

import java.util.Dictionary;
import java.util.Hashtable;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;
import org.eclipse.soda.sat.core.junit.internal.AbstractServiceTestCase;
import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecordOwner;
import org.eclipse.soda.sat.junit.util.ValueHolder;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Filter;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceRegistration;

public class ImportServiceRecordTestCase extends AbstractServiceTestCase {
	private interface TestService1 {
		public static final String SERVICE_NAME = TestService1.class.getName();
	}

	private interface TestService2 {
		public static final String SERVICE_NAME = TestService2.class.getName();
	}

	private static class TestServiceImplementation extends Object implements TestService1, TestService2 { // $codepro.audit.disable convertClassToInterface, com.instantiations.assist.eclipse.analysis.emptyClass
		//...
	}

	private static final String AUTHOR_KEY = "author"; //$NON-NLS-1$
	private static final String COMPANY_KEY = "company"; //$NON-NLS-1$
	private static final String TYPE_KEY = "type"; //$NON-NLS-1$

	private static final String FRED = "Fred"; //$NON-NLS-1$
	private static final String JOHN = "John"; //$NON-NLS-1$

	private static final String AUTOMATIC_TYPE = "automatic"; //$NON-NLS-1$
	private static final String MANUAL_TYPE = "manual"; //$NON-NLS-1$

	private static final String IBM_ORG = "IBM"; //$NON-NLS-1$
	private static final String ECLIPSE_ORG = "Eclipse"; //$NON-NLS-1$

	public static Test suite() {
		return new TestSuite(ImportServiceRecordTestCase.class);
	}

	public ImportServiceRecordTestCase(String name) {
		super(name);
	}

	private IImportServiceRecordOwner getNoOpOwner() {
		return new IImportServiceRecordOwner() {
			public Object getLock() {
				return this;
			}

			public void serviceAcquired(IImportServiceRecord record) {
				// No-op
			}

			public void serviceReleased(IImportServiceRecord record) {
				// No-op
			}
		};
	}

	public void test_acquire() {
		Object service1 = new TestServiceImplementation();
		Object service2 = new TestServiceImplementation();

		ServiceRegistration registration1 = null;
		ServiceRegistration registration2 = null;

		final ValueHolder acquiredHolder = ValueHolder.nullValue();
		final ValueHolder releasedHolder = ValueHolder.nullValue();

		IImportServiceRecordOwner owner = new IImportServiceRecordOwner() {
			public Object getLock() {
				return this;
			}

			public void serviceAcquired(IImportServiceRecord record) {
				Object service = record.getService();
				acquiredHolder.setValue(service);
			}

			public void serviceReleased(IImportServiceRecord record) {
				Object service = record.getService();
				releasedHolder.setValue(service);
			}
		};

		BundleContext context = getBundleContext();
		IImportServiceRecord record = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);
		record.setOwner(owner);

		// Start trying to acquire the imported service.
		record.acquire();

		// Check that the record is not yet acquired or released.
		Assert.assertNull(acquiredHolder.getValue());
		Assert.assertNull(releasedHolder.getValue());

		// Register a TestService instance.
		registration1 = context.registerService(TestService1.SERVICE_NAME, service1, null);

		Object expected;
		Object actual;

		// Check that the TestService was acquired.
		expected = service1;
		actual = acquiredHolder.getValue();
		Assert.assertSame(expected, actual);

		// Null out the acquiredHolder.
		acquiredHolder.setNull();

		// Register a second TestService instance.
		registration2 = context.registerService(TestService1.SERVICE_NAME, service2, null);

		// Check that the acquired imported service has not changed.
		Assert.assertNull(acquiredHolder.getValue());
		Assert.assertNull(releasedHolder.getValue());

		// Unregister the first TestService instance.
		registration1.unregister();

		expected = service1;
		actual = releasedHolder.getValue();
		Assert.assertSame(expected, actual);

		expected = service2;
		actual = acquiredHolder.getValue();
		Assert.assertSame(expected, actual);

		acquiredHolder.setNull();
		releasedHolder.setNull();

		registration1 = context.registerService(TestService1.SERVICE_NAME, service1, null);

		Assert.assertNull(acquiredHolder.getValue());
		Assert.assertNull(releasedHolder.getValue());

		registration1.unregister();

		Assert.assertNull(acquiredHolder.getValue());
		Assert.assertNull(releasedHolder.getValue());

		registration2.unregister();

		Assert.assertNull(acquiredHolder.getValue());

		expected = service2;
		actual = releasedHolder.getValue();
		Assert.assertSame(expected, actual);

		releasedHolder.setNull();

		record.release();

		Assert.assertNull(acquiredHolder.getValue());
		Assert.assertNull(releasedHolder.getValue());
	}

	public void test_getFilter() throws InvalidSyntaxException {
		BundleContext context = getBundleContext();
		// "(author=Fred)"
		String filterString = '(' + ImportServiceRecordTestCase.AUTHOR_KEY + '=' + ImportServiceRecordTestCase.FRED + ')';
		Filter filter = context.createFilter(filterString);
		IImportServiceRecord record = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, filter);
		Object expected = filter;
		Object actual = record.getFilter();
		Assert.assertEquals(expected, actual);
	}

	public void test_getName() {
		BundleContext context = getBundleContext();
		IImportServiceRecord record = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);
		Object expected = TestService1.SERVICE_NAME;
		Object actual = record.getName();
		Assert.assertEquals(expected, actual);
	}

	public void test_isAcquired() {
		Object service = new TestServiceImplementation();
		ServiceRegistration registration = null;

		BundleContext context = getBundleContext();
		IImportServiceRecord record = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);

		boolean acquired;

		acquired = record.isAcquired();
		Assert.assertFalse(acquired);

		// Start trying to acquire the imported service.
		IImportServiceRecordOwner owner = getNoOpOwner();  // TODO Do we nee a no-op owner now?
		record.setOwner(owner);
		record.acquire();

		acquired = record.isAcquired();
		Assert.assertFalse(acquired);

		// Register a TestService instance.
		registration = context.registerService(TestService1.SERVICE_NAME, service, null);

		acquired = record.isAcquired();
		Assert.assertTrue(acquired);

		// Unregister the TestService instance.
		registration.unregister();

		acquired = record.isAcquired();
		Assert.assertFalse(acquired);

		// Register a TestService instance.
		registration = context.registerService(TestService1.SERVICE_NAME, service, null);

		acquired = record.isAcquired();
		Assert.assertTrue(acquired);

		record.release();

		acquired = record.isAcquired();
		Assert.assertFalse(acquired);

		// Unregister the TestService instance.
		registration.unregister();
	}

	public void test_release() {
		Object service = new TestServiceImplementation();
		BundleContext context = getBundleContext();

		// Register a TestService instance.
		ServiceRegistration registration = context.registerService(TestService1.SERVICE_NAME, service, null);

		IImportServiceRecord record = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);

		final ValueHolder acquiredHolder = ValueHolder.nullValue();
		final ValueHolder releasedHolder = ValueHolder.nullValue();

		IImportServiceRecordOwner owner = new IImportServiceRecordOwner() {
			public Object getLock() {
				return this;
			}

			public void serviceAcquired(IImportServiceRecord record) {
				Object service = record.getService();
				acquiredHolder.setValue(service);
			}

			public void serviceReleased(IImportServiceRecord record) {
				Object service = record.getService();
				releasedHolder.setValue(service);
			}
		};

		// Start trying to acquire the imported service.
		record.setOwner(owner);
		record.acquire();

		record.release();

		Object expected;
		Object actual;

		expected = service;
		actual = releasedHolder.getValue();
		Assert.assertSame(expected, actual);

		releasedHolder.setNull();

		record.setOwner(owner);
		record.acquire();

		registration.unregister();

		expected = service;
		actual = releasedHolder.getValue();
		Assert.assertSame(expected, actual);

		releasedHolder.setNull();

		record.release();

		Assert.assertNull(releasedHolder.getValue());
	}

	public void test_setFilter() throws InvalidSyntaxException {
		BundleContext context = getBundleContext();

		TestService1 service1 = new TestServiceImplementation();
		Dictionary properties1 = new Hashtable(11);
		properties1.put(ImportServiceRecordTestCase.AUTHOR_KEY, ImportServiceRecordTestCase.JOHN);
		properties1.put(ImportServiceRecordTestCase.COMPANY_KEY, ImportServiceRecordTestCase.IBM_ORG);
		properties1.put(ImportServiceRecordTestCase.TYPE_KEY, ImportServiceRecordTestCase.AUTOMATIC_TYPE);
		ServiceRegistration registration1 = context.registerService(TestService1.SERVICE_NAME, service1, properties1);

		TestService1 service2 = new TestServiceImplementation();
		Dictionary properties2 = new Hashtable(11);
		properties2.put(ImportServiceRecordTestCase.AUTHOR_KEY, ImportServiceRecordTestCase.FRED);
		properties2.put(ImportServiceRecordTestCase.COMPANY_KEY, ImportServiceRecordTestCase.IBM_ORG);
		properties2.put(ImportServiceRecordTestCase.TYPE_KEY, ImportServiceRecordTestCase.MANUAL_TYPE);
		ServiceRegistration registration2 = context.registerService(TestService1.SERVICE_NAME, service2, properties2);

		TestService1 service3 = new TestServiceImplementation();
		Dictionary properties3 = new Hashtable(11);
		properties3.put(ImportServiceRecordTestCase.AUTHOR_KEY, ImportServiceRecordTestCase.JOHN);
		properties3.put(ImportServiceRecordTestCase.COMPANY_KEY, ImportServiceRecordTestCase.ECLIPSE_ORG);
		properties3.put(ImportServiceRecordTestCase.TYPE_KEY, ImportServiceRecordTestCase.AUTOMATIC_TYPE);
		ServiceRegistration registration3 = context.registerService(TestService1.SERVICE_NAME, service3, properties3);

		IImportServiceRecord record = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);

		Object expected;
		Object actual;

		String filterString;
		Filter filter;

		actual = record.getFilter();
		Assert.assertNull(actual);

		// "(author=Fred)"
		filterString = '(' + ImportServiceRecordTestCase.AUTHOR_KEY + '=' + ImportServiceRecordTestCase.FRED + ')';
		filter = context.createFilter(filterString);
		record.setFilter(filter);

		expected = filter;
		actual = record.getFilter();
		Assert.assertEquals(expected, actual);

		final ValueHolder acquiredHolder = ValueHolder.nullValue();
		final ValueHolder releasedHolder = ValueHolder.nullValue();

		IImportServiceRecordOwner owner = new IImportServiceRecordOwner() {
			public Object getLock() {
				return this;
			}

			public void serviceAcquired(IImportServiceRecord record) {
				Object service = record.getService();
				acquiredHolder.setValue(service);
			}

			public void serviceReleased(IImportServiceRecord record) {
				Object service = record.getService();
				releasedHolder.setValue(service);
			}
		};

		record.setOwner(owner);
		record.acquire();

		expected = service2;
		actual = acquiredHolder.getValue();
		Assert.assertSame(expected, actual);

		acquiredHolder.setNull();
		releasedHolder.setNull();

		// "(&(author=John)(company=IBM))"
		filterString = "(&(" + ImportServiceRecordTestCase.AUTHOR_KEY + '=' + ImportServiceRecordTestCase.JOHN + ")(" + ImportServiceRecordTestCase.COMPANY_KEY + '=' + ImportServiceRecordTestCase.IBM_ORG + "))"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
		filter = context.createFilter(filterString);
		record.setFilter(filter);

		expected = service2;
		actual = releasedHolder.getValue();
		Assert.assertSame(expected, actual);

		expected = service1;
		actual = acquiredHolder.getValue();
		Assert.assertSame(expected, actual);
		acquiredHolder.setNull();

		acquiredHolder.setNull();
		releasedHolder.setNull();

		// "(&(author=Fred)(company=Eclipse))"
		filterString = "(&(" + ImportServiceRecordTestCase.AUTHOR_KEY + '=' + ImportServiceRecordTestCase.FRED + ")(" + ImportServiceRecordTestCase.COMPANY_KEY + '=' + ImportServiceRecordTestCase.ECLIPSE_ORG + "))"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
		filter = context.createFilter(filterString);
		record.setFilter(filter);

		expected = service1;
		actual = releasedHolder.getValue();
		Assert.assertSame(expected, actual);

		Assert.assertNull(acquiredHolder.getValue());

		acquiredHolder.setNull();
		releasedHolder.setNull();

		record.setFilter(null);

		Assert.assertNotNull(acquiredHolder.getValue());

		registration3.unregister();
		registration2.unregister();
		registration1.unregister();

		record.release();
	}
}
