/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.junit.internal.cm;

import java.io.IOException;
import java.util.Dictionary;
import java.util.Hashtable;

import org.osgi.framework.InvalidSyntaxException;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;

public class ConfigurationAdminConfigurator extends Object {
	private ConfigurationAdmin configurationAdmin;

	public ConfigurationAdminConfigurator(ConfigurationAdmin configurationAdmin) {
		super();
		setConfigurationAdmin(configurationAdmin);
	}

	public Configuration create(IManagedServiceFactoryActivationDelegate factory, Object id, Dictionary properties) throws IOException, InterruptedException {
		Configuration configuration = createConfiguration(factory);
		synchronized (factory) {
			updateConfiguration(factory, properties, configuration);
			waitForConfigurationUpdate(factory, id);
		}

		return configuration;
	}

	private Configuration createConfiguration(IManagedServiceFactoryActivationDelegate factory) throws IOException {
		ConfigurationAdmin admin = getConfigurationAdmin();
		String pid = factory.getPid();
		String location = factory.getLocation();
		Configuration configuration = admin.createFactoryConfiguration(pid, location);
		return configuration;
	}

	public void delete(IManagedServiceFactoryActivationDelegate factory, Object id, Configuration configuration) throws IOException, InterruptedException {
		if (configuration == null) return;
		
		synchronized (factory) {
			configuration.delete();
			waitForConfigurationDeletion(factory, id);
		}
	}

	private ConfigurationAdmin getConfigurationAdmin() {
		return configurationAdmin;
	}

	public Configuration[] getConfigurations(String filter) throws IOException, InvalidSyntaxException {
		ConfigurationAdmin admin = getConfigurationAdmin();
		Configuration[] configurations = admin.listConfigurations(filter);
		return configurations;
	}

	private void setConfigurationAdmin(ConfigurationAdmin configurationAdmin) {
		this.configurationAdmin = configurationAdmin;
	}

	public void update(IManagedServiceFactoryActivationDelegate factory, Dictionary properties, Configuration configuration) throws IOException, InterruptedException {
		synchronized (factory) {
			updateConfiguration(factory, properties, configuration);
			waitForConfigurationUpdate(factory);
		}
	}

	private void updateConfiguration(IManagedServiceFactoryActivationDelegate factory, Dictionary properties, Configuration configuration) throws IOException {
		Dictionary configurationProperties = properties == null ? new Hashtable(17) : properties;
		String pid = factory.getPid();
		configurationProperties.put(ConfigurationAdmin.SERVICE_FACTORYPID, pid);
		configuration.update(configurationProperties);
	}

	private void waitForConfigurationDeletion(IManagedServiceFactoryActivationDelegate factory, Object id) throws InterruptedException {
		while (factory.getObjectWithId(id) != null) {
			factory.wait();
		}
	}

	private void waitForConfigurationUpdate(IManagedServiceFactoryActivationDelegate factory) throws InterruptedException {
		factory.wait();
	}

	private void waitForConfigurationUpdate(IManagedServiceFactoryActivationDelegate factory, Object id) throws InterruptedException {
		while (factory.getObjectWithId(id) == null) {
			factory.wait();
		}
	}
}
