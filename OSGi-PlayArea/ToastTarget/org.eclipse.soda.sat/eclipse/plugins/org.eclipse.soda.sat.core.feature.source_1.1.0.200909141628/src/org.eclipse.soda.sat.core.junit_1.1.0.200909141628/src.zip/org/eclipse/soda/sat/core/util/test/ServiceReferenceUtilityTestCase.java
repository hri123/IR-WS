/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.util.test;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.List;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.junit.internal.AbstractServiceTestCase;
import org.eclipse.soda.sat.core.util.ServiceReferenceUtility;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.framework.ServiceReference;
import org.osgi.framework.ServiceRegistration;

public class ServiceReferenceUtilityTestCase extends AbstractServiceTestCase {
	private interface TestService1 {
		public static final String SERVICE_NAME = TestService1.class.getName();
	}

	private interface TestService2 {
		public static final String SERVICE_NAME = TestService2.class.getName();
	}

	interface TestService3 {
		public static final String SERVICE_NAME = TestService3.class.getName();
	}

	private static class TestServiceImplementation extends Object implements TestService1, TestService2 { // $codepro.audit.disable convertClassToInterface, com.instantiations.assist.eclipse.analysis.emptyClass
		//...
	}

	private static final ServiceReference[] NO_SERVICE_REFERENCES = new ServiceReference [ 0 ];
	private static final Integer ONE = new Integer(1);
	private static final Integer TWO = new Integer(2);
	private static final Integer THREE = new Integer(3);
	private static final Integer FOUR = new Integer(4);

	public static Test suite() {
		return new TestSuite(ServiceReferenceUtilityTestCase.class);
	}

	public ServiceReferenceUtilityTestCase(String name) {
		super(name);
	}

	public void test_getServiceNames() {
		BundleContext context = getBundleContext();

		String[] services = {
			TestService1.SERVICE_NAME,
			TestService2.SERVICE_NAME
		};

		Object service = new TestServiceImplementation();
		ServiceRegistration registration = context.registerService(services, service, null);
		ServiceReference reference = registration.getReference();

		ServiceReferenceUtility utility = ServiceReferenceUtility.getInstance();
		List serviceNames = utility.getServiceNames(reference);

		int expectedLength = 2;
		int actualLength = serviceNames.size();

		Assert.assertEquals(expectedLength, actualLength);

		Object serviceName;
		boolean valid;

		serviceName = serviceNames.get(0);
		valid = serviceName.equals(TestService1.SERVICE_NAME) || serviceName.equals(TestService2.SERVICE_NAME);
		Assert.assertTrue(valid);

		serviceName = serviceNames.get(1);
		valid = serviceName.equals(TestService1.SERVICE_NAME) || serviceName.equals(TestService2.SERVICE_NAME);
		Assert.assertTrue(valid);

		registration.unregister();
	}

	public void test_isServiceInstanceOf() {
		BundleContext context = getBundleContext();

		String[] services = new String[] {
			TestService1.SERVICE_NAME,
			TestService2.SERVICE_NAME
		};

		Object test1 = new TestServiceImplementation();
		ServiceRegistration registration1 = context.registerService(services, test1, null);
		ServiceReference reference1 = registration1.getReference();

		Object test3 = new TestService3() {
			//...
		};

		ServiceRegistration registration3 = context.registerService(TestService3.SERVICE_NAME, test3, null);
		ServiceReference reference3 = registration3.getReference();

		ServiceReferenceUtility utility = ServiceReferenceUtility.getInstance();
		boolean result;

		// Positive cases
		result = utility.isServiceInstanceOf(reference1, TestService1.SERVICE_NAME);
		Assert.assertTrue(result);

		result = utility.isServiceInstanceOf(reference1, TestService2.SERVICE_NAME);
		Assert.assertTrue(result);

		result = utility.isServiceInstanceOf(reference3, TestService3.SERVICE_NAME);
		Assert.assertTrue(result);

		// Negative cases
		result = utility.isServiceInstanceOf(reference1, TestService3.SERVICE_NAME);
		Assert.assertFalse(result);

		result = utility.isServiceInstanceOf(reference3, TestService1.SERVICE_NAME);
		Assert.assertFalse(result);

		result = utility.isServiceInstanceOf(reference3, TestService2.SERVICE_NAME);
		Assert.assertFalse(result);

		registration3.unregister();
		registration1.unregister();
	}

	public void test_select() {
		BundleContext context = getBundleContext();

		Object test1 = new TestServiceImplementation();
		Dictionary properties1 = new Hashtable(11);
		properties1.put(Constants.SERVICE_RANKING, ServiceReferenceUtilityTestCase.ONE);

		ServiceRegistration registration1 = context.registerService(TestService1.SERVICE_NAME, test1, properties1);
		ServiceReference reference1 = registration1.getReference();

		Object test2 = new TestServiceImplementation();
		Dictionary properties2 = new Hashtable(11);
		properties2.put(Constants.SERVICE_RANKING, ServiceReferenceUtilityTestCase.TWO);

		ServiceRegistration registration2 = context.registerService(TestService1.SERVICE_NAME, test2, properties2);
		ServiceReference reference2 = registration2.getReference();

		Object test3 = new TestServiceImplementation();
		Dictionary properties3 = new Hashtable(11);
		properties3.put(Constants.SERVICE_RANKING, ServiceReferenceUtilityTestCase.TWO);

		ServiceRegistration registration3 = context.registerService(TestService1.SERVICE_NAME, test3, properties3);
		ServiceReference reference3 = registration3.getReference();

		ServiceReferenceUtility utility = ServiceReferenceUtility.getInstance();
		Object expected = reference2;
		Object actual;

		ServiceReference[] references = new ServiceReference [ 3 ];
		
		references [ 0 ] = reference1; // Rank=1, Service ID=1
		references [ 1 ] = reference2; // Rank=2, Service ID=2
		references [ 2 ] = reference3; // Rank=2, Service ID=3
		actual = utility.select(references);
		Assert.assertSame(expected, actual);
		
		references [ 0 ] = reference2; // Rank=2, Service ID=3
		references [ 1 ] = reference3; // Rank=2, Service ID=2
		references [ 2 ] = reference1; // Rank=1, Service ID=1
		actual = utility.select(references);
		Assert.assertSame(expected, actual);

		references [ 0 ] = reference3; // Rank=2, Service ID=2
		references [ 1 ] = reference1; // Rank=1, Service ID=1
		references [ 2 ] = reference2; // Rank=2, Service ID=3
		actual = utility.select(references);
		Assert.assertSame(expected, actual);
		
		registration3.unregister();
		registration2.unregister();
		registration1.unregister();
	}

	public void test_selectWithEmptyServiceReferenceArray() {
		ServiceReferenceUtility utility = ServiceReferenceUtility.getInstance();
		ServiceReference[] references = ServiceReferenceUtilityTestCase.NO_SERVICE_REFERENCES;
		Object reference = utility.select(references);
		Assert.assertNull(reference);
	}
	
	public void test_createServiceRankingComparator() {
		BundleContext context = getBundleContext();

		Object test1 = new TestServiceImplementation();
		Dictionary properties1 = new Hashtable(11);
		properties1.put(Constants.SERVICE_RANKING, ServiceReferenceUtilityTestCase.ONE);

		ServiceRegistration registration1 = context.registerService(TestService1.SERVICE_NAME, test1, properties1);
		ServiceReference reference1 = registration1.getReference();

		Object test2a = new TestServiceImplementation();
		Dictionary properties2a = new Hashtable(11);
		properties2a.put(Constants.SERVICE_RANKING, ServiceReferenceUtilityTestCase.TWO);

		ServiceRegistration registration2a = context.registerService(TestService1.SERVICE_NAME, test2a, properties2a);
		ServiceReference reference2a = registration2a.getReference();

		Object test2b = new TestServiceImplementation();
		Dictionary properties2b = new Hashtable(11);
		properties2b.put(Constants.SERVICE_RANKING, ServiceReferenceUtilityTestCase.TWO);

		ServiceRegistration registration2b = context.registerService(TestService1.SERVICE_NAME, test2b, properties2b);
		ServiceReference reference2b = registration2b.getReference();
		
		Object test3 = new TestServiceImplementation();
		Dictionary properties3 = new Hashtable(11);
		properties3.put(Constants.SERVICE_RANKING, ServiceReferenceUtilityTestCase.THREE);

		ServiceRegistration registration3 = context.registerService(TestService1.SERVICE_NAME, test3, properties3);
		ServiceReference reference3 = registration3.getReference();

		Object test4 = new TestServiceImplementation();
		Dictionary properties4 = new Hashtable(11);
		properties4.put(Constants.SERVICE_RANKING, ServiceReferenceUtilityTestCase.FOUR);
		
		ServiceRegistration registration4 = context.registerService(TestService1.SERVICE_NAME, test4, properties4);
		ServiceReference reference4 = registration4.getReference();

		ServiceReferenceUtility utility = ServiceReferenceUtility.getInstance();
		Comparator comparator = utility.createServiceRankingComparator();
		Object expected;
		Object actual;

		ServiceReference[] references = new ServiceReference [ 5 ];
		references [ 0 ] = reference2b; // Rank=2, Service ID=3
		references [ 1 ] = reference4; // Rank=4, Service ID=5
		references [ 2 ] = reference2a; // Rank=2, Service ID=2
		references [ 3 ] = reference1; // Rank=1, Service ID=1
		references [ 4 ] = reference3; // Rank=3, Service ID=4
		
		Arrays.sort(references, comparator);

		expected = reference4;
		actual = references [ 0 ];
		Assert.assertSame(expected, actual);

		expected = reference3;
		actual = references [ 1 ];
		Assert.assertSame(expected, actual);

		expected = reference2a;
		actual = references [ 2 ];
		Assert.assertSame(expected, actual);

		expected = reference2b;
		actual = references [ 3 ];
		Assert.assertSame(expected, actual);
		
		expected = reference1;
		actual = references [ 4 ];
		Assert.assertSame(expected, actual);
		
		registration4.unregister();
		registration3.unregister();
		registration2b.unregister();
		registration2a.unregister();
		registration1.unregister();
	}
}