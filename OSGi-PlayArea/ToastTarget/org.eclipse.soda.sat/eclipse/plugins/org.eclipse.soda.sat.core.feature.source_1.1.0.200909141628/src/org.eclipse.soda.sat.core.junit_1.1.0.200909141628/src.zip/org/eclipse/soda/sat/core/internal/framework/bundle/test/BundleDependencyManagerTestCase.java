/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle.test;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.framework.interfaces.BundleDependencyListener;
import org.eclipse.soda.sat.core.junit.internal.AbstractServiceTestCase;
import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecordOwner;
import org.eclipse.soda.sat.core.service.BundleDependencyService;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.junit.util.ValueHolder;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;

public class BundleDependencyManagerTestCase extends AbstractServiceTestCase {
	public static Test suite() {
		return new TestSuite(BundleDependencyManagerTestCase.class);
	}

	private IImportServiceRecord record;
	private ValueHolder acquiredHolder;
	private ValueHolder releasedHolder;
	private BundleDependencyService bds;
	private Map bundlesMap;

	public BundleDependencyManagerTestCase(String name) {
		super(name);
	}

	private void acquireBundleDependencyService() {
		acquiredHolder = ValueHolder.nullValue();
		releasedHolder = ValueHolder.nullValue();
		FactoryUtility utility = FactoryUtility.getInstance();
		BundleContext context = getBundleContext();
		record = utility.createImportServiceRecord(context, BundleDependencyService.SERVICE_NAME, null);
		IImportServiceRecordOwner owner = createImportServiceRecordOwner();
		record.setOwner(owner);
		record.acquire();
		Object expected = record;
		Object actual = acquiredHolder.getValue();
		Assert.assertSame(expected, actual);
		bds = (BundleDependencyService) record.getService();
	}

	private Map createBundlesMap() {
		Map map = new HashMap(17);
		BundleContext context = getBundleContext();
		Bundle[] bundles = context.getBundles();

		for (int i = 0; i < bundles.length; i++) {
			Bundle bundle = bundles [ i ];
			Object key = bundle.getSymbolicName();
			map.put(key, bundle);
		}

		return map;
	}

	private IImportServiceRecordOwner createImportServiceRecordOwner() {
		return new IImportServiceRecordOwner(){
			public Object getLock() {
				return this;
			}

			public void serviceAcquired(IImportServiceRecord record) {
				acquiredHolder.setValue(record);
			}

			public void serviceReleased(IImportServiceRecord record) {
				releasedHolder.setValue(record);
			}
		};
	}

	private Map getBundlesMap() {
		synchronized (this) {
			if (bundlesMap == null) {
				Map map = createBundlesMap();
				setBundlesMap(map);
			}
		}

		return bundlesMap;
	}

	private void releaseBundleDependencyService() {
		bds = null;
		record.release();
		Object expected = record;
		Object actual = releasedHolder.getValue();
		Assert.assertSame(expected, actual);
		record = null;
		acquiredHolder = null;
		releasedHolder = null;
	}

	private void setBundlesMap(Map bundlesMap) {
		this.bundlesMap = bundlesMap;
	}

	protected void setUp() throws Exception {
		super.setUp();
		acquireBundleDependencyService();
	}

	protected void tearDown() throws Exception {
		releaseBundleDependencyService();
		super.tearDown();
	}

	public void test_addBundleDependencyListener() {
		BundleDependencyListener listener = new BundleDependencyListener(){
			public void registered(Bundle importer, Bundle exporter) {
				// No-op
			}

			public void unregistered(Bundle importer, Bundle exporter) {
				// No-op
			}
		};

		try {
			bds.addBundleDependencyListener(listener);
		} finally {
			bds.removeBundleDependencyListener(listener);
		}
	}

	public void test_addUninstallableBundle() {
		// No-op
	}

	public void test_getAllDependentsOf() {
		BundleContext context = getBundleContext();
		Bundle systemBundle = context.getBundle(0);  // System Bundle
		List allDependentsOfSystemBundle = bds.getAllDependentsOf(systemBundle);
		Iterator iterator = allDependentsOfSystemBundle.iterator();

		while (iterator.hasNext() == true) {
			Bundle dependent = (Bundle) iterator.next();
			List allPrerequisites = bds.getAllPrerequisitesOf(dependent);
			boolean exists = allPrerequisites.contains(systemBundle);
			Assert.assertTrue(exists);
		}
	}

	public void test_getAllPrerequisitesOf() {
		Bundle bundle = getBundle();
		List allPrerequisites = bds.getAllPrerequisitesOf(bundle);
		Iterator iterator = allPrerequisites.iterator();

		while (iterator.hasNext() == true) {
			Bundle prerequisite = (Bundle) iterator.next();
			List allDependents = bds.getAllDependentsOf(prerequisite);
			boolean exists = allDependents.contains(bundle);
			Assert.assertTrue(exists);
		}
	}

	public void test_getBundles() {
		Map map = getBundlesMap();
		Collection bundles = bds.getBundles();
		int mapSize = map.size();
		int bundlesSize = bundles.size();
		Assert.assertEquals(mapSize, bundlesSize);

		Set keys = map.keySet();
		Iterator iterator = keys.iterator();
		boolean match = true;

		while (match == true && iterator.hasNext() == true) {
			Object key = iterator.next();
			Object bundle = map.get(key);
			match = bundles.contains(bundle);
		}

		if (match == true) return;  // Early return.
		Assert.fail("The lists of the bundles do not match"); //$NON-NLS-1$
	}

	public void test_getDependentsOf() {
		BundleContext context = getBundleContext();
		Bundle systemBundle = context.getBundle(0);  // System Bundle
		List dependentsOfSystemBundle = bds.getDependentsOf(systemBundle);
		Iterator iterator = dependentsOfSystemBundle.iterator();

		while (iterator.hasNext() == true) {
			Bundle dependent = (Bundle) iterator.next();
			List prerequisites = bds.getPrerequisitesOf(dependent);
			boolean exists = prerequisites.contains(systemBundle);
			Assert.assertTrue(exists);
		}
	}

	public void test_getPrerequisitesOf() {
		Bundle bundle = getBundle();
		List prerequisites = bds.getPrerequisitesOf(bundle);
		Iterator iterator = prerequisites.iterator();

		while (iterator.hasNext() == true) {
			Bundle prerequisite = (Bundle) iterator.next();
			List dependents = bds.getDependentsOf(prerequisite);
			boolean exists = dependents.contains(bundle);
			Assert.assertTrue(exists);
		}
	}

	public void test_isRegisteredAsUninstallable() {
		// No-op
	}

	public void test_removeBundleDependencyListener() {
		// No-op
	}

	public void test_removeUninstallableBundle() {
		// No-op
	}

	public void test_toXml() {
		// No-op
	}
}
