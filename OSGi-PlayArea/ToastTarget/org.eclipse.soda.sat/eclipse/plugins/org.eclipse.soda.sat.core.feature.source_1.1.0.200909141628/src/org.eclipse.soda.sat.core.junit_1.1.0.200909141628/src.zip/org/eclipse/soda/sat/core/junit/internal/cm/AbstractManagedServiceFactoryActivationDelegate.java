/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.junit.internal.cm;

import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.soda.sat.core.framework.ManagedServiceFactoryBundleActivator;
import org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryAdvisor;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public abstract class AbstractManagedServiceFactoryActivationDelegate extends Object implements IManagedServiceFactoryActivationDelegate {
	private ManagedServiceFactoryBundleActivator activator;
	private String pid;
	private String location;
	private Map objects;

	protected AbstractManagedServiceFactoryActivationDelegate(String pid, String location) {
		super();
		setPid(pid);
		setLocation(location);
	}

	protected final void addObjectWithId(Object id, Object object) {
		synchronized (this) {
			basicAddObjectWithId(id, object);
			log("Added: " + object); //$NON-NLS-1$
			notifyAll();
		}
	}

	private void basicAddObjectWithId(Object id, Object object) {
		Map map = getObjects();

		synchronized (map) {
			map.put(id, object);
		}
	}

	private Object basicRemoveObjectWithId(Object id) {
		Object object;
		Map map = getObjects();

		synchronized (map) {
			object = map.remove(id);
		}

		return object;
	}

	private final ManagedServiceFactoryBundleActivator createActivator() {
		return new ManagedServiceFactoryBundleActivator(){
			protected IManagedServiceFactoryAdvisor createAdvisor() {
				return AbstractManagedServiceFactoryActivationDelegate.this.createAdvisor();
			}

			protected String createPid() {
				return AbstractManagedServiceFactoryActivationDelegate.this.getPid();
			}
		};
	}

	protected abstract IManagedServiceFactoryAdvisor createAdvisor();

	private ManagedServiceFactoryBundleActivator getActivator() {
		synchronized (this) {
			if (activator == null) {
				ManagedServiceFactoryBundleActivator activator = createActivator();
				setActivator(activator);
			}
		}

		return activator;
	}

	protected final String getId(Dictionary properties) {
		return (String) properties.get(IManagedServiceFactoryActivationDelegate.ID_PROPERTY_KEY);
	}

	public final String getLocation() {
		return location;
	}

	private Map getObjects() {
		synchronized (this) {
			if (objects == null) {
				Map map = new HashMap(11);
				setObjects(map);
			}
		}

		return objects;
	}

	public final Object getObjectWithId(Object id) {
		Map map = getObjects();
		Object object;

		synchronized (map) {
			object = map.get(id);
		}

		return object;
	}

	public String getPid() {
		return pid;
	}

	private void log(String message) {
		LogUtility.logInfo(message);
	}

	protected final Object removeObjectWithId(Object id) {
		Object object;

		synchronized (this) {
			object = basicRemoveObjectWithId(id);
			log("Removed: " + object); //$NON-NLS-1$
			notifyAll();
		}

		return object;
	}

	private void setActivator(ManagedServiceFactoryBundleActivator activator) {
		this.activator = activator;
	}

	private void setLocation(String location) {
		this.location = location;
	}

	private void setObjects(Map objects) {
		this.objects = objects;
	}

	private void setPid(String pid) {
		this.pid = pid;
	}

	public final void start(BundleContext context) throws Exception {
		BundleActivator activator = getActivator();
		activator.start(context);
	}

	public final void stop(BundleContext context) throws Exception {
		BundleActivator activator = getActivator();
		activator.stop(context);
	}

	protected final void updated(Object object) {
		synchronized (this) {
			log("Updated: " + object); //$NON-NLS-1$
			notifyAll();
		}
	}
}
