/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.record.test;

import java.util.Dictionary;
import java.util.Hashtable;
import java.util.List;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;
import org.eclipse.soda.sat.core.junit.internal.AbstractServiceTestCase;
import org.eclipse.soda.sat.core.record.interfaces.IServiceDetecter;
import org.eclipse.soda.sat.core.record.interfaces.ServiceDetecterListener;
import org.eclipse.soda.sat.junit.util.ValueHolder;
import org.osgi.framework.BundleContext;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceReference;
import org.osgi.framework.ServiceRegistration;

public class ServiceDetecterTestCase extends AbstractServiceTestCase {
	private interface TestService1 {
		public static final String SERVICE_NAME = TestService1.class.getName();
	}

	private interface TestService2 {
		public static final String SERVICE_NAME = TestService2.class.getName();
	}

	private static class TestServiceImplementation extends Object implements TestService1, TestService2 { // $codepro.audit.disable convertClassToInterface, com.instantiations.assist.eclipse.analysis.emptyClass
		//...
	}

	public static Test suite() {
		return new TestSuite(ServiceDetecterTestCase.class);
	}

	public ServiceDetecterTestCase(String name) {
		super(name);
	}

	private IServiceDetecter createServiceDetecter(String name) {
		BundleContext context = getBundleContext();
		IServiceDetecter detecter = AbstractSatTestCase.FACTORY.createServiceDetecter(context, name);
		return detecter;
	}

	public void test_acquire() {
		IServiceDetecter detecter = createServiceDetecter(TestService1.SERVICE_NAME);
		BundleContext context = getBundleContext();
		Object service = new TestServiceImplementation();
		ServiceRegistration registration = context.registerService(TestService1.SERVICE_NAME, service, null);

		Object expected;
		Object actual;

		final ValueHolder addedHolder = ValueHolder.nullValue();
		final ValueHolder removedHolder = ValueHolder.nullValue();

		expected = null;
		actual = addedHolder.getValue();
		Assert.assertSame(expected, actual);

		ServiceDetecterListener listener = new ServiceDetecterListener() {
			public void serviceAdded(IServiceDetecter detecter, ServiceReference serviceReference, Object service) {
				addedHolder.setValue(service);
			}

			public void serviceRemoved(IServiceDetecter detecter, ServiceReference serviceReference, Object service) {
				removedHolder.setValue(service);
			}
		};


		detecter.addServiceDetecterListener(listener);
		detecter.acquire();

		expected = service;
		actual = addedHolder.getValue();
		Assert.assertSame(expected, actual);

		addedHolder.setNull();
		detecter.acquire();

		expected = null;
		actual = addedHolder.getValue();
		Assert.assertSame(expected, actual);

		actual = removedHolder.getValue();
		Assert.assertSame(expected, actual);

		registration.unregister();

		expected = service;
		actual = removedHolder.getValue();
		Assert.assertSame(expected, actual);

		detecter.removeServiceDetecterListener(listener);
		detecter.release();
	}

	public void test_getName() {
		IServiceDetecter detecter = createServiceDetecter(TestService1.SERVICE_NAME);
		Object expected = TestService1.SERVICE_NAME;
		Object actual = detecter.getName();
		Assert.assertEquals(expected, actual);
	}

	public void test_getServiceReferences() {
		BundleContext context = getBundleContext();

		TestService1 service1 = new TestServiceImplementation();
		ServiceRegistration registration1 = context.registerService(TestService1.SERVICE_NAME, service1, null);
		Object reference1 = registration1.getReference();

		TestService1 service2 = new TestServiceImplementation();
		ServiceRegistration registration2 = context.registerService(TestService1.SERVICE_NAME, service2, null);
		Object reference2 = registration2.getReference();

		IServiceDetecter detecter = createServiceDetecter(TestService1.SERVICE_NAME);

		detecter.acquire();

		List references = detecter.getServiceReferences();
		int expected = 2;
		int actual = references.size();
		Assert.assertEquals(expected, actual);

		boolean exists;

		exists = references.contains(reference1);
		Assert.assertTrue(exists);

		exists = references.contains(reference2);
		Assert.assertTrue(exists);

		registration2.unregister();
		registration1.unregister();
		detecter.release();
	}

	public void test_getServices() {
		BundleContext context = getBundleContext();
		TestService1 service1 = new TestServiceImplementation();
		TestService1 service2 = new TestServiceImplementation();
		ServiceRegistration registration1 = context.registerService(TestService1.SERVICE_NAME, service1, null);
		ServiceRegistration registration2 = context.registerService(TestService1.SERVICE_NAME, service2, null);

		IServiceDetecter detecter = createServiceDetecter(TestService1.SERVICE_NAME);
		detecter.acquire();

		boolean exists;

		List services = detecter.getServices();
		int expected = 2;
		int actual = services.size();
		Assert.assertEquals(expected, actual);

		exists = services.contains(service1);
		Assert.assertTrue(exists);

		exists = services.contains(service2);
		Assert.assertTrue(exists);

		registration2.unregister();
		registration1.unregister();
		detecter.release();
	}

	public void test_getServicesReferencesWithFilter() throws InvalidSyntaxException {
		TestService1 service1 = new TestServiceImplementation();
		TestService1 service2 = new TestServiceImplementation();
		TestService1 service3 = new TestServiceImplementation();

		Dictionary serviceProperties1 = new Hashtable(11);
		Dictionary serviceProperties2 = new Hashtable(11);
		Dictionary serviceProperties3 = new Hashtable(11);

		String vendorKey = "vendor";  //$NON-NLS-1$
		String ibmVendor = "IBM";  //$NON-NLS-1$
		String otiVendor = "OTI";  //$NON-NLS-1$
		String xyzVendor = "XYZ";  //$NON-NLS-1$

		serviceProperties1.put(vendorKey, ibmVendor);
		serviceProperties2.put(vendorKey, otiVendor);
		serviceProperties3.put(vendorKey, ibmVendor);

		BundleContext context = getBundleContext();

		ServiceRegistration registration1 = null;
		ServiceRegistration registration2 = null;
		ServiceRegistration registration3 = null;

		IServiceDetecter detecter = null;

		try {
			registration1 = context.registerService(TestService1.SERVICE_NAME, service1, serviceProperties1);
			registration2 = context.registerService(TestService1.SERVICE_NAME, service2, serviceProperties2);
			registration3 = context.registerService(TestService1.SERVICE_NAME, service3, serviceProperties3);

			detecter = createServiceDetecter(TestService1.SERVICE_NAME);
			detecter.acquire();

			String filter;
			List services;
			int expectedSize;
			int actualSize;
			ServiceReference reference;
			Object expectedVendor;
			Object actualVendor;

			filter = '(' + vendorKey + '=' + ibmVendor + ')';
			services = detecter.getServiceReferences(filter);
			expectedSize = 2;
			actualSize = services.size();
			Assert.assertEquals(expectedSize, actualSize);

			expectedVendor = ibmVendor;
			reference = (ServiceReference) services.get(0);
			actualVendor = reference.getProperty(vendorKey);
			Assert.assertEquals(expectedVendor, actualVendor);
			reference = (ServiceReference) services.get(1);
			actualVendor = reference.getProperty(vendorKey);
			Assert.assertEquals(expectedVendor, actualVendor);

			filter = '(' + vendorKey + '=' + otiVendor + ')';
			services = detecter.getServiceReferences(filter);
			expectedSize = 1;
			actualSize = services.size();
			Assert.assertEquals(expectedSize, actualSize);

			expectedVendor = otiVendor;
			reference = (ServiceReference) services.get(0);
			actualVendor = reference.getProperty(vendorKey);
			Assert.assertEquals(expectedVendor, actualVendor);

			filter = '(' + vendorKey + '=' + xyzVendor + ')';
			services = detecter.getServiceReferences(filter);
			expectedSize = 0;
			actualSize = services.size();
			Assert.assertEquals(expectedSize, actualSize);
		} finally {
			if (registration3 != null) {
				registration3.unregister();
			}

			if (registration2 != null) {
				registration2.unregister();
			}

			if (registration1 != null) {
				registration1.unregister();
			}

			if (detecter != null) {
				detecter.release();
			}
		}
	}

	public void test_getServicesWithFilter() throws InvalidSyntaxException {
		TestService1 service1 = new TestServiceImplementation();
		TestService1 service2 = new TestServiceImplementation();
		TestService1 service3 = new TestServiceImplementation();

		Dictionary serviceProperties1 = new Hashtable(11);
		Dictionary serviceProperties2 = new Hashtable(11);
		Dictionary serviceProperties3 = new Hashtable(11);

		String vendor = "vendor";  //$NON-NLS-1$
		String ibmVendor = "IBM";  //$NON-NLS-1$
		String otiVendor = "OTI";  //$NON-NLS-1$
		String xyzVendor = "XYZ";  //$NON-NLS-1$

		serviceProperties1.put(vendor, ibmVendor);
		serviceProperties2.put(vendor, otiVendor);
		serviceProperties3.put(vendor, ibmVendor);

		BundleContext context = getBundleContext();

		ServiceRegistration registration1 = null;
		ServiceRegistration registration2 = null;
		ServiceRegistration registration3 = null;

		IServiceDetecter detecter = null;

		try {
			registration1 = context.registerService(TestService1.SERVICE_NAME, service1, serviceProperties1);
			registration2 = context.registerService(TestService1.SERVICE_NAME, service2, serviceProperties2);
			registration3 = context.registerService(TestService1.SERVICE_NAME, service3, serviceProperties3);

			detecter = createServiceDetecter(TestService1.SERVICE_NAME);
			detecter.acquire();

			String filter;
			List services;
			int expected;
			int actual;

			filter = '(' + vendor + '=' + ibmVendor + ')';
			services = detecter.getServices(filter);
			expected = 2;
			actual = services.size();
			Assert.assertEquals(expected, actual);

			filter = '(' + vendor + '=' + otiVendor + ')';
			services = detecter.getServices(filter);
			expected = 1;
			actual = services.size();
			Assert.assertEquals(expected, actual);

			filter = '(' + vendor + '=' + xyzVendor + ')';
			services = detecter.getServices(filter);
			expected = 0;
			actual = services.size();
			Assert.assertEquals(expected, actual);
		} finally {
			if (registration3 != null) {
				registration3.unregister();
			}

			if (registration2 != null) {
				registration2.unregister();
			}

			if (registration1 != null) {
				registration1.unregister();
			}

			if (detecter != null) {
				detecter.release();
			}
		}
	}

	public void test_isAcquired() {
		IServiceDetecter detecter = createServiceDetecter(TestService1.SERVICE_NAME);

		BundleContext context = getBundleContext();
		TestService1 service = new TestServiceImplementation();
		ServiceRegistration registration = context.registerService(TestService1.SERVICE_NAME, service, null);

		boolean acquired;
		List services;
		int expectedSize;
		int actualSize;

		// Negative case
		acquired = detecter.isAcquired();
		Assert.assertFalse(acquired);

		services = detecter.getServices();
		expectedSize = 0;
		actualSize = services.size();
		Assert.assertEquals(expectedSize, actualSize);

		// Positive case
		detecter.acquire();
		acquired = detecter.isAcquired();
		Assert.assertTrue(acquired);

		services = detecter.getServices();
		expectedSize = 1;
		actualSize = services.size();
		Assert.assertEquals(expectedSize, actualSize);

		boolean exists = services.contains(service);
		Assert.assertTrue(exists);

		registration.unregister();
		detecter.release();
	}

	public void test_release() {
		IServiceDetecter detecter = createServiceDetecter(TestService1.SERVICE_NAME);

		final ValueHolder removedHolder = ValueHolder.nullValue();

		ServiceDetecterListener listener = new ServiceDetecterListener() {
			public void serviceAdded(IServiceDetecter detecter, ServiceReference serviceReference, Object service) {
				// No-op
			}

			public void serviceRemoved(IServiceDetecter detecter, ServiceReference serviceReference, Object service) {
				removedHolder.setValue(service);
			}
		};

		detecter.addServiceDetecterListener(listener);
		detecter.acquire();

		BundleContext context = getBundleContext();
		TestService1 service = new TestServiceImplementation();
		ServiceRegistration registration = context.registerService(TestService1.SERVICE_NAME, service, null);

		Object expected;
		Object actual;

		expected = null;
		actual = removedHolder.getValue();
		Assert.assertSame(expected, actual);

		detecter.release();

		expected = service;
		actual = removedHolder.getValue();
		Assert.assertSame(expected, actual);

		detecter.removeServiceDetecterListener(listener);
		registration.unregister();
	}

	public void test_setFilter() throws InvalidSyntaxException {
		final String AUTHOR_KEY = "author"; //$NON-NLS-1$
		final String COMPANY_KEY = "company"; //$NON-NLS-1$
		final String TYPE_KEY = "type"; //$NON-NLS-1$

		final String FRED = "Fred"; //$NON-NLS-1$
		final String JOHN = "John"; //$NON-NLS-1$

		final String AUTOMATIC_TYPE = "automatic"; //$NON-NLS-1$
		final String MANUAL_TYPE = "manual"; //$NON-NLS-1$

		final String IBM_ORG = "IBM"; //$NON-NLS-1$
		final String ECLIPSE_ORG = "Eclipse"; //$NON-NLS-1$

		TestService1 service1 = new TestServiceImplementation();
		Dictionary properties1 = new Hashtable(11);
		properties1.put(AUTHOR_KEY, JOHN);
		properties1.put(COMPANY_KEY, IBM_ORG);
		properties1.put(TYPE_KEY, AUTOMATIC_TYPE);

		TestService1 service2 = new TestServiceImplementation();
		Dictionary properties2 = new Hashtable(11);
		properties2.put(AUTHOR_KEY, FRED);
		properties2.put(COMPANY_KEY, IBM_ORG);
		properties2.put(TYPE_KEY, MANUAL_TYPE);

		TestService1 service3 = new TestServiceImplementation();
		Dictionary properties3 = new Hashtable(11);
		properties3.put(AUTHOR_KEY, JOHN);
		properties3.put(COMPANY_KEY, ECLIPSE_ORG);
		properties3.put(TYPE_KEY, AUTOMATIC_TYPE);

		IServiceDetecter detecter = createServiceDetecter(TestService1.SERVICE_NAME);
		detecter.acquire();

		BundleContext context = getBundleContext();

		ServiceRegistration registration1 = context.registerService(TestService1.SERVICE_NAME, service1, properties1);
		ServiceRegistration registration2 = context.registerService(TestService1.SERVICE_NAME, service2, properties2);
		ServiceRegistration registration3 = context.registerService(TestService1.SERVICE_NAME, service3, properties3);

		// "(author=John)"
		String filter = '(' + AUTHOR_KEY + '=' + JOHN + ')';
		detecter.setFilter(filter);

		List services;
		int expectedSize;
		int actualSize;
		boolean exists;

		services = detecter.getServices();
		expectedSize = 2;
		actualSize = services.size();
		Assert.assertEquals(expectedSize, actualSize);

		exists = services.contains(service1);
		Assert.assertTrue(exists);

		exists = services.contains(service3);
		Assert.assertTrue(exists);

		// "(author=Fred)"
		filter = '(' + AUTHOR_KEY + '=' + FRED + ')';
		detecter.setFilter(filter);

		services = detecter.getServices();
		expectedSize = 1;
		actualSize = services.size();
		Assert.assertEquals(expectedSize, actualSize);

		exists = services.contains(service2);
		Assert.assertTrue(exists);

		// "(company=IBM)"
		filter = '(' + COMPANY_KEY + '=' + IBM_ORG + ')';
		detecter.setFilter(filter);

		services = detecter.getServices();
		expectedSize = 2;
		actualSize = services.size();
		Assert.assertEquals(expectedSize, actualSize);

		exists = services.contains(service1);
		Assert.assertTrue(exists);

		exists = services.contains(service2);
		Assert.assertTrue(exists);

		// "(&(company=IBM)(type=automatic))"
		filter = "(&(" + COMPANY_KEY + '=' + IBM_ORG + ")(" + TYPE_KEY + '='  + AUTOMATIC_TYPE + "))";  //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
		detecter.setFilter(filter);

		services = detecter.getServices();
		expectedSize = 1;
		actualSize = services.size();
		Assert.assertEquals(expectedSize, actualSize);

		exists = services.contains(service1);
		Assert.assertTrue(exists);

		// "(&(company=Eclipse)(type=manual))"
		filter = "(&(" + COMPANY_KEY + '=' + ECLIPSE_ORG + ")(" + TYPE_KEY + '='  + MANUAL_TYPE + "))";  //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
		detecter.setFilter(filter);

		services = detecter.getServices();
		expectedSize = 0;
		actualSize = services.size();
		Assert.assertEquals(expectedSize, actualSize);

		registration3.unregister();
		registration2.unregister();
		registration1.unregister();
		detecter.release();
	}
}
