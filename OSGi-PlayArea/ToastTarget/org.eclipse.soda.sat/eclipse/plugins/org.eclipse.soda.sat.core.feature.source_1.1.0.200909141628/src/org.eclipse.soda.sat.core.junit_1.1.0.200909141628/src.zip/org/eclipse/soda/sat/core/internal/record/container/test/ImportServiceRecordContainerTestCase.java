/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.record.container.test;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;
import org.eclipse.soda.sat.core.junit.internal.AbstractServiceTestCase;
import org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainer;
import org.eclipse.soda.sat.core.record.container.interfaces.IImportServiceRecordContainerOwner;
import org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordAction;
import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IServiceRecord;
import org.eclipse.soda.sat.junit.util.ValueHolder;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Filter;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceRegistration;

public class ImportServiceRecordContainerTestCase extends AbstractServiceTestCase {
	private static class ImportServiceRecordContainerOwnerAdapter extends Object implements IImportServiceRecordContainerOwner {
		public void acquired(IImportServiceRecordContainer container) {
			//...
		}

		public void released(IImportServiceRecordContainer container) {
			//...
		}
	}

	private interface TestService1 {
		public static final String SERVICE_NAME = TestService1.class.getName();
	}

	private interface TestService2 {
		public static final String SERVICE_NAME = TestService2.class.getName();
	}

	private interface TestService3 {
		public static final String SERVICE_NAME = TestService3.class.getName();
	}

	private static class TestServiceImplementation extends Object implements TestService1, TestService2 { // $codepro.audit.disable com.instantiations.assist.eclipse.analysis.emptyClass
		//...
	}

	private static final String COMPANY_KEY = "company"; //$NON-NLS-1$
	private static final String IBM_ORG = "IBM"; //$NON-NLS-1$
	private static final String ECLIPSE_ORG = "Eclipse"; //$NON-NLS-1$
	private static final String OTI_ORG = "OTI"; //$NON-NLS-1$

	public static Test suite() {
		return new TestSuite(ImportServiceRecordContainerTestCase.class);
	}

	private IImportServiceRecordContainer container;

	public ImportServiceRecordContainerTestCase(String name) {
		super(name);
	}

	private IImportServiceRecordContainerOwner createNoOpImportServiceRecordContainerOwner() {
		return new ImportServiceRecordContainerOwnerAdapter();
	}

	protected void setUp() throws Exception {
		super.setUp();
		container = AbstractSatTestCase.FACTORY.createImportServiceRecordContainer();
	}

	protected void tearDown() throws Exception {
		container = null;
		super.tearDown();
	}

	public void test_acquire() {
		BundleContext context = getBundleContext();
		ServiceRegistration registration1;
		ServiceRegistration registration2;
		ServiceRegistration registration3;
		Object expected;
		Object actual;

		TestService1 service1 = new TestServiceImplementation();
		registration1 = context.registerService(TestService1.SERVICE_NAME, service1, null);

		TestService2 service2 = new TestServiceImplementation();
		registration2 = context.registerService(TestService2.SERVICE_NAME, service2, null);

		IImportServiceRecord record1 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);
		container.add(record1);

		IImportServiceRecord record2 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService2.SERVICE_NAME, null);
		container.add(record2);

		final ValueHolder holder = ValueHolder.nullValue();

		IImportServiceRecordContainerOwner owner = new ImportServiceRecordContainerOwnerAdapter(){
			public void acquired(IImportServiceRecordContainer container) {
				holder.setValue(container);
			}
		};

		container.setOwner(owner);
		container.acquire();

		expected = container;
		actual = holder.getValue();
		Assert.assertSame(expected, actual);

		holder.setNull();

		registration1.unregister();

		expected = null;
		actual = holder.getValue();
		Assert.assertSame(expected, actual);

		registration1 = context.registerService(TestService1.SERVICE_NAME, service1, null);

		expected = container;
		actual = holder.getValue();
		Assert.assertSame(expected, actual);

		holder.setNull();

		registration3 = context.registerService(TestService1.SERVICE_NAME, service1, null);

		expected = null;
		actual = holder.getValue();
		Assert.assertSame(expected, actual);

		registration1.unregister();

		expected = container;
		actual = holder.getValue();
		Assert.assertSame(expected, actual);

		registration3.unregister();

		container.release();

		container.setOwner(null);
		container.acquire();  // TODO Verify this test

		registration2.unregister();
	}

	public void test_add() {
		BundleContext context = getBundleContext();
		IImportServiceRecord record1;
		IImportServiceRecord record2;
		IImportServiceRecord record3;
		boolean acquired;
		boolean released;
		boolean added;
		boolean removed;
		int expectedSize;
		int actualSize;

		// Register a TestService1 service.
		TestService1 service1 = new TestServiceImplementation();
		ServiceRegistration registration1 = context.registerService(TestService1.SERVICE_NAME, service1, null);

		// Register a TestService2 service.
		TestService2 service2 = new TestServiceImplementation();
		ServiceRegistration registration2 = context.registerService(TestService2.SERVICE_NAME, service2, null);

		// Add a record.
		record1 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);
		added = container.add(record1);
		Assert.assertTrue(added);

		// Check the size is 1.
		expectedSize = 1;
		actualSize = container.size();
		Assert.assertEquals(expectedSize, actualSize);

		// Check that a record cannot be added twice.
		added = container.add(record1);
		Assert.assertFalse(added);

		// Check the size is 1.
		expectedSize = 1;
		actualSize = container.size();
		Assert.assertEquals(expectedSize, actualSize);

		final ValueHolder acquiredHolder = ValueHolder.falseValue();
		final ValueHolder releasedHolder = ValueHolder.falseValue();

		// Acquire the import service records.
		IImportServiceRecordContainerOwner owner = new IImportServiceRecordContainerOwner() {
			public void acquired(IImportServiceRecordContainer container) {
				acquiredHolder.setTrue();
				releasedHolder.setFalse();
			}

			public void released(IImportServiceRecordContainer container) {
				acquiredHolder.setFalse();
				releasedHolder.setTrue();
			}
		};

		container.setOwner(owner);
		container.acquire();

		record2 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService2.SERVICE_NAME, null);
		container.add(record2);

		// Check remove...

		acquired = acquiredHolder.isTrue();
		Assert.assertTrue(acquired);

		released = releasedHolder.isFalse();
		Assert.assertTrue(released);

		acquired = record2.isAcquired();
		Assert.assertTrue(acquired);

		removed = container.remove(record2);  // Remove
		Assert.assertTrue(removed);

		acquired = acquiredHolder.isTrue();
		Assert.assertTrue(acquired);

		released = releasedHolder.isFalse();
		Assert.assertTrue(released);

		acquired = record2.isAcquired();
		Assert.assertFalse(acquired);

		// Check add...

		container.add(record2);  // Add

		acquired = acquiredHolder.isTrue();
		Assert.assertTrue(acquired);

		released = releasedHolder.isFalse();
		Assert.assertTrue(released);

		acquired = record2.isAcquired();
		Assert.assertTrue(acquired);

		// Check the size is 2.
		expectedSize = 2;
		actualSize = container.size();
		Assert.assertEquals(expectedSize, actualSize);

		// Release the import service records.
		container.release();

		// Add a record.
		record3 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService3.SERVICE_NAME, null);
		added = container.add(record3);
		Assert.assertTrue(added);

		// Check the size is 3.
		expectedSize = 3;
		actualSize = container.size();
		Assert.assertEquals(expectedSize, actualSize);

		// Clean up.
		registration1.unregister();
		registration2.unregister();
	}

	public void test_contains() {
		BundleContext context = getBundleContext();
		boolean exists;

		IImportServiceRecord record1 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);
		container.add(record1);

		IImportServiceRecord record2 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService2.SERVICE_NAME, null);
		container.add(record2);

		IImportServiceRecord record3 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService3.SERVICE_NAME, null);
		container.add(record3);

		exists = container.contains(record1);
		Assert.assertTrue(exists);

		exists = container.contains(record2);
		Assert.assertTrue(exists);

		exists = container.contains(record3);
		Assert.assertTrue(exists);

		IImportServiceRecord record4 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService3.SERVICE_NAME, null);
		exists = container.contains(record4);
		Assert.assertFalse(exists);

		container.remove(record2);
		exists = container.contains(record2);
		Assert.assertFalse(exists);
	}

	public void test_doForEach() {
		BundleContext context = getBundleContext();
		IImportServiceRecord record;
		int count = 3;

		for (int i = 0; i < count; i++) {
			// Add a record.
			record = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);
			container.add(record);
		}

		IServiceRecordAction action = new IServiceRecordAction(){
			public boolean execute(IServiceRecord record, Object parameter) {
				List list = (List) parameter;
				list.add(record);
				return true;
			}
		};

		List list = new ArrayList(3);
		container.doForEach(action, list);

		int expectedSize = count;
		int actualSize = list.size();
		Assert.assertEquals(expectedSize, actualSize);
	}

	public void test_empty() {
		BundleContext context = getBundleContext();
		IImportServiceRecord record;
		int count = 3;
		boolean empty;

		for (int i = 0; i < count; i++) {
			// Add a record.
			record = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);
			container.add(record);
		}

		container.empty();

		empty = container.isEmpty();
		Assert.assertTrue(empty);
	}

	public void test_get() throws InvalidSyntaxException {
		BundleContext context = getBundleContext();
		IImportServiceRecord record1;
		IImportServiceRecord record2;
		IImportServiceRecord record3;
		Object expected;
		Object actual;

		// Add a record.
		record1 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);
		container.add(record1);

		// Add a record.
		record2 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService2.SERVICE_NAME, null);
		container.add(record2);

		expected = record1;
		actual = container.get(TestService1.SERVICE_NAME);
		Assert.assertSame(expected, actual);

		expected = record2;
		actual = container.get(TestService2.SERVICE_NAME);
		Assert.assertSame(expected, actual);

		Object service = new TestServiceImplementation();
		ServiceRegistration registration = context.registerService(TestService1.SERVICE_NAME, service, null);

		// Add a record.
		Filter filter = context.createFilter('(' + ImportServiceRecordContainerTestCase.COMPANY_KEY + '=' + ImportServiceRecordContainerTestCase.IBM_ORG + ')');
		record3 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, filter);
		container.add(record3);

		IImportServiceRecordContainerOwner owner = createNoOpImportServiceRecordContainerOwner();
		container.setOwner(owner);
		container.acquire();

		expected = record1;
		actual = container.get(TestService1.SERVICE_NAME, service);
		Assert.assertSame(expected, actual);

		try {
			container.get(TestService1.SERVICE_NAME, null);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}

		container.release();
		registration.unregister();
	}

	public void test_getAll() {
		BundleContext context = getBundleContext();
		IImportServiceRecord record;
		Object[] objects;
		int count = 3;
		int expectedLength;
		int actualLength;

		for (int i = 0; i < count; i++) {
			// Add a record.
			record = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);
			container.add(record);

			// Add a record.
			record = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService2.SERVICE_NAME, null);
			container.add(record);
		}

		// Add a record.
		record = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);
		container.add(record);

		objects = container.getAll();

		expectedLength = count * 2 + 1;
		actualLength = objects.length;
		Assert.assertEquals(expectedLength, actualLength);

		objects = container.getAll(TestService1.SERVICE_NAME);

		expectedLength = count  + 1;
		actualLength = objects.length;
		Assert.assertEquals(expectedLength, actualLength);

		objects = container.getAll(TestService2.SERVICE_NAME);

		expectedLength = count;
		actualLength = objects.length;
		Assert.assertEquals(expectedLength, actualLength);

		objects = container.getAll(TestService3.SERVICE_NAME);

		expectedLength = 0;
		actualLength = objects.length;
		Assert.assertEquals(expectedLength, actualLength);

		container.empty();

		objects = container.getAll(TestService1.SERVICE_NAME);

		expectedLength = 0;
		actualLength = objects.length;
		Assert.assertEquals(expectedLength, actualLength);
	}

	public void test_getWithFilter() throws InvalidSyntaxException {
		BundleContext context = getBundleContext();
		IImportServiceRecord record1;
		IImportServiceRecord record2;
		Object expected;
		Object actual;

		Filter filter1 = context.createFilter('(' + ImportServiceRecordContainerTestCase.COMPANY_KEY + '=' + ImportServiceRecordContainerTestCase.IBM_ORG + ')');
		Filter filter2 = context.createFilter('(' + ImportServiceRecordContainerTestCase.COMPANY_KEY + '=' + ImportServiceRecordContainerTestCase.ECLIPSE_ORG + ')');
		Filter filter3 = context.createFilter('(' + ImportServiceRecordContainerTestCase.COMPANY_KEY + '=' + ImportServiceRecordContainerTestCase.OTI_ORG + ')');

		// Add a record.
		record1 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, filter1);
		container.add(record1);

		// Add a record.
		record2 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, filter2);
		container.add(record2);

		expected = record1;
		actual = container.getWithFilter(TestService1.SERVICE_NAME, filter1);
		Assert.assertSame(expected, actual);

		expected = record2;
		actual = container.getWithFilter(TestService1.SERVICE_NAME, filter2);
		Assert.assertSame(expected, actual);

		expected = null;
		actual = container.getWithFilter(TestService1.SERVICE_NAME, filter3);
		Assert.assertSame(expected, actual);
	}

	public void test_isAcquired() {
		BundleContext context = getBundleContext();
		boolean added;
		Object expected;
		Object actual;

		final ValueHolder holder = ValueHolder.nullValue();

		IImportServiceRecordContainerOwner owner = new ImportServiceRecordContainerOwnerAdapter(){
			public void acquired(IImportServiceRecordContainer container) {
				holder.setValue(container);
			}
		};

		container.setOwner(owner);
		container.acquire();

		expected = container;
		actual = holder.getValue();
		Assert.assertSame(expected, actual);
		holder.setNull();

		container.release();

		IImportServiceRecord record1 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);
		added = container.add(record1);
		Assert.assertTrue(added);

		IImportServiceRecord record2 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService2.SERVICE_NAME, null);
		added = container.add(record2);
		Assert.assertTrue(added);

		container.acquire();

		expected = null;
		actual = holder.getValue();
		Assert.assertSame(expected, actual);

		ServiceRegistration registration1;
		ServiceRegistration registration2;

		TestService1 service1 = new TestServiceImplementation();
		registration1 = context.registerService(TestService1.SERVICE_NAME, service1, null);

		TestService2 service2 = new TestServiceImplementation();
		registration2 = context.registerService(TestService2.SERVICE_NAME, service2, null);

		expected = container;
		actual = holder.getValue();
		Assert.assertSame(expected, actual);
		holder.setNull();

		registration2.unregister();

		expected = null;
		actual = holder.getValue();
		Assert.assertSame(expected, actual);

		registration1.unregister();

		container.release();
	}

	public void test_isEmpty() {
		BundleContext context = getBundleContext();
		IImportServiceRecord record;
		int count = 3;
		boolean empty;

		empty = container.isEmpty();
		Assert.assertTrue(empty);

		for (int i = 0; i < count; i++) {
			// Add a record.
			record = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);
			container.add(record);
		}

		empty = container.isEmpty();
		Assert.assertFalse(empty);
	}

	public void test_release() {
		BundleContext context = getBundleContext();
		ServiceRegistration registration1;
		ServiceRegistration registration2;
		Object expected;
		Object actual;

		TestService1 service1 = new TestServiceImplementation();
		registration1 = context.registerService(TestService1.SERVICE_NAME, service1, null);

		TestService2 service2 = new TestServiceImplementation();
		registration2 = context.registerService(TestService2.SERVICE_NAME, service2, null);

		IImportServiceRecord record1 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);
		container.add(record1);

		IImportServiceRecord record2 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService2.SERVICE_NAME, null);
		container.add(record2);

		final ValueHolder holder = ValueHolder.nullValue();

		IImportServiceRecordContainerOwner owner = new ImportServiceRecordContainerOwnerAdapter(){
			public void released(IImportServiceRecordContainer container) {
				holder.setValue(container);
			}
		};

		container.setOwner(owner);
		container.acquire();
		registration1.unregister();

		expected = container;
		actual = holder.getValue();
		Assert.assertSame(expected, actual);
		holder.setNull();

		container.release();

		expected = null;
		actual = holder.getValue();
		Assert.assertSame(expected, actual);

		container.acquire();
		registration1 = context.registerService(TestService1.SERVICE_NAME, service1, null);

		container.release();

		expected = container;
		actual = holder.getValue();
		Assert.assertSame(expected, actual);

		registration2.unregister();
		registration1.unregister();
	}

	public void test_remove() {
		final BundleContext context = getBundleContext();
		boolean removed;
		int expectedSize;
		int actualSize;

		final IImportServiceRecord record1 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);
		container.add(record1);

		final IImportServiceRecord record2 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService2.SERVICE_NAME, null);
		container.add(record2);

		final IImportServiceRecord record3 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService3.SERVICE_NAME, null);
		container.add(record3);

		expectedSize = 3;
		actualSize = container.size();
		Assert.assertEquals(expectedSize, actualSize);

		Thread removerThread = new Thread("remover-thread") {
			private void delay() {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			public void run() {
				boolean removed;
				int expectedSize;
				int actualSize;

				delay();
				IImportServiceRecord record4 = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService3.SERVICE_NAME, null);
				removed = container.remove(record4);
				Assert.assertFalse(removed);

				delay();
				expectedSize = 3;
				actualSize = container.size();
				Assert.assertEquals(expectedSize, actualSize);

				delay();
				removed = container.remove(record1);
				Assert.assertTrue(removed);

				delay();
				expectedSize = 2;
				actualSize = container.size();
				Assert.assertEquals(expectedSize, actualSize);

				delay();
				removed = container.remove(record2);
				Assert.assertTrue(removed);

				delay();
				expectedSize = 1;
				actualSize = container.size();
				Assert.assertEquals(expectedSize, actualSize);

				delay();
				removed = container.remove(record3);
				Assert.assertTrue(removed);
			}
		};

		removerThread.start();

		try {
			removerThread.join();
			expectedSize = 0;
			actualSize = container.size();
			Assert.assertEquals(expectedSize, actualSize);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void test_removeAll() {
		BundleContext context = getBundleContext();
		IImportServiceRecord record;
		boolean added;
		int expectedSize;
		int actualSize;
		int count = 3;

		for (int i = 0; i < count; i++) {
			// Create a record.
			record = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);

			// Add the record.
			added = container.add(record);
			Assert.assertTrue(added);
		}

		// Check the size of the container.
		expectedSize = count;
		actualSize = container.size();
		Assert.assertEquals(actualSize, expectedSize);

		container.removeAll(TestService1.SERVICE_NAME);

		// Check the size of the container.
		expectedSize = 0;
		actualSize = container.size();
		Assert.assertEquals(actualSize, expectedSize);

		for (int i = 0; i < count; i++) {
			// Create a record.
			record = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);

			// Add the record.
			added = container.add(record);
			Assert.assertTrue(added);

			record = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService2.SERVICE_NAME, null);

			// Add the record.
			added = container.add(record);
			Assert.assertTrue(added);
		}

		// Check the size of the container.
		expectedSize = count * 2;
		actualSize = container.size();
		Assert.assertEquals(actualSize, expectedSize);

		container.removeAll(TestService1.SERVICE_NAME);

		// Check the size of the container.
		expectedSize = count;
		actualSize = container.size();
		Assert.assertEquals(actualSize, expectedSize);

		container.removeAll(TestService3.SERVICE_NAME);

		// Check the size of the container.
		expectedSize = count;
		actualSize = container.size();
		Assert.assertEquals(actualSize, expectedSize);

		container.removeAll(TestService2.SERVICE_NAME);

		// Check the size of the container.
		expectedSize = 0;
		actualSize = container.size();
		Assert.assertEquals(actualSize, expectedSize);
	}

	public void test_size() {
		BundleContext context = getBundleContext();
		IImportServiceRecord record;
		int count = 3;
		int expectedSize;
		int actualSize;

		expectedSize = 0;
		actualSize = container.size();
		Assert.assertEquals(expectedSize, actualSize);

		for (int i = 0; i < count; i++) {
			// Add a record.
			record = AbstractSatTestCase.FACTORY.createImportServiceRecord(context, TestService1.SERVICE_NAME, null);
			container.add(record);
		}

		expectedSize = count;
		actualSize = container.size();
		Assert.assertEquals(expectedSize, actualSize);
	}
}
