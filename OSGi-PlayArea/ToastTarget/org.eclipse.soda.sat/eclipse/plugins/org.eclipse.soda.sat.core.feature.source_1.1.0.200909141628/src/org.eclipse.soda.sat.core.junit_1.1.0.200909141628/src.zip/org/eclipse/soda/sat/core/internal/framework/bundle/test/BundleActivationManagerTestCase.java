/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle.test;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.framework.BundleActivationManagerOwnerAdapter;
import org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager;
import org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManagerOwner;
import org.eclipse.soda.sat.core.framework.interfaces.ILineReader;
import org.eclipse.soda.sat.core.framework.interfaces.ILineWriter;
import org.eclipse.soda.sat.core.junit.internal.AbstractServiceTestCase;
import org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord;
import org.eclipse.soda.sat.core.service.BundleDependencyService;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.junit.util.ValueHolder;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Filter;
import org.osgi.framework.ServiceReference;
import org.osgi.service.packageadmin.PackageAdmin;

public class BundleActivationManagerTestCase extends AbstractServiceTestCase {
	private interface TestService1 {
		public static final String SERVICE_NAME = TestService1.class.getName();
	}

	private static class TestService1Implementation extends Object implements TestService1 {
		//...
	}

	private interface TestService2 {
		public static final String SERVICE_NAME = TestService2.class.getName();
	}

	private static class TestService2Implementation extends Object implements TestService2 {
		//...
	}

	public static Test suite() {
		return new TestSuite(BundleActivationManagerTestCase.class);
	}

	private IBundleActivationManager bundleActivationManager;

	public BundleActivationManagerTestCase(String name) {
		super(name);
	}

	private void createBundleActivationManager() {
		FactoryUtility utility = FactoryUtility.getInstance();
		bundleActivationManager = utility.createBundleActivationManager();
	}

	private IBundleActivationManagerOwner createNoOpOwner() {
		return new BundleActivationManagerOwnerAdapter();
	}

	private File createTempFile() throws IOException {
		Bundle bundle = getBundle();
		String prefix = bundle.getSymbolicName();
		BundleContext bundleContext = getBundleContext();
		File directory = bundleContext.getDataFile(null);
		File file = File.createTempFile(prefix, null, directory);
		return file;
	}

	private void deleteFile(File file) {
		if (file == null) return;  // Early return.
		file.delete();
	}

	private void destroyBundleActivationManager() {
		bundleActivationManager = null;
	}

	private String readLine(File file) throws IOException {
		InputStream stream = null;
		ILineReader reader;
		String actualLine = null;

		try {
			stream = new FileInputStream(file);
			FactoryUtility utility = FactoryUtility.getInstance();
			reader = utility.createLineReader(stream);

			try {
				actualLine = reader.readLine();
			} finally {
				reader.close();
			}
		} finally {
			if (stream != null) {
				stream.close();
			}
		}

		return actualLine;
	}

	protected void setUp() throws Exception {
		super.setUp();
		createBundleActivationManager();
	}

	private void startBundleActivationManager() throws Exception {
		IBundleActivationManagerOwner owner = createNoOpOwner();
		startBundleActivationManager(owner);
	}

	private void startBundleActivationManager(IBundleActivationManagerOwner owner) throws Exception {
		BundleContext bundleContext = getBundleContext();
		bundleActivationManager.start(bundleContext, owner);
	}

	private void stopBundleActivationManager() throws Exception {
		bundleActivationManager.stop();
	}
	protected void tearDown() throws Exception {
		super.tearDown();
		destroyBundleActivationManager();
	}

	public void test_addExportedService() throws Exception {
		Object actualService;
		String cnKey = "cn";  //$NON-NLS-1$
		String cnValue = "simona";  //$NON-NLS-1$

		try {
			startBundleActivationManager();
			TestService1 expectedService = new TestService1Implementation();
			Dictionary properties = new Hashtable(11);
			properties.put(cnKey, cnValue);
			bundleActivationManager.addExportedService(TestService1.SERVICE_NAME, expectedService, properties);
			actualService = bundleActivationManager.getExportedService(TestService1.SERVICE_NAME);
			Assert.assertSame(expectedService, actualService);

			BundleContext bundleContext = getBundleContext();
			ServiceReference[] references = null;
			ServiceReference reference = null;
			String filter = '(' + cnKey + '=' + cnValue + ')';

			try {
				references = bundleContext.getServiceReferences(TestService1.SERVICE_NAME, filter);
				Assert.assertNotNull(references);
				Assert.assertEquals(1, references.length);
				reference = references [ 0 ];
				actualService = bundleContext.getService(reference);
				Assert.assertSame(expectedService, actualService);
			} finally {
				if (reference != null) {
					bundleContext.ungetService(reference);
				}
			}
		} finally {
			stopBundleActivationManager();
		}
	}

//	public void test_addImportedServiceRecord() throws Exception {
//		final String packageAdminServiceName = PackageAdmin.class.getName();
//
//		IBundleActivationManagerOwner owner = new BundleActivationManagerOwnerAdapter() {
//			public String[] getImportedServiceNames() {
//				return new String[] {
//					packageAdminServiceName,
//					BundleDependencyService.SERVICE_NAME
//				};
//			}
//		};
//
//		FactoryUtility utility = FactoryUtility.getInstance();
//		BundleContext bundleContext = getBundleContext();
//		IExportServiceRecord exportServiceRecord;
//
//		try {
//			TestService1 service = new TestService1Implementation();
//			exportServiceRecord = utility.createExportServiceRecord(bundleContext, TestService1.SERVICE_NAME, service, null);
//			exportServiceRecord.register();
//
//			startBundleActivationManager(owner);
//			IImportServiceRecord importServiceRecord = utility.createImportServiceRecord(bundleContext, TestService1.SERVICE_NAME, null);
//			bundleActivationManager.addImportServiceRecord(importServiceRecord);
//
//		} finally {
//			stopBundleActivationManager();
//			exportServiceRecord.unregister();
//		}
//	}

	public void test_addExportedServiceRecord() throws Exception {
		Object actualService;
		String cnKey = "cn";  //$NON-NLS-1$
		String cnValue = "simona";  //$NON-NLS-1$

		try {
			startBundleActivationManager();
			TestService1 expectedService = new TestService1Implementation();
			Dictionary properties = new Hashtable(11);
			properties.put(cnKey, cnValue);

			BundleContext bundleContext = getBundleContext();
			FactoryUtility utility = FactoryUtility.getInstance();
			IExportServiceRecord record = utility.createExportServiceRecord(bundleContext, TestService1.SERVICE_NAME, expectedService, properties);
			bundleActivationManager.addExportServiceRecord(record);

			actualService = bundleActivationManager.getExportedService(TestService1.SERVICE_NAME);
			Assert.assertSame(expectedService, actualService);

			ServiceReference[] references = null;
			ServiceReference reference = null;
			String filter = '(' + cnKey + '=' + cnValue + ')';

			try {
				references = bundleContext.getServiceReferences(TestService1.SERVICE_NAME, filter);
				Assert.assertNotNull(references);
				Assert.assertEquals(1, references.length);
				reference = references [ 0 ];
				actualService = bundleContext.getService(reference);
				Assert.assertSame(expectedService, actualService);
			} finally {
				if (reference != null) {
					bundleContext.ungetService(reference);
				}
			}
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_addImportedServiceFilter() throws Exception {
		try {
			startBundleActivationManager();

			bundleActivationManager.addImportedServiceFilter(BundleDependencyService.SERVICE_NAME, "(service.vendor=Eclipse.org)");  //$NON-NLS-1$
			String expectedFilterString = "(service.vendor=OTI)";  //$NON-NLS-1$
			bundleActivationManager.addImportedServiceFilter(BundleDependencyService.SERVICE_NAME, expectedFilterString);

			Filter filter = bundleActivationManager.getImportedServiceFilter(BundleDependencyService.SERVICE_NAME);
			String actualFilterString = filter.toString();
			Assert.assertEquals(expectedFilterString, actualFilterString);

			try {
				bundleActivationManager.addImportedServiceFilter(BundleDependencyService.SERVICE_NAME, null);
				Assert.fail();
			} catch (IllegalArgumentException exception) {
				Assert.assertTrue(true);
			}

			try {
				bundleActivationManager.addImportedServiceFilter(null, expectedFilterString);
				Assert.fail();
			} catch (IllegalArgumentException exception) {
				Assert.assertTrue(true);
			}
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_addOptionalImportedServiceFilter() throws Exception {
		try {
			startBundleActivationManager();

			bundleActivationManager.addOptionalImportedServiceFilter(BundleDependencyService.SERVICE_NAME, "(service.vendor=Eclipse.org)");  //$NON-NLS-1$
			String expectedFilterString = "(service.vendor=OTI)";  //$NON-NLS-1$
			bundleActivationManager.addOptionalImportedServiceFilter(BundleDependencyService.SERVICE_NAME, expectedFilterString);

			Filter filter = bundleActivationManager.getOptionalImportedServiceFilter(BundleDependencyService.SERVICE_NAME);
			String actualFilterString = filter.toString();
			Assert.assertEquals(expectedFilterString, actualFilterString);

			try {
				bundleActivationManager.addOptionalImportedServiceFilter(BundleDependencyService.SERVICE_NAME, null);
				Assert.fail();
			} catch (IllegalArgumentException exception) {
				Assert.assertTrue(true);
			}

			try {
				bundleActivationManager.addOptionalImportedServiceFilter(null, expectedFilterString);
				Assert.fail();
			} catch (IllegalArgumentException exception) {
				Assert.assertTrue(true);
			}
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_getBundle() throws Exception {
		Bundle expectedBundle = getBundle();

		try {
			startBundleActivationManager();
			Bundle actualBundle = bundleActivationManager.getBundle();
			Assert.assertSame(expectedBundle, actualBundle);
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_getBundleContext() throws Exception {
		BundleContext expectedBundleContext = getBundleContext();

		try {
			startBundleActivationManager();
			BundleContext actualBundleContext = bundleActivationManager.getBundleContext();
			Assert.assertSame(expectedBundleContext, actualBundleContext);
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_getBundleSymbolicName() throws Exception {
		Bundle bundle = getBundle();
		String expectedBundleSymbolicName = bundle.getSymbolicName();

		try {
			startBundleActivationManager();
			String actualBundleSymbolicName = bundleActivationManager.getBundleSymbolicName();
			Assert.assertEquals(expectedBundleSymbolicName, actualBundleSymbolicName);
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_getDataDirectory() throws Exception {
		BundleContext bundleContext = getBundleContext();
		File expectedDataDirectory = bundleContext.getDataFile(null);


		try {
			startBundleActivationManager();
			File actualDataDirectory = bundleActivationManager.getDataDirectory();
			Assert.assertEquals(expectedDataDirectory, actualDataDirectory);
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_getDataFile() throws Exception {
		try {
			startBundleActivationManager();
			File actualFile = null;
			String filename = null;

			try {
				// Create data file.
				File expectedFile = createTempFile();
				Date date = new Date();
				String expectedLine = date.toString();
				writeLine(expectedFile, expectedLine);

				filename = expectedFile.getName();
				actualFile = bundleActivationManager.getDataFile(filename);
				Assert.assertNotNull(actualFile);
				String actualLine = readLine(actualFile);
				Assert.assertEquals(expectedLine, actualLine);
			} finally {
				// Delete data file.
				deleteFile(actualFile);
			}

			Assert.assertNotNull(filename);
			actualFile = bundleActivationManager.getDataFile(filename);
			Assert.assertNotNull(actualFile);

			boolean expectedExists = false;
			boolean actualExists = actualFile.exists();
			Assert.assertEquals(expectedExists, actualExists);

			try {
				bundleActivationManager.getDataFile(null);
				Assert.fail();
			} catch (IllegalArgumentException exception) {
				Assert.assertTrue(true);
			}
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_getExportedService() throws Exception {
		try {
			startBundleActivationManager();

			TestService1 expectedService1 = new TestService1Implementation();
			bundleActivationManager.addExportedService(TestService1.SERVICE_NAME, expectedService1, null);

			TestService2 expectedService2 = new TestService2Implementation();
			bundleActivationManager.addExportedService(TestService2.SERVICE_NAME, expectedService2, null);

			Object actualService1 = bundleActivationManager.getExportedService(TestService1.SERVICE_NAME);
			Assert.assertSame(expectedService1, actualService1);

			Object actualService2 = bundleActivationManager.getExportedService(TestService2.SERVICE_NAME);
			Assert.assertSame(expectedService2, actualService2);

			Object nullService = bundleActivationManager.getExportedService(String.class.getName());
			Assert.assertNull(nullService);

			try {
				bundleActivationManager.getExportedService(null);
				Assert.fail();
			} catch (IllegalArgumentException exception) {
				Assert.assertTrue(true);
			}
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_getExportedServiceNamesFromManifest() {
		Assert.assertTrue(true);  // Deprecated API.
	}

	public void test_getExportedServiceProperties() throws Exception {
		Dictionary expectedServiceProperties;

		String cnKey = "cn";  //$NON-NLS-1$
		String coKey = "co";  //$NON-NLS-1$
		String yrKey = "yr";  //$NON-NLS-1$

		String expectedCnValue;
		String expectedCoValue;
		String expectedYrValue;

		String actualCnValue;
		String actualCoValue;
		String actualYrValue;

		int expectedServicePropertiesSize;
		int actualServicePropertiesSize;

		try {
			startBundleActivationManager();

			TestService1 expectedService1 = new TestService1Implementation();
			expectedServiceProperties = new Hashtable(11);
			expectedCnValue = "simona";  //$NON-NLS-1$
			expectedCoValue = "OTI";  //$NON-NLS-1$
			expectedServiceProperties.put(cnKey, expectedCnValue);
			expectedServiceProperties.put(coKey, expectedCoValue);
			bundleActivationManager.addExportedService(TestService1.SERVICE_NAME, expectedService1, expectedServiceProperties);

			Dictionary actualServiceProperties = bundleActivationManager.getExportedServiceProperties(TestService1.SERVICE_NAME);

			expectedServicePropertiesSize = expectedServiceProperties.size();
			actualServicePropertiesSize = actualServiceProperties.size();
			Assert.assertEquals(expectedServicePropertiesSize, actualServicePropertiesSize);

			actualCnValue = (String) actualServiceProperties.get(cnKey);
			Assert.assertEquals(expectedCnValue, actualCnValue);

			actualCoValue = (String) actualServiceProperties.get(coKey);
			Assert.assertEquals(expectedCoValue, actualCoValue);

			try {
				bundleActivationManager.getExportedServiceProperties(null);
				Assert.fail();
			} catch (IllegalArgumentException exception) {
				Assert.assertTrue(true);
			}

			TestService1 expectedService2 = new TestService1Implementation();
			expectedServiceProperties = new Hashtable(11);
			expectedCnValue = "sarcher";  //$NON-NLS-1$
			expectedCoValue = "IBM";  //$NON-NLS-1$
			expectedYrValue = "2001";  //$NON-NLS-1$
			expectedServiceProperties.put(cnKey, expectedCnValue);
			expectedServiceProperties.put(coKey, expectedCoValue);
			expectedServiceProperties.put(yrKey, expectedYrValue);
			bundleActivationManager.addExportedService(TestService1.SERVICE_NAME, expectedService2, expectedServiceProperties);

			actualServiceProperties = bundleActivationManager.getExportedServiceProperties(TestService1.SERVICE_NAME, expectedService2);

			expectedServicePropertiesSize = expectedServiceProperties.size();
			actualServicePropertiesSize = actualServiceProperties.size();
			Assert.assertEquals(expectedServicePropertiesSize, actualServicePropertiesSize);

			actualCnValue = (String) actualServiceProperties.get(cnKey);
			Assert.assertEquals(expectedCnValue, actualCnValue);

			actualCoValue = (String) actualServiceProperties.get(coKey);
			Assert.assertEquals(expectedCoValue, actualCoValue);

			actualYrValue = (String) actualServiceProperties.get(yrKey);
			Assert.assertEquals(expectedYrValue, actualYrValue);

			try {
				bundleActivationManager.getExportedServiceProperties(null, expectedService2);
				Assert.fail();
			} catch (IllegalArgumentException exception) {
				Assert.assertTrue(true);
			}

			try {
				bundleActivationManager.getExportedServiceProperties(TestService1.SERVICE_NAME, null);
				Assert.fail();
			} catch (IllegalArgumentException exception) {
				Assert.assertTrue(true);
			}
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_getExportedServices() throws Exception {
		try {
			startBundleActivationManager();

			TestService1 expectedService1 = new TestService1Implementation();
			bundleActivationManager.addExportedService(TestService1.SERVICE_NAME, expectedService1, null);

			TestService1 expectedService2 = new TestService1Implementation();
			bundleActivationManager.addExportedService(TestService1.SERVICE_NAME, expectedService2, null);

			Object[] actualServices;

			actualServices = bundleActivationManager.getExportedServices(TestService1.SERVICE_NAME);
			Assert.assertNotNull(actualServices);

			int expectedLength;
			int actualLength;

			expectedLength = 2;
			actualLength = actualServices.length;
			Assert.assertEquals(expectedLength, actualLength);

			Assert.assertTrue(expectedService1 == actualServices [ 0 ] || expectedService1 == actualServices [ 1 ]);
			Assert.assertTrue(expectedService2 == actualServices [ 0 ] || expectedService2 == actualServices [ 1 ]);

			actualServices = bundleActivationManager.getExportedServices(String.class.getName());
			Assert.assertNotNull(actualServices);

			expectedLength = 0;
			actualLength = actualServices.length;
			Assert.assertEquals(expectedLength, actualLength);

			try {
				bundleActivationManager.getExportedServices(null);
				Assert.fail();
			} catch (IllegalArgumentException exception) {
				Assert.assertTrue(true);
			}

			TestService2 expectedService3 = new TestService2Implementation();
			bundleActivationManager.addExportedService(TestService2.SERVICE_NAME, expectedService3, null);

			int expectedSize;
			int actualSize;

			Map map = bundleActivationManager.getExportedServices();
			expectedSize = 2;
			actualSize = map.size();
			Assert.assertEquals(expectedSize, actualSize);

			List services;

			services = (List) map.get(TestService1.SERVICE_NAME);
			expectedSize = 2;
			actualSize = services.size();
			Assert.assertEquals(expectedSize, actualSize);
			Assert.assertTrue(expectedService1 == services.get(0) || expectedService1 == services.get(1));
			Assert.assertTrue(expectedService2 == services.get(0) || expectedService2 == services.get(1));

			services = (List) map.get(TestService2.SERVICE_NAME);
			expectedSize = 1;
			actualSize = services.size();
			Assert.assertEquals(expectedSize, actualSize);
			Assert.assertTrue(expectedService3 == services.get(0));
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_getFilePropertiesInputStream() throws Exception {
		String cnKey = "cn";  //$NON-NLS-1$
		String expectedCnValue = "simona";  //$NON-NLS-1$
		String coKey = "co";  //$NON-NLS-1$
		String expectedCoValue = "OTI";  //$NON-NLS-1$
		String snKey = "sn";  //$NON-NLS-1$
		char equals = '=';
		try {
			startBundleActivationManager();

			String bundleSymbolicName = bundleActivationManager.getBundleSymbolicName();
			String filename = bundleSymbolicName + ".properties";  //$NON-NLS-1$
			File file = new File(filename);

			boolean exists = file.exists();

			if (exists == true) {
				Assert.fail();
			}

			FactoryUtility utility = FactoryUtility.getInstance();
			OutputStream outputStream = null;

			try {
				try {
					outputStream = new FileOutputStream(file);
					ILineWriter writer = utility.createLineWriter(outputStream);

					try {
						writer.writeLine(cnKey + equals + expectedCnValue);
						writer.writeLine(coKey + equals + expectedCoValue);
					} finally {
						if (writer != null) {
							writer.close();
						}
					}
				} finally {
					if (outputStream != null) {
						outputStream.close();
					}
				}

				InputStream inputStream = null;

				try {
					inputStream = bundleActivationManager.getFilePropertiesInputStream();
					Assert.assertNotNull(inputStream);

					Properties properties = new Properties();
					properties.load(inputStream);

					String actualCnValue = (String) properties.get(cnKey);
					Assert.assertEquals(expectedCnValue, actualCnValue);

					String actualCoValue = (String) properties.get(coKey);
					Assert.assertEquals(expectedCoValue, actualCoValue);

					String actualSnValue = (String) properties.get(snKey);
					Assert.assertNull(actualSnValue);
				} finally {
					if (inputStream != null) {
						inputStream.close();
					}
				}
			} finally {
				boolean deleted = file.delete();
				Assert.assertTrue(deleted);
			}

			try {
				bundleActivationManager.getFilePropertiesInputStream(null);
				Assert.fail();
			} catch (IllegalArgumentException exception) {
				Assert.assertTrue(true);
			}
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_getImportedService() throws Exception {
		final String packageAdminServiceName = PackageAdmin.class.getName();

		IBundleActivationManagerOwner owner = new BundleActivationManagerOwnerAdapter() {
			public String[] getImportedServiceNames() {
				return new String[] {
					packageAdminServiceName,
					BundleDependencyService.SERVICE_NAME
				};
			}
		};

		try {
			startBundleActivationManager(owner);
			Object service;
			boolean state;

			service = bundleActivationManager.getImportedService(packageAdminServiceName);
			Assert.assertNotNull(service);

			state = service instanceof PackageAdmin;
			Assert.assertTrue(state);

			service = bundleActivationManager.getImportedService(BundleDependencyService.SERVICE_NAME);
			Assert.assertNotNull(service);

			state = service instanceof BundleDependencyService;
			Assert.assertTrue(state);

			service = bundleActivationManager.getImportedService(String.class.getName());
			Assert.assertNull(service);

			try {
				service = bundleActivationManager.getImportedService(null);
				Assert.fail();
			} catch (IllegalArgumentException exception) {
				Assert.assertTrue(true);
			}
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_getImportedServiceFilter() throws Exception {
		final String packageAdminServiceName = PackageAdmin.class.getName();

		IBundleActivationManagerOwner owner = new BundleActivationManagerOwnerAdapter() {
			public String[] getImportedServiceNames() {
				return new String[] {
					packageAdminServiceName,
					BundleDependencyService.SERVICE_NAME
				};
			}
		};

		try {
			startBundleActivationManager(owner);
			String expectedFilterString = "(service.vendor=Eclipse.org)";  //$NON-NLS-1$
			bundleActivationManager.addImportedServiceFilter(BundleDependencyService.SERVICE_NAME, expectedFilterString);

			Filter filter;

			filter = bundleActivationManager.getImportedServiceFilter(BundleDependencyService.SERVICE_NAME);
			Assert.assertNotNull(filter);

			String actualFilterString = filter.toString();
			Assert.assertEquals(expectedFilterString, actualFilterString);

			filter = bundleActivationManager.getImportedServiceFilter(packageAdminServiceName);
			Assert.assertNull(filter);
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_getImportedServiceNamesFromManifest() {
		Assert.assertTrue(true);  // Deprecated API.
	}

	public void test_getImportedServices() throws Exception {
		final String packageAdminServiceName = PackageAdmin.class.getName();

		IBundleActivationManagerOwner owner = new BundleActivationManagerOwnerAdapter() {
			public String[] getImportedServiceNames() {
				return new String[] {
					packageAdminServiceName,
					BundleDependencyService.SERVICE_NAME
				};
			}
		};

		try {
			startBundleActivationManager(owner);
			Object expectedService;
			Object actualService;

			Map map = bundleActivationManager.getImportedServices();

			int expectedSize = 2;
			int actualSize = map.size();
			Assert.assertEquals(expectedSize, actualSize);

			expectedService = bundleActivationManager.getImportedService(packageAdminServiceName);
			actualService = map.get(packageAdminServiceName);
			Assert.assertSame(expectedService, actualService);

			expectedService = bundleActivationManager.getImportedService(BundleDependencyService.SERVICE_NAME);
			actualService = map.get(BundleDependencyService.SERVICE_NAME);
			Assert.assertSame(expectedService, actualService);
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_getOptionalImportedService() throws Exception {
		final String packageAdminServiceName = PackageAdmin.class.getName();

		IBundleActivationManagerOwner owner = new BundleActivationManagerOwnerAdapter() {
			public String[] getOptionalImportedServiceNames() {
				return new String[] {
					packageAdminServiceName,
					BundleDependencyService.SERVICE_NAME
				};
			}
		};

		try {
			startBundleActivationManager(owner);
			Object service;
			boolean state;

			service = bundleActivationManager.getOptionalImportedService(packageAdminServiceName);
			state = service instanceof PackageAdmin;
			Assert.assertTrue(state);

			service = bundleActivationManager.getOptionalImportedService(BundleDependencyService.SERVICE_NAME);
			state = service instanceof BundleDependencyService;
			Assert.assertTrue(state);

			service = bundleActivationManager.getOptionalImportedService(String.class.getName());
			Assert.assertNull(service);

			try {
				service = bundleActivationManager.getOptionalImportedService(null);
				Assert.fail();
			} catch (IllegalArgumentException exception) {
				Assert.assertTrue(true);
			}
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_getOptionalImportedServices() throws Exception {
		final String packageAdminServiceName = PackageAdmin.class.getName();

		IBundleActivationManagerOwner owner = new BundleActivationManagerOwnerAdapter() {
			public String[] getOptionalImportedServiceNames() {
				return new String[] {
					packageAdminServiceName,
					BundleDependencyService.SERVICE_NAME
				};
			}
		};

		try {
			startBundleActivationManager(owner);
			Object expectedService;
			Object actualService;

			Map map = bundleActivationManager.getOptionalImportedServices();

			int size = map.size();
			Assert.assertEquals(2, size);

			expectedService = bundleActivationManager.getOptionalImportedService(packageAdminServiceName);
			actualService = map.get(packageAdminServiceName);
			Assert.assertSame(expectedService, actualService);

			expectedService = bundleActivationManager.getOptionalImportedService(BundleDependencyService.SERVICE_NAME);
			actualService = map.get(BundleDependencyService.SERVICE_NAME);
			Assert.assertSame(expectedService, actualService);
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_getProperties() throws Exception {
		String cnKey = "cn";  //$NON-NLS-1$
		String expectedCnValue = "simona";  //$NON-NLS-1$
		String coKey = "co";  //$NON-NLS-1$
		String expectedCoValue = "OTI";  //$NON-NLS-1$
		String snKey = "sn";  //$NON-NLS-1$
		char equals = '=';
		char newLine = '\n';

		StringBuffer buffer = new StringBuffer(20);
		buffer.append(cnKey);
		buffer.append(equals);
		buffer.append(expectedCnValue);
		buffer.append(newLine);
		buffer.append(coKey);
		buffer.append(equals);
		buffer.append(expectedCoValue);
		buffer.append(newLine);

		final String value = buffer.toString();

		IBundleActivationManagerOwner owner = new BundleActivationManagerOwnerAdapter() {
			public InputStream getPropertiesInputStream() throws IOException {
				byte[] bytes = value.getBytes();
				InputStream stream = new ByteArrayInputStream(bytes);
				return stream;
			}
		};

		try {
			startBundleActivationManager(owner);
			Properties properties = bundleActivationManager.getProperties();
			Assert.assertNotNull(properties);

			String actualCnValue = (String) properties.get(cnKey);
			Assert.assertEquals(expectedCnValue, actualCnValue);

			String actualCoValue = (String) properties.get(coKey);
			Assert.assertEquals(expectedCoValue, actualCoValue);

			String actualSnValue = (String) properties.get(snKey);
			Assert.assertNull(actualSnValue);

			Properties properties2 = bundleActivationManager.getProperties();
			Assert.assertSame(properties, properties2);
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_getProperty() throws Exception {
		String cnKey = "cn";  //$NON-NLS-1$
		String expectedCnValue = "simona";  //$NON-NLS-1$
		String coKey = "co";  //$NON-NLS-1$
		String expectedCoValue = "OTI";  //$NON-NLS-1$
		String snKey = "sn";  //$NON-NLS-1$
		char equals = '=';
		char newLine = '\n';

		StringBuffer buffer = new StringBuffer(20);
		buffer.append(cnKey);
		buffer.append(equals);
		buffer.append(expectedCnValue);
		buffer.append(newLine);
		buffer.append(coKey);
		buffer.append(equals);
		buffer.append(expectedCoValue);
		buffer.append(newLine);

		final String value = buffer.toString();

		IBundleActivationManagerOwner owner = new BundleActivationManagerOwnerAdapter() {
			public InputStream getPropertiesInputStream() throws IOException {
				byte[] bytes = value.getBytes();
				InputStream stream = new ByteArrayInputStream(bytes);
				return stream;
			}
		};

		try {
			startBundleActivationManager(owner);

			String actualCnValue = bundleActivationManager.getProperty(cnKey, null);
			Assert.assertEquals(expectedCnValue, actualCnValue);

			String actualCoValue = bundleActivationManager.getProperty(coKey, null);
			Assert.assertEquals(expectedCoValue, actualCoValue);

			String defaultSnValue = "Smith";  //$NON-NLS-1$
			String actualSnValue = bundleActivationManager.getProperty(snKey, defaultSnValue);
			Assert.assertEquals(defaultSnValue, actualSnValue);

			try {
				bundleActivationManager.getProperty(null, null);
				Assert.fail();
			} catch (IllegalArgumentException exception) {
				Assert.assertTrue(true);
			}

			String key = "time.now";  //$NON-NLS-1$
			Date date = new Date();
			Object expectedValue = date.toString();

			Object actualValue;

			actualValue = System.getProperty(key);
			Assert.assertNull(actualValue);

			actualValue = bundleActivationManager.getProperty(key, null);
			Assert.assertNull(actualValue);

			Properties properties = System.getProperties();

			try {
				properties.put(key, expectedValue);

				actualValue = properties.get(key);
				Assert.assertEquals(expectedValue, actualValue);

				Object actualValue2 = bundleActivationManager.getProperty(key, null);
				Assert.assertEquals(actualValue, actualValue2);
			} finally {
				properties.remove(key);
				actualValue = properties.get(key);
				Assert.assertNull(actualValue);
			}
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_restartFramework() {
		Assert.assertTrue(true);  // Cannot test this API.
	}

	public void test_shutdownFramework() {
		Assert.assertTrue(true);  // Cannot test this API.
	}

	public void test_start() throws Exception {
		final ValueHolder holder = ValueHolder.falseValue();
		Assert.assertTrue(holder.isFalse());

		IBundleActivationManagerOwner owner = new BundleActivationManagerOwnerAdapter() {
			public void activate() {
				holder.setTrue();
			}
		};

		try {
			startBundleActivationManager(owner);
			Assert.assertTrue(holder.isTrue());
		} finally {
			stopBundleActivationManager();
		}
	}

	public void test_stop() throws Exception {
		final ValueHolder holder = ValueHolder.falseValue();
		Assert.assertTrue(holder.isFalse());

		IBundleActivationManagerOwner owner = new BundleActivationManagerOwnerAdapter() {
			public void deactivate() {
				holder.setTrue();
			}
		};

		try {
			startBundleActivationManager(owner);
		} finally {
			stopBundleActivationManager();
		}

		Assert.assertTrue(holder.isTrue());
	}

	private void writeLine(File file, String line) throws IOException {
		OutputStream stream = null;

		try {
			stream = new FileOutputStream(file);
			FactoryUtility utility = FactoryUtility.getInstance();
			ILineWriter writer = utility.createLineWriter(stream);

			try {
				writer.writeLine(line);
			} finally {
				writer.close();
			}
		} finally {
			if (stream != null) {
				stream.close();
			}
		}
	}
}
