/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle.cm.test.hotdog;

public interface VendorService {
	public static final String SERVICE_NAME = VendorService.class.getName();
	public static final String SPICINESS_PROPERTY_KEY = "spiciness"; //$NON-NLS-1$

	public String getId();
	public Object getName();
	public int getSpiciness();
	public String sell();
	public void setSpiciness(int spiciness);
}
