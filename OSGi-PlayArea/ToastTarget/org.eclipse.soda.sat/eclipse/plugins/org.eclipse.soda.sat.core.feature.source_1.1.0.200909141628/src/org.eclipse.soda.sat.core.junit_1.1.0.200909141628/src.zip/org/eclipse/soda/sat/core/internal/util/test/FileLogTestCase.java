/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util.test;

import java.io.File;
import java.io.IOException;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.framework.interfaces.IFileLog;
import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;

public class FileLogTestCase extends AbstractSatTestCase {
	private static final String FILENAME = "junit-log.txt"; //$NON-NLS-1$

	public static Test suite() {
		return new TestSuite(FileLogTestCase.class);
	}

	public FileLogTestCase(String name) {
		super(name);
	}

	public void test_delete() throws IOException {
		File file = new File(FileLogTestCase.FILENAME);
		IFileLog log = AbstractSatTestCase.FACTORY.createFileLog(file);
		log.open();
		boolean deleted = log.delete();  // Close is implied.
		Assert.assertTrue("File was not deleted", deleted); //$NON-NLS-1$
	}

	public void test_getFilename() throws IOException {
		File file = new File(FileLogTestCase.FILENAME);
		IFileLog log = AbstractSatTestCase.FACTORY.createFileLog(file);
		Object filename = log.getFilename();
		Assert.assertEquals("Filename is incorrect", FileLogTestCase.FILENAME, filename); //$NON-NLS-1$
	}

	public void test_open() throws IOException {
		File file = new File(FileLogTestCase.FILENAME);
		IFileLog log = AbstractSatTestCase.FACTORY.createFileLog(file);
		log.open();
		boolean exists = file.exists();
		Assert.assertTrue("File does not exist", exists); //$NON-NLS-1$
		boolean isFile = file.isFile();
		Assert.assertTrue("Not a file", isFile); //$NON-NLS-1$
		log.delete();  // Close is implied.
	}
}