/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.record.test;

import java.util.Dictionary;
import java.util.Hashtable;

import junit.framework.Assert;

import org.eclipse.soda.sat.core.junit.internal.AbstractServiceTestCase;
import org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord;
import org.eclipse.soda.sat.junit.util.ValueHolder;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceEvent;
import org.osgi.framework.ServiceListener;
import org.osgi.framework.ServiceReference;

public abstract class AbstractExportServiceRecordTestCase extends AbstractServiceTestCase {
	protected interface TestService1 {
		public static final String SERVICE_NAME = TestService1.class.getName();
	}

	protected interface TestService2 {
		public static final String SERVICE_NAME = TestService2.class.getName();
	}

	protected static class TestServiceImplementation extends Object implements TestService1, TestService2 { // $codepro.audit.disable convertClassToInterface, com.instantiations.assist.eclipse.analysis.emptyClass
		//...
	}

	private static final String COMPANY_KEY = "company";  //$NON-NLS-1$
	private static final String ECLIPSE_ORG = "Eclipse.org"; //$NON-NLS-1$
	private static final String IBM_ORG = "IBM"; //$NON-NLS-1$

	private Object service;

	protected AbstractExportServiceRecordTestCase(String name) {
		super(name);
	}

	protected abstract IExportServiceRecord createExportServiceRecord(BundleContext context, Class[] types, Dictionary properties);

	private boolean exists(Object[] values, Object value) {
		int length = values.length;
		boolean found = false;
		int i = 0;

		while (found == false && i < length) {
			Object object = values [ i ];
			found = object.equals(value);
			i++;
		}

		return found;
	}

	protected final Object getService() {
		return service;
	}

	private void setService(Object service) {
		this.service = service;
	}

	protected void setUp() throws Exception {
		super.setUp();
		setService(new TestServiceImplementation());
	}

	protected void tearDown() throws Exception {
		setService(null);
		super.tearDown();
	}

	public void test_getNames() {
		Class[] types = new Class[] {
			TestService1.class,
			TestService2.class
		};

		BundleContext context = getBundleContext();
		IExportServiceRecord record = createExportServiceRecord(context, types, null);

		Object[] expectedNames = toStringArray(types);
		Object[] actualNames = record.getNames();
		int expectedLength = expectedNames.length;
		int actualLength = actualNames.length;
		Assert.assertEquals(expectedLength, actualLength);

		for (int i = 0; i < expectedLength; i++) {
			Object expectedName = expectedNames [ i ];
			Object actualName = actualNames [ i ];
			Assert.assertEquals(expectedName, actualName);
		}
	}

	public void test_getProperties() {
		Dictionary properties = new Hashtable(11);
		properties.put(AbstractExportServiceRecordTestCase.COMPANY_KEY, AbstractExportServiceRecordTestCase.ECLIPSE_ORG);

		BundleContext context = getBundleContext();
		Class[] types = { TestService1.class };
		IExportServiceRecord record = createExportServiceRecord(context, types, properties);

		Object expected = properties;
		Object actual = record.getProperties();
		Assert.assertSame(expected, actual);
	}

	public void test_getProperty() {
		BundleContext context = getBundleContext();
		Class[] types = { TestService1.class };
		Dictionary properties = new Hashtable(11);
		properties.put(AbstractExportServiceRecordTestCase.COMPANY_KEY, AbstractExportServiceRecordTestCase.ECLIPSE_ORG);

		IExportServiceRecord record = createExportServiceRecord(context, types, properties);

		Object expected = AbstractExportServiceRecordTestCase.ECLIPSE_ORG;
		Object actual = record.getProperty(AbstractExportServiceRecordTestCase.COMPANY_KEY);
		Assert.assertSame(expected, actual);
	}

	public void test_getPropertyKeys() {
		BundleContext context = getBundleContext();
		Class[] types = { TestService1.class };
		Dictionary properties = new Hashtable(11);
		properties.put(AbstractExportServiceRecordTestCase.COMPANY_KEY, AbstractExportServiceRecordTestCase.ECLIPSE_ORG);

		IExportServiceRecord record = createExportServiceRecord(context, types, properties);

		Object[] keys;
		boolean found;

		keys = record.getPropertyKeys();
		found = exists(keys, AbstractExportServiceRecordTestCase.COMPANY_KEY);
		Assert.assertTrue(found);

		record.register();

		keys = record.getPropertyKeys();
		found = exists(keys, AbstractExportServiceRecordTestCase.COMPANY_KEY);
		Assert.assertTrue(found);

		record.unregister();

		keys = record.getPropertyKeys();
		found = exists(keys, AbstractExportServiceRecordTestCase.COMPANY_KEY);
		Assert.assertTrue(found);
	}

	public abstract void test_getService();

	public void test_getServiceReference() {
		BundleContext context = getBundleContext();
		Class[] types = { TestService1.class };
		IExportServiceRecord record = createExportServiceRecord(context, types, null);

		ServiceReference reference;

		reference = record.getServiceReference();
		Assert.assertNull(reference);

		record.register();

		reference = record.getServiceReference();
		Assert.assertNotNull(reference);

		Object[] objectClasses = (Object[]) reference.getProperty(Constants.OBJECTCLASS);
		int expectedLength = 1;
		int actualLength = objectClasses.length;
		Assert.assertEquals(expectedLength, actualLength);

		Object expectedObjectClass = TestService1.SERVICE_NAME;
		Object actualObjectClass = objectClasses [ 0 ];
		Assert.assertEquals(expectedObjectClass, actualObjectClass);

		record.unregister();

		reference = record.getServiceReference();
		Assert.assertNull(reference);
	}

	public abstract void test_isProxy();

	public void test_isRegistered() {
		BundleContext context = getBundleContext();
		Class[] types = { TestService1.class };
		IExportServiceRecord record = createExportServiceRecord(context, types, null);

		boolean isRegistered;

		isRegistered = record.isRegistered();
		Assert.assertFalse(isRegistered);

		record.register();
		isRegistered = record.isRegistered();
		Assert.assertTrue(isRegistered);

		record.unregister();
		isRegistered = record.isRegistered();
		Assert.assertFalse(isRegistered);
	}

	public void test_register() throws InvalidSyntaxException {
		BundleContext context = getBundleContext();
		Class[] types = { TestService1.class };

		final ValueHolder serviceEventTypeHolder = ValueHolder.nullValue();

		ServiceListener listener = new ServiceListener() {
			public void serviceChanged(ServiceEvent event) {
				int type = event.getType();
				serviceEventTypeHolder.setValue(new Integer(type));
			}
		};

		// "(objectClass=org.eclipse.soda.sat.core.internal.record.test.ExportServiceRecordTestCase$TestService1)"
		String filter = '(' + Constants.OBJECTCLASS + '=' + TestService1.SERVICE_NAME + ')';
		context.addServiceListener(listener, filter);
		IExportServiceRecord record = createExportServiceRecord(context, types, null);
		record.register();

		int expectedType = ServiceEvent.REGISTERED;
		Integer wrapper = (Integer) serviceEventTypeHolder.getValue();
		int actualType = wrapper.intValue();
		Assert.assertEquals(expectedType, actualType);

		context.removeServiceListener(listener);
		record.unregister();
	}

	public void test_setProperties() throws InvalidSyntaxException, InterruptedException {
		BundleContext context = getBundleContext();
		Class[] types = { TestService1.class };
		Dictionary properties = new Hashtable(11);
		properties.put(AbstractExportServiceRecordTestCase.COMPANY_KEY, AbstractExportServiceRecordTestCase.ECLIPSE_ORG);

		IExportServiceRecord record = createExportServiceRecord(context, types, properties);
		record.register();

		Thread.sleep(100); // $codepro.audit.disable disallowSleepUsage

		final ValueHolder serviceEventTypeHolder = ValueHolder.nullValue();
		final ValueHolder propertyValueHolder = ValueHolder.nullValue();

		ServiceListener listener = new ServiceListener() {
			public void serviceChanged(ServiceEvent event) {
				int type = event.getType();
				serviceEventTypeHolder.setValue(new Integer(type));

				ServiceReference reference = event.getServiceReference();
				Object value = reference.getProperty(AbstractExportServiceRecordTestCase.COMPANY_KEY);
				propertyValueHolder.setValue(value);
			}
		};

		// "(objectClass=org.eclipse.soda.sat.core.internal.record.test.ExportServiceRecordTestCase$TestService1)"
		String filter = '(' + Constants.OBJECTCLASS + '=' + TestService1.SERVICE_NAME + ')';
		context.addServiceListener(listener, filter);

		Long preTimestampWrapper = (Long) properties.get(IExportServiceRecord.SERVICE_REGISTRATION_TIMESTAMP_PROPERTY);
		long preTimestamp = preTimestampWrapper.longValue();

		properties.put(AbstractExportServiceRecordTestCase.COMPANY_KEY, AbstractExportServiceRecordTestCase.IBM_ORG);
		record.setProperties(properties);

		int expectedServiceEventType = ServiceEvent.MODIFIED;
		Integer wrapper = (Integer) serviceEventTypeHolder.getValue();
		int actualServiceEventType = wrapper.intValue();
		Assert.assertEquals(expectedServiceEventType, actualServiceEventType);

		Object expectedPropertyValue = AbstractExportServiceRecordTestCase.IBM_ORG;
		Object actualPropertyValue = propertyValueHolder.getValue();
		Assert.assertEquals(expectedPropertyValue, actualPropertyValue);

		Long postTimestampWrapper = (Long) properties.get(IExportServiceRecord.SERVICE_REGISTRATION_TIMESTAMP_PROPERTY);
		long postTimestamp = postTimestampWrapper.longValue();

		long timestampDelta = postTimestamp - preTimestamp;
		boolean updatedTimestamp = timestampDelta != 0;
		Assert.assertTrue(updatedTimestamp);

		context.removeServiceListener(listener);
		record.unregister();
	}

	public void test_unregister() throws InvalidSyntaxException {
		BundleContext context = getBundleContext();
		Class[] types = { TestService1.class };

		final ValueHolder serviceEventTypeHolder = ValueHolder.nullValue();

		ServiceListener listener = new ServiceListener() {
			public void serviceChanged(ServiceEvent event) {
				int type = event.getType();
				serviceEventTypeHolder.setValue(new Integer(type));
			}
		};

		// "(objectClass=org.eclipse.soda.sat.core.internal.record.test.ExportServiceRecordTestCase$TestService1)"
		String filter = '(' + Constants.OBJECTCLASS + '=' + TestService1.SERVICE_NAME + ')';
		context.addServiceListener(listener, filter);
		IExportServiceRecord record = createExportServiceRecord(context, types, null);
		record.register();
		record.unregister();
		context.removeServiceListener(listener);

		int expectedServiceEventType = ServiceEvent.UNREGISTERING;
		Integer wrapper = (Integer) serviceEventTypeHolder.getValue();
		int actualServiceEventType = wrapper.intValue();
		Assert.assertEquals(expectedServiceEventType, actualServiceEventType);
	}

	protected final String[] toStringArray(Class[] types) {
		String[] names = new String [ types.length ];

		for (int i = 0; i < types.length; i++) {
			Class type = types [ i ];
			String name = type.getName();
			names [ i ]  = name;
		}

		return names;
	}
}
