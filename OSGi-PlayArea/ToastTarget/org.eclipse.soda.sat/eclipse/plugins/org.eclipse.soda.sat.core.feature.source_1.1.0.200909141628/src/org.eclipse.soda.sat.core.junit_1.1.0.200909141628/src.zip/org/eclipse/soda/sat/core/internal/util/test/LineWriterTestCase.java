/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util.test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.framework.interfaces.ILineWriter;
import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;

public class LineWriterTestCase extends AbstractSatTestCase {
	public static Test suite() {
		return new TestSuite(LineWriterTestCase.class);
	}

	public LineWriterTestCase(String name) {
		super(name);
	}

	private ILineWriter createLineWriter(OutputStream outputStream) {
		ILineWriter writer = AbstractSatTestCase.FACTORY.createLineWriter(outputStream);
		return writer;
	}

	private ILineWriter createLineWriter(OutputStream outputStream, String characterEncoding) {
		ILineWriter writer = AbstractSatTestCase.FACTORY.createLineWriter(outputStream, characterEncoding);
		return writer;
	}

	public void test_flush() throws IOException {
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		ILineWriter writer = createLineWriter(outputStream);
		Object expected;
		Object value;

		try {
			writer.write("one"); //$NON-NLS-1$
			expected = new String();
			value = outputStream.toString();
			Assert.assertEquals(expected, value);
			writer.flush();
			expected = "one"; //$NON-NLS-1$
			value = outputStream.toString();
			Assert.assertEquals(expected, value);
		} finally {
			writer.close();
		}
	}

	public void test_newLine() throws IOException {
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		ILineWriter writer = createLineWriter(outputStream);

		try {
			writer.write("one"); //$NON-NLS-1$
			writer.newLine();
			writer.write("two"); //$NON-NLS-1$
			writer.newLine();
			writer.flush();
			String value = outputStream.toString();
			String newline = "\r\n"; //$NON-NLS-1$ // $codepro.audit.disable platformSpecificLineSeparator
			String expected = "one" + newline + "two" + newline; //$NON-NLS-1$ //$NON-NLS-2$
			Assert.assertEquals(expected, value);
		} finally {
			writer.close();
		}
	}

	public void test_write() throws IOException {
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		ILineWriter writer = createLineWriter(outputStream);

		try {
			writer.write("one"); //$NON-NLS-1$
			writer.write("two"); //$NON-NLS-1$
			writer.flush();
			Object value = outputStream.toString();
			Object expected = "one" + "two"; //$NON-NLS-1$ //$NON-NLS-2$
			Assert.assertEquals(expected, value);
		} finally {
			writer.close();
		}
	}

	public void test_write_japanese() throws IOException {
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		ILineWriter writer = createLineWriter(outputStream, "UTF-8"); //$NON-NLS-1$
		String yamadaTaro = "山田太郎"; //$NON-NLS-1$

		try {
			writer.write(yamadaTaro);
			writer.flush();
			Object value = outputStream.toString();
			Assert.assertEquals(yamadaTaro, value);
		} finally {
			writer.close();
		}
	}

	public void test_writeLine() throws IOException {
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		ILineWriter writer = createLineWriter(outputStream);

		try {
			writer.writeLine("one"); //$NON-NLS-1$
			writer.writeLine("two"); //$NON-NLS-1$
			writer.flush();
			Object value = outputStream.toString();
			Object newline = "\r\n"; //$NON-NLS-1$ // $codepro.audit.disable platformSpecificLineSeparator
			Object expected = "one" + newline + "two" + newline; //$NON-NLS-1$ //$NON-NLS-2$
			Assert.assertEquals(expected, value);
		} finally {
			writer.close();
		}
	}
}
