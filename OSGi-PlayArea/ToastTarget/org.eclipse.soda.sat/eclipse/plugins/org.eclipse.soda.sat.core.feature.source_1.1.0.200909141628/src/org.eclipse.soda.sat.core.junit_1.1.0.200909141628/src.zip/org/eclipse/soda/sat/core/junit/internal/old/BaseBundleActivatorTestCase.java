/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.junit.internal.old;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.framework.BaseBundleActivator;
import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;
import org.eclipse.soda.sat.core.junit.internal.old.service.Dummy;
import org.eclipse.soda.sat.core.junit.internal.old.service.DummyService;
import org.eclipse.soda.sat.core.record.interfaces.IImportServiceRecord;
import org.eclipse.soda.sat.junit.util.ValueHolder;
import org.osgi.framework.BundleContext;


/**
 * BaseBundleActivatorTestCase.java
 */
public class BaseBundleActivatorTestCase extends OldTestCase {
	public static Test suite() {
		return new TestSuite(BaseBundleActivatorTestCase.class);
	}

	private final ValueHolder activatedHolder;
	private final ValueHolder deactivatedHolder;

	public BaseBundleActivatorTestCase(String name) {
		super(name);
		activatedHolder = ValueHolder.nullValue();
		deactivatedHolder = ValueHolder.nullValue();
	}

	private BaseBundleActivator createBaseBundleActivator() {
		return new BaseBundleActivator() {
			protected void activate() {
				activatedHolder.setTrue();
			}

			protected void deactivate() {
				deactivatedHolder.setTrue();
			}

			protected String[] getImportedServiceNames(){
				String[] names = {
					DummyService.SERVICE_NAME
				};

				return names;
			}
		};
	}

	private void runBaseBundleActivatorTest(BaseBundleActivator activator) throws Exception {
		runBaseBundleActivatorTest(activator, null);
	}

	private void runBaseBundleActivatorTest(BaseBundleActivator activator, Runnable action) throws Exception {
		BundleContext bundleContext = getBundleContext();

		try {
			activator.start(bundleContext);
			Assert.assertTrue("BaseBundleActivator was not activated", activatedHolder.isTrue()); //$NON-NLS-1$

			if (action != null) {
				action.run();
			}
		} finally {
			activator.stop(bundleContext);
			Assert.assertTrue("BaseBundleActivator was not deactivated", deactivatedHolder.isTrue()); //$NON-NLS-1$
		}
	}

	protected void setUp() throws Exception {
		super.setUp();
		activatedHolder.setFalse();
		deactivatedHolder.setFalse();
	}

	public void testActivateDeactivate() throws Exception {
		BaseBundleActivator activator = new BaseBundleActivator() {
			protected void activate() {
				super.activate();
				activatedHolder.setTrue();
			}

			protected void deactivate() {
				deactivatedHolder.setTrue();
				super.deactivate();
			}

			protected String[] getImportedServiceNames() {
				return BaseBundleActivator.NO_SERVICES;
			}
		};

		runBaseBundleActivatorTest(activator);
	}

	public void testExportedServices() throws Exception {
		BaseBundleActivator activator = new BaseBundleActivator() {
			protected void activate() {
				Dummy dummy = new Dummy();
				addExportedService(DummyService.SERVICE_NAME, dummy, null);
				activatedHolder.setTrue();
			}

			protected void deactivate() {
				deactivatedHolder.setTrue();
			}

			public String[] getImportedServiceNames() {
				return BaseBundleActivator.NO_SERVICES;
			}
		};

		BundleContext bundleContext = getBundleContext();
		final IImportServiceRecord record = AbstractSatTestCase.FACTORY.createImportServiceRecord(bundleContext, DummyService.SERVICE_NAME, null);

		Runnable acquireAction = new Runnable() {
			public void run() {
				record.setOwner(BaseBundleActivatorTestCase.this);
				record.acquire();
				Assert.assertTrue("ImportServiceRecord was not acquired", record.isAcquired() == true); //$NON-NLS-1$
				record.release();
			}
		};

		runBaseBundleActivatorTest(activator, acquireAction);

		record.setOwner(this);
		record.acquire();
		Assert.assertTrue("ImportServiceRecord was acquired", record.isAcquired() == false); //$NON-NLS-1$
		record.release();
	}

	public void testImportedServices() throws Exception {
		BaseBundleActivator activator = createBaseBundleActivator();
		registerDummyService();
		runBaseBundleActivatorTest(activator);
		unregisterDummyService();
	}

	public void testServiceEvents() throws Exception {
		BaseBundleActivator activator = createBaseBundleActivator();
		BundleContext bundleContext = getBundleContext();

		activator.start(bundleContext);
		Assert.assertTrue("BaseBundleActivator was activated", activatedHolder.isFalse()); //$NON-NLS-1$

		registerDummyService();
		Assert.assertTrue("BaseBundleActivator was not activated", activatedHolder.isTrue() == true); //$NON-NLS-1$

		unregisterDummyService();
		Assert.assertTrue("BaseBundleActivator was activated", deactivatedHolder.isTrue()); //$NON-NLS-1$
	}
}