/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util.test;

import java.util.List;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.framework.interfaces.IDependencyTracker;
import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;

/**
 * DependencyTrackerTestCase.java
 */
public class DependencyTrackerTestCase extends AbstractSatTestCase {
	private static final String JOHN = "John"; //$NON-NLS-1$
	private static final String JANE = "Jane"; //$NON-NLS-1$
	private static final String FRED = "Fred"; //$NON-NLS-1$
	private static final String FREDA = "Freda"; //$NON-NLS-1$
	private static final String PETER = "Peter"; //$NON-NLS-1$
	private static final String TOM = "Tom"; //$NON-NLS-1$
	private static final String BILL = "Bill"; //$NON-NLS-1$
	private static final String MATTHEW = "Matthew"; //$NON-NLS-1$
	private static final String PHILIP = "Philip"; //$NON-NLS-1$

	public static Test suite() {
		return new TestSuite(DependencyTrackerTestCase.class);
	}

	private IDependencyTracker tracker;

	public DependencyTrackerTestCase(String name) {
		super(name);
	}

	protected void setUp() throws Exception {
		super.setUp();
		tracker = AbstractSatTestCase.FACTORY.createDependencyTracker(51, 51);
		Assert.assertNotNull("DependencyTracker is null", tracker); //$NON-NLS-1$

		tracker.add(DependencyTrackerTestCase.FRED, DependencyTrackerTestCase.JOHN);
		tracker.add(DependencyTrackerTestCase.FRED, DependencyTrackerTestCase.JANE);
		tracker.add(DependencyTrackerTestCase.FREDA, DependencyTrackerTestCase.JOHN);
		tracker.add(DependencyTrackerTestCase.FREDA, DependencyTrackerTestCase.JANE);
		tracker.add(DependencyTrackerTestCase.PETER, DependencyTrackerTestCase.FREDA);
		tracker.add(DependencyTrackerTestCase.PETER, DependencyTrackerTestCase.TOM);
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		tracker = null;
	}

	public void test_add() {
		List entries;
		boolean valid;

		entries = tracker.getPrerequisites(DependencyTrackerTestCase.FRED);
		valid = entries.size() == 2 && entries.contains(DependencyTrackerTestCase.JOHN) && entries.contains(DependencyTrackerTestCase.JANE);
		Assert.assertTrue(valid);

		entries = tracker.getPrerequisites(DependencyTrackerTestCase.FREDA);
		valid = entries.size() == 2 && entries.contains(DependencyTrackerTestCase.JOHN) && entries.contains(DependencyTrackerTestCase.JANE);
		Assert.assertTrue(valid);

		entries = tracker.getPrerequisites(DependencyTrackerTestCase.PETER);
		valid = entries.size() == 2 && entries.contains(DependencyTrackerTestCase.FREDA) && entries.contains(DependencyTrackerTestCase.TOM);
		Assert.assertTrue(valid);

		entries = tracker.getDependents(DependencyTrackerTestCase.JOHN);
		valid = entries.size() == 2 && entries.contains(DependencyTrackerTestCase.FREDA) && entries.contains(DependencyTrackerTestCase.FRED);
		Assert.assertTrue(valid);

		entries = tracker.getDependents(DependencyTrackerTestCase.JANE);
		valid = entries.size() == 2 && entries.contains(DependencyTrackerTestCase.FREDA) && entries.contains(DependencyTrackerTestCase.FRED);
		Assert.assertTrue(valid);

		entries = tracker.getDependents(DependencyTrackerTestCase.FREDA);
		valid = entries.size() == 1 && entries.contains(DependencyTrackerTestCase.PETER);
		Assert.assertTrue(valid);

		entries = tracker.getDependents(DependencyTrackerTestCase.TOM);
		valid = entries.size() == 1 && entries.contains(DependencyTrackerTestCase.PETER);
		Assert.assertTrue(valid);
	}

	public void test_getAllDependents() {
		List results = tracker.getAllDependents(DependencyTrackerTestCase.JOHN);

		boolean valid =
			results.size() == 3 &&
			results.contains(DependencyTrackerTestCase.FRED) &&
			results.contains(DependencyTrackerTestCase.FREDA) &&
			results.contains(DependencyTrackerTestCase.PETER);

		Assert.assertTrue("All Dependents of " + DependencyTrackerTestCase.JOHN + " are incorrect", valid); //$NON-NLS-1$ //$NON-NLS-2$
	}

	public void test_getAllPrerequisites() {
		List results = tracker.getAllPrerequisites(DependencyTrackerTestCase.PETER);

		boolean valid =
			results.size() == 4 &&
			results.contains(DependencyTrackerTestCase.FREDA) &&
			results.contains(DependencyTrackerTestCase.TOM) &&
			results.contains(DependencyTrackerTestCase.JOHN) &&
			results.contains(DependencyTrackerTestCase.JANE);

		Assert.assertTrue("All prerequisites of " + DependencyTrackerTestCase.PETER + " are incorrect", valid); //$NON-NLS-1$ //$NON-NLS-2$
	}

	public void test_getDependents() {
		List results = tracker.getDependents();

		boolean valid =
			results.size() >= 3 &&
			results.contains(DependencyTrackerTestCase.FRED) &&
			results.contains(DependencyTrackerTestCase.FREDA) &&
			results.contains(DependencyTrackerTestCase.PETER);


		Assert.assertTrue("Dependents are incorrect", valid); //$NON-NLS-1$
	}

	public void test_getDependentsOfEntry() {
		List results = tracker.getDependents(DependencyTrackerTestCase.JOHN);

		boolean valid =
			results.size() == 2 &&
			results.contains(DependencyTrackerTestCase.FRED) &&
			results.contains(DependencyTrackerTestCase.FREDA);

		Assert.assertTrue("Dependents of " + DependencyTrackerTestCase.JOHN + " are incorrect", valid); //$NON-NLS-1$ //$NON-NLS-2$
	}

	public void test_getPrerequisites() {
		List results = tracker.getPrerequisites();

		boolean valid =
			results.size() >= 4 &&
			results.contains(DependencyTrackerTestCase.JOHN) &&
			results.contains(DependencyTrackerTestCase.JANE) &&
			results.contains(DependencyTrackerTestCase.FREDA) &&
			results.contains(DependencyTrackerTestCase.TOM);

		Assert.assertTrue("Prerequisites are incorrect", valid); //$NON-NLS-1$
	}

	public void test_getPrerequisitesOfEntry() {
		List results = tracker.getPrerequisites(DependencyTrackerTestCase.PETER);

		boolean valid =
			results.size() == 2 &&
			results.contains(DependencyTrackerTestCase.FREDA) &&
			results.contains(DependencyTrackerTestCase.TOM);

		Assert.assertTrue("Prerequisites of " + DependencyTrackerTestCase.PETER + " are incorrect", valid); //$NON-NLS-1$ //$NON-NLS-2$
	}

	public void test_getValues() {
		List results = tracker.getValues();

		boolean valid =
			results.size() == 6 &&
			results.contains(DependencyTrackerTestCase.JOHN) &&
			results.contains(DependencyTrackerTestCase.JANE) &&
			results.contains(DependencyTrackerTestCase.FRED) &&
			results.contains(DependencyTrackerTestCase.FREDA) &&
			results.contains(DependencyTrackerTestCase.PETER) &&
			results.contains(DependencyTrackerTestCase.TOM);

		Assert.assertTrue("Incorrect values", valid); //$NON-NLS-1$

	}

	public void test_hasCircularReference() {
		boolean valid =
			tracker.hasCircularReferences(DependencyTrackerTestCase.JOHN) == false &&
			tracker.hasCircularReferences(DependencyTrackerTestCase.JANE) == false &&
			tracker.hasCircularReferences(DependencyTrackerTestCase.FRED) == false &&
			tracker.hasCircularReferences(DependencyTrackerTestCase.FREDA) == false &&
			tracker.hasCircularReferences(DependencyTrackerTestCase.PETER) == false &&
			tracker.hasCircularReferences(DependencyTrackerTestCase.TOM) == false;

		Assert.assertTrue("Circular reference incorrectly detected", valid); //$NON-NLS-1$

		tracker.add(DependencyTrackerTestCase.BILL, DependencyTrackerTestCase.MATTHEW);
		tracker.add(DependencyTrackerTestCase.MATTHEW, DependencyTrackerTestCase.PHILIP);
		tracker.add(DependencyTrackerTestCase.PHILIP, DependencyTrackerTestCase.BILL);

		valid =
			tracker.hasCircularReferences(DependencyTrackerTestCase.BILL) == true &&
			tracker.hasCircularReferences(DependencyTrackerTestCase.MATTHEW) == true &&
			tracker.hasCircularReferences(DependencyTrackerTestCase.PHILIP) == true;

		Assert.assertTrue("Circular reference not detected", valid); //$NON-NLS-1$
	}

	public void test_hasDependents() {
		boolean result;

		result = tracker.hasDependents();
		Assert.assertTrue("Dependents not detected", result); //$NON-NLS-1$

		tracker.removeAll();

		result = tracker.hasDependents();
		Assert.assertFalse("Dependents incorrectly detected", result); //$NON-NLS-1$
	}

	public void test_hasPrerequisites() {
		boolean result;

		result = tracker.hasPrerequisites();
		Assert.assertTrue("Prerequisites not detected", result); //$NON-NLS-1$

		tracker.removeAll();

		result = tracker.hasPrerequisites();
		Assert.assertFalse("Prerequisites incorrectly detected", result); //$NON-NLS-1$
	}

	public void test_isEmpty() {
		boolean result;

		result = tracker.isEmpty();
		Assert.assertFalse("Incorrectly considered empty", result); //$NON-NLS-1$

		tracker.removeAll();

		result = tracker.isEmpty();
		Assert.assertTrue("Incorrectly considered not empty", result); //$NON-NLS-1$
	}

	public void test_remove() {
		tracker.remove(DependencyTrackerTestCase.FREDA);

		List results;
		boolean valid;

		results = tracker.getDependents(DependencyTrackerTestCase.JOHN);
		valid = results.size() == 1 && results.contains(DependencyTrackerTestCase.FRED);
		Assert.assertTrue(valid);

		results = tracker.getDependents(DependencyTrackerTestCase.JANE);
		valid = results.size() == 1 && results.contains(DependencyTrackerTestCase.FRED);
		Assert.assertTrue(valid);

		results = tracker.getPrerequisites(DependencyTrackerTestCase.PETER);
		valid = results.size() == 1 && results.contains(DependencyTrackerTestCase.TOM);
		Assert.assertTrue(valid);
	}

	public void test_removeAll() {
		int size;
		boolean valid;

		size = tracker.size();
		valid = size > 0;
		Assert.assertTrue(valid);

		tracker.removeAll();

		size = tracker.size();
		valid = size == 0;
		Assert.assertTrue(valid);
	}

	public void test_removeDependent() {
		tracker.removeDependent(DependencyTrackerTestCase.FRED);
		List list = tracker.getDependents();
		boolean result = list.contains(DependencyTrackerTestCase.FRED);
		Assert.assertFalse("Dependent not removed", result); //$NON-NLS-1$
	}

	public void test_removePrerequisite() {
		tracker.removeDependent(DependencyTrackerTestCase.JOHN);
		List list = tracker.getDependents();
		boolean result = list.contains(DependencyTrackerTestCase.JOHN);
		Assert.assertFalse("Prerequisite not removed", result); //$NON-NLS-1$
	}

	public void test_removeRelationship() {
		List results;
		boolean valid;

		results = tracker.getPrerequisites(DependencyTrackerTestCase.FRED);
		valid = results.size() == 2 && results.contains(DependencyTrackerTestCase.JANE)  && results.contains(DependencyTrackerTestCase.JOHN);
		Assert.assertTrue(valid);

		tracker.remove(DependencyTrackerTestCase.FRED, DependencyTrackerTestCase.JOHN);

		results = tracker.getPrerequisites(DependencyTrackerTestCase.FRED);
		valid = results.size() == 1 && results.contains(DependencyTrackerTestCase.JANE);
		Assert.assertTrue(valid);
	}

	public void test_removeWithAllPrerequisites() {
		List results;
		boolean valid;

		results = tracker.removeWithAllPrerequisites(DependencyTrackerTestCase.PETER);

		valid =
			results.size() ==  2 &&
			results.contains(DependencyTrackerTestCase.FREDA) &&
			results.contains(DependencyTrackerTestCase.TOM);

		Assert.assertTrue("Removed all prerequisites of " + DependencyTrackerTestCase.PETER + " are incorrect", valid); //$NON-NLS-1$ //$NON-NLS-2$

		tracker.add(DependencyTrackerTestCase.FREDA, DependencyTrackerTestCase.JOHN);
		tracker.add(DependencyTrackerTestCase.FREDA, DependencyTrackerTestCase.JANE);
		tracker.add(DependencyTrackerTestCase.PETER, DependencyTrackerTestCase.FREDA);
		tracker.add(DependencyTrackerTestCase.PETER, DependencyTrackerTestCase.TOM);
		tracker.remove(DependencyTrackerTestCase.FRED);

		results = tracker.removeWithAllPrerequisites(DependencyTrackerTestCase.PETER);

		valid =
			results.size() ==  4 &&
			results.contains(DependencyTrackerTestCase.FREDA) &&
			results.contains(DependencyTrackerTestCase.TOM) &&
			results.contains(DependencyTrackerTestCase.JOHN) &&
			results.contains(DependencyTrackerTestCase.JANE);

		Assert.assertTrue("Removed all prerequisites of " + DependencyTrackerTestCase.PETER + " are incorrect", valid); //$NON-NLS-1$ //$NON-NLS-2$
	}

	public void test_removeWithPrerequisites() {
		List results;
		boolean valid;

		tracker.remove(DependencyTrackerTestCase.FRED);
		results = tracker.removeWithPrerequisites(DependencyTrackerTestCase.PETER);

		valid =
			results.size() ==  2 &&
			results.contains(DependencyTrackerTestCase.FREDA) &&
			results.contains(DependencyTrackerTestCase.TOM);

		Assert.assertTrue("Removed prerequisites of " + DependencyTrackerTestCase.PETER + " are incorrect", valid); //$NON-NLS-1$ //$NON-NLS-2$
	}

	public void test_size() {
		int size;

		size = tracker.size();
		Assert.assertEquals("Incorrect size", 6, size); //$NON-NLS-1$

		tracker.removeAll();
		size = tracker.size();
		Assert.assertEquals("Incorrect size", 0, size); //$NON-NLS-1$
	}

//	public void test_toXml() throws Exception {
//		String xml = tracker.toXml("test");
//		System.out.println(xml);
//		byte[] bytes = xml.getBytes();
//		InputStream stream = new ByteArrayInputStream(bytes);
//		SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
//		DefaultHandler handler = new DefaultHandler() {
//			public void endElement(String uri, String localName, String name) throws SAXException {
//				System.out.println("End: " + name);
//			}
//			public void startElement(String uri, String localName, String name, Attributes attributes) throws SAXException {
//				System.out.println("Start: " + name);
//			}
//		};
//		parser.parse(stream, handler);
//	}
}