/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.record.container.test;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;
import org.eclipse.soda.sat.core.junit.internal.AbstractServiceTestCase;
import org.eclipse.soda.sat.core.record.container.interfaces.IExportServiceRecordContainer;
import org.eclipse.soda.sat.core.record.container.interfaces.IServiceRecordAction;
import org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IServiceRecord;
import org.osgi.framework.BundleContext;

public class ExportServiceRecordContainerTestCase extends AbstractServiceTestCase {
	private interface TestService1 {
		public static final String SERVICE_NAME = TestService1.class.getName();
	}

	private interface TestService2 {
		public static final String SERVICE_NAME = TestService2.class.getName();
	}

	private interface TestService3 {
		public static final String SERVICE_NAME = TestService3.class.getName();
	}

	private static class TestServiceImplementation extends Object implements TestService1, TestService2 { // $codepro.audit.disable convertClassToInterface, com.instantiations.assist.eclipse.analysis.emptyClass
		//...
	}

	public static Test suite() {
		return new TestSuite(ExportServiceRecordContainerTestCase.class);
	}

	private IExportServiceRecordContainer container;

	public ExportServiceRecordContainerTestCase(String name) {
		super(name);
	}

	protected void setUp() throws Exception {
		super.setUp();
		container = AbstractSatTestCase.FACTORY.createExportServiceRecordContainer();
	}

	protected void tearDown() throws Exception {
		container = null;
		super.tearDown();
	}

	public void test_add() {
		BundleContext context = getBundleContext();
		String[] names = { TestService1.SERVICE_NAME };
		Object service;
		IExportServiceRecord record;
		boolean added;
		int expectedSize;
		int actualSize;

		// Check that a record can be added.
		service = new TestServiceImplementation();
		record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names, service, null);
		added = container.add(record);
		Assert.assertTrue(added);

		// Check the size of the container.
		expectedSize = 1;
		actualSize = container.size();
		Assert.assertEquals(actualSize, expectedSize);

		// Register the container.
		container.register();
		boolean registered = container.isRegistered();
		Assert.assertTrue(registered);

		// Check that a record can be added while the container is registered.
		service = new TestServiceImplementation();
		record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names, service, null);
		added = container.add(record);
		Assert.assertTrue(added);

		// Check the size of the container.
		expectedSize = 2;
		actualSize = container.size();
		Assert.assertEquals(expectedSize, actualSize);

		// Clean up
		container.unregister();
	}

	public void test_Constructor() {
		// Check that the container is not null.
		Assert.assertNotNull(container);

		// Check that the container is empty.
		boolean empty = container.isEmpty();
		Assert.assertTrue(empty);

		// Check the size of the container.
		int expectedSize = 0;
		int actualSize = container.size();
		Assert.assertEquals(expectedSize, actualSize);
	}

	public void test_contains(){
		BundleContext context = getBundleContext();
		String[] names = { TestService1.SERVICE_NAME };
		IExportServiceRecord record = null;
		Object service = new TestServiceImplementation();
		int count = 3;
		boolean exists;
		boolean removed;

		// Add some records to the container.
		for (int i = 0; i < count; i++) {
			// Add a record.
			record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names, service, null);
			container.add(record);
		}

		Assert.assertNotNull(record);

		// Check that the last record added is contained in the container.
		exists = container.contains(record);
		Assert.assertTrue(exists);

		// Remove the record.
		removed = container.remove(record);
		Assert.assertTrue(removed);

		// Check that the record is not contained in the container.
		exists = container.contains(record);
		Assert.assertFalse(exists);
	}

	public void test_doForEach() {
		BundleContext context = getBundleContext();
		String[] names = { TestService1.SERVICE_NAME };
		IExportServiceRecord record;
		Object service = new TestServiceImplementation();
		int count = 3;

		// Add some records to the container.
		for (int i = 0; i < count; i++) {
			// Add a record.
			record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names, service, null);
			container.add(record);
		}

		// An action that adds a record to a List.
		IServiceRecordAction action = new IServiceRecordAction(){
			public boolean execute(IServiceRecord record, Object parameter) {
				List list = (List) parameter;
				list.add(record);
				return true;
			}
		};

		// Add the records to a List.
		List list = new ArrayList(3);
		container.doForEach(action, list);

		// Check that the List contains 3 items.
		int expectedSize = count;
		int actualSize = list.size();
		Assert.assertEquals(expectedSize, actualSize);
	}

	public void test_empty() {
		BundleContext context = getBundleContext();
		String[] names = { TestService1.SERVICE_NAME };
		IExportServiceRecord record;
		Object service = new TestServiceImplementation();
		int count = 3;
		boolean empty;

		// Add some records to the container.
		for (int i = 0; i < count; i++) {
			// Add a record.
			record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names, service, null);
			container.add(record);
		}

		// Empty the container.
		container.empty();

		// Check that the container is empty.
		empty = container.isEmpty();
		Assert.assertTrue(empty);
	}

	public void test_get() {
		BundleContext context = getBundleContext();
		String[] names1 = { TestService1.SERVICE_NAME };
		String[] names2 = { TestService2.SERVICE_NAME };
		IExportServiceRecord record1;
		IExportServiceRecord record2;
		IExportServiceRecord record3;
		Object service;
		Object expected;
		Object actual;

		// Add a record to the container.
		service = new TestServiceImplementation();
		record1 = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names1, service, null);
		container.add(record1);

		// Add a record to the container.
		service = new TestServiceImplementation();
		record2 = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names2, service, null);
		container.add(record2);

		// Get the record for the TestService1 service name.
		expected = record1;
		actual = container.get(TestService1.SERVICE_NAME);
		Assert.assertSame(expected, actual);

		// Get the record TestService2 service name.
		expected = record2;
		actual = container.get(TestService2.SERVICE_NAME);
		Assert.assertSame(expected, actual);

		// Add a record to the container.
		service = new TestServiceImplementation();
		record3 = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names1, service, null);
		container.add(record3);

		// Get the record for the specified TestService1 service name and object.
		expected = record3;
		actual = container.get(TestService1.SERVICE_NAME, service);
		Assert.assertSame(expected, actual);

		// Check that trying to get a service by name that does not exist returns null.
		expected = null;
		actual = container.get(TestService3.SERVICE_NAME);
		Assert.assertSame(expected, actual);

		// Check that trying to get a service by name and service object that does not exist returns null.
		service = new TestServiceImplementation();
		actual = container.get(TestService1.SERVICE_NAME, service);
		Assert.assertSame(expected, actual);

		// Check that trying to a service by name and a null throws IllegalArgumentException.
		try {
			actual = container.get(TestService1.SERVICE_NAME, null);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}
	}

	public void test_getAll() {
		BundleContext context = getBundleContext();
		String[] names1 = { TestService1.SERVICE_NAME };
		String[] names2 = { TestService2.SERVICE_NAME };
		IExportServiceRecord record;
		Object service = new TestServiceImplementation();
		Object[] objects;
		int count = 3;
		int expectedLength;
		int actualLength;

		// Add some records to the container.
		for (int i = 0; i < count; i++) {
			// Add a TestService1 record to the container.
			record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names1, service, null);
			container.add(record);

			// Add a TestService2 record to the container.
			record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names2, service, null);
			container.add(record);
		}

		// Add a TestService1 record to the container.
		record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names1, service, null);
		container.add(record);

		// Get all the records.
		objects = container.getAll();

		// Check that the correct number of records is returned.
		expectedLength = count * 2 + 1;
		actualLength = objects.length;
		Assert.assertEquals(expectedLength, actualLength);

		// Get all the TestService1 records.
		objects = container.getAll(TestService1.SERVICE_NAME);

		// Check that the correct number of records is returned.
		expectedLength = count  + 1;
		actualLength = objects.length;
		Assert.assertEquals(expectedLength, actualLength);

		// Get all the TestService2 records.
		objects = container.getAll(TestService2.SERVICE_NAME);

		// Check that the correct number of records is returned.
		expectedLength = count;
		actualLength = objects.length;
		Assert.assertEquals(expectedLength, actualLength);

		// Get all the TestService3 records.  There should be none.
		objects = container.getAll(TestService3.SERVICE_NAME);

		// Check that no records are returned.
		expectedLength = 0;
		actualLength = objects.length;
		Assert.assertEquals(expectedLength, actualLength);

		// Empty the container.
		container.empty();

		// Get all the TestService1 records.  There should be none.
		objects = container.getAll(TestService1.SERVICE_NAME);

		// Check that no records are returned.
		expectedLength = 0;
		actualLength = objects.length;
		Assert.assertEquals(expectedLength, actualLength);
	}

	public void test_isEmpty() {
		BundleContext context = getBundleContext();
		String[] names = { TestService1.SERVICE_NAME };
		IExportServiceRecord record;
		Object service = new TestServiceImplementation();
		int count = 3;
		boolean empty;

		// Check that the container is initially empty.
		empty = container.isEmpty();
		Assert.assertTrue(empty);

		// Add some records to the container.
		for (int i = 0; i < count; i++) {
			// Add a record.
			record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names, service, null);
			container.add(record);
		}

		// Check that the container is not empty.
		empty = container.isEmpty();
		Assert.assertFalse(empty);
	}

	public void test_isRegistered() {
		BundleContext context = getBundleContext();
		String[] names = { TestService1.SERVICE_NAME };
		IExportServiceRecord record;
		Object service;
		boolean registered;
		boolean removed;
		int expectedSize;
		int actualSize;

		// Check that the container is not registered.
		registered = container.isRegistered();
		Assert.assertFalse(registered);

		// Add a record to the container.
		service = new TestServiceImplementation();
		record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names, service, null);
		container.add(record);

		// Check that the container is not registered.
		registered = container.isRegistered();
		Assert.assertFalse(registered);

		// Register the container.
		container.register();

		// Check that the container is registered.
		registered = container.isRegistered();
		Assert.assertTrue(registered);

		// Add a record to the container.
		service = new TestServiceImplementation();
		record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names, service, null);
		container.add(record);

		// Check that the container is not registered.
		registered = container.isRegistered();
		Assert.assertFalse(registered);

		// Remove the previously added record.
		removed = container.remove(record);
		Assert.assertTrue(removed);

		// Check the size of the container.
		expectedSize = 1;
		actualSize = container.size();
		Assert.assertEquals(expectedSize, actualSize);

		// Check that the container is registered.
		registered = container.isRegistered();
		Assert.assertTrue(registered);

		// Unregister the record in the container.
		record = (IExportServiceRecord) container.get(TestService1.SERVICE_NAME);
		record.unregister();

		// Check that the record is not registered.
		registered = record.isRegistered();
		Assert.assertFalse(registered);

		// Check that the container is not registered.
		registered = container.isRegistered();
		Assert.assertFalse(registered);

		// Remove the record from the container.
		removed = container.remove(record);
		Assert.assertTrue(removed);

		// Check that the container is not registered.
		registered = container.isRegistered();
		Assert.assertFalse(registered);
	}

	public void test_register() {
		BundleContext context = getBundleContext();
		String[] names = { TestService1.SERVICE_NAME };
		IExportServiceRecord record;
		Object[] objects;
		Object service = new TestServiceImplementation();
		boolean registered;
		int count = 3;

		// Add some records to the container.
		for (int i = 0; i < count; i++) {
			record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names, service, null);
			container.add(record);
		}

		// Register the container.
		container.register();

		// Check that the container is registered.
		registered = container.isRegistered();
		Assert.assertTrue(registered);

		// Get all the records in the container.
		objects = container.getAll();

		// Check that all the records in the container are registered.
		for (int i = 0; i < count; i++) {
			record = (IExportServiceRecord) objects [ i ];
			registered = record.isRegistered();
			Assert.assertTrue(registered);
		}

		// Add an unregistered record to the container.
		record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names, service, null);
		container.add(record);

		// Check that the container is not registered.
		registered = container.isRegistered();
		Assert.assertFalse(registered);

		// Register the record.
		record.register();

		// Check that the container is registered.
		registered = container.isRegistered();
		Assert.assertTrue(registered);

		// Unregister the record.
		record.unregister();

		// Check that the container is unregistered.
		registered = container.isRegistered();
		Assert.assertFalse(registered);

		// Remove the record from the container.
		container.remove(record);

		// Check that the container is registered.
		registered = container.isRegistered();
		Assert.assertTrue(registered);

		// Add a registered record to the container.
		record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names, service, null);
		record.register();
		container.add(record);

		// CHeck that the container is registered.
		registered = container.isRegistered();
		Assert.assertTrue(registered);

		// Clean up.
		container.unregister();
	}

	public void test_remove() {
		BundleContext context = getBundleContext();
		String[] names = { TestService1.SERVICE_NAME };
		Object service;
		IExportServiceRecord record;
		boolean removed;
		int expectedSize;
		int actualSize;

		// Add the record to the container.
		service = new TestServiceImplementation();
		record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names, service, null);
		container.add(record);

		// Check the size of the container is 1.
		expectedSize = 1;
		actualSize = container.size();
		Assert.assertEquals(actualSize, expectedSize);

		// Remove the record from the container.
		removed = container.remove(record);
		Assert.assertTrue(removed);

		// Check the size of the container is 0.
		expectedSize = 0;
		actualSize = container.size();
		Assert.assertEquals(actualSize, expectedSize);

		// Register the container.
		container.register();

		// Add the record to the container.
		service = new TestServiceImplementation();
		record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names, service, null);
		container.add(record);

		// Check the size of the container is 1.
		expectedSize = 1;
		actualSize = container.size();
		Assert.assertEquals(expectedSize, actualSize);

		// Remove the record from the container.
		removed = container.remove(record);
		Assert.assertTrue(removed);

		// Check the size of the container is 0.
		expectedSize = 0;
		actualSize = container.size();
		Assert.assertEquals(actualSize, expectedSize);

		// Clean up.
		container.unregister();
	}

	public void test_removeAll() {
		BundleContext context = getBundleContext();
		String[] names1 = { TestService1.SERVICE_NAME };
		String[] names2 = { TestService2.SERVICE_NAME };
		Object service = new TestServiceImplementation();
		IExportServiceRecord record;
		int expectedSize;
		int actualSize;
		int count = 3;

		// Add some TestService1 records to the container.
		for (int i = 0; i < count; i++) {
			record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names1, service, null);
			container.add(record);
		}

		// Check the size of the container.
		expectedSize = count;
		actualSize = container.size();
		Assert.assertEquals(actualSize, expectedSize);

		// Remove all the TestService1 records from the container.
		container.removeAll(TestService1.SERVICE_NAME);

		// Check the size of the container is 0.
		expectedSize = 0;
		actualSize = container.size();
		Assert.assertEquals(actualSize, expectedSize);

		// Add some TestService1 and TestService2 records to the container.
		for (int i = 0; i < count; i++) {
			record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names1, service, null);
			container.add(record);
			record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names2, service, null);
			container.add(record);
		}

		// Check the size of the container.
		expectedSize = count * 2;
		actualSize = container.size();
		Assert.assertEquals(actualSize, expectedSize);

		// Remove all the TestService1 records from the container.
		container.removeAll(TestService1.SERVICE_NAME);

		// Check the size of the container.
		expectedSize = count;
		actualSize = container.size();
		Assert.assertEquals(actualSize, expectedSize);

		// Remove all the TestService3 records from the container.  There should be none.
		container.removeAll(TestService3.SERVICE_NAME);

		// Check the size of the container.
		expectedSize = count;
		actualSize = container.size();
		Assert.assertEquals(actualSize, expectedSize);

		// Remove all the TestService2 records from the container.
		container.removeAll(TestService2.SERVICE_NAME);

		// Check the size of the container is 0.
		expectedSize = 0;
		actualSize = container.size();
		Assert.assertEquals(actualSize, expectedSize);
	}

	public void test_size() {
		BundleContext context = getBundleContext();
		String[] names = { TestService1.SERVICE_NAME };
		IExportServiceRecord record;
		Object service = new TestServiceImplementation();
		int count = 3;
		int expectedSize;
		int actualSize;

		// Check that the initial size of the container is 0.
		expectedSize = 0;
		actualSize = container.size();
		Assert.assertEquals(expectedSize, actualSize);

		// Add some records to the container.
		for (int i = 0; i < count; i++) {
			record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names, service, null);
			container.add(record);
		}

		// Check the size of the container.
		expectedSize = count;
		actualSize = container.size();
		Assert.assertEquals(expectedSize, actualSize);
	}

	public void test_unregister() {
		BundleContext context = getBundleContext();
		String[] names = { TestService1.SERVICE_NAME };
		IExportServiceRecord record;
		Object[] objects;
		Object service = new TestServiceImplementation();
		boolean registered;
		int count = 3;

		// Add some TestService1 records to the container.
		for (int i = 0; i < count; i++) {
			record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names, service, null);
			container.add(record);
		}

		// Register the container.
		container.register();

		// Check that the container is registered.
		registered = container.isRegistered();
		Assert.assertTrue(registered);

		// Unregister the container.
		container.unregister();

		// Check that the container is unregistered.
		registered = container.isRegistered();
		Assert.assertFalse(registered);

		// Get all the records in the container.
		objects = container.getAll();

		// Check that the records are unregistered.
		for (int i = 0; i < count; i++) {
			record = (IExportServiceRecord) objects [ i ];
			registered = record.isRegistered();
			Assert.assertFalse(registered);
		}

		// Register the container.
		container.register();

		// Add an unregistered record to the container.
		record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names, service, null);
		container.add(record);

		// Check that the container is not registered.
		registered = container.isRegistered();
		Assert.assertFalse(registered);

		// Unregister the container.
		container.unregister();

		// Check that the container is unregistered.
		registered = container.isRegistered();
		Assert.assertFalse(registered);

		// Get all the records from the container.
		objects = container.getAll();

		// Check that the records are unregistered.
		for (int i = 0; i < count; i++) {
			record = (IExportServiceRecord) objects [ i ];
			registered = record.isRegistered();
			Assert.assertFalse(registered);
		}
	}
}
