/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.util.test;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.junit.internal.AbstractServiceTestCase;
import org.eclipse.soda.sat.core.junit.internal.bundle.Activator;
import org.eclipse.soda.sat.core.util.BundleManifestUtility;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleException;
import org.osgi.framework.Constants;
import org.osgi.framework.ServiceReference;
import org.osgi.framework.Version;

public class BundleManifestUtilityTestCase extends AbstractServiceTestCase {
	private class AbstractBundle extends Object implements Bundle {
		public Enumeration findEntries(String path, String filePattern, boolean recurse) {
			return null;
		}

		public BundleContext getBundleContext() {
			return null;
		}

		public long getBundleId() {
			return Long.MAX_VALUE;
		}

		public URL getEntry(String path) {
			return null;
		}

		public Enumeration getEntryPaths(String path) {
			return null;
		}

		public Dictionary getHeaders() {
			Dictionary headers = new Hashtable(17);
			headers.put("Manifest-Version", "1.0");  //$NON-NLS-1$ //$NON-NLS-2$
			headers.put(Constants.BUNDLE_MANIFESTVERSION, "2");  //$NON-NLS-1$
			headers.put(Constants.BUNDLE_SYMBOLICNAME, "org.dummy.foo");  //$NON-NLS-1$
			return headers;
		}

		public Dictionary getHeaders(String locale) {
			return getHeaders();
		}

		public long getLastModified() {
			return 0;
		}

		public String getLocation() {
			return null;
		}

		public ServiceReference[] getRegisteredServices() {
			return null;
		}

		public URL getResource(String name) {
			return null;
		}

		public Enumeration getResources(String name) throws IOException {
			return null;
		}

		public ServiceReference[] getServicesInUse() {
			return null;
		}

		public Map getSignerCertificates(int signersType) {
			return new HashMap();
		}

		public int getState() {
			return Bundle.ACTIVE;
		}

		public String getSymbolicName() {
			Dictionary headers = getHeaders();
			String value = (String) headers.get(Constants.BUNDLE_SYMBOLICNAME);
			return value;
		}

		public Version getVersion() {
			return Version.emptyVersion;
		}

		public boolean hasPermission(Object permission) {
			return true;
		}

		public Class loadClass(String name) throws ClassNotFoundException {
			return null;
		}

		public void start() throws BundleException {
			// No-op
		}

		public void start(int options) throws BundleException {
			start();
		}

		public void stop() throws BundleException {
			// No-op
		}

		public void stop(int options) throws BundleException {
			stop();

		}

		public void uninstall() throws BundleException {
			// No-op
		}

		public void update() throws BundleException {
			// No-op
		}

		public void update(InputStream in) throws BundleException {
			// No-op
		}
	}

	private static final BundleManifestUtility UTILITY = BundleManifestUtility.getInstance();

	private static final Object[] EMPTY_OBJECT_ARRAY = new Object [ 0 ];

	public static Test suite() {
		return new TestSuite(BundleManifestUtilityTestCase.class);
	}

	public BundleManifestUtilityTestCase(String name) {
		super(name);
	}

	private String createPackageList() {
		char semicolon = ';';
		char comma = ',';
		char quote = '"';
		char equals = '=';
		String version = Constants.VERSION_ATTRIBUTE + equals + quote + "1.0.0" + quote; //$NON-NLS-1$

		StringBuffer buffer = new StringBuffer(100);
		buffer.append("org.dummy.foo.one").append(comma);  //$NON-NLS-1$
		buffer.append("org.dummy.foo.two").append(comma);  //$NON-NLS-1$
		buffer.append("org.dummy.foo.three").append(semicolon);  //$NON-NLS-1$
		buffer.append(version).append(comma);
		buffer.append("org.dummy.foo.four").append(semicolon);  //$NON-NLS-1$
		buffer.append(version).append(comma);

//		buffer.append("org.dummy.foo.five").append(semicolon);  //$NON-NLS-1$
//		buffer.append("org.dummy.foo.six").append(semicolon);  //$NON-NLS-1$
//		buffer.append(version);

		buffer.append("org.dummy.foo.five").append(comma);  //$NON-NLS-1$
		buffer.append("org.dummy.foo.six");  //$NON-NLS-1$

		String value = buffer.toString();
		return value;
	}

	public void test_getBundleActivator() {
		Object expected = Activator.class.getName();
		Bundle bundle = getBundle();
		Object actual = BundleManifestUtilityTestCase.UTILITY.getBundleActivator(bundle);
		Assert.assertEquals(expected, actual);
	}

	public void test_getBundleCategory() {
		Object expected = "Unit Test";  //$NON-NLS-1$
		Bundle bundle = getBundle();
		Object actual = BundleManifestUtilityTestCase.UTILITY.getBundleCategory(bundle);
		Assert.assertEquals(expected, actual);
	}

	public void test_getBundleClasspath() {
		Object expected = ".";  //$NON-NLS-1$
		Bundle bundle = getBundle();
		Object actual = BundleManifestUtilityTestCase.UTILITY.getBundleClasspath(bundle);
		Assert.assertEquals(expected, actual);
	}

	public void test_getBundleContactAddress() {
		Object expected = "license@eclipse.org";  //$NON-NLS-1$
		Bundle bundle = getBundle();
		Object actual = BundleManifestUtilityTestCase.UTILITY.getBundleContactAddress(bundle);
		Assert.assertEquals(expected, actual);
	}

	public void test_getBundleCopyright() {
		Object expected = "Copyright (c) 2001, 2007 IBM Corporation and others.";  //$NON-NLS-1$
		Bundle bundle = getBundle();
		Object actual = BundleManifestUtilityTestCase.UTILITY.getBundleCopyright(bundle);
		Assert.assertEquals(expected, actual);
	}

	public void test_getBundleDescription() {
		Object expected = "Unit tests for org.eclipse.soda.sat.core";  //$NON-NLS-1$
		Bundle bundle = getBundle();
		Object actual = BundleManifestUtilityTestCase.UTILITY.getBundleDescription(bundle);
		Assert.assertEquals(expected, actual);
	}

	public void test_getBundleDocUrl() {
		Object expected = "www.eclipse.org";  //$NON-NLS-1$
		Bundle bundle = getBundle();
		Object actual = BundleManifestUtilityTestCase.UTILITY.getBundleDocUrl(bundle);
		Assert.assertEquals(expected, actual);
	}

	public void test_getBundleLocalization() {
		Object expected = "bundle";  //$NON-NLS-1$
		Bundle bundle = getBundle();
		Object actual = BundleManifestUtilityTestCase.UTILITY.getBundleLocalization(bundle);
		Assert.assertEquals(expected, actual);
	}

	public void test_getBundleManifestVersion() {
		Object expected = "2";  //$NON-NLS-1$
		Bundle bundle = getBundle();
		Object actual = BundleManifestUtilityTestCase.UTILITY.getBundleManifestVersion(bundle);
		Assert.assertEquals(expected, actual);
	}

	public void test_getBundleName() {
		Object expected = "SAT Core JUnit Tests (Incubation)";  //$NON-NLS-1$
		Bundle bundle = getBundle();
		Object actual = BundleManifestUtilityTestCase.UTILITY.getBundleName(bundle);
		Assert.assertEquals(expected, actual);
	}

	public void test_getBundleNativeCode() {
		Object expected = null;
		Bundle bundle = getBundle();
		Object actual = BundleManifestUtilityTestCase.UTILITY.getBundleNativeCode(bundle);
		Assert.assertEquals(expected, actual);
	}

	public void test_getBundleRequiredExecutionEnvironments() {
		String[] expected = new String[] {
			"OSGi/Minimum-1.1"  //$NON-NLS-1$
		};
		Bundle bundle = getBundle();
		Object[] actual = BundleManifestUtilityTestCase.UTILITY.getBundleRequiredExecutionEnvironments(bundle);
		Assert.assertEquals(expected.length, actual.length);
	}

	public void test_getBundleSymbolicName() {
		Object expected = "org.eclipse.soda.sat.core.junit";  //$NON-NLS-1$
		Bundle bundle = getBundle();
		Object actual = BundleManifestUtilityTestCase.UTILITY.getBundleSymbolicName(bundle);
		Assert.assertEquals(expected, actual);
	}

	public void test_getBundleUpdateLocation() {
		Object expected = ".";  //$NON-NLS-1$
		Bundle bundle = getBundle();
		Object actual = BundleManifestUtilityTestCase.UTILITY.getBundleUpdateLocation(bundle);
		Assert.assertEquals(expected, actual);
	}

	public void test_getBundleVendor() {
		Object expected = "Eclipse.org";  //$NON-NLS-1$
		Bundle bundle = getBundle();
		Object actual = BundleManifestUtilityTestCase.UTILITY.getBundleVendor(bundle);
		Assert.assertEquals(expected, actual);
	}

	public void test_getBundleVersion() {
		Bundle bundle = getBundle();
		Object actual = BundleManifestUtilityTestCase.UTILITY.getBundleVersion(bundle);
		Assert.assertNotNull(actual);
	}

	public void test_getDynamicImportPackage() {
		Object[] expectedPackages = BundleManifestUtilityTestCase.EMPTY_OBJECT_ARRAY;
		Bundle bundle = getBundle();
		Object[] actualPackages = BundleManifestUtilityTestCase.UTILITY.getDynamicImportPackages(bundle);
		int expected = expectedPackages.length;
		int actual = actualPackages.length;
		Assert.assertEquals(expected, actual);
	}

	public void test_getExportPackage() {
		Bundle bundle = new AbstractBundle() {
			public Dictionary getHeaders() {
				Dictionary headers = super.getHeaders();
				String value = BundleManifestUtilityTestCase.this.createPackageList();
				headers.put(Constants.EXPORT_PACKAGE, value);
				return headers;
			}
		};

		Object[] actual = BundleManifestUtilityTestCase.UTILITY.getExportPackages(bundle);
		Assert.assertTrue(actual.length == 6);
	}

	public void test_getFragmentHost() {
		Bundle bundle = getBundle();
		Object expected = null;
		Object actual = BundleManifestUtilityTestCase.UTILITY.getFragmentHost(bundle);
		Assert.assertSame(expected, actual);
	}

	public void test_getImportPackage() {
		Bundle bundle = new AbstractBundle() {
			public Dictionary getHeaders() {
				Dictionary headers = super.getHeaders();
				String value = BundleManifestUtilityTestCase.this.createPackageList();
				headers.put(Constants.IMPORT_PACKAGE, value);
				return headers;
			}
		};

		Object[] actual = BundleManifestUtilityTestCase.UTILITY.getImportPackages(bundle);
		Assert.assertTrue(actual.length == 6);
	}

	public void test_getInstance() {
		Assert.assertNotNull(BundleManifestUtilityTestCase.UTILITY);
		BundleManifestUtility instance = BundleManifestUtility.getInstance();
		Object expected = BundleManifestUtilityTestCase.UTILITY;
		Object actual = instance;
		Assert.assertSame(expected, actual);
	}

	public void test_getRequiredBundles() {
		Object[] expected = BundleManifestUtilityTestCase.EMPTY_OBJECT_ARRAY;
		Bundle bundle = getBundle();
		Object[] actual = BundleManifestUtilityTestCase.UTILITY.getRequireBundles(bundle);
		Assert.assertEquals(expected.length, actual.length);
	}

	public void test_getServiceComponents() {
		Bundle bundle = getBundle();
		Object[] actual = BundleManifestUtilityTestCase.UTILITY.getServiceComponents(bundle);
		Assert.assertTrue(actual.length == 0);
	}

	public void test_getUnlocalizedHeader() {
		Object expected = "%bundle.name"; //$NON-NLS-1$
		Bundle bundle = getBundle();
		Object actual = BundleManifestUtilityTestCase.UTILITY.getUnlocalizedHeader(bundle, Constants.BUNDLE_NAME);
		Assert.assertEquals(expected, actual);
	}
}
