/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.junit.internal;

import org.eclipse.soda.sat.core.junit.internal.bundle.Activator;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.service.cm.ConfigurationAdmin;

public abstract class AbstractServiceTestCase extends AbstractSatTestCase {
	private BundleContext bundleContext;
	private ConfigurationAdmin configurationAdmin;

	protected AbstractServiceTestCase(String name) {
		super(name);
	}

	protected final Bundle getBundle() throws IllegalStateException {
		BundleContext bundleContext = getBundleContext();
		Bundle bundle = bundleContext.getBundle();
		return bundle;
	}

	protected final BundleContext getBundleContext() {
		return bundleContext;
	}

	protected final ConfigurationAdmin getConfigurationAdmin() {
		return configurationAdmin;
	}

	private void setBundleContext(BundleContext bundleContext) {
		this.bundleContext = bundleContext;
	}

	private void setConfigurationAdmin(ConfigurationAdmin configurationAdmin) {
		this.configurationAdmin = configurationAdmin;
	}

	protected void setUp() throws Exception {
		super.setUp();
		setBundleContext(Activator.BUNDLE_CONTEXT);
		setConfigurationAdmin(Activator.CONFIGURATION_ADMIN);
	}

	protected void tearDown() throws Exception {
		setConfigurationAdmin(null);
		setBundleContext(null);
		super.tearDown();
	}
}
