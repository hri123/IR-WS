/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle.log.test;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.junit.internal.AbstractServiceTestCase;
import org.eclipse.soda.sat.core.junit.internal.bundle.Activator;
import org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord;
import org.eclipse.soda.sat.core.service.LogReaderAggregatorService;
import org.eclipse.soda.sat.core.util.FactoryUtility;
import org.eclipse.soda.sat.junit.util.ValueHolder;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.service.log.LogEntry;
import org.osgi.service.log.LogListener;
import org.osgi.service.log.LogReaderService;
import org.osgi.service.log.LogService;

public class LogReaderAggregatorTestCase extends AbstractServiceTestCase {
	private static class Log extends Object implements LogService, LogReaderService {
		private List entries = new ArrayList(100);
		private List listeners = new ArrayList(5);

		public void addLogListener(LogListener listener) {
			synchronized (listeners) {
				listeners.add(listener);
			}
		}

		private LogEntry createLogEntry(final ServiceReference reference, final int level, final String message, final Throwable exception) {
			final long now = System.currentTimeMillis();

			return new LogEntry() {
				public Bundle getBundle() {
					if (reference == null) return null;
					Bundle bundle = reference.getBundle();
					return bundle;
				}

				public Throwable getException() {
					return exception;
				}

				public int getLevel() {
					return level;
				}

				public String getMessage() {
					return message;
				}

				public ServiceReference getServiceReference() {
					return reference;
				}

				public long getTime() {
					return now;
				}
			};
		}

		public Enumeration getLog() {
			synchronized (this) {
				int size = entries.size();
				Vector vector = new Vector(size);

				for (int i = size - 1; i >= 0; i--) {
					LogEntry entry = (LogEntry) entries.get(i);
					vector.add(entry);
				}

				Enumeration enumeration = vector.elements();
				return enumeration;
			}
		}

		public void log(int level, String message) {
			log(null, level, message, null);
		}

		public void log(int level, String message, Throwable exception) {
			log(null, level, message, exception);
		}

		public void log(ServiceReference reference, int level, String message) {
			log(reference, level, message, null);
		}

		public void log(ServiceReference reference, int level, String message, Throwable exception) {
			LogEntry entry = createLogEntry(reference, level, message, exception);
			synchronized (this) {
				entries.add(entry);
			}
			notifyListeners(entry);
		}

		private void notifyListeners(LogEntry entry) {
			synchronized (listeners) {
				Iterator iterator = listeners.iterator();
				while (iterator.hasNext() == true) {
					LogListener listener = (LogListener) iterator.next();
					listener.logged(entry);
				}
			}
		}

		public void removeLogListener(LogListener listener) {
			synchronized (listeners) {
				listeners.remove(listener);
			}
		}
	}

	private static final String TEST_MESSAGE = "test";  //$NON-NLS-1$
	private static final String LOG_READER_SERVICE_NAME = LogReaderService.class.getName();

	public static Test suite() {
		return new TestSuite(LogReaderAggregatorTestCase.class);
	}

	private IExportServiceRecord logReaderService1;
	private IExportServiceRecord logReaderService2;

	public LogReaderAggregatorTestCase(String name) {
		super(name);
	}

	private List/*<String>*/ asListOfMessages(Enumeration/*<LogEntry*/ enumeration) {
		ArrayList/*<String>*/ list = new ArrayList/*<String>*/(100);

		while (enumeration.hasMoreElements() == true) {
			LogEntry entry = (LogEntry) enumeration.nextElement();
			String message = entry.getMessage();
			list.add(message);
		}

		list.trimToSize();
		return list;
	}

	private Runnable createLoggingRunnable(final Log log, final int count) {
		return new Runnable() {
			public void run() {
				LogReaderAggregatorTestCase.this.process(log, count);
			}
		};
	}

	private void drain(Enumeration enumeration) {
		while (enumeration.hasMoreElements() == true) {
			enumeration.nextElement();
		}
	}

	private Log getLog(IExportServiceRecord record) {
		Log log = null;

		synchronized (this) {
			if (record != null) {
				log = (Log) record.getService();
			}
		}

		return log;
	}

	private Log getLog1() {
		return getLog(logReaderService1);
	}

	private Log getLog2() {
		return getLog(logReaderService2);
	}

	private LogReaderAggregatorService getLogReaderAggregatorService() {
		return Activator.LOG_READER_AGGREGATOR_SERVICE;
	}

	private void joinWithLoggingThreads(List threads) throws InterruptedException {
		Iterator/*<Thread>*/ iterator = threads.iterator();

		while (iterator.hasNext() == true) {
			Thread thread = (Thread) iterator.next();
			thread.join();
		}
	}

	private void process(Log log, int count) {
		for (int i = 0; i < count; i++) {
			String message = String.valueOf(count);
			log.log(LogService.LOG_INFO, message);
			Thread.yield();
		}
	}

	private IExportServiceRecord registerLogReaderService(Log log) {
		FactoryUtility utility = FactoryUtility.getInstance();
		BundleContext bundleContext = getBundleContext();
		IExportServiceRecord record = utility.createExportServiceRecord(bundleContext, LogReaderAggregatorTestCase.LOG_READER_SERVICE_NAME, log, null);
		record.register();
		return record;
	}

	private void registerLogReaderService1() {
		synchronized (this) {
			if (logReaderService1 != null) return;  // Early return.
			Log log = new Log();
			logReaderService1 = registerLogReaderService(log);
		}
	}

	private void registerLogReaderService2() {
		synchronized (this) {
			if (logReaderService2 != null) return;  // Early return.
			Log log = new Log();
			logReaderService2 = registerLogReaderService(log);
		}
	}

	private Thread startLoggingThread(int id, Log log, int count) {
		Runnable runnable = createLoggingRunnable(log, count);
		String name = "LoggingThread-" + id;  //$NON-NLS-1$
		Thread thread = new Thread(runnable, name);
		thread.start();
		return thread;
	}

	private List startLoggingThreads(Log log, int count, int threadCount) {
		List/*<Thread>*/ threads = new ArrayList/*<Thread>*/(threadCount);

		for (int i = 0; i < threadCount; i++) {
			Thread thread = startLoggingThread(i, log, count);
			threads.add(thread);
		}
		return threads;
	}

	public void test_addLogListener() {
		final String loggedMessage = "message";  //$NON-NLS-1$
		final ValueHolder holder = ValueHolder.zeroValue();

		LogListener listener1 = new LogListener() {
			public void logged(LogEntry entry) {
				String message = entry.getMessage();
				boolean match = loggedMessage.equals(message);
				if (match == false) return;  // Early return.
				holder.increment();
			}
		};

		boolean state;

		state = holder.isZero();
		Assert.assertTrue(state);

		LogReaderAggregatorService aggregator = getLogReaderAggregatorService();

		try {
			registerLogReaderService1();
			aggregator.addLogListener(listener1);
			aggregator.addLogListener(listener1);
			Log log = getLog1();
			log.log(LogService.LOG_INFO, loggedMessage);
			int expectedValue = 1;
			int actualValue = holder.getIntValue();
			Assert.assertEquals(expectedValue, actualValue);

			holder.setZero();
			aggregator.removeLogListener(listener1);
			log.log(LogService.LOG_INFO, loggedMessage);
			state = holder.isZero();
			Assert.assertTrue(state);
		} finally {
			aggregator.removeLogListener(listener1);
			unregisterLogReaderService1();
		}
	}

	public void test_concurrent() throws Exception {
		final ValueHolder holder = ValueHolder.zeroValue();
		LogListener listener = new LogListener() {
			public void logged(LogEntry entry) {
				holder.increment();
			}
		};

		LogReaderAggregatorService aggregator = getLogReaderAggregatorService();

		try {
			registerLogReaderService1();
			Log log = getLog1();

			aggregator.addLogListener(listener);

			int count = 150;
			int threadCount = 3;

			List threads = startLoggingThreads(log, count, threadCount);
			joinWithLoggingThreads(threads);

			int expected;
			int actual;

			expected = count * threadCount;
			actual = holder.getIntValue();
			Assert.assertTrue(actual >= expected);

			aggregator.removeLogListener(listener);
		} finally {
			aggregator.removeLogListener(listener);
			unregisterLogReaderService1();
		}
	}

	public void test_count() {
		final ValueHolder holder = ValueHolder.zeroValue();
		LogListener listener = new LogListener() {
			public void logged(LogEntry entry) {
				holder.increment();
			}
		};

		LogReaderAggregatorService aggregator = getLogReaderAggregatorService();

		try {
			registerLogReaderService1();
			Log log = getLog1();

			aggregator.addLogListener(listener);

			log.log(LogService.LOG_INFO, "one");  //$NON-NLS-1$
			log.log(LogService.LOG_INFO, "two");  //$NON-NLS-1$
			log.log(LogService.LOG_INFO, "three");  //$NON-NLS-1$
			log.log(LogService.LOG_INFO, "four");  //$NON-NLS-1$

			int expected = 4;
			int actual = holder.getIntValue();
			Assert.assertTrue(actual >= expected);

			aggregator.removeLogListener(listener);
			holder.setZero();

			aggregator.addLogListener(listener);

			boolean state = holder.isZero();
			Assert.assertTrue(state);
		} finally {
			aggregator.removeLogListener(listener);
			unregisterLogReaderService1();
		}
	}

	public void test_drain() {
		Log log = new Log();
		log.log(LogService.LOG_INFO, "one");  //$NON-NLS-1$
		log.log(LogService.LOG_INFO, "two");  //$NON-NLS-1$
		log.log(LogService.LOG_INFO, "three");  //$NON-NLS-1$
		log.log(LogService.LOG_INFO, "four");  //$NON-NLS-1$

		final ValueHolder holder = ValueHolder.zeroValue();
		LogListener listener = new LogListener() {
			public void logged(LogEntry entry) {
				holder.increment();
			}
		};

		LogReaderAggregatorService aggregator = getLogReaderAggregatorService();
		IExportServiceRecord record = null;

		try {
			aggregator.addLogListener(listener);
			record = registerLogReaderService(log);

			int expected = 4;
			int actual = holder.getIntValue();
			Assert.assertTrue(actual >= expected);
		} finally {
			if (record != null) {
				record.unregister();
			}
			aggregator.removeLogListener(listener);
		}
	}
	public void test_getLog() {
		Enumeration enumeration;

		LogReaderAggregatorService aggregator = getLogReaderAggregatorService();
		enumeration = aggregator.getLog();
		drain(enumeration);

		try {
			registerLogReaderService1();
			registerLogReaderService2();

			Log log1 = getLog1();
			Log log2 = getLog1();

			log1.log(LogService.LOG_INFO, "one");  //$NON-NLS-1$
			log2.log(LogService.LOG_INFO, "two");  //$NON-NLS-1$
			log1.log(LogService.LOG_INFO, "three");  //$NON-NLS-1$
			log2.log(LogService.LOG_INFO, "four");  //$NON-NLS-1$

			enumeration = aggregator.getLog();
			List/*<String>*/ messages = asListOfMessages(enumeration);
			boolean exists;

			exists = messages.contains("four");  //$NON-NLS-1$
			Assert.assertTrue(exists);

			exists = messages.contains("three");  //$NON-NLS-1$
			Assert.assertTrue(exists);

			exists = messages.contains("two");  //$NON-NLS-1$
			Assert.assertTrue(exists);

			exists = messages.contains("one");  //$NON-NLS-1$
			Assert.assertTrue(exists);
		} finally {
			unregisterLogReaderService2();
			unregisterLogReaderService1();
		}
	}

	public void test_getLogInOrder() {
		Enumeration enumeration;

		LogReaderAggregatorService aggregator = getLogReaderAggregatorService();
		enumeration = aggregator.getLogInOrder();

		try {
			registerLogReaderService1();
			registerLogReaderService2();

			Log log1 = getLog1();
			Log log2 = getLog1();

			log1.log(LogService.LOG_INFO, "one");  //$NON-NLS-1$
			log2.log(LogService.LOG_INFO, "two");  //$NON-NLS-1$
			log1.log(LogService.LOG_INFO, "three");  //$NON-NLS-1$
			log2.log(LogService.LOG_INFO, "four");  //$NON-NLS-1$

			enumeration = aggregator.getLogInOrder();
			List/*<String>*/ messages = asListOfMessages(enumeration);
			boolean empty = messages.isEmpty();
			Assert.assertFalse(empty);

			int indexOfOne = messages.indexOf("one");  //$NON-NLS-1$
			int indexOfTwo = messages.indexOf("two");  //$NON-NLS-1$
			int indexOfThree = messages.indexOf("three");  //$NON-NLS-1$
			int indexOfFour = messages.indexOf("four");  //$NON-NLS-1$

			Assert.assertTrue(indexOfOne != -1);
			Assert.assertTrue(indexOfTwo != -1);
			Assert.assertTrue(indexOfThree != -1);
			Assert.assertTrue(indexOfFour != -1);

			Assert.assertTrue(indexOfOne < indexOfTwo);
			Assert.assertTrue(indexOfTwo < indexOfThree);
			Assert.assertTrue(indexOfThree < indexOfFour);
		} finally {
			unregisterLogReaderService2();
			unregisterLogReaderService1();
		}
	}

	public void test_multipleListeners() {
		final ValueHolder valueHolder1 = ValueHolder.falseValue();
		LogListener listener1 = new LogListener() {
			public void logged(LogEntry entry) {
				String message = entry.getMessage();
				boolean state = message.equals(LogReaderAggregatorTestCase.TEST_MESSAGE);
				if (state == true) {
					valueHolder1.setTrue();
				}
			}
		};

		final ValueHolder valueHolder2 = ValueHolder.falseValue();
		LogListener listener2 = new LogListener() {
			public void logged(LogEntry entry) {
				String message = entry.getMessage();
				boolean state = message.equals(LogReaderAggregatorTestCase.TEST_MESSAGE);
				if (state == true) {
					valueHolder2.setTrue();
				}
			}
		};

		LogReaderAggregatorService aggregator = getLogReaderAggregatorService();

		try {
			registerLogReaderService1();
			Log log = getLog1();

			aggregator.addLogListener(listener1);
			aggregator.addLogListener(listener2);

			log.log(LogService.LOG_INFO, LogReaderAggregatorTestCase.TEST_MESSAGE);
			delay(100); // Our test message might not have arrived yet.

			Object expectedValue = Boolean.TRUE;
			Object actualValue;

			actualValue = valueHolder1.getValue();
			Assert.assertEquals(expectedValue, actualValue);

			actualValue = valueHolder2.getValue();
			Assert.assertEquals(expectedValue, actualValue);
		} finally {
			unregisterLogReaderService1();
			aggregator.removeLogListener(listener2);
			aggregator.removeLogListener(listener1);
		}
	}

	public void test_multipleLogs() {
		final List/*<String>*/ messages = new ArrayList(6);
		LogListener listener = new LogListener() {
			public void logged(LogEntry entry) {
				synchronized (messages) {
					String message = entry.getMessage();
					messages.add(message);
				}
			}
		};

		LogReaderAggregatorService aggregator = getLogReaderAggregatorService();

		Log log1 = null;
		Log log2 = null;

		try {
			registerLogReaderService1();
			registerLogReaderService2();

			log1 = getLog1();
			log2 = getLog2();

			aggregator.addLogListener(listener);

			log1.log(LogService.LOG_INFO, "one");  //$NON-NLS-1$
			log1.log(LogService.LOG_INFO, "two");  //$NON-NLS-1$
			log2.log(LogService.LOG_INFO, "three");  //$NON-NLS-1$
			log2.log(LogService.LOG_INFO, "four");  //$NON-NLS-1$

			boolean state;

			state = messages.contains("one");  //$NON-NLS-1$
			Assert.assertTrue(state);

			state = messages.contains("two");  //$NON-NLS-1$
			Assert.assertTrue(state);

			state = messages.contains("three");  //$NON-NLS-1$
			Assert.assertTrue(state);

			state = messages.contains("four");  //$NON-NLS-1$
			Assert.assertTrue(state);
		} finally {
			unregisterLogReaderService2();
			unregisterLogReaderService1();

			aggregator.removeLogListener(listener);
		}

		int expectedSize = 4;
		int actualSize = messages.size();
		Assert.assertTrue(actualSize >= expectedSize);

		expectedSize = actualSize;
		log1.log(LogService.LOG_INFO, "info3");  //$NON-NLS-1$
		log2.log(LogService.LOG_INFO, "info4");  //$NON-NLS-1$
		actualSize = messages.size();
		Assert.assertEquals(expectedSize, actualSize);
	}

	public void test_simple() {
		try {
			registerLogReaderService1();
			Log log = getLog1();

			Enumeration enumeration;
			boolean state;

			enumeration = log.getLog();
			state = enumeration.hasMoreElements();
			Assert.assertFalse(state);

			log.log(LogService.LOG_INFO, LogReaderAggregatorTestCase.TEST_MESSAGE);

			enumeration = log.getLog();
			state = enumeration.hasMoreElements();
			Assert.assertTrue(state);

			LogEntry entry = (LogEntry) enumeration.nextElement();
			Assert.assertNotNull(entry);

			String expectedMessage = LogReaderAggregatorTestCase.TEST_MESSAGE;
			String actualMessage = entry.getMessage();
			Assert.assertEquals(expectedMessage, actualMessage);

			int expectedLevel = LogService.LOG_INFO;
			int actualLevel = entry.getLevel();
			Assert.assertEquals(expectedLevel, actualLevel);

			long now = System.currentTimeMillis();
			long actualTime = entry.getTime();
			boolean beforeNow = actualTime <= now;
			Assert.assertTrue(beforeNow);

			state = enumeration.hasMoreElements();
			Assert.assertFalse(state);
		} finally {
			unregisterLogReaderService1();
		}
	}

	public void test_simpleException() {
		try {
			registerLogReaderService1();
			Log log = getLog1();

			Enumeration enumeration;
			boolean state;

			enumeration = log.getLog();
			state = enumeration.hasMoreElements();
			Assert.assertFalse(state);

			Throwable exception = new RuntimeException();
			log.log(LogService.LOG_INFO, "error", exception);  //$NON-NLS-1$

			enumeration = log.getLog();
			state = enumeration.hasMoreElements();
			Assert.assertTrue(state);

			LogEntry entry = (LogEntry) enumeration.nextElement();
			Assert.assertNotNull(entry);

			Throwable actualException = entry.getException();
			Assert.assertSame(exception, actualException);

			state = enumeration.hasMoreElements();
			Assert.assertFalse(state);
		} finally {
			unregisterLogReaderService1();
		}
	}

	private void unregisterLogReaderService1() {
		synchronized (this) {
			if (logReaderService1 == null) return;  // Early return.
			logReaderService1.unregister();
			logReaderService1 = null;
		}
	}

	private void unregisterLogReaderService2() {
		synchronized (this) {
			if (logReaderService2 == null) return;  // Early return.
			logReaderService2.unregister();
			logReaderService2 = null;
		}
	}
}
