/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle.cm.test.hotdog;

public class HotdogVendor extends Object implements VendorService {
	private String id;
	private int spiciness;

	public HotdogVendor(String id, int spiciness) {
		super();
		setId(id);
		setSpiciness(spiciness);
	}

	public String getId() {
		return id;
	}

	public Object getName() {
		return "Ball Park"; //$NON-NLS-1$
	}

	public int getSpiciness() {
		return spiciness;
	}

	public String sell() {
		return "Spicy Hotdog (" + getSpiciness() + ')'; //$NON-NLS-1$
	}

	private void setId(String id) {
		this.id = id;
	}

	public void setSpiciness(int spiciness) {
		this.spiciness = spiciness;
	}

	public String toString() {
		return super.toString() + ", id=" + getId() + ", spiciness=" + getSpiciness(); //$NON-NLS-1$ //$NON-NLS-2$
	}
}
