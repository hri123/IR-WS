/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle.cm.test.customer;

import java.util.Dictionary;

import org.eclipse.soda.sat.core.framework.BaseManagedServiceFactoryAdvisor;
import org.eclipse.soda.sat.core.framework.interfaces.IBundleActivationManager;
import org.eclipse.soda.sat.core.framework.interfaces.IManagedServiceFactoryAdvisor;
import org.eclipse.soda.sat.core.internal.framework.bundle.cm.test.hotdog.VendorService;
import org.eclipse.soda.sat.core.junit.internal.cm.AbstractManagedServiceFactoryActivationDelegate;
import org.osgi.service.cm.ConfigurationException;

public class CustomerManagedServiceFactory extends AbstractManagedServiceFactoryActivationDelegate {
	public CustomerManagedServiceFactory(String pid, String location) {
		super(pid, location);
	}

	private Object create(String pid, Dictionary properties, IBundleActivationManager manager) {
		String id = getId(properties);
		Customer customer = new Customer(id);
		int spiciness = getSpiciness(properties);
		customer.setSpiciness(spiciness);
		VendorService vendor = (VendorService) manager.getImportedService(VendorService.SERVICE_NAME);
		customer.setVendor(vendor);
		customer.eat();
		addObjectWithId(id, customer);
		return customer;
	}

	protected IManagedServiceFactoryAdvisor createAdvisor() {
		return new BaseManagedServiceFactoryAdvisor(){
			public Object create(String pid, Dictionary properties, IBundleActivationManager manager) {
				return CustomerManagedServiceFactory.this.create(pid, properties, manager);
			}

			public void createImportedServiceFilters(String pid, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager) {
				CustomerManagedServiceFactory.this.createImportedServiceFilters(pid, oldProperties, properties, manager);
			}

			public void destroy(String pid, Object object, Dictionary properties, IBundleActivationManager manager) {
				CustomerManagedServiceFactory.this.destroy(pid, object, properties, manager);
			}

			public String[] getImportedServiceNames(String pid, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager) {
				return CustomerManagedServiceFactory.this.getImportedServiceNames(pid, oldProperties, properties, manager);
			}

			public Object update(String pid, Object object, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager) {
				return CustomerManagedServiceFactory.this.update(pid, object, oldProperties, properties, manager);
			}

			public void validateConfiguration(String pid, Dictionary properties) throws ConfigurationException {
				CustomerManagedServiceFactory.this.validateConfiguration(pid, properties);
			}
		};
	}

	private void createImportedServiceFilters(String pid, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager) {
		int spiciness = getSpiciness(properties);
		String filter = '(' + VendorService.SPICINESS_PROPERTY_KEY + '=' + spiciness + ')';
		manager.addImportedServiceFilter(VendorService.SERVICE_NAME, filter);
	}

	private void destroy(String pid, Object object, Dictionary properties, IBundleActivationManager manager) {
		Customer customer = (Customer) object;
		customer.setVendor(null);
		String id = customer.getId();
		removeObjectWithId(id);
	}

	private String[] getImportedServiceNames(String pid, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager) {
		return new String[] {
			VendorService.SERVICE_NAME
		};
	}

	private int getSpiciness(Dictionary properties) {
		Integer wrapper = (Integer) properties.get(Customer.SPICINESS_PROPERTY_KEY);
		int spiciness = wrapper.intValue();
		return spiciness;
	}

	private Object update(String pid, Object object, Dictionary oldProperties, Dictionary properties, IBundleActivationManager manager) {
		Customer customer = (Customer) object;
		int spiciness = CustomerManagedServiceFactory.this.getSpiciness(properties);
		customer.setSpiciness(spiciness);
		updated(customer);
		return customer;
	}

	private void validateConfiguration(String pid, Dictionary properties) throws ConfigurationException {
		// No-op
	}
}
