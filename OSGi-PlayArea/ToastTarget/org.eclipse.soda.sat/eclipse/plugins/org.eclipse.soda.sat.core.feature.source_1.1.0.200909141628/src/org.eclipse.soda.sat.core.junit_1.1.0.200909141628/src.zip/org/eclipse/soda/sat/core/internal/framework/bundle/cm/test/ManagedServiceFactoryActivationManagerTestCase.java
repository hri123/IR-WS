/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle.cm.test;

import java.io.IOException;
import java.util.Dictionary;
import java.util.Hashtable;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.internal.framework.bundle.cm.test.customer.Customer;
import org.eclipse.soda.sat.core.internal.framework.bundle.cm.test.customer.CustomerManagedServiceFactory;
import org.eclipse.soda.sat.core.internal.framework.bundle.cm.test.hotdog.HotdogVendor;
import org.eclipse.soda.sat.core.internal.framework.bundle.cm.test.hotdog.HotdogVendorManagedServiceFactory;
import org.eclipse.soda.sat.core.internal.framework.bundle.cm.test.hotdog.VendorService;
import org.eclipse.soda.sat.core.junit.internal.cm.AbstractManagedServiceFactoryActivationManagerTestCase;
import org.eclipse.soda.sat.core.junit.internal.cm.ConfigurationAdminConfigurator;
import org.eclipse.soda.sat.core.junit.internal.cm.IManagedServiceFactoryActivationDelegate;
import org.osgi.framework.BundleContext;
import org.osgi.service.cm.Configuration;

public class ManagedServiceFactoryActivationManagerTestCase extends AbstractManagedServiceFactoryActivationManagerTestCase {
	private static final Integer FIVE = new Integer(5);

	public static Test suite() {
		return new TestSuite(ManagedServiceFactoryActivationManagerTestCase.class);
	}

	private IManagedServiceFactoryActivationDelegate hotdogVendorFactory;
	private IManagedServiceFactoryActivationDelegate customerFactory;

	public ManagedServiceFactoryActivationManagerTestCase(String name) {
		super(name);
	}

	private Configuration createCustomerConfiguration(Object id, int spiciness) throws IOException, InterruptedException {
		Dictionary properties = new Hashtable(17);
		properties.put(IManagedServiceFactoryActivationDelegate.ID_PROPERTY_KEY, id);
		properties.put(Customer.SPICINESS_PROPERTY_KEY, new Integer(spiciness));
		IManagedServiceFactoryActivationDelegate factory = getCustomerFactory();
		Configuration configuration = createConfiguration(factory, id, properties);
		return configuration;
	}

	private IManagedServiceFactoryActivationDelegate createCustomerManagedServiceFactory() {
		String location = getLocation();
		IManagedServiceFactoryActivationDelegate factory = new CustomerManagedServiceFactory("CustomerFactory", location); //$NON-NLS-1$
		return factory;
	}

	private Configuration createHogdogVendorConfiguration(Object id, int spiciness) throws IOException, InterruptedException {
		Dictionary properties = new Hashtable(17);
		properties.put(IManagedServiceFactoryActivationDelegate.ID_PROPERTY_KEY, id);
		properties.put(VendorService.SPICINESS_PROPERTY_KEY, new Integer(spiciness));
		IManagedServiceFactoryActivationDelegate factory = getHotdogVendorFactory();
		Configuration configuration = createConfiguration(factory, id, properties);
		return configuration;
	}

	private IManagedServiceFactoryActivationDelegate createHotdogVendorManagedServiceFactory() {
		String location = getLocation();
		IManagedServiceFactoryActivationDelegate factory = new HotdogVendorManagedServiceFactory("HotdogVendorFactory", location); //$NON-NLS-1$
		return factory;
	}

	private IManagedServiceFactoryActivationDelegate getCustomerFactory() {
		synchronized (this) {
			if (customerFactory == null) {
				IManagedServiceFactoryActivationDelegate factory = createCustomerManagedServiceFactory();
				setCustomerFactory(factory);
			}
		}

		return customerFactory;
	}

	private IManagedServiceFactoryActivationDelegate getHotdogVendorFactory() {
		synchronized (this) {
			if (hotdogVendorFactory == null) {
				IManagedServiceFactoryActivationDelegate factory = createHotdogVendorManagedServiceFactory();
				setHotdogVendorFactory(factory);
			}
		}

		return hotdogVendorFactory;
	}

	private void setCustomerFactory(IManagedServiceFactoryActivationDelegate customerFactory) {
		this.customerFactory = customerFactory;
	}

	private void setHotdogVendorFactory(IManagedServiceFactoryActivationDelegate hotdogVendorFactory) {
		this.hotdogVendorFactory = hotdogVendorFactory;
	}

	private void startCustomerFactory() throws Exception {
		IManagedServiceFactoryActivationDelegate factory = getCustomerFactory();
		BundleContext context = getBundleContext();
		factory.start(context);
	}

	private void startHotdogVendorFactory() throws Exception {
		IManagedServiceFactoryActivationDelegate factory = getHotdogVendorFactory();
		BundleContext context = getBundleContext();
		factory.start(context);
	}

	private void stopCustomerFactory() throws Exception {
		IManagedServiceFactoryActivationDelegate factory = getCustomerFactory();
		BundleContext context = getBundleContext();
		factory.stop(context);
	}

	private void stopHotdogVendorFactory() throws Exception {
		IManagedServiceFactoryActivationDelegate factory = getHotdogVendorFactory();
		BundleContext context = getBundleContext();
		factory.stop(context);
	}

	public void test() throws Exception {
		Object object;
		Object id;

		VendorService vendor;
		Customer customer;

		int expectedSpiciness;
		int actualSpiciness;

		try {
			startHotdogVendorFactory();
			startCustomerFactory();
	
			// Create a HotdogVendor with spiciness of 5
			Object hotdog1Id = "HD1"; //$NON-NLS-1$
			int hotdog1Spiciness = 5;
			Configuration hotdog1Configuration = createHogdogVendorConfiguration(hotdog1Id, hotdog1Spiciness);
	
			// Check HotdogVendor with ID 1 was created.
			id = hotdog1Id;
			object = hotdogVendorFactory.getObjectWithId(id);
			Assert.assertTrue(object instanceof VendorService);
			Assert.assertTrue(object instanceof HotdogVendor);
			vendor = (VendorService) object;
			expectedSpiciness = hotdog1Spiciness;
			actualSpiciness = vendor.getSpiciness();
			Assert.assertEquals(expectedSpiciness, actualSpiciness);
	
			// Create a HotdogVendor with spiciness of 10
			Object hotdog2Id = "HD2"; //$NON-NLS-1$
			int hotdog2Spiciness = 10;
			Configuration hotdog2Configuration = createHogdogVendorConfiguration(hotdog2Id, hotdog2Spiciness);
	
			// Check HotdogVendor with ID 2 was created.
			id = hotdog2Id;
			object = hotdogVendorFactory.getObjectWithId(id);
			Assert.assertTrue(object instanceof VendorService);
			Assert.assertTrue(object instanceof HotdogVendor);
			vendor = (VendorService) object;
			expectedSpiciness = hotdog2Spiciness;
			actualSpiciness = vendor.getSpiciness();
			Assert.assertEquals(expectedSpiciness, actualSpiciness);
	
			// Create a Customer with ID C1 that wants a VendorService with spiciness of 5.
			Object customer1Id = "C1"; //$NON-NLS-1$
			int customer1Spiciness = 5;
			Configuration customer1Configuration = createCustomerConfiguration(customer1Id, customer1Spiciness);
	
			// Check Customer with ID C1 was created.
			id = customer1Id;
			object = customerFactory.getObjectWithId(id);
			Assert.assertTrue(object instanceof Customer);
	
			// Check Customer with ID C1 has a spiciness of 5.
			customer = (Customer) object;
			expectedSpiciness = customer1Spiciness;
			actualSpiciness = customer.getSpiciness();
			Assert.assertEquals(expectedSpiciness, actualSpiciness);
	
			// Check Customer with ID C1 has a Vendor with spiciness of 5.
			vendor = customer.getVendor();
			expectedSpiciness = customer.getSpiciness();
			actualSpiciness = vendor.getSpiciness();
			Assert.assertEquals(expectedSpiciness, actualSpiciness);
	
			// Create a Customer wanting VendorService with spiciness of 10.
			Object customer2Id = "C2"; //$NON-NLS-1$
			int customer2Spiciness = 10;
			Configuration customer2Configuration = createCustomerConfiguration(customer2Id, customer2Spiciness);
	
			// Check Customer with ID C2 was created.
			id = customer2Id;
			object = customerFactory.getObjectWithId(id);
			Assert.assertTrue(object instanceof Customer);
	
			// Check Customer with ID C2 has a spiciness of 10.
			customer = (Customer) object;
			expectedSpiciness = customer2Spiciness;
			actualSpiciness = customer.getSpiciness();
			Assert.assertEquals(expectedSpiciness, actualSpiciness);
	
			// Check Customer with ID C2 has a Vendor with spiciness of 10.
			vendor = customer.getVendor();
			expectedSpiciness = customer.getSpiciness();
			actualSpiciness = vendor.getSpiciness();
			Assert.assertEquals(expectedSpiciness, actualSpiciness);
	
			ConfigurationAdminConfigurator configurator = getConfigurator();
	
			// Delete the Customer wanting a VendorService with spiciness of 10.
			configurator.delete(customerFactory, customer2Id, customer2Configuration);
			object = customerFactory.getObjectWithId(customer2Id);
			Assert.assertNull(object);
	
			// Delete the Customer wanting VendorService with spiciness of 5.
			configurator.delete(customerFactory, customer1Id, customer1Configuration);
			object = customerFactory.getObjectWithId(customer1Id);
			Assert.assertNull(object);
	
			// Delete the HotdogVendor with spiciness of 10
			configurator.delete(hotdogVendorFactory, hotdog2Id, hotdog2Configuration);
			object = hotdogVendorFactory.getObjectWithId(hotdog2Id);
			Assert.assertNull(object);
	
			// Delete the HotdogVendor with spiciness of 5
			configurator.delete(hotdogVendorFactory, hotdog1Id, hotdog1Configuration);
			object = hotdogVendorFactory.getObjectWithId(hotdog1Id);
			Assert.assertNull(object);
		} finally {
			stopCustomerFactory();
			stopHotdogVendorFactory();
		}
	}

//	public void testXXXX() throws Exception {
//		try {
//			startHotdogVendorFactory();
//			startCustomerFactory();
//	
//			// Create a HotdogVendor with spiciness of 5
//			Object hotdog1Id = "HD1x"; //$NON-NLS-1$
//			int hotdog1Spiciness = 5;
////			createHogdogVendorConfiguration(hotdog1Id, hotdog1Spiciness);
//	
//			// Create a HotdogVendor with spiciness of 10
//			Object hotdog2Id = "HD2x"; //$NON-NLS-1$
//			int hotdog2Spiciness = 10;
////			createHogdogVendorConfiguration(hotdog2Id, hotdog2Spiciness);
//		
//			// Create a Customer with ID C1 that wants a VendorService with spiciness of 5.
//			Object customer1Id = "C1x"; //$NON-NLS-1$
//			int customer1Spiciness = 5;
//			createCustomerConfiguration(customer1Id, customer1Spiciness);
//		
//			// Create a Customer wanting VendorService with spiciness of 10.
//			Object customer2Id = "C2x"; //$NON-NLS-1$
//			int customer2Spiciness = 10;
//			createCustomerConfiguration(customer2Id, customer2Spiciness);
//		
////			ConfigurationAdminConfigurator configurator = getConfigurator();
////	
////			// Delete the Customer wanting a VendorService with spiciness of 10.
////			configurator.delete(customerFactory, customer2Id, customer2Configuration);
////			
////			// Delete the Customer wanting VendorService with spiciness of 5.
////			configurator.delete(customerFactory, customer1Id, customer1Configuration);
////	
////			// Delete the HotdogVendor with spiciness of 10
////			configurator.delete(hotdogVendorFactory, hotdog2Id, hotdog2Configuration);
////	
////			// Delete the HotdogVendor with spiciness of 5
////			configurator.delete(hotdogVendorFactory, hotdog1Id, hotdog1Configuration);
//		} finally {
////			stopCustomerFactory();
////			stopHotdogVendorFactory();
//		}
//	}
	
	public void test_create() throws Exception {
		Object object;
		Object id;

		VendorService vendor;

		int expectedSpiciness;
		int actualSpiciness;

		try {
			startHotdogVendorFactory();
	
			// Create a HotdogVendor with spiciness of 5
			Object hotdog1Id = "HD1"; //$NON-NLS-1$
			int hotdog1Spiciness = 5;
			Configuration hotdog1Configuration = createHogdogVendorConfiguration(hotdog1Id, hotdog1Spiciness);
	
			// Check HotdogVendor with ID 1 was created.
			id = hotdog1Id;
			object = hotdogVendorFactory.getObjectWithId(id);
			Assert.assertTrue(object instanceof VendorService);
			Assert.assertTrue(object instanceof HotdogVendor);
			vendor = (VendorService) object;
			expectedSpiciness = hotdog1Spiciness;
			actualSpiciness = vendor.getSpiciness();
			Assert.assertEquals(expectedSpiciness, actualSpiciness);
	
			// Create a HotdogVendor with spiciness of 10
			Object hotdog2Id = "HD2"; //$NON-NLS-1$
			int hotdog2Spiciness = 10;
			Configuration hotdog2Configuration = createHogdogVendorConfiguration(hotdog2Id, hotdog2Spiciness);
	
			// Check HotdogVendor with ID 2 was created.
			id = hotdog2Id;
			object = hotdogVendorFactory.getObjectWithId(id);
			Assert.assertTrue(object instanceof VendorService);
			Assert.assertTrue(object instanceof HotdogVendor);
			vendor = (VendorService) object;
			expectedSpiciness = hotdog2Spiciness;
			actualSpiciness = vendor.getSpiciness();
			Assert.assertEquals(expectedSpiciness, actualSpiciness);
	
			ConfigurationAdminConfigurator admin = getConfigurator();
			IManagedServiceFactoryActivationDelegate factory = getHotdogVendorFactory();
	
			admin.delete(factory, hotdog1Id, hotdog1Configuration);
			admin.delete(factory, hotdog2Id, hotdog2Configuration);
		} finally {
			stopHotdogVendorFactory();
		}
	}

	public void test_createWithDependenciesAcquired() throws Exception {
		Object object;
		Object id;

		VendorService vendor;
		Customer customer;

		int expectedSpiciness;
		int actualSpiciness;

		Object hotdog1Id = "HD1"; //$NON-NLS-1$
		Object hotdog2Id = "HD2"; //$NON-NLS-1$
		Object customer1Id = "C1"; //$NON-NLS-1$
		Object customer2Id = "C2"; //$NON-NLS-1$
		
		Configuration hotdog1Configuration = null;
		Configuration hotdog2Configuration = null;
		Configuration customer1Configuration = null;
		Configuration customer2Configuration = null;

		try {
			startHotdogVendorFactory();
			startCustomerFactory();
	
			// Create a HotdogVendor with spiciness of 5
			int hotdog1Spiciness = 5;
			hotdog1Configuration = createHogdogVendorConfiguration(hotdog1Id, hotdog1Spiciness);
	
			// Create a HotdogVendor with spiciness of 10
			int hotdog2Spiciness = 10;
			hotdog2Configuration = createHogdogVendorConfiguration(hotdog2Id, hotdog2Spiciness);
	
			// Create a Customer with ID C1 that wants a VendorService with spiciness of 5.
			int customer1Spiciness = 5;
			customer1Configuration = createCustomerConfiguration(customer1Id, customer1Spiciness);
	
			// Check Customer with ID C1 was created.
			id = customer1Id;
			object = customerFactory.getObjectWithId(id);
			Assert.assertTrue(object instanceof Customer);
	
			// Check Customer with ID C1 has a spiciness of 5.
			customer = (Customer) object;
			expectedSpiciness = customer1Spiciness;
			actualSpiciness = customer.getSpiciness();
			Assert.assertEquals(expectedSpiciness, actualSpiciness);
	
			// Check Customer with ID C1 has a Vendor with spiciness of 5.
			vendor = customer.getVendor();
			expectedSpiciness = customer.getSpiciness();
			actualSpiciness = vendor.getSpiciness();
			Assert.assertEquals(expectedSpiciness, actualSpiciness);
	
			// Create a Customer wanting VendorService with spiciness of 10.
			int customer2Spiciness = 10;
			customer2Configuration = createCustomerConfiguration(customer2Id, customer2Spiciness);
	
			// Check Customer with ID C2 was created.
			id = customer2Id;
			object = customerFactory.getObjectWithId(id);
			Assert.assertTrue(object instanceof Customer);
	
			// Check Customer with ID C2 has a spiciness of 10.
			customer = (Customer) object;
			expectedSpiciness = customer2Spiciness;
			actualSpiciness = customer.getSpiciness();
			Assert.assertEquals(expectedSpiciness, actualSpiciness);
	
			// Check Customer with ID C2 has a Vendor with spiciness of 10.
			vendor = customer.getVendor();
			expectedSpiciness = customer.getSpiciness();
			actualSpiciness = vendor.getSpiciness();
			Assert.assertEquals(expectedSpiciness, actualSpiciness);
		} finally {
			ConfigurationAdminConfigurator admin = getConfigurator();
			IManagedServiceFactoryActivationDelegate factory;
			
			factory = getHotdogVendorFactory();
			admin.delete(factory, hotdog1Id, hotdog1Configuration);
			admin.delete(factory, hotdog2Id, hotdog2Configuration);
			stopHotdogVendorFactory();
			
			factory = getCustomerFactory();
			admin.delete(factory, customer1Id, customer1Configuration);
			admin.delete(factory, customer2Id, customer2Configuration);
			stopCustomerFactory();
		}
	}

	public void test_createWithDependenciesLost() throws Exception {
		startHotdogVendorFactory();
		startCustomerFactory();

		// Create a HotdogVendor with spiciness of 5
		Object hotdog1Id = "HD1"; //$NON-NLS-1$
		int hotdog1Spiciness = 5;
		Configuration hotdog1Configuration = createHogdogVendorConfiguration(hotdog1Id, hotdog1Spiciness);

		// Create a HotdogVendor with spiciness of 10
		Object hotdog2Id = "HD2"; //$NON-NLS-1$
		int hotdog2Spiciness = 10;
		Configuration hotdog2Configuration = createHogdogVendorConfiguration(hotdog2Id, hotdog2Spiciness);

		// Create a Customer with ID C1 that wants a VendorService with spiciness of 5.
		Object customer1Id = "C1"; //$NON-NLS-1$
		int customer1Spiciness = 5;
		Configuration customer1Configuration = createCustomerConfiguration(customer1Id, customer1Spiciness);

		// Create a Customer wanting VendorService with spiciness of 10.
		Object customer2Id = "C2"; //$NON-NLS-1$
		int customer2Spiciness = 10;
		Configuration customer2Configuration = createCustomerConfiguration(customer2Id, customer2Spiciness);

		ConfigurationAdminConfigurator configurator = getConfigurator();
		Object object;

		// Delete the HotdogVendor with spiciness of 10
		configurator.delete(hotdogVendorFactory, hotdog2Id, hotdog2Configuration);
		object = hotdogVendorFactory.getObjectWithId(hotdog2Id);
		Assert.assertNull(object);

		object = customerFactory.getObjectWithId(customer2Id);
		Assert.assertNull(object);

		Dictionary customer2Properties = customer2Configuration.getProperties();
		customer2Properties.put(Customer.SPICINESS_PROPERTY_KEY, ManagedServiceFactoryActivationManagerTestCase.FIVE);
		configurator.update(customerFactory, customer2Properties, customer2Configuration);
		object = customerFactory.getObjectWithId(customer2Id);
		Assert.assertNotNull(object);

		// Delete the HotdogVendor with spiciness of 5
		configurator.delete(hotdogVendorFactory, hotdog1Id, hotdog1Configuration);
		object = hotdogVendorFactory.getObjectWithId(hotdog1Id);
		Assert.assertNull(object);

		object = customerFactory.getObjectWithId(customer1Id);
		Assert.assertNull(object);

		object = customerFactory.getObjectWithId(customer2Id);
		Assert.assertNull(object);

		configurator.delete(customerFactory, customer1Id, customer1Configuration);
		configurator.delete(customerFactory, customer2Id, customer2Configuration);

		stopCustomerFactory();
		stopHotdogVendorFactory();
	}

	public void test_delete() throws Exception {
		startHotdogVendorFactory();

		// Create a HotdogVendor with spiciness of 5
		Object hotdog1Id = "HD1"; //$NON-NLS-1$
		Configuration hotdog1Configuration = createHogdogVendorConfiguration(hotdog1Id, 5);

		// Create a HotdogVendor with spiciness of 10
		Object hotdog2Id = "HD2"; //$NON-NLS-1$
		Configuration hotdog2Configuration = createHogdogVendorConfiguration(hotdog2Id, 10);

		ConfigurationAdminConfigurator configurator = getConfigurator();
		Object object;

		// Delete the HotdogVendor with spiciness of 10
		configurator.delete(hotdogVendorFactory, hotdog2Id, hotdog2Configuration);
		object = hotdogVendorFactory.getObjectWithId(hotdog2Id);
		Assert.assertNull(object);

		// Delete the HotdogVendor with spiciness of 5
		configurator.delete(hotdogVendorFactory, hotdog1Id, hotdog1Configuration);
		object = hotdogVendorFactory.getObjectWithId(hotdog1Id);
		Assert.assertNull(object);

		stopHotdogVendorFactory();
	}
}
