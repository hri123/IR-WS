/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.record.test;

import java.util.Dictionary;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;
import org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord;
import org.osgi.framework.BundleContext;

public class ExportServiceRecordTestCase extends AbstractExportServiceRecordTestCase {
	public static Test suite() {
		return new TestSuite(ExportServiceRecordTestCase.class);
	}

	public ExportServiceRecordTestCase(String name) {
		super(name);
	}

	protected IExportServiceRecord createExportServiceRecord(BundleContext context, Class[] types, Dictionary properties) {
		String[] names = toStringArray(types);
		Object service = getService();
		IExportServiceRecord record = AbstractSatTestCase.FACTORY.createExportServiceRecord(context, names, service, properties);
		return record;
	}

	public void test_getService() {
		BundleContext context = getBundleContext();
		Class[] types = { TestService1.class };
		IExportServiceRecord record = createExportServiceRecord(context, types, null);

		Object expected = getService();
		Object actual;

		actual = record.getService();
		Assert.assertSame(expected, actual);

		record.register();

		actual = record.getService();
		Assert.assertSame(expected, actual);

		record.unregister();

		actual = record.getService();
		Assert.assertSame(expected, actual);
	}

	public void test_isProxy() {
		BundleContext context = getBundleContext();
		Class[] types = { TestService1.class };
		IExportServiceRecord record = createExportServiceRecord(context, types, null);
		boolean isProxy = record.isProxy();
		Assert.assertFalse(isProxy);
	}
}
