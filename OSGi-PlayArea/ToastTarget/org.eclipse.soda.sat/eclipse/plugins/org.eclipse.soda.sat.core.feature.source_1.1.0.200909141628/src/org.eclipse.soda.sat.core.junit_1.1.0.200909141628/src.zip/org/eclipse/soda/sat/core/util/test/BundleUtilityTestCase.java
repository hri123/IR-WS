/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.util.test;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.junit.internal.AbstractServiceTestCase;
import org.eclipse.soda.sat.core.util.BundleUtility;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.framework.ServiceReference;
import org.osgi.framework.ServiceRegistration;

public class BundleUtilityTestCase extends AbstractServiceTestCase {
	private interface TestService1 {
		public static final String SERVICE_NAME = TestService1.class.getName();
	}

	private interface TestService2 {
		public static final String SERVICE_NAME = TestService2.class.getName();
	}

	private static class TestServiceImplementation extends Object implements TestService1, TestService2 { // $codepro.audit.disable convertClassToInterface, com.instantiations.assist.eclipse.analysis.emptyClass
		//...
	}

	public static Test suite() {
		return new TestSuite(BundleUtilityTestCase.class);
	}

	private ServiceRegistration registration;

	public BundleUtilityTestCase(String name) {
		super(name);
	}

	private void registerTestService() {
		TestService1 service = new TestServiceImplementation();
		BundleContext context = getBundleContext();
		registration = context.registerService(TestService1.SERVICE_NAME, service, null);
	}

	public void test_getServiceInstanceOf() {
		BundleUtility utility = BundleUtility.getInstance();
		Bundle bundle = getBundle();
		ServiceReference reference;

		// Positive case
		registerTestService();
		reference = utility.getServiceInstanceOf(bundle, TestService1.SERVICE_NAME);
		Object[] objectClasses = (Object[]) reference.getProperty(Constants.OBJECTCLASS);

		int size = objectClasses.length;
		Assert.assertEquals(1, size);

		Object serviceName = objectClasses [ 0 ];
		Assert.assertEquals(TestService1.SERVICE_NAME, serviceName);

		unregisterTestService();

		// Negative case
		reference = utility.getServiceInstanceOf(bundle, TestService1.SERVICE_NAME);
		Assert.assertNull(reference);
	}

	public void test_isBundleState() {
		BundleUtility utility = BundleUtility.getInstance();
		Bundle bundle = getBundle();
		boolean value = utility.isBundleState(bundle, Bundle.ACTIVE);
		Assert.assertTrue(value);
	}

	public void test_isRegisteredService() {
		BundleContext context = getBundleContext();
		BundleUtility utility = BundleUtility.getInstance();
		Bundle bundle = getBundle();

		registerTestService();
		boolean registered;

		// Get the ServiceReference
		ServiceReference reference = context.getServiceReference(TestService1.SERVICE_NAME);

		// Using ServiceReference
		Assert.assertNotNull(reference);
		registered = utility.isRegisteredService(bundle, reference);
		Assert.assertTrue(registered);

		// Using service name String
		Assert.assertNotNull(reference);
		registered = utility.isRegisteredService(bundle, TestService1.SERVICE_NAME);
		Assert.assertTrue(registered);

		unregisterTestService();
	}

	public void test_isServiceInUse() {
		registerTestService();
		BundleContext context = getBundleContext();

		// Get the ServiceReference
		ServiceReference reference = context.getServiceReference(TestService1.SERVICE_NAME);
		Assert.assertNotNull(reference);

		// Get the service
		Object service = context.getService(reference);
		Assert.assertNotNull(service);

		boolean inUse;
		BundleUtility utility = BundleUtility.getInstance();
		Bundle bundle = getBundle();

		// Positive case
		inUse = utility.isServiceInUse(bundle, reference);
		Assert.assertTrue(inUse);

		context.ungetService(reference);

		// Negative case
		Assert.assertNotNull(reference);
		inUse = utility.isServiceInUse(bundle, reference);
		Assert.assertFalse(inUse);

		context.ungetService(reference);
		unregisterTestService();
	}

	public void test_toBundleStateString() {
		BundleUtility utility = BundleUtility.getInstance();
		Bundle bundle = getBundle();
		String expected = "ACTIVE"; //$NON-NLS-1$
		String actual = utility.toBundleStateString(bundle);
		Assert.assertEquals(expected, actual);
	}

	private void unregisterTestService() {
		if (registration == null) return;  // Early return.
		registration.unregister();
		registration = null;
	}
}
