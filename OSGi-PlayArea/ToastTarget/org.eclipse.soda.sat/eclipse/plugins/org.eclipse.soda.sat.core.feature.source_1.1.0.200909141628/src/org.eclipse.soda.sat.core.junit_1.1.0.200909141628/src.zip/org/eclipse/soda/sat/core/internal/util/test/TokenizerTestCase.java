/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.util.test;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.framework.interfaces.ITokenizer;
import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;

public class TokenizerTestCase extends AbstractSatTestCase {
	private static final String ONE = "one";  //$NON-NLS-1$
	private static final String TWO = "two";  //$NON-NLS-1$
	private static final String THREE = "three";  //$NON-NLS-1$
	private static final String ONE_TWO_THREE =
		TokenizerTestCase.ONE + TokenizerTestCase.COMMA +
		TokenizerTestCase.TWO + TokenizerTestCase.COMMA +
		TokenizerTestCase.THREE;
	private static final char COMMA = ',';
	private static final char SPACE = ' ';

	public static Test suite() {
		return new TestSuite(TokenizerTestCase.class);
	}

	public TokenizerTestCase(String name) {
		super(name);
	}

	private void _test_nextToken(String value, char delimiter) {
		ITokenizer tokenizer = createTokenizer(value, delimiter);
		List tokens = new ArrayList(5);

		while (tokenizer.hasMoreTokens() == true) {
			String token = tokenizer.nextToken();
			tokens.add(token);
		}

		Object actual;

		actual = tokens.get(0);
		Assert.assertEquals(TokenizerTestCase.ONE, actual);

		actual = tokens.get(1);
		Assert.assertEquals(TokenizerTestCase.TWO, actual);

		actual = tokens.get(2);
		Assert.assertEquals(TokenizerTestCase.THREE, actual);

		actual = tokenizer.nextToken();
		Assert.assertEquals(null, actual);
	}

	private Runnable createRunnable(final ITokenizer tokenizer, final List/*<String>*/ list) {
		return new Runnable() {
			public void run() {
				TokenizerTestCase.this.process(tokenizer, list);
			}
		};
	}

	private Thread createThread(int id, ITokenizer tokenizer, List/*<String>*/ list) {
		final String name = "Tokenizer-" + id;  //$NON-NLS-1$
		Runnable runnable = createRunnable(tokenizer, list);
		Thread thread = new Thread(runnable, name);
		return thread;
	}

	private ITokenizer createTokenizer(String value) {
		return AbstractSatTestCase.FACTORY.createTokenizer(value);
	}

	private ITokenizer createTokenizer(String value, char delimiter) {
		return AbstractSatTestCase.FACTORY.createTokenizer(value, delimiter);
	}

	private ITokenizer createTokenizer(String value, int offset) {
		ITokenizer tokenizer = AbstractSatTestCase.FACTORY.createTokenizer(value, offset);
		return tokenizer;
	}

	private void process(ITokenizer tokenizer, List/*<String>*/ list) {
		try {
			while (true) {
				Object token = tokenizer.nextToken();
				if (token == null)
					break;
				list.add(token);
				Thread.sleep(25);
			}
		} catch (InterruptedException exception) {
			//...
		}
	}

	public void test_constructorsWithIllegalArguments() {
		try {
			createTokenizer(null);
			Assert.fail("The parameter must not be null"); //$NON-NLS-1$
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}

		try {
			int offset = -1;
			createTokenizer("one,two", offset);  //$NON-NLS-1$
			Assert.fail("The index parameter must be a positive interger"); //$NON-NLS-1$
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}
	}

	public void test_constructorWithOffset() {
		String value = TokenizerTestCase.ONE + TokenizerTestCase.COMMA + TokenizerTestCase.TWO;

		ITokenizer tokenizer;
		Object expected;
		Object actual;

		tokenizer = createTokenizer(value, 0);
		actual = tokenizer.nextToken();
		Assert.assertEquals(TokenizerTestCase.ONE, actual);

		tokenizer = createTokenizer(value, 1);
		expected = "ne"; //$NON-NLS-1$
		actual = tokenizer.nextToken();
		Assert.assertEquals(expected, actual);

		tokenizer = createTokenizer(value, 3);
		expected = new String();
		actual = tokenizer.nextToken();
		Assert.assertEquals(expected, actual);

		tokenizer = createTokenizer(value, 4);
		actual = tokenizer.nextToken();
		Assert.assertEquals(TokenizerTestCase.TWO, actual);

		tokenizer = createTokenizer(value, 6);
		expected = "o"; //$NON-NLS-1$
		actual = tokenizer.nextToken();
		Assert.assertEquals(expected, actual);

		tokenizer = createTokenizer(value, 7);
		actual = tokenizer.nextToken();
		Assert.assertNull(actual);
	}

	public void test_hasMoreTokens() {
		ITokenizer tokenizer = createTokenizer(TokenizerTestCase.ONE_TWO_THREE);
		boolean expected = true;
		boolean actual;

		actual = tokenizer.hasMoreTokens();
		tokenizer.nextToken();
		Assert.assertEquals(expected, actual);

		actual = tokenizer.hasMoreTokens();
		tokenizer.nextToken();
		Assert.assertEquals(expected, actual);

		actual = tokenizer.hasMoreTokens();
		tokenizer.nextToken();
		Assert.assertEquals(expected, actual);

		expected = false;
		actual = tokenizer.hasMoreTokens();
		Assert.assertEquals(expected, actual);
	}

	public void test_nextToken() {
		_test_nextToken(TokenizerTestCase.ONE_TWO_THREE, TokenizerTestCase.COMMA);
		String value = TokenizerTestCase.ONE + TokenizerTestCase.SPACE + TokenizerTestCase.TWO + TokenizerTestCase.SPACE + TokenizerTestCase.THREE;
		_test_nextToken(value, TokenizerTestCase.SPACE);
	}

	public void test_nextTokenWithDuplicateDelimiter() {
		String value = TokenizerTestCase.ONE + TokenizerTestCase.COMMA + TokenizerTestCase.COMMA + TokenizerTestCase.THREE;
		ITokenizer tokenizer = createTokenizer(value);

		Object expected;
		Object actual;

		expected = TokenizerTestCase.ONE;
		actual = tokenizer.nextToken();
		Assert.assertEquals(expected, actual);

		expected = new String();
		actual = tokenizer.nextToken();
		Assert.assertEquals(expected, actual);

		expected = TokenizerTestCase.THREE;
		actual = tokenizer.nextToken();
		Assert.assertEquals(expected, actual);
	}

	public void test_nextTokenWithEmptyString() {
		String value = new String();
		ITokenizer tokenizer = createTokenizer(value);

		Object expected;
		Object actual;

		expected = null;
		actual = tokenizer.nextToken();
		Assert.assertEquals(expected, actual);
	}

	public void test_nextTokenWithLeadingDelimiter() {
		String value = TokenizerTestCase.COMMA + TokenizerTestCase.ONE;
		ITokenizer tokenizer = createTokenizer(value);

		Object expected;
		Object actual;

		expected = new String();
		actual = tokenizer.nextToken();
		Assert.assertEquals(expected, actual);

		expected = TokenizerTestCase.ONE;
		actual = tokenizer.nextToken();
		Assert.assertEquals(expected, actual);

		expected = null;
		actual = tokenizer.nextToken();
		Assert.assertEquals(expected, actual);
	}

	public void test_nextTokenWithTrailingDelimiter() {
		String value = TokenizerTestCase.ONE;
		ITokenizer tokenizer = createTokenizer(value);

		Object expected;
		Object actual;

		expected = TokenizerTestCase.ONE;
		actual = tokenizer.nextToken();
		Assert.assertEquals(expected, actual);

		expected = null;
		actual = tokenizer.nextToken();
		Assert.assertEquals(expected, actual);
	}

	public void test_synchronization() {
		ITokenizer tokenizer = createTokenizer("1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25"); //$NON-NLS-1$
		tokenizer = tokenizer.toSynchronizedTokenizer();

		List/*<String>*/ list1 = new ArrayList/*<String>*/(10);
		List/*<String>*/ list2 = new ArrayList/*<String>*/(10);
		List/*<String>*/ list3 = new ArrayList/*<String>*/(10);

		Thread thread1 = createThread(1, tokenizer, list1);
		Thread thread2 = createThread(2, tokenizer, list2);
		Thread thread3 = createThread(3, tokenizer, list3);

		thread1.start();
		thread2.start();
		thread3.start();

		try {
			thread1.join();
			thread2.join();
			thread3.join();
		} catch (InterruptedException exception) {
			Assert.fail();
		}

		int expectedSize = 25;
		List/*<String>*/ tokens = new ArrayList(expectedSize);
		tokens.addAll(list1);
		tokens.addAll(list2);
		tokens.addAll(list3);
		int actualSize = tokens.size();
		Assert.assertEquals(expectedSize, actualSize);
	}

	public void test_toSynchronizedTokenizer() {
		ITokenizer tokenizer = createTokenizer(TokenizerTestCase.ONE_TWO_THREE);

		// Check that a tokenizer and a synchronized tokenizer are distinct objects.
		ITokenizer synchronizedTokenizer = tokenizer.toSynchronizedTokenizer();
		Assert.assertNotSame(tokenizer, synchronizedTokenizer);

		// Check that asking a synchronized tokenizer for a synchronized
		// tokenizer returns the same instance.
		ITokenizer alias = synchronizedTokenizer.toSynchronizedTokenizer();
		Assert.assertSame(synchronizedTokenizer, alias);

		ITokenizer synchronizedTokenizer2 = tokenizer.toSynchronizedTokenizer();
		Assert.assertNotSame(synchronizedTokenizer, synchronizedTokenizer2);

		// Check that name of the synchronized tokenizer's class is correct.
		String expectedName = "SynchronizedTokenizer"; //$NON-NLS-1$
		Class clazz = synchronizedTokenizer.getClass();
		String actualName = clazz.getName();
		boolean state = actualName.endsWith(expectedName);
		Assert.assertTrue(state);
	}
}
