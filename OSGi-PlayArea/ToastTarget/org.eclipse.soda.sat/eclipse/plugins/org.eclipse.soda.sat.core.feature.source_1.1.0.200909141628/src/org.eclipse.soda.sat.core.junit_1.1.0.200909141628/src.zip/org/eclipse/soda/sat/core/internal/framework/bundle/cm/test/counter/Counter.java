/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.framework.bundle.cm.test.counter;

/**
 * Counter.java
 */
public class Counter extends Object {
	private int value;  // The next value.

	/**
	 * Constructor.
	 */
	public Counter() {
		super();
		setValue(1);
	}

	public int getNextNumber() {
		int value;

		// Hold the mutex before querying  the current value and incrementing it
		// by one.
		synchronized (this) {
			value = getValue();
			int next = value + 1;
			setValue(next);
		}

		return value;
	}

	private int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return super.toString() + ", value = " + getValue(); //$NON-NLS-1$
	}
}