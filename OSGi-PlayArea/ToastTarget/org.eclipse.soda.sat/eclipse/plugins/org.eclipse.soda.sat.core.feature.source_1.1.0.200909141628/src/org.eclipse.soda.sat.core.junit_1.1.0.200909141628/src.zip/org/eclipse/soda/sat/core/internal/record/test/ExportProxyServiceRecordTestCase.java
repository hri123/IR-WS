/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.internal.record.test;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Dictionary;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.framework.ProxyServiceHandlerAdapter;
import org.eclipse.soda.sat.core.framework.interfaces.IProxyServiceHandler;
import org.eclipse.soda.sat.core.junit.internal.AbstractSatTestCase;
import org.eclipse.soda.sat.core.record.interfaces.IExportProxyServiceRecord;
import org.eclipse.soda.sat.core.record.interfaces.IExportServiceRecord;
import org.eclipse.soda.sat.core.util.MiscUtility;
import org.osgi.framework.BundleContext;

public class ExportProxyServiceRecordTestCase extends AbstractExportServiceRecordTestCase {
	public static Test suite() {
		return new TestSuite(ExportProxyServiceRecordTestCase.class);
	}

	public ExportProxyServiceRecordTestCase(String name) {
		super(name);
	}

	protected IExportServiceRecord createExportServiceRecord(BundleContext context, Class[] types, Dictionary properties) {
		IProxyServiceHandler handler = new ProxyServiceHandlerAdapter(){
			public Object createService() {
				return ExportProxyServiceRecordTestCase.this.getService();
			}
		};

		IExportServiceRecord record = AbstractSatTestCase.FACTORY.createExportProxyServiceRecord(context, types, handler, properties);
		return record;
	}

	public void test_getService() {
		BundleContext context = getBundleContext();
		Class[] types = { TestService1.class };
		IExportProxyServiceRecord record = (IExportProxyServiceRecord) createExportServiceRecord(context, types, null);

		Object expected = getService();
		Object actual;

		actual = record.getRealService();
		Assert.assertSame(expected, actual);

		record.register();

		actual = record.getRealService();
		Assert.assertSame(expected, actual);

		record.unregister();

		actual = record.getRealService();
		Assert.assertSame(expected, actual);
	}

	public void test_isProxy() {
		BundleContext context = getBundleContext();
		Class[] types = { TestService1.class };
		IExportServiceRecord record = createExportServiceRecord(context, types, null);
		boolean isProxy = record.isProxy();
		Assert.assertTrue(isProxy);
	}

	public void test_ProxyEquality() {
		BundleContext context = getBundleContext();
		Class[] types = { TestService1.class };
		IExportProxyServiceRecord record = (IExportProxyServiceRecord) createExportServiceRecord(context, types, null);

		Object service1 = record.getService();
		Object service2 = service1;
		boolean equal;

		// Is service1 equal to itself?
		equal = service1.equals(service1);
		Assert.assertTrue(equal);

		// Is the service1 equal to service2?
		equal = service1.equals(service2);
		Assert.assertTrue(equal);

		// Is service1 equal to a new Object?
		equal = service1.equals(new Object());
		Assert.assertFalse(equal);

		// Is service1 equal to null?
		equal = service1.equals(null);
		Assert.assertFalse(equal);

		// Is service1 equal to its real service?
		Object realService = record.getRealService();
		equal = service1.equals(realService);
		Assert.assertTrue(equal);
	}

	public void test_ProxyHashcode() {
		BundleContext context = getBundleContext();
		Class[] types = { TestService1.class };
		IExportServiceRecord record = createExportServiceRecord(context, types, null);

		int hashCode1;
		int hashCode2;

		Object service1 = record.getService();
		hashCode1 = service1.hashCode();
		hashCode2 = service1.hashCode();
		Assert.assertEquals(hashCode1, hashCode2);

		Object service2 = service1;
		hashCode2 = service2.hashCode();
		Assert.assertEquals(hashCode1, hashCode2);
	}

	public void test_ProxyUnwrapping() {
		BundleContext context = getBundleContext();
		Class[] types = { TestService1.class };
		IExportProxyServiceRecord record = (IExportProxyServiceRecord) createExportServiceRecord(context, types, null);
		Object realService = record.getRealService();

		Object service = record.getService();
		MiscUtility utility = MiscUtility.getInstance();
		Object unwrappedService = utility.unwrapExportedServiceProxy(service);

		Assert.assertSame(realService, unwrappedService);

		try {
			utility.unwrapExportedServiceProxy(null);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}

		try {
			utility.unwrapExportedServiceProxy(new Object());
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}

		final TestService1 testService1 = (TestService1) getService();

		InvocationHandler handler = new InvocationHandler() {
			public Object invoke(Object proxy, Method method, Object[] parameters) throws Throwable {
				return method.invoke(testService1, parameters);
			}
		};

		Class clazz = testService1.getClass();
		ClassLoader classLoader = clazz.getClassLoader();

		Class[] interfaces = new Class[] {
			TestService1.class
		};

		Object proxy = Proxy.newProxyInstance(classLoader, interfaces, handler);

		try {
			utility.unwrapExportedServiceProxy(proxy);
			Assert.fail();
		} catch (IllegalArgumentException exception) {
			Assert.assertTrue(true);
		}
	}
}
