/*******************************************************************************
 * Copyright (c) 2001, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.junit.internal;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.junit.internal.bundle.Activator;
import org.osgi.framework.Bundle;
import org.osgi.framework.Constants;

public class BundleConfigurationTestCase extends TestCase {
	public static Test suite() {
		return new TestSuite(BundleConfigurationTestCase.class);
	}

	public BundleConfigurationTestCase(String name) {
		super(name);
	}

	public void test() {
		String frameworkVendor = Activator.BUNDLE_CONTEXT.getProperty(Constants.FRAMEWORK_VENDOR);
		boolean isEclipse = "Eclipse".equals(frameworkVendor);  //$NON-NLS-1$
		if (isEclipse == false) return;  // Early return.

		Bundle[] bundles = Activator.BUNDLE_CONTEXT.getBundles();
		List actualSymbolicNames = new ArrayList(bundles.length);

		for (int i = 0; i < bundles.length; i++) {
			Bundle bundle = bundles [ i ];
			String symbolicName = bundle.getSymbolicName();
			actualSymbolicNames.add(symbolicName);
		}

		String[] expectedSymbolicNames = new String[] {
			"org.eclipse.osgi",  //$NON-NLS-1$
			"org.eclipse.osgi.services",  //$NON-NLS-1$
			"org.eclipse.equinox.cm",  //$NON-NLS-1$
			"org.junit",  //$NON-NLS-1$
			"javax.servlet",  //$NON-NLS-1$
			"org.eclipse.soda.sat.core",  //$NON-NLS-1$
			"org.eclipse.soda.sat.junit",  //$NON-NLS-1$
			"org.eclipse.soda.sat.core.junit"  //$NON-NLS-1$
		};

		for (int i = 0; i < expectedSymbolicNames.length; i++) {
			String expectedSymbolicName = expectedSymbolicNames [ i ];
			boolean exists = actualSymbolicNames.contains(expectedSymbolicName);
			Assert.assertTrue(expectedSymbolicName, exists);
		}
	}
}
