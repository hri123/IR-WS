/*******************************************************************************
 * Copyright (c) 2001, 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.soda.sat.core.junit.internal;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.soda.sat.core.internal.util.test.CharBufferTestCase;
import org.eclipse.soda.sat.core.internal.util.test.DependencyTrackerTestCase;
import org.eclipse.soda.sat.core.internal.util.test.FileLogTestCase;
import org.eclipse.soda.sat.core.internal.util.test.LineReaderTestCase;
import org.eclipse.soda.sat.core.internal.util.test.LineWriterTestCase;
import org.eclipse.soda.sat.core.internal.util.test.OutputStreamLogTestCase;
import org.eclipse.soda.sat.core.internal.util.test.QueueTestCase;
import org.eclipse.soda.sat.core.internal.util.test.TokenizerTestCase;
import org.eclipse.soda.sat.core.util.LogUtility;
import org.eclipse.soda.sat.core.util.test.CollectionUtilityTestCase;
import org.eclipse.soda.sat.core.util.test.LogUtilityTestCase;
import org.osgi.service.log.LogService;

/**
 * AllPojoTest.java
 */
public class AllPojoTest extends Object {
	/*
	 * Initialize the logging level use for the SAT tests.
	 */
	private static void initializeLoggingLevel() {
		boolean tracing = LogUtility.isTracing();
		int loggingLevel = tracing == true ? LogService.LOG_DEBUG : LogService.LOG_ERROR;
		LogUtility.setLoggingLevel(loggingLevel);
	}

	/*
	 * Answers a JUnit TestSuite containing all the SAT tests.
	 */
	public static Test suite() {
		AllPojoTest.initializeLoggingLevel();

		TestSuite suite = new TestSuite("All SAT Core Pojo JUnit Tests"); //$NON-NLS-1$

		// org.eclipse.soda.sat.core.internal.util.test
		suite.addTest(CharBufferTestCase.suite());
		suite.addTest(DependencyTrackerTestCase.suite());
		suite.addTest(FileLogTestCase.suite());
		suite.addTest(LineReaderTestCase.suite());
		suite.addTest(LineWriterTestCase.suite());
		suite.addTest(OutputStreamLogTestCase.suite());
		suite.addTest(QueueTestCase.suite());
		suite.addTest(TokenizerTestCase.suite());

		// org.eclipse.soda.sat.core.util.test
		suite.addTest(CollectionUtilityTestCase.suite());
		suite.addTest(LogUtilityTestCase.suite());

		return suite;
	}
}